'use client';

import { AlertTriangle, Wallet } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { DataTable, PageHeader } from '@/components/kit';
import { Card, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num } from '@/lib/format';
import { useBranchQuery } from '@/lib/hooks';
import type { Payables } from '@/lib/types';

export default function PayablesPage() {
  const router = useRouter();
  const { profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const { data, isLoading } = useBranchQuery<Payables>('/suppliers/payables');
  return (
    <div className="space-y-4">
      <PageHeader title="Supplier payables" subtitle="What the pharmacy owes, across all branches, from the supplier ledgers." />
      <div className="grid gap-3 sm:grid-cols-2">
        <StatTile label="Total payable" value={money(num(data?.totalPayable), cur)} icon={<Wallet size={18} />} tone="warning" />
        <StatTile label="Overdue" value={money(num(data?.totalOverdue), cur)} icon={<AlertTriangle size={18} />} tone={num(data?.totalOverdue) > 0 ? 'danger' : 'neutral'} />
      </div>
      <Card>
        <DataTable
          rows={data?.suppliers}
          loading={isLoading}
          rowKey={(s) => s.id}
          onRowClick={(s) => router.push(`/purchasing/suppliers/${s.id}`)}
          empty={<p className="px-4 py-10 text-center text-sm text-fg-muted">Nothing owed. Every supplier is settled.</p>}
          columns={[
            { key: 'n', header: 'Supplier', cell: (s) => <div><p className="font-medium">{s.name}</p><p className="text-xs text-fg-muted">{s.phone ?? ''}</p></div> },
            { key: 'i', header: 'Open invoices', align: 'right', cell: (s) => s.openInvoices },
            { key: 'due', header: 'Oldest due', cell: (s) => dateOnly(s.oldestDue) },
            { key: 'o', header: 'Overdue', align: 'right', cell: (s) => <span className={num(s.overdue) > 0 ? 'font-medium text-danger' : 'text-fg-muted'}>{money(num(s.overdue), cur)}</span> },
            { key: 'b', header: 'Balance', align: 'right', cell: (s) => <span className="font-semibold">{money(num(s.balance), cur)}</span> },
          ]}
        />
      </Card>
    </div>
  );
}
