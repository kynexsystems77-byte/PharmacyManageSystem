'use client';

import { useEffect, useState } from 'react';
import { Checkbox, Forbidden, PageHeader, Textarea, useToast } from '@/components/kit';
import { Alert, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { BranchRow, TenantInfo, TenantSettings } from '@/lib/types';

export default function SettingsPage() {
  const { can } = useAuth();
  const toast = useToast();
  const { data } = useBranchQuery<TenantInfo>('/settings');
  const [s, setS] = useState<TenantSettings | null>(null);
  const [tenant, setTenant] = useState({ name: '', currencyCode: '', timezone: '' });
  useEffect(() => { if (data) { setS(data.settings); setTenant({ name: data.name, currencyCode: data.currencyCode, timezone: data.timezone }); } }, [data]);
  const save = useApiMutation<object>('PUT', '/settings', { onSuccess: () => toast.success('Settings saved') });
  const saveTenant = useApiMutation<object>('PATCH', '/tenant', { onSuccess: () => { toast.success('Pharmacy details saved'); } });
  if (!can('tenant:settings:manage')) return <Forbidden what="settings" />;
  if (!s) return <Skeleton className="h-64" />;
  const set = <K extends keyof TenantSettings>(k: K, v: TenantSettings[K]) => setS({ ...s, [k]: v });
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="Pharmacy settings" subtitle="Apply to every branch." />
      <Card>
        <CardHeader title="Company" />
        <div className="grid gap-3 p-4 sm:grid-cols-3">
          {saveTenant.error && <div className="sm:col-span-3"><Alert>{errorMessage(saveTenant.error)}</Alert></div>}
          <Field label="Name"><Input value={tenant.name} onChange={(e) => setTenant({ ...tenant, name: e.target.value })} /></Field>
          <Field label="Currency (ISO code)"><Input value={tenant.currencyCode} maxLength={3} onChange={(e) => setTenant({ ...tenant, currencyCode: e.target.value.toUpperCase() })} placeholder="LKR" /></Field>
          <Field label="Time zone"><Input value={tenant.timezone} onChange={(e) => setTenant({ ...tenant, timezone: e.target.value })} placeholder="Asia/Colombo" /></Field>
          <div className="sm:col-span-3 flex justify-end"><Button variant="outline" loading={saveTenant.isPending} onClick={() => saveTenant.mutate(tenant)}>Save company details</Button></div>
        </div>
      </Card>
      {can('branch:manage') && <BranchAddresses />}
      <Card>
        <CardHeader title="Selling rules" />
        <div className="grid gap-4 p-4 sm:grid-cols-2">
          <Field label="Block batches with fewer days to expiry than"><Input type="number" min="0" value={s.minDaysToExpiryForSale} onChange={(e) => set('minDaysToExpiryForSale', Number(e.target.value))} /></Field>
          <Field label="Warn at the POS when a batch expires within (days)"><Input type="number" min="1" value={s.expiryWarningDays} onChange={(e) => set('expiryWarningDays', Number(e.target.value))} /></Field>
          <Field label="Refunds at or above this amount need a manager"><Input type="number" min="0" step="0.01" value={s.refundApprovalThreshold} onChange={(e) => set('refundApprovalThreshold', Number(e.target.value))} /></Field>
          <Field label="Round bill totals to the nearest (0 = off)"><Input type="number" min="0" step="0.01" value={s.cashRoundingStep} onChange={(e) => set('cashRoundingStep', Number(e.target.value))} /></Field>
          <Checkbox label="Require an open register shift to sell" checked={s.requireOpenShiftForSale} onChange={(v) => set('requireOpenShiftForSale', v)} />
          <Checkbox label="Allow prescription medicines without a recorded prescription" hint="Not recommended. A pharmacist can always confirm one at the POS." checked={s.allowRxWithoutRecord} onChange={(v) => set('allowRxWithoutRecord', v)} />
        </div>
      </Card>
      <Card>
        <CardHeader title="Alerts" />
        <div className="grid gap-3 p-4 sm:grid-cols-2">
          <Checkbox label="Low-stock alerts" checked={s.lowStockAlerts} onChange={(v) => set('lowStockAlerts', v)} />
          <Checkbox label="Expiry alerts" checked={s.expiryAlerts} onChange={(v) => set('expiryAlerts', v)} />
        </div>
      </Card>
      {save.error && <Alert>{errorMessage(save.error)}</Alert>}
      <div className="flex justify-end"><Button loading={save.isPending} onClick={() => save.mutate(s)}>Save settings</Button></div>
    </div>
  );
}

interface AddressDraft { address: string; phone: string; receiptFooter: string }

/** Address, phone and receipt footer of every branch: what customers see on receipts and invoices. */
function BranchAddresses() {
  const toast = useToast();
  const { data } = useBranchQuery<BranchRow[]>('/branches');
  const [drafts, setDrafts] = useState<Record<string, AddressDraft>>({});
  useEffect(() => {
    if (data) setDrafts(Object.fromEntries(data.map((b) => [b.id, { address: b.address ?? '', phone: b.phone ?? '', receiptFooter: b.receiptFooter ?? '' }])));
  }, [data]);
  const save = useApiMutation<{ id: string; address: string; phone: string; receiptFooter: string }>('PATCH', (v) => `/branches/${v.id}`, { onSuccess: () => toast.success('Branch details saved') });
  if (!data) return <Skeleton className="h-40" />;
  return (
    <Card>
      <CardHeader title="Branch addresses" action={<span className="text-xs text-fg-muted">Printed on receipts and invoices</span>} />
      <div className="divide-y divide-line">
        {save.error && <div className="p-4"><Alert>{errorMessage(save.error)}</Alert></div>}
        {data.map((b) => {
          const d = drafts[b.id];
          if (!d) return null;
          const set = (k: keyof AddressDraft, v: string) => setDrafts({ ...drafts, [b.id]: { ...d, [k]: v } });
          const changed = d.address !== (b.address ?? '') || d.phone !== (b.phone ?? '') || d.receiptFooter !== (b.receiptFooter ?? '');
          return (
            <div key={b.id} className="grid gap-3 p-4 sm:grid-cols-3">
              <p className="text-sm font-semibold sm:col-span-3">{b.name} <span className="font-normal text-fg-muted">· {b.code}</span></p>
              <div className="sm:col-span-2"><Field label="Address"><Input value={d.address} onChange={(e) => set('address', e.target.value)} maxLength={300} placeholder="No., street, town" /></Field></div>
              <Field label="Phone"><Input value={d.phone} onChange={(e) => set('phone', e.target.value)} maxLength={40} placeholder="037 222 1450" /></Field>
              <div className="sm:col-span-3"><Field label="Receipt footer"><Textarea value={d.receiptFooter} onChange={(e) => set('receiptFooter', e.target.value)} maxLength={500} className="min-h-[56px]" placeholder="Thank you. Get well soon!" /></Field></div>
              <div className="flex justify-end sm:col-span-3">
                <Button variant="outline" disabled={!changed} loading={save.isPending && save.variables?.id === b.id}
                  onClick={() => save.mutate({ id: b.id, address: d.address.trim(), phone: d.phone.trim(), receiptFooter: d.receiptFooter.trim() })}>
                  Save {b.name}
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
