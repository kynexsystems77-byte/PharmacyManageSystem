import { INestApplication } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { addStock, bootApp, createProduct, expectStatus, isoDay, login, uid, type Session } from './helpers';

const key = () => randomUUID().replace(/-/g, '');

describe('POS and sales (Phase 7)', () => {
  let app: INestApplication;
  let owner: Session;
  beforeAll(async () => {
    app = await bootApp();
    owner = await login(app, 'owner@demo.local');
  });
  afterAll(async () => {
    await app.close();
  });

  /** Gives the user an open shift (creates a dedicated register when needed). */
  async function ensureShift(s: Session, opening = 100) {
    const mine = await s.get('/registers/my-shift');
    if (mine.body.current) return mine.body.current.shift.id as string;
    const reg = await owner.post('/registers', { name: `Till ${uid()}` });
    expectStatus(reg, 201);
    const open = await s.post(`/registers/${reg.body.id}/open`, { openingBalance: opening });
    expectStatus(open, 201);
    return open.body.id as string;
  }

  async function closeShiftIfAny(s: Session) {
    const mine = await s.get('/registers/my-shift');
    const cur = mine.body.current;
    if (cur) expectStatus(await s.post(`/shifts/${cur.shift.id}/close`, { countedClosingBalance: Number(cur.expectedCash) }), 201);
  }

  async function stockedProduct(overrides: Record<string, unknown> = {}, batches: { qty: number; days: number }[] = [{ qty: 50, days: 365 }]) {
    const p = await createProduct(owner, { sellingPrice: 5, purchasePrice: 2, ...overrides });
    const ids: string[] = [];
    for (const b of batches) ids.push(await addStock(owner, p.id, { quantity: b.qty, expiryDate: isoDay(b.days), unitCost: 2 }));
    return { ...p, batchIds: ids };
  }

  const total = async (productId: string) => Number((await owner.get(`/products/${productId}/stock`)).body.total);

  it('needs an open register shift to sell', async () => {
    const cashier = await login(app, 'cashier@demo.local');
    await closeShiftIfAny(cashier);
    const p = await stockedProduct();
    const res = await cashier.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CASH', amount: 5 }] });
    expect(res.status).toBe(422);
    expect(res.body.error.message).toMatch(/shift/);
  });

  it('quotes with FEFO and completes a sale: batches, change, ledger, idempotent replay', async () => {
    await ensureShift(owner);
    const p = await stockedProduct({}, [{ qty: 100, days: 400 }, { qty: 10, days: 30 }]);
    const items = [{ productId: p.id, quantity: 15, discountPercent: 10 }];

    const q = await owner.post('/sales/quote', { items });
    expectStatus(q, 200);
    expect(q.body.lines[0].allocations.map((a: { batchId: string; quantity: string }) => [a.batchId, Number(a.quantity)])).toEqual([[p.batchIds[1], 10], [p.batchIds[0], 5]]);
    expect(q.body.grandTotal).toBe('67.50');

    const k = key();
    const sale = await owner.post('/sales', { idempotencyKey: k, items, payments: [{ method: 'CASH', amount: 100 }] });
    expectStatus(sale, 201);
    expect(sale.body.invoiceNo).toMatch(/^INV-\d{4}-\d{6}$/);
    expect(sale.body.grandTotal).toBe('67.5');
    expect(sale.body.changeGiven).toBe('32.5');
    expect(sale.body.saleItems[0].saleItemAllocations).toHaveLength(2);
    expect(Number(sale.body.saleItems[0].costTotal)).toBe(30);
    expect(await total(p.id)).toBe(95);

    const replay = await owner.post('/sales', { idempotencyKey: k, items, payments: [{ method: 'CASH', amount: 100 }] });
    expectStatus(replay, 201);
    expect(replay.body.id).toBe(sale.body.id);
    expect(await total(p.id)).toBe(95); // not sold twice

    const reused = await owner.post('/sales', { idempotencyKey: k, items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CASH', amount: 5 }] });
    expect(reused.status).toBe(422);

    const ledger = await owner.get(`/inventory/movements?productId=${p.id}&type=SALE`);
    expect(ledger.body.data).toHaveLength(2);
  });

  it('validates split payments', async () => {
    await ensureShift(owner);
    const p = await stockedProduct();
    const items = [{ productId: p.id, quantity: 4 }]; // 20.00
    expect((await owner.post('/sales', { idempotencyKey: key(), items, payments: [{ method: 'CARD', amount: 25 }] })).status).toBe(422);
    expect((await owner.post('/sales', { idempotencyKey: key(), items, payments: [{ method: 'CARD', amount: 10 }, { method: 'CASH', amount: 5 }] })).status).toBe(422);
    const ok = await owner.post('/sales', { idempotencyKey: key(), items, payments: [{ method: 'CARD', amount: 12, reference: 'AUTH1' }, { method: 'CASH', amount: 10 }] });
    expectStatus(ok, 201);
    expect(ok.body.changeGiven).toBe('2');
    expect(ok.body.payments.map((x: { method: string; amount: string }) => [x.method, x.amount]).sort()).toEqual([['CARD', '12'], ['CASH', '8']]);
  });

  it('enforces the prescription rule (pharmacist override, cashier blocked)', async () => {
    const p = await stockedProduct({ requiresPrescription: true });
    const cashier = await login(app, 'cashier@demo.local');
    await ensureShift(cashier);
    const body = { items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CASH', amount: 5 }] };
    const blocked = await cashier.post('/sales', { ...body, idempotencyKey: key(), rxOverride: true });
    expect(blocked.status).toBe(422);
    expect(blocked.body.error.message).toMatch(/prescription/i);
    const pharmacist = await login(app, 'pharmacist@demo.local');
    await ensureShift(pharmacist);
    const ok = await pharmacist.post('/sales', { ...body, idempotencyKey: key(), rxOverride: true });
    expectStatus(ok, 201);
    expect(ok.body.notes).toMatch(/pharmacist/);
  });

  it('enforces the role discount limit', async () => {
    const p = await stockedProduct();
    const cashier = await login(app, 'cashier@demo.local');
    await ensureShift(cashier);
    const over = await cashier.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 2, discountPercent: 10 }], payments: [{ method: 'CASH', amount: 10 }] });
    expect(over.status).toBe(403);
    const within = await cashier.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 2 }], billDiscount: { type: 'PERCENT', value: 5 }, payments: [{ method: 'CASH', amount: 10 }] });
    expectStatus(within, 201);
    expect(within.body.grandTotal).toBe('9.5');
  });

  it('sells pack units and applies exclusive tax', async () => {
    await ensureShift(owner);
    const tax = await owner.post('/tax-rates', { name: `VAT ${uid()}`, ratePercent: 10 });
    expectStatus(tax, 201);
    const p = await stockedProduct({ taxRateId: tax.body.id, units: [{ name: 'Strip', factorToBase: 10, sellingPrice: 45 }] });
    const strip = p.productUnits[0].id;
    const sale = await owner.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, productUnitId: strip, quantity: 2 }], payments: [{ method: 'CASH', amount: 100 }] });
    expectStatus(sale, 201);
    const line = sale.body.saleItems[0];
    expect(Number(line.baseQuantity)).toBe(20);
    expect(line.lineTotal).toBe('99'); // 90 + 10% tax
    expect(sale.body.taxTotal).toBe('9');
    expect(await total(p.id)).toBe(30);
  });

  it('sells on credit within the limit and takes the payment later', async () => {
    await ensureShift(owner);
    const cust = await owner.post('/customers', { fullName: `Credit Customer ${uid()}`, phone: `07${Date.now().toString().slice(-8)}`, creditLimit: 100 });
    expectStatus(cust, 201);
    expect(cust.body.code).toMatch(/^C-\d{6}$/);
    const p = await stockedProduct();
    const first = await owner.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, items: [{ productId: p.id, quantity: 12 }], payments: [{ method: 'CUSTOMER_CREDIT', amount: 60 }] });
    expectStatus(first, 201);
    expect(first.body.balanceDue).toBe('60');
    const tooMuch = await owner.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, items: [{ productId: p.id, quantity: 10 }], payments: [{ method: 'CUSTOMER_CREDIT', amount: 50 }] });
    expect(tooMuch.status).toBe(422);
    expect(tooMuch.body.error.message).toMatch(/credit limit/);
    const noCustomer = await owner.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CUSTOMER_CREDIT', amount: 5 }] });
    expect(noCustomer.status).toBe(422);

    const pay = await owner.post(`/customers/${cust.body.id}/payments`, { amount: 60, method: 'CASH' });
    expectStatus(pay, 201);
    expect(pay.body.balance).toBe('0.00');
    const detail = await owner.get(`/customers/${cust.body.id}`);
    expect(detail.body.stats.visits).toBe(1);
  });

  it('holds a bill and completes it later', async () => {
    await ensureShift(owner);
    const p = await stockedProduct();
    const held = await owner.post('/sales/hold', { items: [{ productId: p.id, quantity: 3 }], notes: 'Customer went to ATM' });
    expectStatus(held, 201);
    expect(held.body.status).toBe('HELD');
    expect(held.body.invoiceNo).toBeNull();
    expect(await total(p.id)).toBe(50); // holding does not touch stock
    expect((await owner.get('/sales/held')).body.some((s: { id: string }) => s.id === held.body.id)).toBe(true);
    const done = await owner.post('/sales', { idempotencyKey: key(), heldSaleId: held.body.id, items: [{ productId: p.id, quantity: 3 }], payments: [{ method: 'CASH', amount: 15 }] });
    expectStatus(done, 201);
    expect((await owner.get('/sales/held')).body.some((s: { id: string }) => s.id === held.body.id)).toBe(false);
    expect(await total(p.id)).toBe(47);
  });

  it('voids a sale: stock back, cash refunded, recorded on the shift', async () => {
    const shiftId = await ensureShift(owner);
    const p = await stockedProduct();
    const before = Number((await owner.get(`/shifts/${shiftId}`)).body.expectedCash);
    const sale = await owner.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 4 }], payments: [{ method: 'CASH', amount: 20 }] });
    expectStatus(sale, 201);
    expect(Number((await owner.get(`/shifts/${shiftId}`)).body.expectedCash)).toBe(before + 20);
    const v = await owner.post(`/sales/${sale.body.id}/void`, { reason: 'Wrong product scanned' });
    expectStatus(v, 201);
    expect(v.body.status).toBe('VOIDED');
    expect(await total(p.id)).toBe(50);
    expect(Number((await owner.get(`/shifts/${shiftId}`)).body.expectedCash)).toBe(before);
    expect((await owner.post(`/sales/${sale.body.id}/void`, { reason: 'again' })).status).toBe(409);
  });

  it('processes partial returns per batch and marks the sale fully returned', async () => {
    await ensureShift(owner);
    const p = await stockedProduct({}, [{ qty: 5, days: 20 }, { qty: 20, days: 300 }]);
    const sale = await owner.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 10 }], payments: [{ method: 'CASH', amount: 50 }] });
    expectStatus(sale, 201);
    const lineId = sale.body.saleItems[0].id;
    const r1 = await owner.post(`/sales/${sale.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: lineId, quantity: 7 }], refundMethod: 'CASH', reason: 'Not needed' });
    expectStatus(r1, 201);
    expect(r1.body.total).toBe('35');
    expect(r1.body.salesReturnItems).toHaveLength(2); // 5 from the first batch, 2 from the second
    expect(await total(p.id)).toBe(22);
    expect((await owner.get(`/sales/${sale.body.id}`)).body.status).toBe('PARTIALLY_RETURNED');

    const tooMany = await owner.post(`/sales/${sale.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: lineId, quantity: 4 }], refundMethod: 'CASH', reason: 'x x' });
    expect(tooMany.status).toBe(422);
    const r2 = await owner.post(`/sales/${sale.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: lineId, quantity: 3, restock: false }], refundMethod: 'CARD', reason: 'Damaged box' });
    expectStatus(r2, 201);
    expect(await total(p.id)).toBe(22); // damaged: refunded, not restocked
    expect((await owner.get(`/sales/${sale.body.id}`)).body.status).toBe('RETURNED');
  });

  it('requires refund approval above the threshold', async () => {
    const pharmacist = await login(app, 'pharmacist@demo.local');
    await ensureShift(pharmacist);
    const p = await stockedProduct({ sellingPrice: 1000 });
    const sale = await pharmacist.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 6 }], payments: [{ method: 'CARD', amount: 6000 }] });
    expectStatus(sale, 201);
    const r = await pharmacist.post(`/sales/${sale.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: sale.body.saleItems[0].id, quantity: 6 }], refundMethod: 'CARD', reason: 'Returned unopened' });
    expect(r.status).toBe(403);
    expect(r.body.error.message).toMatch(/refund:approve/);
  });

  it('never oversells the last units when two tills sell at the same time', async () => {
    await ensureShift(owner);
    const p = await stockedProduct({}, [{ qty: 5, days: 200 }]);
    const sell = () => owner.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 4 }], payments: [{ method: 'CARD', amount: 20 }] });
    const results = await Promise.all([sell(), sell()]);
    expect(results.map((r) => r.status).sort()).toEqual([201, 422]);
    expect(await total(p.id)).toBe(1);
  });

  it('closes a shift with a cash count and variance', async () => {
    const cashier = await login(app, 'cashier@demo.local');
    await closeShiftIfAny(cashier);
    const shiftId = await ensureShift(cashier, 200);
    const p = await stockedProduct();
    expectStatus(await cashier.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 6 }], payments: [{ method: 'CASH', amount: 50 }] }), 201);
    expectStatus(await owner.post(`/shifts/${shiftId}/cash`, { type: 'WITHDRAWAL', amount: 100, note: 'Bank deposit' }), 201);
    const x = await cashier.get(`/shifts/${shiftId}`);
    expect(x.body.expectedCash).toBe('130.00'); // 200 + 30 - 100
    const z = await cashier.post(`/shifts/${shiftId}/close`, { countedClosingBalance: 128 });
    expectStatus(z, 201);
    expect(z.body.shift.status).toBe('CLOSED');
    expect(z.body.shift.variance).toBe('-2');
    expect((await cashier.post(`/shifts/${shiftId}/close`, { countedClosingBalance: 1 })).status).toBe(409);
  });
});
