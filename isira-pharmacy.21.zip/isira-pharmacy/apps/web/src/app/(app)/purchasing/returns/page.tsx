'use client';

import { Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox } from '@/components/kit';
import { Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { PurchaseReturn } from '@/lib/types';

export default function ReturnsPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [search, setSearch] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<PurchaseReturn>>(`/purchase-returns${qs({ page, pageSize: 25, search: s })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader
        title="Returns to suppliers"
        subtitle="Returned stock leaves inventory and reduces what you owe the supplier."
        actions={can('purchase:return') && <Link href="/purchasing/returns/new"><Button><Plus size={16} /> New return</Button></Link>}
      />
      <Card>
        <div className="border-b border-line p-3"><SearchBox value={search} onChange={setSearch} placeholder="Return number or supplier" /></div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(r) => r.id}
          onRowClick={(r) => router.push(`/purchasing/returns/${r.id}`)}
          columns={[
            { key: 'n', header: 'Number', cell: (r) => <span className="font-mono text-xs">{r.number}</span> },
            { key: 'd', header: 'Date', cell: (r) => dateOnly(r.returnDate) },
            { key: 's', header: 'Supplier', cell: (r) => <span className="font-medium">{r.supplier.name}</span> },
            { key: 'p', header: 'Purchase', cell: (r) => r.purchase?.number ?? '-' },
            { key: 'r', header: 'Reason', cell: (r) => <span className="text-fg-muted">{r.reason ?? '-'}</span> },
            { key: 't', header: 'Credit', align: 'right', cell: (r) => money(num(r.total), profile.tenant.currencyCode) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
