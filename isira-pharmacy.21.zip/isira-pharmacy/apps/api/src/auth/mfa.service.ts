import { Inject, Injectable } from '@nestjs/common';
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { ENV, type Env } from '../config/env';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const STEP_SECONDS = 30;
const DIGITS = 6;
/** Accept the previous and next 30-second window to tolerate clock drift. */
const WINDOW = 1;
const CHALLENGE_TTL_MS = 5 * 60_000;

export function base32Encode(buf: Buffer): string {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(text: string): Buffer {
  const clean = text.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    value = (value << 5) | B32.indexOf(ch);
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

/** RFC 6238 TOTP (HMAC-SHA1, 6 digits, 30 s) — the profile every authenticator app supports. */
export function totp(secret: Buffer, step: number): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const mac = createHmac('sha1', secret).update(counter).digest();
  const offset = mac[mac.length - 1] & 0x0f;
  const code = (mac.readUInt32BE(offset) & 0x7fffffff) % 10 ** DIGITS;
  return code.toString().padStart(DIGITS, '0');
}

export const currentStep = (now = Date.now()) => Math.floor(now / 1000 / STEP_SECONDS);

const sha256 = (v: string) => createHash('sha256').update(v).digest('hex');

export interface MfaChallenge {
  userId: string;
  tenantId: string;
}

@Injectable()
export class MfaService {
  private readonly encKey: Buffer;
  private readonly signKey: Buffer;

  constructor(@Inject(ENV) env: Env) {
    // Development/test fallback only; env validation requires a real key in production.
    const master = env.MFA_ENCRYPTION_KEY ?? 'kynex-development-only-mfa-key-change-me';
    this.encKey = createHash('sha256').update(`enc:${master}`).digest();
    this.signKey = createHash('sha256').update(`sig:${master}`).digest();
  }

  generateSecret(): string {
    return base32Encode(randomBytes(20));
  }

  otpauthUrl(secret: string, account: string, issuer: string): string {
    const label = encodeURIComponent(`${issuer}:${account}`);
    return `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=${DIGITS}&period=${STEP_SECONDS}`;
  }

  encrypt(plain: string): string {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', this.encKey, iv);
    const data = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
    return ['v1', iv.toString('base64url'), cipher.getAuthTag().toString('base64url'), data.toString('base64url')].join('.');
  }

  decrypt(stored: string): string {
    const [v, iv, tag, data] = stored.split('.');
    if (v !== 'v1' || !iv || !tag || !data) throw new Error('Unsupported MFA secret format');
    const decipher = createDecipheriv('aes-256-gcm', this.encKey, Buffer.from(iv, 'base64url'));
    decipher.setAuthTag(Buffer.from(tag, 'base64url'));
    return Buffer.concat([decipher.update(Buffer.from(data, 'base64url')), decipher.final()]).toString('utf8');
  }

  /**
   * Returns the matched time step, or null. Steps at or before `lastStep` are rejected so a code
   * cannot be used twice.
   */
  verifyTotp(encryptedSecret: string, code: string, lastStep: number | null): number | null {
    if (!/^\d{6}$/.test(code)) return null;
    const secret = base32Decode(this.decrypt(encryptedSecret));
    const now = currentStep();
    for (let d = -WINDOW; d <= WINDOW; d++) {
      const step = now + d;
      if (lastStep !== null && step <= lastStep) continue;
      const expected = Buffer.from(totp(secret, step));
      if (timingSafeEqual(expected, Buffer.from(code))) return step;
    }
    return null;
  }

  /** Ten single-use codes; only their hashes are stored. */
  generateRecoveryCodes(): { codes: string[]; hashes: string[] } {
    const codes = Array.from({ length: 10 }, () => {
      const raw = base32Encode(randomBytes(7)).slice(0, 10).toLowerCase();
      return `${raw.slice(0, 5)}-${raw.slice(5)}`;
    });
    return { codes, hashes: codes.map((c) => this.hashRecovery(c)) };
  }

  hashRecovery(code: string): string {
    return sha256(code.toLowerCase().replace(/[^a-z0-9]/g, ''));
  }

  /** Short-lived signed token proving the password step succeeded. */
  signChallenge(c: MfaChallenge): string {
    const payload = Buffer.from(JSON.stringify({ u: c.userId, t: c.tenantId, e: Date.now() + CHALLENGE_TTL_MS, n: randomBytes(8).toString('hex') })).toString('base64url');
    return `${payload}.${createHmac('sha256', this.signKey).update(payload).digest('base64url')}`;
  }

  verifyChallenge(token: string): MfaChallenge | null {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const expected = Buffer.from(createHmac('sha256', this.signKey).update(payload).digest('base64url'));
    const given = Buffer.from(sig);
    if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null;
    try {
      const p = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { u: string; t: string; e: number };
      if (typeof p.e !== 'number' || p.e < Date.now()) return null;
      return { userId: p.u, tenantId: p.t };
    } catch {
      return null;
    }
  }
}
