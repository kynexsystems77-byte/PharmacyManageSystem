/** Badge tones for document statuses (shared by list and detail pages). */
export type Tone = 'success' | 'warning' | 'danger' | 'neutral';

export const TRANSFER_TONE: Record<string, Tone> = { DISPATCHED: 'warning', RECEIVED: 'success', CANCELLED: 'danger', DRAFT: 'neutral' };

export const PURCHASE_TONE: Record<string, Tone> = { DRAFT: 'neutral', RECEIVED: 'success', CANCELLED: 'danger' };
export const PO_TONE: Record<string, Tone> = { DRAFT: 'neutral', ORDERED: 'warning', PARTIALLY_RECEIVED: 'warning', RECEIVED: 'success', CANCELLED: 'danger' };

/** Paid / part paid / unpaid label for a received invoice. */
export function paymentState(grandTotal: number, paidTotal: number): { label: string; tone: Tone } {
  if (grandTotal <= 0 || paidTotal >= grandTotal) return { label: 'Paid', tone: 'success' };
  if (paidTotal > 0) return { label: 'Part paid', tone: 'warning' };
  return { label: 'Unpaid', tone: 'danger' };
}

export const SALE_TONE: Record<string, Tone> = { COMPLETED: 'success', PARTIALLY_RETURNED: 'warning', RETURNED: 'neutral', VOIDED: 'danger', HELD: 'warning', DRAFT: 'neutral' };
export const RX_TONE: Record<string, Tone> = { ACTIVE: 'success', PARTIALLY_DISPENSED: 'warning', DISPENSED: 'neutral', EXPIRED: 'danger', CANCELLED: 'danger' };

/** Printable 80 mm receipt (branch passed explicitly: the print window has no app state). */
export function receiptUrl(saleId: string, branchId: string | null, autoPrint = false): string {
  const q = new URLSearchParams();
  if (branchId) q.set('branch', branchId);
  if (autoPrint) q.set('auto', '1');
  return `/print/receipt/${saleId}?${q.toString()}`;
}
