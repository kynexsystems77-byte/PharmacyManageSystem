import { z } from 'zod';
import { dateOnlySchema, optionalText, priceSchema, quantitySchema, queryBoolSchema, signedQuantitySchema } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 5: inventory (stock levels, batches, the stock ledger, adjustments, transfers, write-offs, FEFO). */

export const MOVEMENT_TYPES = [
  'OPENING_BALANCE', 'PURCHASE_RECEIPT', 'SALE', 'SALE_RETURN', 'PURCHASE_RETURN', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT',
  'TRANSFER_OUT', 'TRANSFER_IN', 'DAMAGE', 'EXPIRED_WRITE_OFF',
] as const;
export type MovementTypeKey = (typeof MOVEMENT_TYPES)[number];

export const ADJUSTMENT_REASONS = ['COUNT_CORRECTION', 'DAMAGED', 'EXPIRED', 'LOST', 'FOUND', 'OTHER'] as const;
export const BATCH_STATUSES = ['ACTIVE', 'QUARANTINED', 'RECALLED', 'EXPIRED'] as const;

export const listStockQuerySchema = paginationSchema.extend({
  categoryId: uuidSchema.optional(),
  locationId: uuidSchema.optional(),
  /** low = at/below reorder level, out = nothing sellable, expiring = has stock expiring within `days`. */
  filter: z.enum(['all', 'in_stock', 'low', 'out', 'expiring', 'expired']).default('all'),
  days: z.coerce.number().int().min(1).max(730).default(90),
});

export const listBatchesQuerySchema = paginationSchema.extend({
  productId: uuidSchema.optional(),
  locationId: uuidSchema.optional(),
  status: z.enum(BATCH_STATUSES).optional(),
  /** Only batches that have stock in this branch. */
  inStock: queryBoolSchema.default('true'),
  /** Only batches expiring within N days (includes already expired). */
  expiringWithinDays: z.coerce.number().int().min(0).max(3650).optional(),
  expired: queryBoolSchema.optional(),
  sort: z.enum(['expiry', 'received', 'product']).default('expiry'),
});

export const updateBatchSchema = z
  .object({
    status: z.enum(['ACTIVE', 'QUARANTINED', 'RECALLED']).optional(),
    sellingPrice: priceSchema.nullable().optional(),
    expiryDate: dateOnlySchema.nullable().optional(),
    manufactureDate: dateOnlySchema.nullable().optional(),
    notes: z.string().trim().max(500).nullable().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const listMovementsQuerySchema = paginationSchema.extend({
  productId: uuidSchema.optional(),
  batchId: uuidSchema.optional(),
  locationId: uuidSchema.optional(),
  type: z.enum(MOVEMENT_TYPES).optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});

/** Opening stock / stock found without a purchase: creates (or tops up) a batch. */
export const openingStockSchema = z.object({
  locationId: uuidSchema,
  productId: uuidSchema,
  batchNumber: z.string().trim().min(1).max(60),
  expiryDate: dateOnlySchema.nullable().optional(),
  manufactureDate: dateOnlySchema.nullable().optional(),
  unitCost: priceSchema,
  sellingPrice: priceSchema.nullable().optional(),
  quantity: quantitySchema,
  note: optionalText(300),
});

export const createAdjustmentSchema = z.object({
  locationId: uuidSchema,
  reason: z.enum(ADJUSTMENT_REASONS),
  note: optionalText(500),
  items: z
    .array(z.object({ batchId: uuidSchema, quantityDelta: signedQuantitySchema, note: optionalText(300) }))
    .min(1)
    .max(200),
});

/** Removes damaged or expired stock from sale. Creates an adjustment document with DAMAGE / EXPIRED_WRITE_OFF movements. */
export const writeOffSchema = z.object({
  locationId: uuidSchema,
  reason: z.enum(['EXPIRED', 'DAMAGED']),
  note: optionalText(500),
  items: z.array(z.object({ batchId: uuidSchema, quantity: quantitySchema })).min(1).max(200),
});

export const listAdjustmentsQuerySchema = paginationSchema.extend({
  reason: z.enum(ADJUSTMENT_REASONS).optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});

export const createTransferSchema = z.object({
  fromLocationId: uuidSchema,
  toBranchId: uuidSchema,
  /** Defaults to the destination branch's default location. */
  toLocationId: uuidSchema.optional(),
  note: optionalText(500),
  items: z.array(z.object({ batchId: uuidSchema, quantity: quantitySchema })).min(1).max(200),
});

export const receiveTransferSchema = z.object({
  /** Per-item received quantities; omitted items are received in full. Shortfalls are recorded on the item. */
  items: z.array(z.object({ itemId: uuidSchema, receivedQuantity: z.coerce.number().min(0) })).max(200).default([]),
  note: optionalText(500),
});

export const listTransfersQuerySchema = paginationSchema.extend({
  direction: z.enum(['outgoing', 'incoming', 'all']).default('all'),
  status: z.enum(['DRAFT', 'DISPATCHED', 'RECEIVED', 'CANCELLED']).optional(),
});

export const fefoPreviewQuerySchema = z.object({
  productId: uuidSchema,
  quantity: quantitySchema,
  locationId: uuidSchema.optional(),
});
