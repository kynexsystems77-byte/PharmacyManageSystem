import { createParamDecorator, SetMetadata, UnauthorizedException, type ExecutionContext } from '@nestjs/common';
import type { PermissionKey } from '@kynex/contracts';
import { requestContext, type AuthContext } from './request-context';

export const IS_PUBLIC = 'kynex:isPublic';
/** Skips authentication for this route (login, health, ...). */
export const Public = () => SetMetadata(IS_PUBLIC, true);

export const PERMISSIONS_KEY = 'kynex:permissions';
/** All listed permissions are required. Checked against the X-Branch-Id branch when the route is branch-scoped. */
export const RequirePermissions = (...permissions: PermissionKey[]) => SetMetadata(PERMISSIONS_KEY, permissions);

export const BRANCH_SCOPED = 'kynex:branchScoped';
/** The route needs an X-Branch-Id header naming a branch the user may access. */
export const BranchScoped = () => SetMetadata(BRANCH_SCOPED, true);

export const CurrentAuth = createParamDecorator((_data: unknown, _ctx: ExecutionContext): AuthContext => {
  const auth = requestContext.getStore()?.auth;
  if (!auth) {
    throw new UnauthorizedException();
  }
  return auth;
});
