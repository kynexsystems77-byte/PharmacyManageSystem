import { Global, Inject, Injectable, Logger, Module } from '@nestjs/common';
import nodemailer, { type Transporter } from 'nodemailer';
import { ENV, type Env } from '../config/env';

export interface MailMessage { to: string; subject: string; text: string; html?: string }

/** SMTP when SMTP_HOST is set; otherwise messages are written to the log (development). */
@Injectable()
export class Mailer {
  private readonly logger = new Logger('Mail');
  private readonly transport: Transporter | null;

  constructor(@Inject(ENV) private readonly env: Env) {
    this.transport = env.SMTP_HOST
      ? nodemailer.createTransport({
          host: env.SMTP_HOST, port: env.SMTP_PORT, secure: env.SMTP_SECURE,
          auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
        })
      : null;
  }

  async send(m: MailMessage): Promise<void> {
    if (!this.transport) {
      if (this.env.NODE_ENV === 'production') this.logger.warn(`SMTP is not configured; email "${m.subject}" to ${m.to} was NOT sent`);
      else this.logger.log(`[dev mail] to ${m.to}: ${m.subject}\n${m.text}`);
      return;
    }
    await this.transport.sendMail({ from: this.env.MAIL_FROM, to: m.to, subject: m.subject, text: m.text, html: m.html });
  }
}

@Global()
@Module({ providers: [Mailer], exports: [Mailer] })
export class MailerModule {}
