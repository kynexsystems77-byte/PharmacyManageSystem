'use client';

import { Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { SUPPLIER_PAYMENT_METHODS } from '@kynex/contracts';
import { useAuth } from '@/lib/auth';
import { money, productName, titleCase, todayIso } from '@/lib/format';
import { errorMessage, newKey, useBranchQuery, type Paged } from '@/lib/hooks';
import type { Product, Purchase, PurchaseOrder, Supplier } from '@/lib/types';
import { Checkbox, Select, Textarea } from './kit';
import { LocationSelect, ProductPicker } from './pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from './ui';

export type DiscountMode = 'PERCENT' | 'PER_UNIT' | 'AMOUNT';

export interface LineDraft {
  key: string;
  product: { id: string; brandName: string; strength: string | null; sku: string; baseUnit: string; trackExpiry: boolean; sellingPrice?: string | number };
  batchNumber: string; expiryDate: string; manufactureDate: string; quantity: string; bonusQuantity: string;
  /** Supplier's price per unit before discount (often the printed MRP). */
  unitCost: string;
  /** Supplier discount, entered as a percent, an amount per unit, or a total for the line. */
  discountMode: DiscountMode; discountValue: string;
  taxPercent: string; sellingPrice: string;
}

export const DISCOUNT_MODES: { v: DiscountMode; l: string }[] = [
  { v: 'PERCENT', l: '%' },
  { v: 'PER_UNIT', l: 'per unit' },
  { v: 'AMOUNT', l: 'line total' },
];

export interface PurchaseDraft {
  supplierId: string; locationId: string; supplierInvoiceNo: string; purchaseDate: string; dueDate: string; notes: string; orderId?: string;
  lines: LineDraft[];
}

const n = (v: string) => (v.trim() === '' ? 0 : Number(v));
const r2 = (v: number) => Math.round(v * 100) / 100;

export function lineTotals(l: LineDraft) {
  const qtyPaid = n(l.quantity);
  const gross = r2(qtyPaid * n(l.unitCost));
  const v = n(l.discountValue);
  const rawDiscount = l.discountMode === 'PERCENT' ? (gross * v) / 100 : l.discountMode === 'PER_UNIT' ? qtyPaid * v : v;
  const discount = r2(Math.min(Math.max(rawDiscount, 0), gross));
  const tax = r2(((gross - discount) * n(l.taxPercent)) / 100);
  const received = qtyPaid + n(l.bonusQuantity);
  /** What one unit really costs us: after discount, with free units spread in (tax excluded, as on the batch). */
  const landed = received > 0 ? (gross - discount) / received : 0;
  const sell = l.sellingPrice.trim() !== '' ? n(l.sellingPrice) : l.product.sellingPrice !== undefined ? Number(l.product.sellingPrice) : null;
  const profitPerUnit = sell === null ? null : sell - landed;
  return {
    gross, discount, tax, total: r2(gross - discount + tax), landed, received, sell, profitPerUnit,
    margin: sell && profitPerUnit !== null ? (profitPerUnit / sell) * 100 : null,
    lineProfit: profitPerUnit === null ? null : r2(profitPerUnit * received),
    discountPercent: gross > 0 ? (discount / gross) * 100 : 0,
    overDiscount: rawDiscount > gross + 0.001,
  };
}

export function lineFromProduct(p: Product): LineDraft {
  return {
    key: newKey(), product: { id: p.id, brandName: p.brandName, strength: p.strength, sku: p.sku, baseUnit: p.baseUnit, trackExpiry: p.trackExpiry, sellingPrice: p.sellingPrice },
    batchNumber: '', expiryDate: '', manufactureDate: '', quantity: '', bonusQuantity: '0', unitCost: String(Number(p.purchasePrice)),
    discountMode: 'PERCENT', discountValue: '', taxPercent: p.taxRate ? String(Number(p.taxRate.ratePercent)) : '0', sellingPrice: '',
  };
}

export function draftFromPurchase(p: Purchase): PurchaseDraft {
  return {
    supplierId: p.supplier.id, locationId: p.location.id, supplierInvoiceNo: p.supplierInvoiceNo ?? '', purchaseDate: p.purchaseDate.slice(0, 10),
    dueDate: p.dueDate?.slice(0, 10) ?? '', notes: p.notes ?? '', orderId: p.orderId ?? undefined,
    lines: p.purchaseItems.map((i) => ({
      key: i.id, product: i.product, batchNumber: i.batchNumber, expiryDate: i.expiryDate?.slice(0, 10) ?? '', manufactureDate: i.manufactureDate?.slice(0, 10) ?? '',
      quantity: String(Number(i.quantity)), bonusQuantity: String(Number(i.bonusQuantity)), unitCost: String(Number(i.unitCost)),
      discountMode: 'AMOUNT', discountValue: Number(i.discountAmount) ? String(Number(i.discountAmount)) : '', taxPercent: String(Number(i.taxPercent)), sellingPrice: i.sellingPrice === null ? '' : String(Number(i.sellingPrice)),
    })),
  };
}

/** Pre-fills the open quantities of a purchase order. Batch numbers and expiry dates still come from the delivery. */
export function draftFromOrder(po: PurchaseOrder): PurchaseDraft {
  return {
    supplierId: po.supplier.id, locationId: '', supplierInvoiceNo: '', purchaseDate: todayIso(), dueDate: '', notes: `Against ${po.number}`, orderId: po.id,
    lines: po.purchaseOrderItems
      .map((i) => ({ i, open: Number(i.orderedQuantity) - Number(i.receivedQuantity) }))
      .filter((x) => x.open > 0)
      .map(({ i, open }) => ({
        key: newKey(), product: i.product, batchNumber: '', expiryDate: '', manufactureDate: '', quantity: String(open), bonusQuantity: '0',
        unitCost: String(Number(i.unitCost)), discountMode: 'PERCENT' as const, discountValue: '', taxPercent: String(Number(i.taxPercent)), sellingPrice: '',
      })),
  };
}

export function draftBody(d: PurchaseDraft) {
  return {
    supplierId: d.supplierId,
    locationId: d.locationId || undefined,
    supplierInvoiceNo: d.supplierInvoiceNo.trim() || undefined,
    purchaseDate: d.purchaseDate || undefined,
    dueDate: d.dueDate || undefined,
    notes: d.notes.trim() || undefined,
    orderId: d.orderId,
    items: d.lines.map((l) => ({
      productId: l.product.id, batchNumber: l.batchNumber.trim(), expiryDate: l.expiryDate || null, manufactureDate: l.manufactureDate || null,
      quantity: n(l.quantity), bonusQuantity: n(l.bonusQuantity), unitCost: n(l.unitCost), discountAmount: lineTotals(l).discount,
      taxPercent: n(l.taxPercent), sellingPrice: l.sellingPrice.trim() === '' ? null : n(l.sellingPrice),
    })),
  };
}

export function PurchaseForm({
  initial, mode, submitting, error, onSave, onCancel,
}: {
  initial: PurchaseDraft;
  mode: 'create' | 'edit';
  submitting: boolean;
  error: unknown;
  onSave: (d: PurchaseDraft, action: 'draft' | 'receive', payment?: { amount: number; method: string; reference?: string }) => void;
  onCancel: () => void;
}) {
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const [d, setD] = useState<PurchaseDraft>(initial);
  const [pay, setPay] = useState(false);
  const [payMethod, setPayMethod] = useState('CASH');
  const [payAmount, setPayAmount] = useState('');
  const [payRef, setPayRef] = useState('');
  const suppliers = useBranchQuery<Paged<Supplier>>('/suppliers?pageSize=100', { staleTime: 60_000 });
  const set = <K extends keyof PurchaseDraft>(k: K, v: PurchaseDraft[K]) => setD((x) => ({ ...x, [k]: v }));
  const setLine = (key: string, patch: Partial<LineDraft>) => setD((x) => ({ ...x, lines: x.lines.map((l) => (l.key === key ? { ...l, ...patch } : l)) }));

  const totals = useMemo(() => {
    const ls = d.lines.map(lineTotals);
    return {
      gross: r2(ls.reduce((a, l) => a + l.gross, 0)),
      discount: r2(ls.reduce((a, l) => a + l.discount, 0)),
      tax: r2(ls.reduce((a, l) => a + l.tax, 0)),
      total: r2(ls.reduce((a, l) => a + l.total, 0)),
      profit: ls.every((l) => l.lineProfit !== null) ? r2(ls.reduce((a, l) => a + (l.lineProfit ?? 0), 0)) : null,
      cost: r2(ls.reduce((a, l) => a + l.gross - l.discount, 0)),
    };
  }, [d.lines]);

  const missing = d.lines.find((l) => !l.batchNumber.trim() || !(n(l.quantity) > 0) || lineTotals(l).overDiscount);
  const missingExpiry = d.lines.find((l) => l.product.trackExpiry && !l.expiryDate);
  const canSave = d.supplierId && d.lines.length > 0 && !missing;
  const canReceive = canSave && !missingExpiry && can('purchase:receive');

  return (
    <div className="space-y-4">
      {error ? <Alert>{errorMessage(error)}</Alert> : null}
      <Card>
        <div className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Supplier *">
            <Select value={d.supplierId} onChange={(e) => set('supplierId', e.target.value)} disabled={Boolean(d.orderId)}>
              <option value="">Choose…</option>
              {suppliers.data?.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label="Supplier invoice number"><Input value={d.supplierInvoiceNo} onChange={(e) => set('supplierInvoiceNo', e.target.value)} maxLength={60} /></Field>
          <Field label="Receive into"><LocationSelect value={d.locationId} onChange={(id) => set('locationId', id)} /></Field>
          <Field label="Invoice date"><Input type="date" value={d.purchaseDate} onChange={(e) => set('purchaseDate', e.target.value)} /></Field>
          <Field label="Due date"><Input type="date" value={d.dueDate} onChange={(e) => set('dueDate', e.target.value)} placeholder="From supplier terms" /></Field>
        </div>
        {!d.dueDate && <p className="-mt-2 px-4 pb-3 text-xs text-fg-muted">Leave the due date empty to use the supplier&apos;s payment terms.</p>}
      </Card>

      <Card>
        <CardHeader title="Items received" action={<span className="text-xs text-fg-muted">Quantities and costs are per {d.lines[0]?.product.baseUnit ?? 'base unit'}</span>} />
        <div className="space-y-3 p-4">
          <ProductPicker withStock={false} onPick={(p) => setD((x) => ({ ...x, lines: [...x.lines, lineFromProduct(p)] }))} placeholder="Add a product (search or scan)" />
          {d.lines.length === 0 && <p className="py-6 text-center text-sm text-fg-muted">Add the products on the supplier&apos;s invoice.</p>}
          {d.lines.map((l) => {
            const t = lineTotals(l);
            return (
              <div key={l.key} className="rounded-lg border border-line p-3">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div className="text-sm"><p className="font-medium">{productName(l.product.brandName, l.product.strength)}</p><p className="text-xs text-fg-muted">{l.product.sku} · per {l.product.baseUnit}</p></div>
                  <div className="flex items-center gap-3">
                    <span className="tabular text-sm font-semibold">{money(t.total, cur)}</span>
                    <button aria-label="Remove line" onClick={() => setD((x) => ({ ...x, lines: x.lines.filter((y) => y.key !== l.key) }))} className="grid h-8 w-8 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
                  <Field label="Batch no. *"><Input value={l.batchNumber} onChange={(e) => setLine(l.key, { batchNumber: e.target.value })} maxLength={60} /></Field>
                  <Field label={`Expiry${l.product.trackExpiry ? ' *' : ''}`}><Input type="date" value={l.expiryDate} onChange={(e) => setLine(l.key, { expiryDate: e.target.value })} /></Field>
                  <Field label="Mfg date"><Input type="date" value={l.manufactureDate} onChange={(e) => setLine(l.key, { manufactureDate: e.target.value })} /></Field>
                  <Field label="Qty *"><Input type="number" min="0" step="0.001" value={l.quantity} onChange={(e) => setLine(l.key, { quantity: e.target.value })} /></Field>
                  <Field label="Bonus"><Input type="number" min="0" step="0.001" value={l.bonusQuantity} onChange={(e) => setLine(l.key, { bonusQuantity: e.target.value })} /></Field>
                  <Field label="Supplier price"><Input type="number" min="0" step="0.0001" value={l.unitCost} onChange={(e) => setLine(l.key, { unitCost: e.target.value })} /></Field>
                  <Field label="Discount">
                    <div className="flex">
                      <Input type="number" min="0" step="0.01" value={l.discountValue} placeholder="0" aria-label="Discount"
                        className="min-w-0 rounded-r-none" onChange={(e) => setLine(l.key, { discountValue: e.target.value })} />
                      <select aria-label="Discount type" value={l.discountMode} onChange={(e) => setLine(l.key, { discountMode: e.target.value as DiscountMode })}
                        className="h-10 shrink-0 rounded-r-lg border border-l-0 border-line bg-subtle px-1.5 text-xs">
                        {DISCOUNT_MODES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}
                      </select>
                    </div>
                  </Field>
                  <Field label="Tax %"><Input type="number" min="0" max="100" step="0.01" value={l.taxPercent} onChange={(e) => setLine(l.key, { taxPercent: e.target.value })} /></Field>
                  <Field label="Sell price"><Input type="number" min="0" step="0.0001" value={l.sellingPrice} placeholder={l.product.sellingPrice !== undefined ? String(Number(l.product.sellingPrice)) : 'Product'} onChange={(e) => setLine(l.key, { sellingPrice: e.target.value })} /></Field>
                </div>
                <LineProfit t={t} unit={l.product.baseUnit} cur={cur} bonus={n(l.bonusQuantity)} />
              </div>
            );
          })}
        </div>
        <div className="flex flex-col items-end gap-1 border-t border-line px-4 py-3 text-sm">
          <Row label="Subtotal" value={money(totals.gross, cur)} />
          {totals.discount > 0 && <Row label="Supplier discount" value={`- ${money(totals.discount, cur)}`} />}
          <Row label="Tax" value={money(totals.tax, cur)} />
          <Row label="Invoice total" value={money(totals.total, cur)} strong />
          {totals.profit !== null && d.lines.length > 0 && (
            <div className="mt-1 flex w-full max-w-xs justify-between gap-4 rounded-md bg-success/10 px-2 py-1 text-success">
              <span>Profit when all sold</span><span className="tabular font-semibold">{money(totals.profit, cur)}{totals.cost > 0 ? ` (${((totals.profit / (totals.profit + totals.cost)) * 100).toFixed(1)}%)` : ''}</span>
            </div>
          )}
        </div>
      </Card>

      {can('purchase:receive') && can('supplier:payment') && (
        <Card className="space-y-3 p-4">
          <Checkbox label="Record a payment now" hint="Only when receiving. Otherwise the invoice is added to what you owe the supplier." checked={pay} onChange={setPay} />
          {pay && (
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Amount"><Input type="number" min="0" step="0.01" value={payAmount || String(totals.total)} onChange={(e) => setPayAmount(e.target.value)} /></Field>
              <Field label="Method">
                <Select value={payMethod} onChange={(e) => setPayMethod(e.target.value)}>
                  {SUPPLIER_PAYMENT_METHODS.map((m) => <option key={m} value={m}>{titleCase(m)}</option>)}
                </Select>
              </Field>
              <Field label="Reference"><Input value={payRef} onChange={(e) => setPayRef(e.target.value)} placeholder="Cheque / transfer no." /></Field>
            </div>
          )}
        </Card>
      )}

      <Card className="p-4">
        <Field label="Internal notes"><Textarea value={d.notes} onChange={(e) => set('notes', e.target.value)} maxLength={1000} className="min-h-[60px]" /></Field>
      </Card>

      {missingExpiry && <p className="text-right text-xs text-warning">{missingExpiry.product.brandName} needs an expiry date before it can be received.</p>}
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button variant="outline" disabled={!canSave} loading={submitting} onClick={() => onSave(d, 'draft')}>{mode === 'create' ? 'Save as draft' : 'Save draft'}</Button>
        {can('purchase:receive') && (
          <Button
            disabled={!canReceive}
            loading={submitting}
            onClick={() => onSave(d, 'receive', pay ? { amount: Number(payAmount || totals.total), method: payMethod, reference: payRef.trim() || undefined } : undefined)}
          >
            Receive into stock
          </Button>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={`flex w-full max-w-xs justify-between gap-4 ${strong ? 'border-t border-line pt-1 text-base font-semibold' : 'text-fg-muted'}`}>
      <span>{label}</span><span className="tabular text-fg">{value}</span>
    </div>
  );
}

/** Net cost per unit after the supplier discount, and the profit at the selling price (e.g. price 2,000 - discount 500 = cost 1,500, profit 500). */
function LineProfit({ t, unit, cur, bonus }: { t: ReturnType<typeof lineTotals>; unit: string; cur: string; bonus: number }) {
  if (t.overDiscount) return <p className="mt-2 text-xs font-medium text-danger">The discount is more than the line amount.</p>;
  if (t.gross <= 0) return null;
  const loss = t.profitPerUnit !== null && t.profitPerUnit < 0;
  return (
    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-md bg-subtle px-3 py-2 text-xs">
      <span>Cost per {unit} <b className="tabular">{money(t.landed, cur)}</b>{t.discount > 0 ? <span className="text-fg-muted"> ({t.discountPercent.toFixed(1)}% off{bonus > 0 ? ', free units included' : ''})</span> : bonus > 0 ? <span className="text-fg-muted"> (free units included)</span> : null}</span>
      {t.sell !== null && <span>Sells at <b className="tabular">{money(t.sell, cur)}</b></span>}
      {t.profitPerUnit !== null ? (
        <span className={loss ? 'font-semibold text-danger' : 'font-semibold text-success'}>
          {loss ? 'Loss' : 'Profit'} {money(Math.abs(t.profitPerUnit), cur)} per {unit}{t.margin !== null ? ` (${t.margin.toFixed(1)}%)` : ''} · {money(Math.abs(t.lineProfit ?? 0), cur)} on this line
        </span>
      ) : <span className="text-fg-muted">Enter a sell price to see the profit</span>}
    </div>
  );
}
