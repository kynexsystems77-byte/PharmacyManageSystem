'use client';

import { useRouter } from 'next/navigation';
import { Forbidden, PageHeader, useToast } from '@/components/kit';
import { draftToBody, emptyDraft, ProductForm } from '@/components/product-form';
import { useAuth } from '@/lib/auth';
import { useApiMutation } from '@/lib/hooks';
import type { Product } from '@/lib/types';

export default function NewProductPage() {
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const create = useApiMutation<ReturnType<typeof draftToBody>, Product>('POST', '/products', {
    onSuccess: (p) => {
      toast.success(`${p.brandName} created (${p.sku})`);
      router.push(`/medicines/${p.id}`);
    },
  });
  if (!can('product:create')) return <Forbidden what="creating products" />;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="New product" back="/medicines" />
      <ProductForm
        mode="create"
        initial={emptyDraft()}
        canEditPrices
        canDeactivate={false}
        submitting={create.isPending}
        error={create.error}
        onSubmit={(d) => create.mutate(draftToBody(d, 'create'))}
        onCancel={() => router.push('/medicines')}
      />
    </div>
  );
}
