import {
  BadRequestException, ConflictException, Injectable, NotFoundException, UnprocessableEntityException,
} from '@nestjs/common';
import type { z } from 'zod';
import type { createPurchaseReturnSchema, purchaseItemSchema, supplierPaymentInputSchema } from '@kynex/contracts';
import type { PaymentMethod, Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { openSessionFor, partyBalance, recordCash } from '../common/cash';
import {
  dec, Decimal, formatDateOnly, money2, optionalDate, parseDateOnly, price4, SequenceService, sumDec, TenantInfoService, todayIn, type Dec,
} from '../common/core';
import type { AuthContext } from '../common/request-context';
import { StockService } from '../inventory/stock.service';
import { TenantDb } from '../prisma/prisma.service';

type ItemInput = z.infer<typeof purchaseItemSchema>;
type PaymentInput = z.infer<typeof supplierPaymentInputSchema>;
type ReturnInput = z.infer<typeof createPurchaseReturnSchema>;

export const PURCHASE_SELECT = {
  id: true, number: true, supplierInvoiceNo: true, status: true, purchaseDate: true, dueDate: true, subtotal: true,
  discountTotal: true, taxTotal: true, grandTotal: true, paidTotal: true, notes: true, receivedAt: true, createdAt: true,
  orderId: true,
  supplier: { select: { id: true, name: true, paymentTermsDays: true } },
  location: { select: { id: true, name: true } },
  order: { select: { id: true, number: true } },
  createdBy: { select: { id: true, fullName: true } },
  purchaseItems: {
    orderBy: { createdAt: 'asc' },
    select: {
      id: true, batchNumber: true, expiryDate: true, manufactureDate: true, quantity: true, bonusQuantity: true, unitCost: true,
      discountAmount: true, taxPercent: true, taxAmount: true, lineTotal: true, sellingPrice: true, batchId: true,
      product: { select: { id: true, brandName: true, strength: true, sku: true, baseUnit: true, trackExpiry: true, sellingPrice: true } },
    },
  },
  payments: { orderBy: { paidAt: 'asc' }, select: { id: true, method: true, amount: true, reference: true, paidAt: true, note: true } },
} satisfies Prisma.PurchaseSelect;

export interface ComputedLine {
  input: ItemInput;
  gross: Dec;
  discount: Dec;
  tax: Dec;
  lineTotal: Dec;
  /** Cost per received base unit (net of discount, bonus units included, tax excluded). */
  landedCost: Dec;
  receivedQty: Dec;
}

export function computeLines(items: ItemInput[]) {
  const lines: ComputedLine[] = items.map((i) => {
    const qty = dec(i.quantity);
    const bonus = dec(i.bonusQuantity ?? 0);
    const gross = money2(qty.times(i.unitCost));
    const discount = money2(i.discountAmount ?? 0);
    if (discount.gt(gross)) throw new BadRequestException('A line discount cannot exceed the line amount');
    const net = gross.minus(discount);
    const tax = money2(net.times(i.taxPercent ?? 0).div(100));
    const receivedQty = qty.plus(bonus);
    return { input: i, gross, discount, tax, lineTotal: net.plus(tax), landedCost: price4(net.div(receivedQty)), receivedQty };
  });
  return {
    lines,
    subtotal: sumDec(lines.map((l) => l.gross)),
    discountTotal: sumDec(lines.map((l) => l.discount)),
    taxTotal: sumDec(lines.map((l) => l.tax)),
    grandTotal: sumDec(lines.map((l) => l.lineTotal)),
  };
}

@Injectable()
export class PurchasingService {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly stock: StockService,
    private readonly sequences: SequenceService,
    private readonly tenantInfo: TenantInfoService,
  ) {}

  async assertSupplier(tx: Prisma.TransactionClient, supplierId: string) {
    const s = await tx.supplier.findFirst({ where: { id: supplierId, deletedAt: null }, select: { id: true, name: true, isActive: true, paymentTermsDays: true } });
    if (!s) throw new BadRequestException('Supplier not found');
    if (!s.isActive) throw new UnprocessableEntityException(`Supplier ${s.name} is inactive`);
    return s;
  }

  /** Product checks shared by drafts and receipts. `strict` (at receipt) also enforces expiry rules. */
  async validateItems(tx: Prisma.TransactionClient, items: ItemInput[], strict: boolean, timezone: string) {
    const ids = [...new Set(items.map((i) => i.productId))];
    const products = await tx.product.findMany({ where: { id: { in: ids }, deletedAt: null }, select: { id: true, brandName: true, trackExpiry: true } });
    if (products.length !== ids.length) throw new BadRequestException('Unknown or deleted product on a line');
    const byId = new Map(products.map((p) => [p.id, p]));
    const seen = new Set<string>();
    const today = todayIn(timezone);
    for (const i of items) {
      const p = byId.get(i.productId)!;
      const key = `${i.productId}:${i.batchNumber.toLowerCase()}`;
      if (seen.has(key)) throw new BadRequestException(`${p.brandName} batch ${i.batchNumber} appears twice; merge the lines`);
      seen.add(key);
      if (i.expiryDate && i.manufactureDate && i.manufactureDate > i.expiryDate) {
        throw new BadRequestException(`${p.brandName}: manufacture date is after the expiry date`);
      }
      if (strict && p.trackExpiry && !i.expiryDate) throw new UnprocessableEntityException(`${p.brandName} tracks expiry: enter the expiry date for batch ${i.batchNumber}`);
      if (strict && i.expiryDate && i.expiryDate < today) throw new UnprocessableEntityException(`${p.brandName} batch ${i.batchNumber} is already expired`);
    }
    return byId;
  }

  itemRows(tenantId: string, computed: ReturnType<typeof computeLines>) {
    return computed.lines.map((l) => ({
      tenantId,
      productId: l.input.productId,
      batchNumber: l.input.batchNumber,
      expiryDate: optionalDate(l.input.expiryDate) ?? null,
      manufactureDate: optionalDate(l.input.manufactureDate) ?? null,
      quantity: dec(l.input.quantity),
      bonusQuantity: dec(l.input.bonusQuantity ?? 0),
      unitCost: dec(l.input.unitCost),
      discountAmount: l.discount,
      taxPercent: dec(l.input.taxPercent ?? 0),
      taxAmount: l.tax,
      lineTotal: l.lineTotal,
      sellingPrice: l.input.sellingPrice === undefined || l.input.sellingPrice === null ? null : dec(l.input.sellingPrice),
    }));
  }

  /**
   * Posts a DRAFT purchase: creates/tops up batches, adds stock, updates the supplier ledger and the purchase order.
   * Selling prices from the purchase lines are stored on the batches.
   */
  async receive(auth: AuthContext, branchId: string, purchaseId: string, payment?: PaymentInput) {
    const tx = this.db.tx;
    const locked = await tx.$queryRaw<{ status: string; branch_id: string }[]>`
      SELECT status::text AS status, branch_id FROM purchases WHERE id = ${purchaseId}::uuid FOR UPDATE`;
    const row = locked[0];
    if (!row || row.branch_id !== branchId) throw new NotFoundException('Purchase not found in this branch');
    if (row.status !== 'DRAFT') throw new ConflictException(`Purchase is already ${row.status.toLowerCase()}`);

    const p = await tx.purchase.findFirstOrThrow({ where: { id: purchaseId }, select: PURCHASE_SELECT });
    const { timezone } = await this.tenantInfo.get(tx);
    await this.assertSupplier(tx, p.supplier.id);
    await this.stock.assertLocation(tx, branchId, p.location.id);
    const items: ItemInput[] = p.purchaseItems.map((i) => ({
      productId: i.product.id, batchNumber: i.batchNumber, expiryDate: formatDateOnly(i.expiryDate), manufactureDate: formatDateOnly(i.manufactureDate),
      quantity: Number(i.quantity), bonusQuantity: Number(i.bonusQuantity), unitCost: Number(i.unitCost), discountAmount: Number(i.discountAmount),
      taxPercent: Number(i.taxPercent),
    }));
    await this.validateItems(tx, items, true, timezone);

    for (const item of p.purchaseItems) {
      const qty = dec(item.quantity);
      const received = qty.plus(item.bonusQuantity);
      const net = money2(qty.times(item.unitCost)).minus(item.discountAmount);
      const landed = price4(net.div(received));
      const sellingPrice = item.sellingPrice;

      let batch = await tx.batch.findFirst({ where: { productId: item.product.id, batchNumber: item.batchNumber } });
      if (batch) {
        if (formatDateOnly(batch.expiryDate) !== formatDateOnly(item.expiryDate)) {
          throw new ConflictException(
            `${item.product.brandName} batch ${item.batchNumber} already exists with expiry ${formatDateOnly(batch.expiryDate) ?? 'none'}. Check the batch number or expiry date.`,
          );
        }
        // weighted-average cost of this batch across all stock on hand
        const onHand = dec((await tx.stockLevel.aggregate({ where: { batchId: batch.id }, _sum: { quantity: true } }))._sum.quantity);
        const newCost = onHand.plus(received).isZero()
          ? landed
          : price4(onHand.times(batch.unitCost).plus(received.times(landed)).div(onHand.plus(received)));
        batch = await tx.batch.update({
          where: { id: batch.id },
          data: {
            unitCost: newCost,
            status: batch.status === 'EXPIRED' ? 'ACTIVE' : batch.status,
            ...(sellingPrice !== null ? { sellingPrice } : {}),
          },
        });
      } else {
        batch = await tx.batch.create({
          data: {
            tenantId: auth.tenantId, productId: item.product.id, supplierId: p.supplier.id, batchNumber: item.batchNumber,
            expiryDate: item.expiryDate, manufactureDate: item.manufactureDate, unitCost: landed,
            sellingPrice,
          },
        });
      }
      await tx.purchaseItem.update({ where: { id: item.id }, data: { batchId: batch.id } });
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId, locationId: p.location.id, productId: item.product.id, batchId: batch.id,
        delta: received, type: 'PURCHASE_RECEIPT', unitCost: landed, referenceType: 'purchase', referenceId: p.id, reason: p.number, userId: auth.userId,
      });
      // the latest net cost (after the supplier's discount and free units) becomes the product's reference purchase price
      await tx.product.update({ where: { id: item.product.id }, data: { purchasePrice: landed } });
    }

    if (p.orderId) await this.applyToOrder(tx, p.orderId, p.purchaseItems.map((i) => ({ productId: i.product.id, quantity: dec(i.quantity) })));

    await tx.purchase.update({ where: { id: p.id }, data: { status: 'RECEIVED', receivedAt: new Date() } });
    if (dec(p.grandTotal).gt(0)) {
      await tx.partyLedgerEntry.create({
        data: {
          tenantId: auth.tenantId, entryType: 'PURCHASE_ON_CREDIT', amount: p.grandTotal, referenceType: 'purchase', referenceId: p.id,
          description: `${p.number}${p.supplierInvoiceNo ? ` (invoice ${p.supplierInvoiceNo})` : ''}`, branchId, supplierId: p.supplier.id, createdById: auth.userId,
        },
      });
    }
    if (payment) await this.paySupplier(auth, branchId, p.supplier.id, { ...payment, purchaseId: p.id });

    const after = await tx.purchase.findFirstOrThrow({ where: { id: p.id }, select: PURCHASE_SELECT });
    await this.audit.record({ action: 'purchase.received', entityType: 'purchase', entityId: p.id, after });
    return after;
  }

  private async applyToOrder(tx: Prisma.TransactionClient, orderId: string, lines: { productId: string; quantity: Dec }[]) {
    const items = await tx.purchaseOrderItem.findMany({ where: { orderId }, orderBy: { createdAt: 'asc' } });
    for (const l of lines) {
      let left = l.quantity;
      for (const it of items.filter((x) => x.productId === l.productId)) {
        if (left.lte(0)) break;
        const open = Decimal.max(dec(it.orderedQuantity).minus(it.receivedQuantity), 0);
        const take = open.gt(0) ? Decimal.min(open, left) : new Decimal(0);
        if (take.gt(0)) {
          it.receivedQuantity = dec(it.receivedQuantity).plus(take);
          await tx.purchaseOrderItem.update({ where: { id: it.id }, data: { receivedQuantity: it.receivedQuantity } });
          left = left.minus(take);
        }
      }
      // over-delivery is booked on the first matching line
      const first = items.find((x) => x.productId === l.productId);
      if (left.gt(0) && first) {
        first.receivedQuantity = dec(first.receivedQuantity).plus(left);
        await tx.purchaseOrderItem.update({ where: { id: first.id }, data: { receivedQuantity: first.receivedQuantity } });
      }
    }
    const done = items.every((it) => dec(it.receivedQuantity).gte(it.orderedQuantity));
    await tx.purchaseOrder.update({ where: { id: orderId }, data: { status: done ? 'RECEIVED' : 'PARTIALLY_RECEIVED' } });
  }

  /**
   * Records a payment to a supplier. With purchaseId it settles that invoice (up to its outstanding amount);
   * otherwise it settles the oldest unpaid invoices first. Anything left over is an advance (credit with the supplier).
   * Cash payments come out of the user's open register shift when there is one.
   */
  async paySupplier(auth: AuthContext, branchId: string, supplierId: string, input: PaymentInput & { purchaseId?: string }) {
    const tx = this.db.tx;
    const supplier = await tx.supplier.findFirst({ where: { id: supplierId, deletedAt: null }, select: { id: true, name: true } });
    if (!supplier) throw new NotFoundException('Supplier not found');
    const amount = money2(input.amount);
    if (amount.lte(0)) throw new BadRequestException('Amount must be positive');

    let targets: { id: string; number: string; outstanding: Dec }[];
    if (input.purchaseId) {
      const p = await tx.purchase.findFirst({ where: { id: input.purchaseId, supplierId, status: 'RECEIVED' }, select: { id: true, number: true, grandTotal: true, paidTotal: true } });
      if (!p) throw new BadRequestException('That purchase is not a received invoice of this supplier');
      const outstanding = dec(p.grandTotal).minus(p.paidTotal);
      if (amount.gt(outstanding)) throw new UnprocessableEntityException(`Only ${outstanding.toFixed(2)} is outstanding on ${p.number}`);
      targets = [{ id: p.id, number: p.number, outstanding }];
    } else {
      const open = await tx.$queryRaw<{ id: string; number: string; outstanding: string }[]>`
        SELECT id, number, (grand_total - paid_total)::text AS outstanding FROM purchases
        WHERE supplier_id = ${supplierId}::uuid AND status = 'RECEIVED' AND paid_total < grand_total
        ORDER BY purchase_date ASC, created_at ASC FOR UPDATE`;
      targets = open.map((o) => ({ id: o.id, number: o.number, outstanding: dec(o.outstanding) }));
    }

    const session = input.method === 'CASH' ? await openSessionFor(tx, branchId, auth.userId) : null;
    const base = {
      tenantId: auth.tenantId, kind: 'SUPPLIER_PAYMENT' as const, method: input.method as PaymentMethod, reference: input.reference ?? null,
      note: input.note ?? null, branchId, receivedById: auth.userId, supplierId, registerSessionId: session?.id ?? null,
    };
    let left = amount;
    const applied: { purchaseId: string | null; number: string | null; amount: string }[] = [];
    for (const t of targets) {
      if (left.lte(0)) break;
      const take = Decimal.min(left, t.outstanding);
      if (take.lte(0)) continue;
      await tx.payment.create({ data: { ...base, amount: take, purchaseId: t.id } });
      await tx.purchase.update({ where: { id: t.id }, data: { paidTotal: { increment: take } } });
      applied.push({ purchaseId: t.id, number: t.number, amount: take.toFixed(2) });
      left = left.minus(take);
    }
    if (left.gt(0)) {
      await tx.payment.create({ data: { ...base, amount: left, note: input.note ?? 'Advance / unallocated' } });
      applied.push({ purchaseId: null, number: null, amount: left.toFixed(2) });
    }
    await tx.partyLedgerEntry.create({
      data: {
        tenantId: auth.tenantId, entryType: 'PAYMENT', amount: amount.negated(), referenceType: 'supplier_payment',
        description: `Payment (${input.method.toLowerCase().replace('_', ' ')})${input.reference ? ` ref ${input.reference}` : ''}`,
        branchId, supplierId, createdById: auth.userId,
      },
    });
    if (session) {
      await recordCash(tx, {
        tenantId: auth.tenantId, branchId, registerSessionId: session.id, userId: auth.userId, type: 'SUPPLIER_PAYMENT',
        amount: amount.negated(), referenceType: 'supplier', referenceId: supplierId, note: `Paid ${supplier.name}`,
      });
    }
    const balance = await partyBalance(tx, { supplierId });
    const result = { supplierId, amount: amount.toFixed(2), method: input.method, applied, cashFromRegister: Boolean(session), balance: balance.toFixed(2) };
    await this.audit.record({ action: 'supplier.payment', entityType: 'supplier', entityId: supplierId, after: result });
    return result;
  }

  async createReturn(auth: AuthContext, branchId: string, input: ReturnInput) {
    const tx = this.db.tx;
    await this.assertSupplier(tx, input.supplierId);
    const batchIds = [...new Set(input.items.map((i) => i.batchId))];
    const batches = await tx.batch.findMany({
      where: { id: { in: batchIds } },
      select: { id: true, productId: true, unitCost: true, batchNumber: true, supplierId: true, product: { select: { brandName: true } } },
    });
    if (batches.length !== batchIds.length) throw new BadRequestException('Unknown batch');
    const byId = new Map(batches.map((b) => [b.id, b]));
    for (const i of input.items) await this.stock.assertLocation(tx, branchId, i.locationId);

    if (input.purchaseId) {
      const purchase = await tx.purchase.findFirst({
        where: { id: input.purchaseId, supplierId: input.supplierId, status: 'RECEIVED' },
        select: { id: true, purchaseItems: { select: { batchId: true, quantity: true, bonusQuantity: true } } },
      });
      if (!purchase) throw new BadRequestException('That purchase is not a received invoice of this supplier');
      for (const bId of batchIds) {
        const bought = purchase.purchaseItems.filter((pi) => pi.batchId === bId).reduce((a, pi) => a.plus(pi.quantity).plus(pi.bonusQuantity), dec(0));
        if (bought.isZero()) throw new BadRequestException(`Batch ${byId.get(bId)!.batchNumber} was not on that purchase`);
        const already = dec(
          (await tx.purchaseReturnItem.aggregate({ where: { batchId: bId, return: { purchaseId: purchase.id, status: 'POSTED' } }, _sum: { quantity: true } }))._sum.quantity,
        );
        const now = input.items.filter((i) => i.batchId === bId).reduce((a, i) => a.plus(i.quantity), dec(0));
        if (already.plus(now).gt(bought)) throw new UnprocessableEntityException(`Cannot return more of batch ${byId.get(bId)!.batchNumber} than was received (${bought.minus(already).toString()} left)`);
      }
    }

    const lines = input.items.map((i) => {
      const b = byId.get(i.batchId)!;
      const unitCost = i.unitCost === undefined ? dec(b.unitCost) : dec(i.unitCost);
      return { ...i, b, unitCost, lineTotal: money2(dec(i.quantity).times(unitCost)) };
    });
    const total = sumDec(lines.map((l) => l.lineTotal));
    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'PURCHASE_RETURN', scopeKey: branchId, prefix: 'PRN' });
    const { timezone } = await this.tenantInfo.get(tx);
    const doc = await tx.purchaseReturn.create({
      data: {
        tenantId: auth.tenantId, number, status: 'POSTED', returnDate: parseDateOnly(todayIn(timezone)), total, reason: input.reason ?? null,
        purchaseId: input.purchaseId ?? null, supplierId: input.supplierId, branchId, createdById: auth.userId,
        purchaseReturnItems: {
          create: lines.map((l) => ({
            tenantId: auth.tenantId, quantity: dec(l.quantity), unitCost: l.unitCost, lineTotal: l.lineTotal,
            productId: l.b.productId, batchId: l.b.id, locationId: l.locationId,
          })),
        },
      },
      select: { id: true },
    });
    for (const l of lines) {
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId, locationId: l.locationId, productId: l.b.productId, batchId: l.b.id, delta: -l.quantity,
        type: 'PURCHASE_RETURN', unitCost: l.unitCost, referenceType: 'purchase_return', referenceId: doc.id, reason: input.reason ?? number, userId: auth.userId,
      });
    }
    if (total.gt(0)) {
      await tx.partyLedgerEntry.create({
        data: {
          tenantId: auth.tenantId, entryType: 'PURCHASE_RETURN', amount: total.negated(), referenceType: 'purchase_return', referenceId: doc.id,
          description: number, branchId, supplierId: input.supplierId, createdById: auth.userId,
        },
      });
    }
    const after = await tx.purchaseReturn.findFirstOrThrow({ where: { id: doc.id }, select: PURCHASE_RETURN_SELECT });
    await this.audit.record({ action: 'purchase_return.posted', entityType: 'purchase_return', entityId: doc.id, after });
    return after;
  }
}

export const PURCHASE_RETURN_SELECT = {
  id: true, number: true, status: true, returnDate: true, total: true, reason: true, createdAt: true,
  supplier: { select: { id: true, name: true } },
  purchase: { select: { id: true, number: true } },
  createdBy: { select: { id: true, fullName: true } },
  purchaseReturnItems: {
    select: {
      id: true, quantity: true, unitCost: true, lineTotal: true,
      product: { select: { id: true, brandName: true, sku: true, baseUnit: true } },
      batch: { select: { id: true, batchNumber: true, expiryDate: true } },
      location: { select: { id: true, name: true } },
    },
  },
} satisfies Prisma.PurchaseReturnSelect;
