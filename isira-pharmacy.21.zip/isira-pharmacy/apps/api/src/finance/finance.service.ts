import { ForbiddenException, Injectable } from '@nestjs/common';
import type { PermissionKey } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { hasPermission } from '../common/branch';
import { dec, money2 } from '../common/core';
import type { AuthContext } from '../common/request-context';

export interface Range { from: string; to: string; timezone: string; branchIds: string[] }

const REVENUE_STATUSES = `('COMPLETED','PARTIALLY_RETURNED','RETURNED')`;

/**
 * Financial figures shared by the Finance screen and the Reports module.
 * Conventions:
 *  - revenue and profit exclude tax (tax collected is a liability, reported separately);
 *  - a return reverses its share of revenue and tax; its cost only comes back when the goods were restocked;
 *  - stock losses = cost of damage, expiry write-offs and count adjustments (net of stock found).
 */
@Injectable()
export class FinanceService {
  /** Branches covered by a report: the selected one, or every branch where the user holds the permission. */
  branchesFor(auth: AuthContext, permission: PermissionKey, currentBranchId: string, scope: 'branch' | 'all'): string[] {
    if (scope === 'branch') return [currentBranchId];
    const ids = [...auth.branchIds].filter((b) => hasPermission(auth, permission, b));
    if (ids.length === 0) throw new ForbiddenException(`Missing permission: ${permission}`);
    return ids;
  }

  async profitAndLoss(tx: Prisma.TransactionClient, r: Range) {
    const [sales] = await tx.$queryRawUnsafe<{ invoices: number; gross: string; discounts: string; tax: string; total: string; rounding: string; ex_tax: string; cogs: string }[]>(
      `WITH s AS (
         SELECT s.* FROM sales s
         WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REVENUE_STATUSES}
           AND (s.sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date)
       SELECT (SELECT COUNT(*) FROM s)::int AS invoices,
              (SELECT COALESCE(SUM(subtotal), 0) FROM s)::text AS gross,
              (SELECT COALESCE(SUM(discount_total), 0) FROM s)::text AS discounts,
              (SELECT COALESCE(SUM(tax_total), 0) FROM s)::text AS tax,
              (SELECT COALESCE(SUM(grand_total), 0) FROM s)::text AS total,
              (SELECT COALESCE(SUM(rounding_adjustment), 0) FROM s)::text AS rounding,
              (SELECT COALESCE(SUM(si.line_total - si.tax_amount), 0) FROM sale_items si JOIN s ON s.id = si.sale_id)::text AS ex_tax,
              (SELECT COALESCE(SUM(si.cost_total), 0) FROM sale_items si JOIN s ON s.id = si.sale_id)::text AS cogs`,
      r.branchIds, r.from, r.to, r.timezone,
    );
    const [ret] = await tx.$queryRawUnsafe<{ count: number; refunds: string; ex_tax: string; restocked_cost: string; damaged_cost: string }[]>(
      `SELECT COUNT(DISTINCT sr.id)::int AS count,
              COALESCE(SUM(ri.line_total), 0)::text AS refunds,
              COALESCE(SUM(ri.line_total * (1 - si.tax_amount / NULLIF(si.line_total, 0))), 0)::text AS ex_tax,
              COALESCE(SUM(ri.cost_total) FILTER (WHERE ri.restock), 0)::text AS restocked_cost,
              COALESCE(SUM(ri.cost_total) FILTER (WHERE NOT ri.restock), 0)::text AS damaged_cost
       FROM sales_returns sr
       JOIN sales_return_items ri ON ri.return_id = sr.id
       JOIN sale_items si ON si.id = ri.sale_item_id
       WHERE sr.branch_id = ANY($1::uuid[]) AND sr.status = 'POSTED'
         AND (sr.return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date`,
      r.branchIds, r.from, r.to, r.timezone,
    );
    const [loss] = await tx.$queryRawUnsafe<{ damage: string; expired: string; adjust_out: string; adjust_in: string }[]>(
      `SELECT COALESCE(SUM(-m.quantity_delta * m.unit_cost) FILTER (WHERE m.movement_type = 'DAMAGE'), 0)::text AS damage,
              COALESCE(SUM(-m.quantity_delta * m.unit_cost) FILTER (WHERE m.movement_type = 'EXPIRED_WRITE_OFF'), 0)::text AS expired,
              COALESCE(SUM(-m.quantity_delta * m.unit_cost) FILTER (WHERE m.movement_type = 'ADJUSTMENT_OUT'), 0)::text AS adjust_out,
              COALESCE(SUM(m.quantity_delta * m.unit_cost) FILTER (WHERE m.movement_type = 'ADJUSTMENT_IN'), 0)::text AS adjust_in
       FROM inventory_movements m
       WHERE m.branch_id = ANY($1::uuid[]) AND (m.occurred_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date`,
      r.branchIds, r.from, r.to, r.timezone,
    );
    const expenses = await tx.$queryRawUnsafe<{ category: string; amount: string; count: number }[]>(
      `SELECT c.name AS category, SUM(e.amount)::text AS amount, COUNT(*)::int AS count
       FROM expenses e JOIN expense_categories c ON c.id = e.category_id
       WHERE e.branch_id = ANY($1::uuid[]) AND e.expense_date BETWEEN $2::date AND $3::date
       GROUP BY c.name ORDER BY SUM(e.amount) DESC`,
      r.branchIds, r.from, r.to,
    );
    const payments = await tx.$queryRawUnsafe<{ kind: string; method: string; amount: string; count: number }[]>(
      `SELECT p.kind::text, p.method::text, SUM(p.amount)::text AS amount, COUNT(*)::int AS count
       FROM payments p
       WHERE p.branch_id = ANY($1::uuid[]) AND (p.paid_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
       GROUP BY p.kind, p.method ORDER BY p.kind, p.method`,
      r.branchIds, r.from, r.to, r.timezone,
    );

    const revenueExTax = dec(sales.ex_tax);
    const returnsExTax = money2(ret.ex_tax);
    const cogs = dec(sales.cogs).minus(ret.restocked_cost);
    const grossProfit = revenueExTax.minus(returnsExTax).minus(cogs);
    const stockLoss = dec(loss.damage).plus(loss.expired).plus(loss.adjust_out).minus(loss.adjust_in);
    const expenseTotal = expenses.reduce((a, e) => a.plus(e.amount), dec(0));
    const netProfit = grossProfit.minus(stockLoss).minus(expenseTotal);
    const netSales = revenueExTax.minus(returnsExTax);
    const f = (v: Prisma.Decimal.Value) => money2(v).toFixed(2);
    return {
      from: r.from, to: r.to, branchIds: r.branchIds,
      sales: {
        invoices: sales.invoices,
        gross: f(sales.gross),
        discounts: f(sales.discounts),
        tax: f(sales.tax),
        rounding: f(sales.rounding),
        total: f(sales.total),
        revenueExTax: f(revenueExTax),
      },
      returns: { count: ret.count, refunds: f(ret.refunds), exTax: f(returnsExTax), tax: f(dec(ret.refunds).minus(ret.ex_tax)), damagedCost: f(ret.damaged_cost) },
      netSales: f(netSales),
      cogs: f(cogs),
      grossProfit: f(grossProfit),
      grossMarginPercent: netSales.isZero() ? null : grossProfit.div(netSales).times(100).toFixed(1),
      stockLoss: { total: f(stockLoss), damage: f(loss.damage), expired: f(loss.expired), adjustmentsOut: f(loss.adjust_out), adjustmentsIn: f(loss.adjust_in) },
      expenses: { total: f(expenseTotal), byCategory: expenses.map((e) => ({ ...e, amount: f(e.amount) })) },
      netProfit: f(netProfit),
      taxCollected: f(dec(sales.tax).minus(dec(ret.refunds).minus(ret.ex_tax))),
      payments: payments.map((p) => ({ ...p, amount: f(p.amount) })),
    };
  }

  /** Per-day revenue (ex tax), cost and gross profit, returns netted on the day they happened. */
  async daily(tx: Prisma.TransactionClient, r: Range) {
    return tx.$queryRawUnsafe<{ day: string; revenue: number; cost: number; profit: number; invoices: number; expenses: number }[]>(
      `WITH days AS (SELECT generate_series($2::date, $3::date, interval '1 day')::date AS day),
            s AS (SELECT (s.sold_at AT TIME ZONE $4::text)::date AS day, COUNT(DISTINCT s.id) AS invoices,
                         SUM(si.line_total - si.tax_amount) AS revenue, SUM(si.cost_total) AS cost
                  FROM sales s JOIN sale_items si ON si.sale_id = s.id
                  WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REVENUE_STATUSES}
                    AND (s.sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
                  GROUP BY 1),
            r AS (SELECT (sr.return_date AT TIME ZONE $4::text)::date AS day,
                         SUM(ri.line_total * (1 - si.tax_amount / NULLIF(si.line_total, 0))) AS revenue,
                         SUM(ri.cost_total) FILTER (WHERE ri.restock) AS cost
                  FROM sales_returns sr JOIN sales_return_items ri ON ri.return_id = sr.id JOIN sale_items si ON si.id = ri.sale_item_id
                  WHERE sr.branch_id = ANY($1::uuid[]) AND sr.status = 'POSTED'
                    AND (sr.return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
                  GROUP BY 1),
            e AS (SELECT expense_date AS day, SUM(amount) AS amount FROM expenses
                  WHERE branch_id = ANY($1::uuid[]) AND expense_date BETWEEN $2::date AND $3::date GROUP BY 1)
       SELECT to_char(d.day, 'YYYY-MM-DD') AS day,
              ROUND(COALESCE(s.revenue, 0) - COALESCE(r.revenue, 0), 2)::float8 AS revenue,
              ROUND(COALESCE(s.cost, 0) - COALESCE(r.cost, 0), 2)::float8 AS cost,
              ROUND(COALESCE(s.revenue, 0) - COALESCE(r.revenue, 0) - COALESCE(s.cost, 0) + COALESCE(r.cost, 0), 2)::float8 AS profit,
              COALESCE(s.invoices, 0)::int AS invoices,
              ROUND(COALESCE(e.amount, 0), 2)::float8 AS expenses
       FROM days d LEFT JOIN s ON s.day = d.day LEFT JOIN r ON r.day = d.day LEFT JOIN e ON e.day = d.day
       ORDER BY d.day`,
      r.branchIds, r.from, r.to, r.timezone,
    );
  }

  /** Closed shifts in the range with their variances (cash reconciliation). */
  async shifts(tx: Prisma.TransactionClient, r: Range) {
    return tx.$queryRawUnsafe<{ id: string; register: string; branch: string; opened_by: string; closed_by: string | null; opened_at: Date; closed_at: Date | null; status: string; opening: string; expected: string | null; counted: string | null; variance: string | null }[]>(
      `SELECT rs.id, cr.name AS register, b.name AS branch, ou.full_name AS opened_by, cu.full_name AS closed_by, rs.opened_at, rs.closed_at,
              rs.status::text, rs.opening_balance::text AS opening, rs.expected_closing_balance::text AS expected,
              rs.counted_closing_balance::text AS counted, rs.variance::text
       FROM register_sessions rs
       JOIN cash_registers cr ON cr.id = rs.register_id
       JOIN branches b ON b.id = cr.branch_id
       JOIN users ou ON ou.id = rs.opened_by_id
       LEFT JOIN users cu ON cu.id = rs.closed_by_id
       WHERE cr.branch_id = ANY($1::uuid[]) AND (rs.opened_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
       ORDER BY rs.opened_at DESC`,
      r.branchIds, r.from, r.to, r.timezone,
    );
  }
}
