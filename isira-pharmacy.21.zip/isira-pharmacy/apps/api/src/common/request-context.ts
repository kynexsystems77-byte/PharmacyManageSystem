import { AsyncLocalStorage } from 'node:async_hooks';
import { Injectable, NestMiddleware } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { Prisma } from '@kynex/database';

export interface AuthContext {
  userId: string;
  tenantId: string;
  sessionId: string;
  email: string;
  fullName: string;
  isOwner: boolean;
  /** Branches the user may work in (active only). */
  branchIds: ReadonlySet<string>;
  permissionsByBranch: ReadonlyMap<string, ReadonlySet<string>>;
  /** Union of permissions across all branches (used by tenant-level endpoints). */
  allPermissions: ReadonlySet<string>;
}

export interface RequestStore {
  requestId: string;
  ip: string | null;
  userAgent: string | null;
  auth?: AuthContext;
  branchId?: string;
  /** The request's tenant-scoped database transaction (set by TenantTransactionInterceptor). */
  tx?: Prisma.TransactionClient;
}

export const requestContext = new AsyncLocalStorage<RequestStore>();

export function getStore(): RequestStore {
  const store = requestContext.getStore();
  if (!store) {
    throw new Error('No request context is active');
  }
  return store;
}

@Injectable()
export class RequestContextMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void {
    const incoming = req.header('x-request-id');
    const requestId = incoming && /^[\w-]{8,64}$/.test(incoming) ? incoming : randomUUID();
    res.setHeader('x-request-id', requestId);
    requestContext.run(
      { requestId, ip: req.ip ?? null, userAgent: req.header('user-agent')?.slice(0, 300) ?? null },
      next,
    );
  }
}
