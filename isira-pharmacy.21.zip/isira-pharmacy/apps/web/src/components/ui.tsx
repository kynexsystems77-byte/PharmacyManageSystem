import clsx from 'clsx';
import type { ButtonHTMLAttributes, HTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx('rounded-xl border border-line bg-surface shadow-card', className)} {...props} />;
}

export function CardHeader({ title, action, className }: { title: string; action?: ReactNode; className?: string }) {
  return (
    <div className={clsx('flex items-center justify-between gap-2 border-b border-line px-4 py-3', className)}>
      <h2 className="text-sm font-semibold">{title}</h2>
      {action}
    </div>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost' | 'outline'; loading?: boolean };

export function Button({ variant = 'primary', loading, className, children, disabled, ...props }: ButtonProps) {
  return (
    <button
      disabled={disabled || loading}
      className={clsx(
        'inline-flex h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-60',
        variant === 'primary' && 'bg-brand text-brand-fg hover:opacity-90',
        variant === 'outline' && 'border border-line bg-surface hover:bg-subtle',
        variant === 'ghost' && 'hover:bg-subtle',
        className,
      )}
      {...props}
    >
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden />}
      {children}
    </button>
  );
}

export function Field({ label, error, children }: { label: string; error?: string | null; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-danger">{error}</span>}
    </label>
  );
}

/** True when the caller passes its own width utility (then the default w-full must not override it). */
export function hasWidth(className?: string): boolean {
  return /(^|\s)!?w-/.test(className ?? '');
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={clsx(
        'h-10 rounded-lg border border-line bg-surface px-3 text-sm placeholder:text-fg-muted/70 focus-visible:border-brand',
        !hasWidth(className) && 'w-full',
        className,
      )}
      {...props}
    />
  );
}

export function Badge({ tone = 'neutral', children }: { tone?: 'neutral' | 'success' | 'warning' | 'danger'; children: ReactNode }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium',
        tone === 'neutral' && 'bg-subtle text-fg-muted',
        tone === 'success' && 'bg-success/15 text-success',
        tone === 'warning' && 'bg-warning/15 text-warning',
        tone === 'danger' && 'bg-danger/15 text-danger',
      )}
    >
      {children}
    </span>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx('animate-pulse rounded-lg bg-subtle', className)} />;
}

export function Alert({ tone = 'danger', children }: { tone?: 'danger' | 'success'; children: ReactNode }) {
  return (
    <div
      role={tone === 'danger' ? 'alert' : 'status'}
      className={clsx('rounded-lg border px-3 py-2 text-sm', tone === 'danger' ? 'border-danger/30 bg-danger/10 text-danger' : 'border-success/30 bg-success/10 text-success')}
    >
      {children}
    </div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="px-4 py-8 text-center">
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="mt-1 text-xs text-fg-muted">{hint}</p>}
    </div>
  );
}

export function StatTile({
  label, value, icon, hint, tone = 'neutral',
}: { label: string; value: string; icon: ReactNode; hint?: ReactNode; tone?: 'neutral' | 'warning' | 'danger' | 'success' }) {
  return (
    <Card className="h-full p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium uppercase tracking-wide text-fg-muted">{label}</p>
          <p className="tabular mt-1 truncate text-2xl font-semibold">{value}</p>
        </div>
        <div
          className={clsx(
            'grid h-9 w-9 shrink-0 place-items-center rounded-lg',
            tone === 'neutral' && 'bg-brand/10 text-brand',
            tone === 'warning' && 'bg-warning/15 text-warning',
            tone === 'danger' && 'bg-danger/15 text-danger',
            tone === 'success' && 'bg-success/15 text-success',
          )}
        >
          {icon}
        </div>
      </div>
      {hint && <div className="mt-2 text-xs text-fg-muted">{hint}</div>}
    </Card>
  );
}
