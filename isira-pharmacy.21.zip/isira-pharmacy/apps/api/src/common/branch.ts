import { BadRequestException, ForbiddenException } from '@nestjs/common';
import type { PermissionKey } from '@kynex/contracts';
import { getStore, type AuthContext } from './request-context';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** The X-Branch-Id branch of a @BranchScoped() route (already validated by BranchGuard). */
export function currentBranchId(): string {
  const id = getStore().branchId;
  if (!id) throw new BadRequestException('A valid X-Branch-Id header is required');
  return id;
}

/** For routes where the branch header is optional: validates it when present. */
export function optionalBranchId(auth: AuthContext, header: string | undefined): string | null {
  if (!header) return null;
  if (!UUID_RE.test(header)) throw new BadRequestException('Invalid X-Branch-Id header');
  if (!auth.branchIds.has(header)) throw new ForbiddenException('You do not have access to this branch');
  return header;
}

/** Permission check against the current branch (or tenant-wide when no branch is selected). */
export function hasPermission(auth: AuthContext, permission: PermissionKey, branchId?: string | null): boolean {
  if (branchId) return auth.permissionsByBranch.get(branchId)?.has(permission) ?? false;
  return auth.allPermissions.has(permission);
}

export function requirePermission(auth: AuthContext, permission: PermissionKey, branchId?: string | null): void {
  if (!hasPermission(auth, permission, branchId)) throw new ForbiddenException(`Missing permission: ${permission}`);
}
