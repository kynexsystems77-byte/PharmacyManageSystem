import { createReadStream, promises as fs } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import type { Readable } from 'node:stream';
import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { Global, Inject, Injectable, Logger, Module, NotFoundException } from '@nestjs/common';
import { ENV, type Env } from '../config/env';

/**
 * File storage for attachments (prescription scans, PDFs).
 * Keys always start with the tenant id: "<tenantId>/prescriptions/<id>/<uuid>-<name>", so one tenant's files can never
 * be addressed through another tenant's records.
 */
export interface StoredObject { stream: Readable; contentType?: string; size?: number }

@Injectable()
export class StorageService {
  private readonly logger = new Logger('Storage');
  private readonly s3: S3Client | null;
  private readonly bucket: string | null;
  private readonly root: string;

  constructor(@Inject(ENV) env: Env) {
    this.root = resolve(env.STORAGE_DIR);
    if (env.S3_ENDPOINT && env.S3_BUCKET) {
      this.bucket = env.S3_BUCKET;
      this.s3 = new S3Client({
        endpoint: env.S3_ENDPOINT,
        region: env.S3_REGION,
        forcePathStyle: env.S3_FORCE_PATH_STYLE,
        credentials: env.S3_ACCESS_KEY && env.S3_SECRET_KEY ? { accessKeyId: env.S3_ACCESS_KEY, secretAccessKey: env.S3_SECRET_KEY } : undefined,
      });
      this.logger.log(`Attachments stored in S3 bucket "${env.S3_BUCKET}" at ${env.S3_ENDPOINT}`);
    } else {
      this.s3 = null;
      this.bucket = null;
      this.logger.log(`Attachments stored on local disk at ${this.root} (set S3_ENDPOINT and S3_BUCKET to use S3/MinIO)`);
    }
  }

  get driver(): 's3' | 'local' {
    return this.s3 ? 's3' : 'local';
  }

  private localPath(key: string): string {
    const p = resolve(join(this.root, key));
    if (!p.startsWith(this.root + sep)) throw new Error('Invalid storage key');
    return p;
  }

  async put(key: string, body: Buffer, contentType: string): Promise<void> {
    if (this.s3 && this.bucket) {
      await this.s3.send(new PutObjectCommand({ Bucket: this.bucket, Key: key, Body: body, ContentType: contentType }));
      return;
    }
    const p = this.localPath(key);
    await fs.mkdir(dirname(p), { recursive: true });
    await fs.writeFile(p, body);
  }

  async get(key: string): Promise<StoredObject> {
    try {
      if (this.s3 && this.bucket) {
        const res = await this.s3.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
        return { stream: res.Body as Readable, contentType: res.ContentType, size: res.ContentLength };
      }
      const p = this.localPath(key);
      const stat = await fs.stat(p);
      return { stream: createReadStream(p), size: stat.size };
    } catch (err) {
      const e = err as { code?: string; name?: string };
      if (e.code === 'ENOENT' || e.name === 'NoSuchKey' || e.name === 'NotFound') {
        this.logger.warn(`Missing object in storage: ${key}`);
        throw new NotFoundException('The file is missing from storage');
      }
      throw err;
    }
  }

  async delete(key: string): Promise<void> {
    if (this.s3 && this.bucket) {
      await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
      return;
    }
    await fs.rm(this.localPath(key), { force: true });
  }
}

@Global()
@Module({ providers: [StorageService], exports: [StorageService] })
export class StorageModule {}
