'use client';

import Link from 'next/link';
import { DataTable, KeyValue, PageHeader } from '@/components/kit';
import { Alert, Card, CardHeader, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, qty } from '@/lib/format';
import { errorMessage, useBranchQuery } from '@/lib/hooks';
import type { PurchaseReturn } from '@/lib/types';

export default function ReturnPage({ params }: { params: { id: string } }) {
  const { profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const { data: r, isLoading, error } = useBranchQuery<PurchaseReturn>(`/purchase-returns/${params.id}`);
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !r) return <Alert>{errorMessage(error) || 'Return not found'}</Alert>;
  return (
    <div className="space-y-4">
      <PageHeader back="/purchasing/returns" title={r.number} subtitle={r.supplier.name} />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Supplier', value: <Link className="text-brand hover:underline" href={`/purchasing/suppliers/${r.supplier.id}`}>{r.supplier.name}</Link> },
          { label: 'Purchase', value: r.purchase ? <Link className="text-brand hover:underline" href={`/purchasing/${r.purchase.id}`}>{r.purchase.number}</Link> : null },
          { label: 'Date', value: dateOnly(r.returnDate) },
          { label: 'Posted by', value: `${r.createdBy.fullName}, ${dateTime(r.createdAt)}` },
          { label: 'Credit', value: money(num(r.total), cur) },
          { label: 'Reason', value: r.reason },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Lines" />
        <DataTable
          rows={r.purchaseReturnItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => i.product.brandName },
            { key: 'b', header: 'Batch', cell: (i) => <span className="font-mono text-xs">{i.batch.batchNumber}</span> },
            { key: 'l', header: 'From', cell: (i) => i.location.name },
            { key: 'q', header: 'Qty', align: 'right', cell: (i) => `${qty(num(i.quantity))} ${i.product.baseUnit}` },
            { key: 'c', header: 'Unit', align: 'right', cell: (i) => money(num(i.unitCost), cur) },
            { key: 't', header: 'Total', align: 'right', cell: (i) => money(num(i.lineTotal), cur) },
          ]}
        />
      </Card>
    </div>
  );
}
