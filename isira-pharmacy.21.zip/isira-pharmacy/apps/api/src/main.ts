import 'reflect-metadata';
import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import { ENV, type Env } from './config/env';
import { configureApp } from './setup';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  const env = app.get<Env>(ENV);
  if (env.TRUST_PROXY > 0) app.set('trust proxy', env.TRUST_PROXY);
  configureApp(app, env);
  await app.listen(env.PORT);
  new Logger('Bootstrap').log(`API listening on http://localhost:${env.PORT}  (docs: /docs, health: /health)`);
}

bootstrap().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
