-- ============================================================================
-- Kynex Pharmacy - database hardening (idempotent: safe to run after EVERY migration)
-- Run as the owner role:  pnpm db:harden
--
-- What this does
--   1. Grants the least privileges the application role (kynex_app) needs
--   2. Row-Level Security on every table that has a tenant_id column
--   3. "Same tenant" triggers: a row may only reference rows of its own tenant
--   4. Append-only protection for the ledgers (stock movements, audit log, party/cash ledgers)
--   5. CHECK constraints for money/stock invariants
--   6. SECURITY DEFINER lookups needed BEFORE a tenant is known (login) and by background jobs
-- ============================================================================

-- ---------- 0. tenant context helper -----------------------------------------
CREATE OR REPLACE FUNCTION app_tenant_id() RETURNS uuid
LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.tenant_id', true), '')::uuid $$;

-- ---------- 1. privileges ----------------------------------------------------
GRANT USAGE ON SCHEMA public TO kynex_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO kynex_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO kynex_app;

DO $$
BEGIN
  IF to_regclass('public._prisma_migrations') IS NOT NULL THEN
    EXECUTE 'REVOKE ALL ON TABLE public._prisma_migrations FROM kynex_app';
  END IF;
  -- global reference data: the API only reads it (seed/migrations write it as owner)
  EXECUTE 'REVOKE INSERT, UPDATE, DELETE ON TABLE public.permissions FROM kynex_app';
  -- platform staff realm is not reachable from the tenant application role
  EXECUTE 'REVOKE ALL ON TABLE public.platform_admins FROM kynex_app';
END $$;

-- ---------- 2. Row-Level Security --------------------------------------------
-- Tables below are ENABLE (not FORCE): needed so SECURITY DEFINER lookups owned by the owner role work
-- before a tenant is known. The application role is still fully subject to the policies.
DO $$
DECLARE
  r record;
  unforced text[] := ARRAY['users', 'sessions', 'password_reset_tokens', 'outbox_events'];
BEGIN
  FOR r IN
    SELECT c.table_name
    FROM information_schema.columns c
    JOIN information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name AND t.table_type = 'BASE TABLE'
    WHERE c.table_schema = 'public' AND c.column_name = 'tenant_id'
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', r.table_name);
    IF r.table_name = ANY (unforced) THEN
      EXECUTE format('ALTER TABLE public.%I NO FORCE ROW LEVEL SECURITY', r.table_name);
    ELSE
      EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', r.table_name);
    END IF;
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON public.%I', r.table_name);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON public.%I USING (tenant_id = app_tenant_id()) WITH CHECK (tenant_id = app_tenant_id())',
      r.table_name);
  END LOOP;
END $$;

ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenants NO FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON tenants;
CREATE POLICY tenant_isolation ON tenants USING (id = app_tenant_id()) WITH CHECK (id = app_tenant_id());

-- ---------- 3. same-tenant references ----------------------------------------
CREATE OR REPLACE FUNCTION enforce_same_tenant() RETURNS trigger
LANGUAGE plpgsql AS
$$
DECLARE
  fk_col text := TG_ARGV[0];
  parent_table text := TG_ARGV[1];
  fk_val uuid;
  parent_ok boolean;
BEGIN
  EXECUTE format('SELECT ($1).%I', fk_col) INTO fk_val USING NEW;
  IF fk_val IS NULL THEN
    RETURN NEW;
  END IF;
  EXECUTE format('SELECT EXISTS (SELECT 1 FROM public.%I WHERE id = $1 AND tenant_id = $2)', parent_table)
    INTO parent_ok USING fk_val, NEW.tenant_id;
  IF NOT parent_ok THEN
    RAISE EXCEPTION 'cross-tenant reference blocked: %.% -> %', TG_TABLE_NAME, fk_col, parent_table
      USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END
$$;

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT cl.relname AS child, a.attname AS fk_col, pc.relname AS parent
    FROM pg_constraint c
    JOIN pg_class cl ON cl.oid = c.conrelid
    JOIN pg_class pc ON pc.oid = c.confrelid
    JOIN pg_namespace n ON n.oid = cl.relnamespace AND n.nspname = 'public'
    JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = c.conkey[1]
    WHERE c.contype = 'f'
      AND array_length(c.conkey, 1) = 1
      AND EXISTS (SELECT 1 FROM information_schema.columns
                  WHERE table_schema = 'public' AND table_name = cl.relname AND column_name = 'tenant_id')
      AND EXISTS (SELECT 1 FROM information_schema.columns
                  WHERE table_schema = 'public' AND table_name = pc.relname AND column_name = 'tenant_id')
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON public.%I',
                   left('trg_tenant_' || r.child || '_' || r.fk_col, 63), r.child);
    EXECUTE format(
      'CREATE TRIGGER %I BEFORE INSERT OR UPDATE OF %I, tenant_id ON public.%I FOR EACH ROW EXECUTE FUNCTION enforce_same_tenant(%L, %L)',
      left('trg_tenant_' || r.child || '_' || r.fk_col, 63), r.fk_col, r.child, r.fk_col, r.parent);
  END LOOP;
END $$;

-- ---------- 4. append-only ledgers -------------------------------------------
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger
LANGUAGE plpgsql AS
$$
BEGIN
  RAISE EXCEPTION '% is append-only: % is not allowed (create a reversing entry instead)', TG_TABLE_NAME, TG_OP
    USING ERRCODE = '42501';
END
$$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['inventory_movements', 'audit_logs', 'party_ledger_entries', 'cash_transactions']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_append_only ON public.%I', t);
    EXECUTE format('CREATE TRIGGER trg_append_only BEFORE UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION forbid_mutation()', t);
    EXECUTE format('DROP TRIGGER IF EXISTS trg_append_only_truncate ON public.%I', t);
    EXECUTE format('CREATE TRIGGER trg_append_only_truncate BEFORE TRUNCATE ON public.%I FOR EACH STATEMENT EXECUTE FUNCTION forbid_mutation()', t);
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON TABLE public.%I FROM kynex_app', t);
  END LOOP;
END $$;

-- ---------- 5. invariants ----------------------------------------------------
CREATE OR REPLACE FUNCTION harden_add_check(tbl text, cname text, expr text) RETURNS void
LANGUAGE plpgsql AS
$$
BEGIN
  EXECUTE format('ALTER TABLE public.%I DROP CONSTRAINT IF EXISTS %I', tbl, cname);
  EXECUTE format('ALTER TABLE public.%I ADD CONSTRAINT %I CHECK (%s)', tbl, cname, expr);
END
$$;

SELECT harden_add_check('stock_levels', 'ck_stock_levels_non_negative', 'quantity >= 0');
SELECT harden_add_check('products', 'ck_products_prices', 'selling_price >= 0 AND purchase_price >= 0');
SELECT harden_add_check('batches', 'ck_batches_cost', 'unit_cost >= 0');
SELECT harden_add_check('batches', 'ck_batches_dates', 'expiry_date IS NULL OR manufacture_date IS NULL OR manufacture_date <= expiry_date');
SELECT harden_add_check('inventory_movements', 'ck_movements_nonzero', 'quantity_delta <> 0');
SELECT harden_add_check('sale_items', 'ck_sale_items_qty', 'quantity > 0 AND base_quantity > 0');
SELECT harden_add_check('sale_item_allocations', 'ck_allocations_qty', 'base_quantity > 0');
SELECT harden_add_check('sales', 'ck_sales_totals', 'grand_total >= 0 AND paid_total >= 0 AND discount_total >= 0');
SELECT harden_add_check('purchase_items', 'ck_purchase_items_qty', 'quantity > 0');
SELECT harden_add_check('payments', 'ck_payments_positive', 'amount > 0');
SELECT harden_add_check('cash_transactions', 'ck_cash_nonzero', 'amount <> 0');
SELECT harden_add_check('document_sequences', 'ck_sequences_positive', 'next_value >= 1');
SELECT harden_add_check('party_ledger_entries', 'ck_ledger_one_party', '(customer_id IS NOT NULL) <> (supplier_id IS NOT NULL)');

DROP FUNCTION harden_add_check(text, text, text);

-- ---------- 6. lookups that must work before a tenant is known ---------------
-- SECURITY DEFINER = runs as the owner role, which bypasses RLS on these (non-forced) tables.
CREATE OR REPLACE FUNCTION auth_find_user_by_email(p_email text) RETURNS SETOF users
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT * FROM users WHERE email = lower(p_email) AND deleted_at IS NULL $$;

CREATE OR REPLACE FUNCTION auth_find_session(p_token_hash text) RETURNS SETOF sessions
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT * FROM sessions WHERE token_hash = p_token_hash AND revoked_at IS NULL AND expires_at > now() $$;

CREATE OR REPLACE FUNCTION auth_find_tenant(p_id uuid) RETURNS SETOF tenants
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT * FROM tenants WHERE id = p_id AND deleted_at IS NULL $$;

CREATE OR REPLACE FUNCTION auth_find_reset_token(p_token_hash text) RETURNS SETOF password_reset_tokens
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT * FROM password_reset_tokens WHERE token_hash = p_token_hash AND used_at IS NULL AND expires_at > now() $$;

-- background jobs: which tenants to iterate (each tenant is then processed inside withTenant)
CREATE OR REPLACE FUNCTION system_list_active_tenants() RETURNS TABLE (id uuid, slug text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT t.id, t.slug FROM tenants t WHERE t.status = 'ACTIVE' AND t.deleted_at IS NULL $$;

CREATE OR REPLACE FUNCTION system_tenants_with_pending_outbox() RETURNS TABLE (tenant_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT DISTINCT o.tenant_id FROM outbox_events o WHERE o.status = 'PENDING' AND o.available_at <= now() $$;

REVOKE ALL ON FUNCTION auth_find_user_by_email(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION auth_find_session(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION auth_find_tenant(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION auth_find_reset_token(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION system_list_active_tenants() FROM PUBLIC;
REVOKE ALL ON FUNCTION system_tenants_with_pending_outbox() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION auth_find_user_by_email(text) TO kynex_app;
GRANT EXECUTE ON FUNCTION auth_find_session(text) TO kynex_app;
GRANT EXECUTE ON FUNCTION auth_find_tenant(uuid) TO kynex_app;
GRANT EXECUTE ON FUNCTION auth_find_reset_token(text) TO kynex_app;
GRANT EXECUTE ON FUNCTION system_list_active_tenants() TO kynex_app;
GRANT EXECUTE ON FUNCTION system_tenants_with_pending_outbox() TO kynex_app;
