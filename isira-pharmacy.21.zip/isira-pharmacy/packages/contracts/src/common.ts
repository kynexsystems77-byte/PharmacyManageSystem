import { z } from 'zod';

/** Small shared building blocks for request schemas (Phase 5+). */

/** Money amount with at most 2 decimals, sent as a JSON number. Stored as NUMERIC(14,2). */
export const moneySchema = z.coerce
  .number()
  .finite()
  .min(0)
  .max(999_999_999_999)
  .refine((v) => Math.round(v * 100) / 100 === v, 'Use at most 2 decimals');

/** Unit price / cost with at most 4 decimals. Stored as NUMERIC(14,4). */
export const priceSchema = z.coerce
  .number()
  .finite()
  .min(0)
  .max(9_999_999_999)
  .refine((v) => Math.round(v * 10_000) / 10_000 === v, 'Use at most 4 decimals');

/** Quantity in base units with at most 3 decimals. Stored as NUMERIC(14,3). */
export const quantitySchema = z.coerce
  .number()
  .finite()
  .positive()
  .max(99_999_999_999)
  .refine((v) => Math.round(v * 1000) / 1000 === v, 'Use at most 3 decimals');

/** Signed, non-zero quantity (stock adjustments). */
export const signedQuantitySchema = z.coerce
  .number()
  .finite()
  .refine((v) => v !== 0, 'Quantity cannot be zero')
  .refine((v) => Math.abs(v) <= 99_999_999_999, 'Quantity is too large')
  .refine((v) => Math.round(v * 1000) / 1000 === v, 'Use at most 3 decimals');

export const percentSchema = z.coerce.number().finite().min(0).max(100);

/** YYYY-MM-DD calendar date (no time zone). */
export const dateOnlySchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');

/** Query-string boolean: "true" / "false" / "1" / "0". */
export const queryBoolSchema = z
  .union([z.boolean(), z.enum(['true', 'false', '1', '0'])])
  .transform((v) => v === true || v === 'true' || v === '1');

export const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === '' ? undefined : v))
    .optional();

export const nullableText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === '' ? null : v))
    .nullable()
    .optional();

/** Client-generated key that makes a write safe to retry (POS, payments). */
export const idempotencyKeySchema = z.string().trim().regex(/^[A-Za-z0-9_-]{8,80}$/, 'Invalid idempotency key');
