'use client';

import { Pencil, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ConfirmDialog, DataTable, KeyValue, PageHeader, useToast } from '@/components/kit';
import { ExpiryBadge } from '@/components/pickers';
import { draftFromProduct, draftToBody, ProductForm } from '@/components/product-form';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num, qty, titleCase, productName } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { FefoPreview, Product, ProductStock } from '@/lib/types';

export default function ProductPage({ params }: { params: { id: string } }) {
  const { id } = params;
  const router = useRouter();
  const toast = useToast();
  const { can, profile, branch } = useAuth();
  const cur = profile.tenant.currencyCode;
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const { data: p, isLoading, error } = useBranchQuery<Product>(`/products/${id}`);
  const stock = useBranchQuery<ProductStock>(can('inventory:read') ? `/products/${id}/stock` : null);
  const update = useApiMutation<ReturnType<typeof draftToBody>, Product>('PATCH', `/products/${id}`, {
    onSuccess: () => {
      toast.success('Product saved');
      setEditing(false);
    },
  });
  const remove = useApiMutation<void>('DELETE', `/products/${id}`, {
    onSuccess: () => {
      toast.success('Product deleted');
      router.push('/medicines');
    },
  });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !p) return <Alert>{errorMessage(error) || 'Product not found'}</Alert>;

  if (editing) {
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title={`Edit ${p.brandName}`} />
        <ProductForm
          mode="update"
          initial={draftFromProduct(p)}
          canEditPrices={can('product:price:update')}
          canDeactivate={can('product:deactivate')}
          submitting={update.isPending}
          error={update.error}
          onSubmit={(d) => {
            const body = draftToBody(d, 'update');
            // Without product:price:update, send the existing prices back unchanged (the server refuses any price change).
            if (!can('product:price:update')) {
              const { purchasePrice: _a, sellingPrice: _b, wholesalePrice: _c, ...rest } = body;
              const oldUnitPrice = (unitId?: string) => {
                const old = p.productUnits.find((x) => x.id === unitId)?.sellingPrice;
                return old === undefined || old === null ? null : Number(old);
              };
              update.mutate({ ...rest, units: body.units.map((u) => ({ ...u, sellingPrice: oldUnitPrice(u.id) })) } as typeof body);
            } else update.mutate(body);
          }}
          onCancel={() => setEditing(false)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <PageHeader
        back="/medicines"
        title={productName(p.brandName, p.strength)}
        subtitle={
          <span className="flex flex-wrap items-center gap-2">
            <span className="font-mono">{p.sku}</span>
            {p.requiresPrescription && <Badge tone="warning">Prescription</Badge>}
            {p.isControlled && <Badge tone="danger">Controlled</Badge>}
            {!p.isActive && <Badge>Inactive</Badge>}
          </span>
        }
        actions={
          <>
            {can('product:deactivate') && (
              <Button variant="outline" onClick={() => setConfirmDelete(true)}><Trash2 size={16} /> Delete</Button>
            )}
            {can('product:update') && <Button onClick={() => setEditing(true)}><Pencil size={16} /> Edit</Button>}
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Details" />
          <div className="p-4">
            <KeyValue
              items={[
                { label: 'Generic name', value: p.genericName },
                { label: 'Category', value: p.category.name },
                { label: 'Dosage form', value: titleCase(p.dosageForm) },
                { label: 'Base unit', value: p.baseUnit },
                { label: 'Barcode', value: p.barcode ? <span className="font-mono">{p.barcode}</span> : null },
                { label: 'Manufacturer', value: p.manufacturer?.name },
                { label: 'Preferred supplier', value: p.preferredSupplier?.name },
                { label: 'Tax', value: p.taxRate ? `${p.taxRate.name} (${num(p.taxRate.ratePercent)}%${p.taxRate.isInclusive ? ', inclusive' : ''})` : 'None' },
                { label: 'Track expiry', value: p.trackExpiry ? 'Yes' : 'No' },
                { label: 'Reorder level', value: `${qty(num(p.reorderLevel))} ${p.baseUnit}` },
              ]}
            />
            {p.description && <p className="mt-4 whitespace-pre-wrap border-t border-line pt-3 text-sm">{p.description}</p>}
          </div>
        </Card>
        <Card>
          <CardHeader title="Prices" />
          <div className="space-y-2 p-4 text-sm">
            <Row label={`Selling (per ${p.baseUnit})`} value={money(num(p.sellingPrice), cur)} strong />
            <Row label="Purchase" value={money(num(p.purchasePrice), cur)} />
            {p.wholesalePrice !== null && <Row label="Wholesale" value={money(num(p.wholesalePrice), cur)} />}
            {p.productUnits.length > 0 && <div className="border-t border-line pt-2 text-xs font-medium uppercase tracking-wide text-fg-muted">Sale units</div>}
            {p.productUnits.map((u) => (
              <Row
                key={u.id}
                label={`${u.name} (${qty(num(u.factorToBase))} ${p.baseUnit})${u.isDefaultSaleUnit ? ' · default' : ''}`}
                value={money(u.sellingPrice !== null ? num(u.sellingPrice) : num(p.sellingPrice) * num(u.factorToBase), cur)}
              />
            ))}
          </div>
          {can('product:price:update') && branch && <BranchPrice productId={id} branchName={branch.name} />}
        </Card>
      </div>

      {stock.data && (
        <Card>
          <CardHeader
            title={`Stock in ${branch?.name ?? 'this branch'}`}
            action={
              <span className="text-sm text-fg-muted">
                On hand <b className="text-fg">{qty(num(stock.data.total))}</b> · sellable <b className="text-fg">{qty(num(stock.data.sellable))}</b> {p.baseUnit}
              </span>
            }
          />
          <DataTable
            rows={stock.data.levels}
            rowKey={(l) => `${l.location.id}-${l.batch.id}`}
            onRowClick={(l) => router.push(`/inventory/batches/${l.batch.id}`)}
            empty={<p className="px-4 py-8 text-center text-sm text-fg-muted">No stock. Receive a purchase or add opening stock.</p>}
            columns={[
              { key: 'batch', header: 'Batch', cell: (l) => <span className="font-mono text-xs">{l.batch.batchNumber}</span> },
              { key: 'exp', header: 'Expiry', cell: (l) => <ExpiryBadge date={l.batch.expiryDate} warnDays={stock.data.expiryWarningDays} /> },
              { key: 'loc', header: 'Location', cell: (l) => l.location.name },
              { key: 'status', header: 'Status', cell: (l) => <Badge tone={l.batch.status === 'ACTIVE' ? 'success' : 'warning'}>{titleCase(l.batch.status)}</Badge> },
              ...(can('report:financial:view') ? [{ key: 'cost', header: 'Unit cost', align: 'right' as const, cell: (l: ProductStock['levels'][number]) => money(num(l.batch.unitCost), cur) }] : []),
              { key: 'qty', header: 'Quantity', align: 'right', cell: (l) => qty(num(l.quantity)) },
            ]}
          />
          <div className="flex flex-wrap gap-3 border-t border-line px-4 py-3 text-sm">
            <Link className="font-medium text-brand hover:underline" href={`/inventory/ledger?productId=${id}`}>View stock ledger</Link>
            {can('inventory:adjust') && <Link className="font-medium text-brand hover:underline" href={`/inventory/opening-stock?productId=${id}`}>Add opening stock</Link>}
          </div>
        </Card>
      )}

      {can('batch:read') && <FefoTool productId={id} baseUnit={p.baseUnit} />}

      <ConfirmDialog
        open={confirmDelete}
        title="Delete product?"
        danger
        loading={remove.isPending}
        confirmLabel="Delete"
        onClose={() => setConfirmDelete(false)}
        onConfirm={() => remove.mutate(undefined, { onError: (e) => { toast.error(errorMessage(e)); setConfirmDelete(false); } })}
        body={<p>{p.brandName} will be removed from the catalogue. Invoices and the stock ledger keep their history. Products that still have stock cannot be deleted; deactivate them instead.</p>}
      />
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-fg-muted">{label}</span>
      <span className={`tabular ${strong ? 'text-base font-semibold' : ''}`}>{value}</span>
    </div>
  );
}

function BranchPrice({ productId, branchName }: { productId: string; branchName: string }) {
  const toast = useToast();
  const { data } = useBranchQuery<{ sellingPrice: string | null; reorderLevel: string | null; isAvailable: boolean }>(`/products/${productId}/branch-settings`);
  const [price, setPrice] = useState<string | null>(null);
  const [reorder, setReorder] = useState<string | null>(null);
  const save = useApiMutation<object>('PUT', `/products/${productId}/branch-settings`, { onSuccess: () => toast.success('Branch settings saved') });
  const priceVal = price ?? (data?.sellingPrice ? String(Number(data.sellingPrice)) : '');
  const reorderVal = reorder ?? (data?.reorderLevel ? String(Number(data.reorderLevel)) : '');
  return (
    <div className="space-y-3 border-t border-line p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-fg-muted">Override for {branchName}</p>
      <div className="grid grid-cols-2 gap-2">
        <Field label="Selling price"><Input type="number" step="0.0001" min="0" value={priceVal} placeholder="Default" onChange={(e) => setPrice(e.target.value)} /></Field>
        <Field label="Reorder level"><Input type="number" step="0.001" min="0" value={reorderVal} placeholder="Default" onChange={(e) => setReorder(e.target.value)} /></Field>
      </div>
      {save.error && <Alert>{errorMessage(save.error)}</Alert>}
      <Button
        variant="outline"
        className="w-full"
        loading={save.isPending}
        onClick={() => save.mutate({ sellingPrice: priceVal === '' ? null : Number(priceVal), reorderLevel: reorderVal === '' ? null : Number(reorderVal) })}
      >
        Save branch override
      </Button>
    </div>
  );
}

function FefoTool({ productId, baseUnit }: { productId: string; baseUnit: string }) {
  const [q, setQ] = useState('10');
  const n = Number(q);
  const { data, error, isFetching } = useBranchQuery<FefoPreview>(n > 0 ? `/inventory/fefo${qs({ productId, quantity: n })}` : null);
  return (
    <Card>
      <CardHeader title="FEFO preview" action={<span className="text-xs text-fg-muted">Which batches a sale would use right now</span>} />
      <div className="flex flex-wrap items-end gap-3 p-4">
        <Field label={`Quantity (${baseUnit})`}><Input type="number" min="0.001" step="0.001" value={q} onChange={(e) => setQ(e.target.value)} className="w-40" /></Field>
        {data && (
          <p className="pb-2 text-sm">
            {data.fulfilled ? <Badge tone="success">Fully available</Badge> : <Badge tone="danger">Short by {qty(num(data.shortfall))}</Badge>}
            {data.minDaysToExpiryForSale > 0 && <span className="ml-2 text-xs text-fg-muted">Batches with under {data.minDaysToExpiryForSale} days left are not sold.</span>}
          </p>
        )}
      </div>
      {error && <div className="px-4 pb-4"><Alert>{errorMessage(error)}</Alert></div>}
      {data && data.allocations.length > 0 && (
        <DataTable
          rows={data.allocations}
          loading={isFetching}
          rowKey={(a) => a.batchId}
          columns={[
            { key: 'b', header: 'Batch', cell: (a) => <span className="font-mono text-xs">{a.batchNumber}</span> },
            { key: 'e', header: 'Expiry', cell: (a) => <ExpiryBadge date={a.expiryDate} /> },
            { key: 'q', header: 'Takes', align: 'right', cell: (a) => `${qty(num(a.quantity))} ${baseUnit}` },
          ]}
        />
      )}
    </Card>
  );
}
