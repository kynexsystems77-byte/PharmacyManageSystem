'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { ExpiryBadge, LocationSelect } from '@/components/pickers';
import { Badge, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, qty, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { BatchRow } from '@/lib/types';

const VIEWS = [
  { v: 'expiring30', l: 'Expiring in 30 days', p: { expiringWithinDays: 30 } },
  { v: 'expiring90', l: 'Expiring in 90 days', p: { expiringWithinDays: 90 } },
  { v: 'expired', l: 'Expired (on hand)', p: { expired: true } },
  { v: 'all', l: 'All batches with stock', p: {} },
  { v: 'quarantined', l: 'Quarantined', p: { status: 'QUARANTINED' } },
  { v: 'recalled', l: 'Recalled', p: { status: 'RECALLED' } },
  { v: 'history', l: 'All batches (incl. empty)', p: { inStock: false } },
] as const;

export default function BatchesPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const initialView = useSearchParams().get('view');
  const [view, setView] = useState<(typeof VIEWS)[number]['v']>(VIEWS.some((x) => x.v === initialView) ? (initialView as (typeof VIEWS)[number]['v']) : 'expiring90');
  const [search, setSearch] = useState('');
  const [locationId, setLocationId] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([view, s, locationId]);
  const v = VIEWS.find((x) => x.v === view)!;
  const { data, isLoading, isFetching } = useBranchQuery<Paged<BatchRow> & { today: string }>(
    `/inventory/batches${qs({ page, pageSize: 25, search: s, locationId, sort: 'expiry', ...v.p })}`,
    { keepPrevious: true },
  );
  return (
    <div>
      <PageHeader title="Batches & expiry" subtitle="FEFO sells the earliest-expiring sellable batch first. Expired batches can never be sold." />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_220px_200px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Batch number or product" />
          <Select value={view} onChange={(e) => setView(e.target.value as typeof view)} aria-label="View">
            {VIEWS.map((x) => <option key={x.v} value={x.v}>{x.l}</option>)}
          </Select>
          <LocationSelect value={locationId} onChange={setLocationId} allowAll />
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(b) => b.id}
          onRowClick={(b) => router.push(`/inventory/batches/${b.id}`)}
          columns={[
            { key: 'p', header: 'Product', cell: (b) => <div><p className="font-medium">{b.brandName}</p><p className="text-xs text-fg-muted">{b.sku}</p></div> },
            { key: 'b', header: 'Batch', cell: (b) => <span className="font-mono text-xs">{b.batchNumber}</span> },
            { key: 'e', header: 'Expiry', cell: (b) => <ExpiryBadge date={b.expiryDate} /> },
            { key: 's', header: 'Status', cell: (b) => <Badge tone={b.status === 'ACTIVE' ? (b.sellable ? 'success' : 'danger') : 'warning'}>{b.status === 'ACTIVE' && !b.sellable ? 'Expired' : titleCase(b.status)}</Badge> },
            { key: 'sup', header: 'Supplier', cell: (b) => b.supplierName ?? '-' },
            { key: 'r', header: 'Received', cell: (b) => dateOnly(b.receivedAt) },
            ...(can('report:financial:view') ? [{ key: 'c', header: 'Unit cost', align: 'right' as const, cell: (b: BatchRow) => money(num(b.unitCost), cur) }] : []),
            { key: 'q', header: 'On hand', align: 'right', cell: (b) => <span className="font-medium">{qty(num(b.quantity))} <span className="text-xs font-normal text-fg-muted">{b.baseUnit}</span></span> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
