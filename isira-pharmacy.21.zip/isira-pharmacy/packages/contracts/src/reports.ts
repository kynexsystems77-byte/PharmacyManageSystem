import { z } from 'zod';
import { dateOnlySchema } from './common';
import type { PermissionKey } from './permissions';
import { uuidSchema } from './schemas';

/** Phase 10: report catalogue (shared by the API and the web app). */

export type ReportParam = 'range' | 'days' | 'category' | 'scope';

export interface ReportDefinition {
  key: string;
  title: string;
  group: 'Sales' | 'Finance' | 'Inventory' | 'Parties';
  description: string;
  permission: PermissionKey;
  params: ReportParam[];
}

export const REPORTS: readonly ReportDefinition[] = [
  { key: 'sales-daily', title: 'Daily sales', group: 'Sales', description: 'Invoices, discounts, tax, returns and net sales per day.', permission: 'report:sales:view', params: ['range', 'scope'] },
  { key: 'sales-by-product', title: 'Sales by product', group: 'Sales', description: 'Quantity, revenue and (with financial access) profit per product.', permission: 'report:sales:view', params: ['range', 'scope', 'category'] },
  { key: 'sales-by-category', title: 'Sales by category', group: 'Sales', description: 'Revenue and profit per category.', permission: 'report:sales:view', params: ['range', 'scope'] },
  { key: 'sales-by-cashier', title: 'Sales by cashier', group: 'Sales', description: 'Invoices, revenue, discounts, voids and returns per cashier.', permission: 'report:sales:view', params: ['range', 'scope'] },
  { key: 'payments-by-method', title: 'Payments by method', group: 'Sales', description: 'Money received and refunded per day and payment method.', permission: 'report:sales:view', params: ['range', 'scope'] },
  { key: 'profit-loss', title: 'Profit and loss', group: 'Finance', description: 'Net sales, cost of goods, gross profit, losses, expenses and net profit.', permission: 'report:financial:view', params: ['range', 'scope'] },
  { key: 'tax', title: 'Tax collected', group: 'Finance', description: 'Taxable sales and tax per tax rate, net of returns.', permission: 'report:financial:view', params: ['range', 'scope'] },
  { key: 'expenses', title: 'Expenses', group: 'Finance', description: 'Every expense in the period.', permission: 'report:financial:view', params: ['range', 'scope'] },
  { key: 'stock-valuation', title: 'Stock valuation', group: 'Inventory', description: 'On-hand quantity, cost value and retail value per product.', permission: 'report:inventory:view', params: ['scope', 'category'] },
  { key: 'expiry', title: 'Expiry', group: 'Inventory', description: 'Batches already expired or expiring within N days, with the value at risk.', permission: 'report:inventory:view', params: ['days', 'scope'] },
  { key: 'reorder', title: 'Reorder list', group: 'Inventory', description: 'Products at or below their reorder level with a suggested order quantity.', permission: 'report:inventory:view', params: ['scope', 'category'] },
  { key: 'dead-stock', title: 'Slow and dead stock', group: 'Inventory', description: 'Products with stock that have not sold in N days.', permission: 'report:inventory:view', params: ['days', 'scope'] },
  { key: 'stock-movements', title: 'Stock movement summary', group: 'Inventory', description: 'In and out quantities per product and movement type.', permission: 'report:inventory:view', params: ['range', 'scope'] },
  { key: 'receivables-aging', title: 'Receivables aging', group: 'Parties', description: 'What customers owe, by age of the credit sale.', permission: 'report:financial:view', params: [] },
  { key: 'payables-aging', title: 'Payables aging', group: 'Parties', description: 'What the pharmacy owes suppliers, by days past due.', permission: 'report:financial:view', params: [] },
  { key: 'purchases-by-supplier', title: 'Purchases by supplier', group: 'Parties', description: 'Received purchases, returns and payments per supplier.', permission: 'report:financial:view', params: ['range', 'scope'] },
] as const;

export const REPORT_KEYS = REPORTS.map((r) => r.key) as [string, ...string[]];

export const reportQuerySchema = z.object({
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
  scope: z.enum(['branch', 'all']).default('branch'),
  days: z.coerce.number().int().min(1).max(3650).default(60),
  categoryId: uuidSchema.optional(),
  format: z.enum(['json', 'csv', 'xlsx', 'pdf']).default('json'),
});

export type ColumnType = 'text' | 'number' | 'money' | 'quantity' | 'percent' | 'date' | 'datetime';
export interface ReportColumn { key: string; label: string; type: ColumnType }
export interface ReportResult {
  key: string;
  title: string;
  subtitle: string;
  columns: ReportColumn[];
  rows: Record<string, string | number | null>[];
  totals?: Record<string, string | number | null>;
  notes?: string[];
  currencyCode: string;
  generatedAt: string;
}
