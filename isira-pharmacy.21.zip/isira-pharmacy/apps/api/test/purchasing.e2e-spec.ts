import { INestApplication } from '@nestjs/common';
import { bootApp, createProduct, expectStatus, isoDay, login, uid, type Session } from './helpers';

describe('Purchasing (Phase 6)', () => {
  let app: INestApplication;
  beforeAll(async () => {
    app = await bootApp();
  });
  afterAll(async () => {
    await app.close();
  });

  async function supplier(s: Session, terms = 30) {
    const res = await s.post('/suppliers', { name: `Supplier ${uid()}`, phone: '0771234567', paymentTermsDays: terms });
    expectStatus(res, 201);
    return res.body as { id: string; name: string };
  }

  it('manages suppliers and refuses duplicate names', async () => {
    const owner = await login(app, 'owner@demo.local');
    const s = await supplier(owner);
    expect((await owner.post('/suppliers', { name: s.name.toLowerCase() })).status).toBe(409);
    const upd = await owner.patch(`/suppliers/${s.id}`, { contactName: 'Nimal', email: '' });
    expectStatus(upd, 200);
    expect(upd.body.contactName).toBe('Nimal');
    expect(upd.body.email).toBeNull();
  });

  it('receives a purchase: creates the batch at landed cost, adds stock and books the payable', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner, 30);
    const p = await createProduct(owner);
    const batchNumber = `GRN-${uid()}`;
    const res = await owner.post('/purchases', {
      supplierId: sup.id, supplierInvoiceNo: `INV-${uid()}`, receive: true,
      items: [{ productId: p.id, batchNumber, expiryDate: isoDay(500), quantity: 100, bonusQuantity: 10, unitCost: 2, discountAmount: 20, taxPercent: 10, sellingPrice: 4.5 }],
    });
    expectStatus(res, 201);
    expect(res.body.status).toBe('RECEIVED');
    expect(res.body.number).toMatch(/^GRN-\d{4}-\d{6}$/);
    // gross 200 - discount 20 = 180, tax 18 => 198
    expect(Number(res.body.grandTotal)).toBe(198);
    expect(res.body.dueDate.slice(0, 10)).toBe(isoDay(30));

    const stock = await owner.get(`/products/${p.id}/stock`);
    expect(Number(stock.body.total)).toBe(110); // bonus units included
    const batch = stock.body.levels[0].batch;
    expect(Number(batch.unitCost)).toBeCloseTo(180 / 110, 4); // landed cost excludes tax, spreads the discount over bonus units
    expect(Number(batch.sellingPrice)).toBe(4.5);

    const sup2 = await owner.get(`/suppliers/${sup.id}`);
    expect(sup2.body.balance).toBe('198.00');
    expect(sup2.body.openInvoices).toHaveLength(1);
  });

  it('validates expiry at receipt and protects existing batch numbers', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const expired = await owner.post('/purchases', { supplierId: sup.id, receive: true, items: [{ productId: p.id, batchNumber: 'X1', expiryDate: isoDay(-1), quantity: 1, unitCost: 1 }] });
    expect(expired.status).toBe(422);

    // a draft may be saved without an expiry date, but cannot be received like that
    const draft = await owner.post('/purchases', { supplierId: sup.id, items: [{ productId: p.id, batchNumber: 'X2', quantity: 5, unitCost: 1 }] });
    expectStatus(draft, 201);
    expect(draft.body.status).toBe('DRAFT');
    expect((await owner.post(`/purchases/${draft.body.id}/receive`)).status).toBe(422);
    const fixed = await owner.patch(`/purchases/${draft.body.id}`, { items: [{ productId: p.id, batchNumber: 'X2', expiryDate: isoDay(200), quantity: 5, unitCost: 1 }] });
    expectStatus(fixed, 200);
    expectStatus(await owner.post(`/purchases/${draft.body.id}/receive`), 201);
    expect((await owner.post(`/purchases/${draft.body.id}/receive`)).status).toBe(409);

    const clash = await owner.post('/purchases', { supplierId: sup.id, receive: true, items: [{ productId: p.id, batchNumber: 'X2', expiryDate: isoDay(300), quantity: 1, unitCost: 1 }] });
    expect(clash.status).toBe(409);
  });

  it('averages the cost when the same batch is received again', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const item = { productId: p.id, batchNumber: 'AVG-1', expiryDate: isoDay(400) };
    expectStatus(await owner.post('/purchases', { supplierId: sup.id, receive: true, items: [{ ...item, quantity: 10, unitCost: 1 }] }), 201);
    expectStatus(await owner.post('/purchases', { supplierId: sup.id, receive: true, items: [{ ...item, quantity: 30, unitCost: 3 }] }), 201);
    const stock = await owner.get(`/products/${p.id}/stock`);
    expect(Number(stock.body.total)).toBe(40);
    expect(Number(stock.body.levels[0].batch.unitCost)).toBe(2.5); // (10*1 + 30*3) / 40
  });

  it('follows a purchase order from draft to fully received', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const po = await owner.post('/purchase-orders', { supplierId: sup.id, items: [{ productId: p.id, orderedQuantity: 50, unitCost: 2 }] });
    expectStatus(po, 201);
    expect(po.body.number).toMatch(/^PO-/);
    // not yet sent: cannot receive against it
    const early = await owner.post('/purchases', { supplierId: sup.id, orderId: po.body.id, receive: true, items: [{ productId: p.id, batchNumber: `PO-${uid()}`, expiryDate: isoDay(300), quantity: 20, unitCost: 2 }] });
    expect(early.status).toBe(409);
    expectStatus(await owner.post(`/purchase-orders/${po.body.id}/order`), 201);

    const first = await owner.post('/purchases', { supplierId: sup.id, orderId: po.body.id, receive: true, items: [{ productId: p.id, batchNumber: `PO-${uid()}`, expiryDate: isoDay(300), quantity: 20, unitCost: 2 }] });
    expectStatus(first, 201);
    let order = await owner.get(`/purchase-orders/${po.body.id}`);
    expect(order.body.status).toBe('PARTIALLY_RECEIVED');
    expect(Number(order.body.purchaseOrderItems[0].receivedQuantity)).toBe(20);

    expectStatus(await owner.post('/purchases', { supplierId: sup.id, orderId: po.body.id, receive: true, items: [{ productId: p.id, batchNumber: `PO-${uid()}`, expiryDate: isoDay(300), quantity: 30, unitCost: 2 }] }), 201);
    order = await owner.get(`/purchase-orders/${po.body.id}`);
    expect(order.body.status).toBe('RECEIVED');
    expect(order.body.purchases).toHaveLength(2);
  });

  it('applies supplier payments to the oldest invoices first and never overpays an invoice', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const buy = async (qty: number, date: string, payment?: object) => {
      const res = await owner.post('/purchases', {
        supplierId: sup.id, purchaseDate: date, receive: true, payment,
        items: [{ productId: p.id, batchNumber: `PAY-${uid()}`, expiryDate: isoDay(300), quantity: qty, unitCost: 1 }],
      });
      expectStatus(res, 201);
      return res.body as { id: string; paidTotal: string };
    };
    const a = await buy(100, isoDay(-20), { amount: 40, method: 'BANK_TRANSFER', reference: 'TT-1' });
    expect(a.paidTotal).toBe('40');
    const b = await buy(50, isoDay(-5));

    const over = await owner.post(`/suppliers/${sup.id}/payments`, { amount: 61, method: 'CARD', purchaseId: a.id });
    expect(over.status).toBe(422);

    const pay = await owner.post(`/suppliers/${sup.id}/payments`, { amount: 80, method: 'BANK_TRANSFER' });
    expectStatus(pay, 201);
    expect(pay.body.applied).toEqual([
      { purchaseId: a.id, number: expect.any(String), amount: '60.00' },
      { purchaseId: b.id, number: expect.any(String), amount: '20.00' },
    ]);
    expect(pay.body.balance).toBe('30.00'); // 150 - 40 - 80

    const ledger = await owner.get(`/suppliers/${sup.id}/ledger`);
    expect(ledger.body.data[0].balance).toBe('30.00');
    expect(ledger.body.data.map((e: { entryType: string }) => e.entryType)).toEqual(['PAYMENT', 'PURCHASE_ON_CREDIT', 'PAYMENT', 'PURCHASE_ON_CREDIT']);

    const payables = await owner.get('/suppliers/payables');
    expect(payables.body.suppliers.find((s: { id: string }) => s.id === sup.id).balance).toBe('30.00');
  });

  it('returns goods to the supplier: stock out, payable down, never more than received', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const buy = await owner.post('/purchases', { supplierId: sup.id, receive: true, items: [{ productId: p.id, batchNumber: `RET-${uid()}`, expiryDate: isoDay(300), quantity: 10, unitCost: 3 }] });
    expectStatus(buy, 201);
    const batchId = buy.body.purchaseItems[0].batchId as string;
    const locationId = buy.body.location.id as string;

    const tooMany = await owner.post('/purchase-returns', { supplierId: sup.id, purchaseId: buy.body.id, items: [{ batchId, locationId, quantity: 11 }] });
    expect(tooMany.status).toBe(422);
    const ret = await owner.post('/purchase-returns', { supplierId: sup.id, purchaseId: buy.body.id, reason: 'Damaged in transit', items: [{ batchId, locationId, quantity: 4 }] });
    expectStatus(ret, 201);
    expect(ret.body.total).toBe('12');
    expect(Number((await owner.get(`/products/${p.id}/stock`)).body.total)).toBe(6);
    expect((await owner.get(`/suppliers/${sup.id}`)).body.balance).toBe('18.00');
  });

  it('enforces purchasing permissions per role', async () => {
    const owner = await login(app, 'owner@demo.local');
    const sup = await supplier(owner);
    const p = await createProduct(owner);
    const item = { productId: p.id, batchNumber: `PERM-${uid()}`, expiryDate: isoDay(300), quantity: 1, unitCost: 1 };
    const cashier = await login(app, 'cashier@demo.local');
    expect((await cashier.post('/purchases', { supplierId: sup.id, items: [item] })).status).toBe(403);
    const pharmacist = await login(app, 'pharmacist@demo.local');
    expectStatus(await pharmacist.post('/purchases', { supplierId: sup.id, receive: true, items: [item] }), 201);
    const withPay = await pharmacist.post('/purchases', { supplierId: sup.id, receive: true, payment: { amount: 1, method: 'CASH' }, items: [{ ...item, batchNumber: `PERM-${uid()}` }] });
    expect(withPay.status).toBe(400);
    expect((await pharmacist.post(`/suppliers/${sup.id}/payments`, { amount: 1, method: 'CASH' })).status).toBe(403);
  });
});
