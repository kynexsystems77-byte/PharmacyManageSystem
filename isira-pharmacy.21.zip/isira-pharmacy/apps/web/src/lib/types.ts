/** Response shapes of the API endpoints this app uses (mirrors apps/api). */

export interface BranchAccess {
  id: string;
  name: string;
  code: string;
  permissions: string[];
}

export interface Profile {
  user: { id: string; email: string; fullName: string; isOwner: boolean; mfaEnabled: boolean };
  tenant: { id: string; name: string; slug: string; currencyCode: string; timezone: string };
  branches: BranchAccess[];
}

export interface DayPoint { day: string; total: number; count: number }

export interface Dashboard {
  generatedAt: string;
  currencyCode: string;
  timezone: string;
  unreadNotifications: number;
  sales: {
    today: { total: number; count: number; average: number };
    yesterday: { total: number; count: number };
    last7Days: DayPoint[];
    heldBills: number;
    profitToday: number | null;
    topProducts: { productId: string; name: string; quantity: number; revenue: number }[];
    recent: { id: string; invoiceNo: string | null; total: number; status: string; soldAt: string | null; cashier: string; customer: string | null }[];
  } | null;
  inventory: {
    lowStockCount: number;
    expiringSoonCount: number;
    expiredCount: number;
    stockValue: number | null;
    lowStock: { productId: string; name: string; sku: string; quantity: number; reorderLevel: number }[];
    expiring: { batchId: string; name: string; batchNumber: string; expiryDate: string; daysLeft: number; quantity: number }[];
  } | null;
}

// ---------------------------------------------------------------------------------------------
// Phase 5: catalogue + inventory. Decimals are strings (exact values from the API).
// ---------------------------------------------------------------------------------------------
export type Dec = string;

export interface Location { id: string; name: string; type: string; isDefault: boolean }
export interface CurrentBranch {
  id: string; name: string; code: string; address: string | null; phone: string | null; email: string | null;
  invoicePrefix: string; receiptHeader: string | null; receiptFooter: string | null; taxNumber: string | null;
  isActive: boolean; locations: Location[];
}

export interface Category { id: string; name: string; parentId: string | null; sortOrder: number; isActive: boolean; productCount: number }
export interface TaxRate { id: string; name: string; ratePercent: Dec; isInclusive: boolean; isActive: boolean }
export interface Manufacturer { id: string; name: string; country: string | null; isActive: boolean }

export interface ProductUnit { id: string; name: string; factorToBase: Dec; barcode: string | null; sellingPrice: Dec | null; isDefaultSaleUnit: boolean }

export interface Product {
  id: string; sku: string; barcode: string | null; brandName: string; genericName: string | null; strength: string | null;
  dosageForm: string; baseUnit: string; requiresPrescription: boolean; isControlled: boolean; trackExpiry: boolean;
  purchasePrice: Dec; sellingPrice: Dec; wholesalePrice: Dec | null; reorderLevel: Dec; description: string | null;
  isActive: boolean; createdAt: string; updatedAt: string;
  categoryId: string; manufacturerId: string | null; preferredSupplierId: string | null; taxRateId: string | null;
  category: { id: string; name: string; parentId: string | null };
  manufacturer: { id: string; name: string } | null;
  preferredSupplier: { id: string; name: string } | null;
  taxRate: { id: string; name: string; ratePercent: Dec; isInclusive: boolean } | null;
  productUnits: ProductUnit[];
  // present with withStock=true
  stock?: Dec; branchSellingPrice?: Dec | null; branchReorderLevel?: Dec | null; availableInBranch?: boolean;
}

export interface StockRow {
  productId: string; sku: string; brandName: string; genericName: string | null; strength: string | null; dosageForm: string;
  baseUnit: string; categoryName: string; onHand: Dec; sellable: Dec; expired: Dec; expiring: Dec; nextExpiry: string | null;
  batches: number; value: Dec | null; reorderLevel: Dec; status: 'OK' | 'LOW' | 'OUT';
}

export interface BatchRow {
  id: string; batchNumber: string; expiryDate: string | null; manufactureDate: string | null; unitCost: Dec; sellingPrice: Dec | null;
  status: string; receivedAt: string; productId: string; brandName: string; sku: string; baseUnit: string; supplierName: string | null;
  quantity: Dec; daysLeft: number | null; sellable: boolean;
}

export interface Movement {
  id: string; movementType: string; quantityDelta: Dec; unitCost: Dec; referenceType: string | null; referenceId: string | null;
  reason: string | null; occurredAt: string;
  product: { id: string; brandName: string; sku: string; baseUnit: string };
  batch: { id: string; batchNumber: string; expiryDate: string | null };
  location: { id: string; name: string };
  createdBy: { id: string; fullName: string } | null;
}

export interface Adjustment {
  id: string; number: string; reason: string; note: string | null; status: string; postedAt: string | null; createdAt: string;
  location: { id: string; name: string }; createdBy: { id: string; fullName: string };
  stockAdjustmentItems: {
    id: string; quantityDelta: Dec; unitCost: Dec; note: string | null;
    product: { id: string; brandName: string; sku: string; baseUnit: string };
    batch: { id: string; batchNumber: string; expiryDate: string | null };
  }[];
}

export interface Transfer {
  id: string; number: string; status: string; note: string | null; dispatchedAt: string | null; receivedAt: string | null; createdAt: string;
  fromBranch: { id: string; name: string }; toBranch: { id: string; name: string };
  fromLocation: { id: string; name: string }; toLocation: { id: string; name: string };
  createdBy: { id: string; fullName: string }; receivedBy: { id: string; fullName: string } | null;
  stockTransferItems: {
    id: string; quantity: Dec; receivedQuantity: Dec;
    product: { id: string; brandName: string; sku: string; baseUnit: string };
    batch: { id: string; batchNumber: string; expiryDate: string | null; unitCost: Dec };
  }[];
}

export interface ProductStock {
  product: { id: string; brandName: string; baseUnit: string; reorderLevel: Dec };
  timezone: string; expiryWarningDays: number; total: Dec; sellable: Dec;
  levels: {
    quantity: Dec;
    location: { id: string; name: string; type: string };
    batch: { id: string; batchNumber: string; expiryDate: string | null; unitCost: Dec; sellingPrice: Dec | null; status: string; receivedAt: string };
  }[];
}

export interface FefoPreview {
  product: { id: string; brandName: string; baseUnit: string };
  location: { id: string; name: string };
  requested: Dec; minDaysToExpiryForSale: number;
  allocations: { batchId: string; batchNumber: string; expiryDate: string | null; unitCost: Dec; sellingPrice: Dec | null; quantity: Dec }[];
  shortfall: Dec; fulfilled: boolean;
}

// ---------------------------------------------------------------------------------------------
// Phase 6: purchasing
// ---------------------------------------------------------------------------------------------
export interface Supplier {
  id: string; name: string; contactName: string | null; phone: string | null; email: string | null; address: string | null;
  taxNumber: string | null; paymentTermsDays: number; notes: string | null; isActive: boolean; createdAt: string; balance?: Dec;
}

export interface SupplierDetail extends Supplier {
  balance: Dec; overdue: Dec;
  openInvoices: { id: string; number: string; supplierInvoiceNo: string | null; purchaseDate: string; dueDate: string | null; grandTotal: Dec; paidTotal: Dec; outstanding: Dec; overdue: boolean }[];
}

export interface LedgerEntry { id: string; entryType: string; amount: Dec; description: string | null; referenceType: string | null; referenceId: string | null; createdAt: string; balance: Dec }

export interface PurchaseItem {
  id: string; batchNumber: string; expiryDate: string | null; manufactureDate: string | null; quantity: Dec; bonusQuantity: Dec; unitCost: Dec;
  discountAmount: Dec; taxPercent: Dec; taxAmount: Dec; lineTotal: Dec; sellingPrice: Dec | null; batchId: string | null;
  product: { id: string; brandName: string; strength: string | null; sku: string; baseUnit: string; trackExpiry: boolean; sellingPrice?: Dec };
}

export interface Purchase {
  id: string; number: string; supplierInvoiceNo: string | null; status: 'DRAFT' | 'RECEIVED' | 'CANCELLED'; purchaseDate: string; dueDate: string | null;
  subtotal: Dec; discountTotal: Dec; taxTotal: Dec; grandTotal: Dec; paidTotal: Dec; notes: string | null; receivedAt: string | null; createdAt: string;
  orderId: string | null;
  supplier: { id: string; name: string; paymentTermsDays: number };
  location: { id: string; name: string };
  order: { id: string; number: string } | null;
  createdBy: { id: string; fullName: string };
  purchaseItems: PurchaseItem[];
  payments: { id: string; method: string; amount: Dec; reference: string | null; paidAt: string; note: string | null }[];
}

export interface PurchaseListRow {
  id: string; number: string; supplierInvoiceNo: string | null; status: string; purchaseDate: string; dueDate: string | null;
  grandTotal: Dec; paidTotal: Dec; receivedAt: string | null; supplier: { id: string; name: string }; itemCount: number;
}

export interface PurchaseOrder {
  id: string; number: string; status: string; orderDate: string; expectedDate: string | null; subtotal: Dec; taxTotal: Dec; grandTotal: Dec;
  notes: string | null; createdAt: string;
  supplier: { id: string; name: string; phone: string | null; email: string | null };
  createdBy: { id: string; fullName: string };
  purchaseOrderItems: { id: string; orderedQuantity: Dec; receivedQuantity: Dec; unitCost: Dec; taxPercent: Dec; lineTotal: Dec; product: { id: string; brandName: string; strength: string | null; sku: string; baseUnit: string; trackExpiry: boolean; sellingPrice?: Dec } }[];
  purchases: { id: string; number: string; status: string; receivedAt: string | null }[];
}

export interface PurchaseReturn {
  id: string; number: string; status: string; returnDate: string; total: Dec; reason: string | null; createdAt: string;
  supplier: { id: string; name: string }; purchase: { id: string; number: string } | null; createdBy: { id: string; fullName: string };
  purchaseReturnItems: { id: string; quantity: Dec; unitCost: Dec; lineTotal: Dec; product: { id: string; brandName: string; sku: string; baseUnit: string }; batch: { id: string; batchNumber: string; expiryDate: string | null }; location: { id: string; name: string } }[];
}

export interface Payables {
  today: string; totalPayable: Dec; totalOverdue: Dec;
  suppliers: { id: string; name: string; phone: string | null; balance: Dec; overdue: Dec; openInvoices: number; oldestDue: string | null }[];
}

// ---------------------------------------------------------------------------------------------
// Phase 7: POS, sales, shifts
// ---------------------------------------------------------------------------------------------
export interface QuoteLine {
  index: number; productId: string; name: string; strength: string | null; sku: string; baseUnit: string; requiresPrescription: boolean;
  unit: { id: string; name: string; factor: Dec } | null; quantity: Dec; baseQuantity: Dec; unitPrice: Dec; gross: Dec; discount: Dec;
  taxPercent: Dec; taxInclusive: boolean; tax: Dec; lineTotal: Dec; shortfall: Dec;
  allocations: { batchId: string; batchNumber: string; expiryDate: string | null; quantity: Dec }[];
}
export interface Quote {
  locationId: string; lines: QuoteLine[]; subtotal: Dec; discountTotal: Dec; taxTotal: Dec; roundingAdjustment: Dec; grandTotal: Dec;
  needsPrescription: boolean; maxDiscountPercent: number; warnings: string[];
}

export interface SaleItem {
  id: string; productName: string; sku: string | null; quantity: Dec; unitFactor: Dec; baseQuantity: Dec; unitPrice: Dec; discountAmount: Dec;
  taxPercent: Dec; taxAmount: Dec; lineTotal: Dec; costTotal: Dec; prescriptionItemId: string | null;
  product: { id: string; baseUnit: string; requiresPrescription: boolean };
  productUnit: { id: string; name: string } | null;
  saleItemAllocations: { id: string; baseQuantity: Dec; unitCost: Dec; expiryDate: string | null; batch: { id: string; batchNumber: string }; location: { id: string } }[];
  salesReturnItems: { quantity: Dec; lineTotal: Dec; costTotal: Dec }[];
}
export interface Sale {
  id: string; invoiceNo: string | null; status: string; subtotal: Dec; discountTotal: Dec; taxTotal: Dec; roundingAdjustment: Dec; grandTotal: Dec;
  paidTotal: Dec; changeGiven: Dec; balanceDue: Dec; notes: string | null; soldAt: string | null; heldAt: string | null; voidedAt: string | null;
  voidReason: string | null; createdAt: string; registerSessionId: string | null;
  branch: { id: string; name: string; code: string; address: string | null; phone: string | null; taxNumber: string | null; receiptHeader: string | null; receiptFooter: string | null };
  location: { id: string; name: string };
  cashier: { id: string; fullName: string };
  voidedBy: { id: string; fullName: string } | null;
  customer: { id: string; fullName: string; phone: string | null; code: string | null } | null;
  prescription: { id: string; prescriptionNumber: string | null; doctorName: string } | null;
  saleItems: SaleItem[];
  payments: { id: string; kind: string; method: string; amount: Dec; reference: string | null; paidAt: string }[];
  salesReturns: { id: string; number: string; total: Dec; refundMethod: string | null; returnDate: string; reason: string | null }[];
  warnings?: string[];
}
export interface SaleListRow {
  id: string; invoiceNo: string | null; status: string; grandTotal: Dec; paidTotal: Dec; balanceDue: Dec; discountTotal: Dec; soldAt: string | null;
  cashier: { id: string; fullName: string }; customer: { id: string; fullName: string } | null; itemCount: number; methods: string[];
}
export interface SalesReturn {
  id: string; number: string; status: string; returnDate: string; total: Dec; refundMethod: string | null; reason: string | null; createdAt: string;
  sale: { id: string; invoiceNo: string | null; customer: { id: string; fullName: string } | null };
  createdBy: { id: string; fullName: string }; approvedBy: { id: string; fullName: string } | null;
  salesReturnItems: { id: string; quantity: Dec; unitPrice: Dec; lineTotal: Dec; costTotal: Dec; restock: boolean; saleItem: { id: string; productName: string }; product: { id: string; baseUnit: string }; batch: { id: string; batchNumber: string } }[];
}

export interface Shift {
  id: string; status: 'OPEN' | 'CLOSED'; openedAt: string; closedAt: string | null; openingBalance: Dec; expectedClosingBalance: Dec | null;
  countedClosingBalance: Dec | null; variance: Dec | null; notes: string | null;
  register: { id: string; name: string; branchId: string };
  openedBy: { id: string; fullName: string }; closedBy: { id: string; fullName: string } | null;
}
export interface ShiftSummary {
  shift: Shift;
  sales: { count: number; total: Dec; discounts: Dec; tax: Dec; voided: number };
  returns: { count: number; total: Dec };
  payments: { kind: string; method: string; count: number; amount: Dec }[];
  cash: { type: string; count: number; amount: Dec }[];
  expectedCash: Dec;
}
export interface Register {
  id: string; name: string; isActive: boolean;
  registerSessions: { id: string; openedAt: string; openingBalance: Dec; openedBy: { id: string; fullName: string } }[];
}

// ---------------------------------------------------------------------------------------------
// Phase 8: customers, prescriptions
// ---------------------------------------------------------------------------------------------
export interface Customer {
  id: string; code: string | null; fullName: string; phone: string | null; email: string | null; address: string | null; dateOfBirth: string | null;
  creditLimit: Dec; notes: string | null; isActive: boolean; createdAt: string; balance?: Dec;
}
export interface CustomerDetail extends Customer {
  balance: Dec; availableCredit: Dec;
  stats: { visits: number; totalSpent: Dec; lastVisit: string | null };
  recentSales: { id: string; invoiceNo: string | null; status: string; grandTotal: Dec; balanceDue: Dec; soldAt: string | null; branch: { id: string; name: string }; itemCount: number }[];
  prescriptions: { id: string; prescriptionNumber: string | null; doctorName: string; prescribedDate: string; validUntil: string | null; status: string; itemCount: number }[];
}
export interface PrescriptionItem {
  id: string; medicineName: string; dosage: string | null; frequency: string | null; durationDays: number | null; quantityPrescribed: Dec | null;
  quantityDispensed: Dec; instructions: string | null; product: { id: string; brandName: string; strength: string | null; baseUnit: string; sku: string } | null;
}
export interface Prescription {
  id: string; prescriptionNumber: string | null; doctorName: string; doctorRegistration: string | null; prescribedDate: string; validUntil: string | null;
  notes: string | null; status: string; dispensable: boolean; createdAt: string;
  customer: { id: string; fullName: string; phone: string | null; code: string | null };
  branch: { id: string; name: string } | null; createdBy: { id: string; fullName: string };
  prescriptionItems: PrescriptionItem[];
  attachments?: { id: string; fileName: string; mimeType: string; sizeBytes: number; createdAt: string; uploadedBy: { fullName: string } | null }[];
  sales?: { id: string; invoiceNo: string | null; status: string; soldAt: string | null; grandTotal: Dec; branch: { name: string } }[];
}
export interface Receivables { total: Dec; customers: { id: string; fullName: string; phone: string | null; code: string | null; creditLimit: Dec; balance: Dec; lastActivity: string }[] }

// ---------------------------------------------------------------------------------------------
// Phase 9: finance
// ---------------------------------------------------------------------------------------------
export interface TenantSettings {
  minDaysToExpiryForSale: number; expiryWarningDays: number; refundApprovalThreshold: number; cashRoundingStep: number;
  requireOpenShiftForSale: boolean; allowRxWithoutRecord: boolean; lowStockAlerts: boolean; expiryAlerts: boolean;
}
export interface TenantInfo { id: string; name: string; currencyCode: string; timezone: string; settings: TenantSettings }

export interface ProfitAndLoss {
  from: string; to: string; branchIds: string[]; currencyCode: string; timezone: string;
  sales: { invoices: number; gross: Dec; discounts: Dec; tax: Dec; rounding: Dec; total: Dec; revenueExTax: Dec };
  returns: { count: number; refunds: Dec; exTax: Dec; tax: Dec; damagedCost: Dec };
  netSales: Dec; cogs: Dec; grossProfit: Dec; grossMarginPercent: string | null;
  stockLoss: { total: Dec; damage: Dec; expired: Dec; adjustmentsOut: Dec; adjustmentsIn: Dec };
  expenses: { total: Dec; byCategory: { category: string; amount: Dec; count: number }[] };
  netProfit: Dec; taxCollected: Dec;
  payments: { kind: string; method: string; amount: Dec; count: number }[];
  daily: { day: string; revenue: number; cost: number; profit: number; invoices: number; expenses: number }[];
  receivables: Dec; payables: Dec;
}
export interface Expense {
  id: string; amount: Dec; paymentMethod: string; description: string; expenseDate: string; reference: string | null; createdAt: string;
  registerSessionId: string | null; category: { id: string; name: string }; createdBy: { id: string; fullName: string };
}
export interface Reconciliation {
  shifts: { id: string; register: string; branch: string; openedBy: string; closedBy: string | null; openedAt: string; closedAt: string | null; status: string; opening: Dec; expected: Dec | null; counted: Dec | null; variance: Dec | null }[];
  totals: { shifts: number; open: number; shortages: number; netVariance: Dec };
}

// ---------------------------------------------------------------------------------------------
// Phase 11: notifications
// ---------------------------------------------------------------------------------------------
export interface AppNotification {
  id: string; type: string; severity: 'INFO' | 'WARNING' | 'CRITICAL'; title: string; body: string | null;
  data: { link?: string } | null; createdAt: string; branch: { id: string; name: string } | null; readAt: string | null;
}

// ---------------------------------------------------------------------------------------------
// Phase 12: administration
// ---------------------------------------------------------------------------------------------
export interface BranchRow extends Omit<CurrentBranch, 'locations'> { createdAt: string; locations: Location[] }
export interface UserRow {
  id: string; email: string; fullName: string; phone: string | null; status: 'ACTIVE' | 'INVITED' | 'DISABLED'; isOwner: boolean; lastLoginAt: string | null; createdAt: string; mfaEnabledAt: string | null;
  userBranchRoles: { branchId: string; roleId: string; branch: { name: string }; role: { name: string } }[];
}
export interface RoleRow {
  id: string; name: string; description: string | null; isSystem: boolean; systemKey: string | null; maxDiscountPercent: Dec;
  permissions: string[]; assignedUsers: number;
}
export interface PermissionRow { id: string; key: string; module: string; description: string }
export interface AuditRow {
  id: string; action: string; entityType: string; entityId: string | null; before: unknown; after: unknown; ipAddress: string | null;
  createdAt: string; branchId: string | null; requestId: string | null; user: { id: string; fullName: string; email: string } | null;
}

export interface MfaStatus { enabled: boolean; enabledAt: string | null; recoveryCodesLeft: number }
export interface MfaChallenge { mfaRequired: true; challenge: string }

export interface ExpiryCheckBatch {
  id: string; batchNumber: string; expiryDate: string | null; daysLeft: number | null; quantity: string;
  state: 'EXPIRED' | 'BLOCKED' | 'TOO_CLOSE' | 'EXPIRING' | 'OK';
}
export interface ExpiryCheck {
  product: { id: string; brandName: string; strength: string | null; baseUnit: string; trackExpiry: boolean };
  today: string; level: 'none' | 'warning' | 'danger'; message: string; warningDays: number; minDaysToExpiryForSale: number;
  next: ExpiryCheckBatch | null; sellableQuantity: string; unsellableQuantity: string; batches: ExpiryCheckBatch[];
}
