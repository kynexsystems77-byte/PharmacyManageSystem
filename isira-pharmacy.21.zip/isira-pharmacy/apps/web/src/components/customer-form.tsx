'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { errorMessage, useApiMutation } from '@/lib/hooks';
import type { Customer } from '@/lib/types';
import { Modal, Textarea, useToast } from './kit';
import { Alert, Button, Field, Input } from './ui';

export function CustomerFormModal({ customer, onClose, onSaved }: { customer?: Customer; onClose: () => void; onSaved?: (c: Customer) => void }) {
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({
    fullName: customer?.fullName ?? '', phone: customer?.phone ?? '', email: customer?.email ?? '', address: customer?.address ?? '',
    dateOfBirth: customer?.dateOfBirth?.slice(0, 10) ?? '', creditLimit: String(Number(customer?.creditLimit ?? 0)), notes: customer?.notes ?? '',
    isActive: customer?.isActive ?? true,
  });
  const save = useApiMutation<object, Customer>(customer ? 'PATCH' : 'POST', customer ? `/customers/${customer.id}` : '/customers', {
    onSuccess: (c) => { toast.success('Customer saved'); onSaved?.(c); onClose(); },
  });
  const t = (v: string) => (v.trim() === '' ? (customer ? null : undefined) : v.trim());
  const body = {
    fullName: f.fullName.trim(), phone: t(f.phone), email: f.email.trim() === '' ? (customer ? null : undefined) : f.email.trim(), address: t(f.address),
    dateOfBirth: f.dateOfBirth || (customer ? null : undefined), notes: t(f.notes),
    ...(can('customer:credit:manage') ? { creditLimit: Number(f.creditLimit || 0) } : {}),
    ...(customer ? { isActive: f.isActive } : {}),
  };
  return (
    <Modal open onClose={onClose} title={customer ? `Edit ${customer.fullName}` : 'New customer'} size="lg"
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button loading={save.isPending} disabled={f.fullName.trim().length < 2} onClick={() => save.mutate(body)}>Save</Button></>}>
      <div className="grid gap-3 sm:grid-cols-2">
        {save.error && <div className="sm:col-span-2"><Alert>{errorMessage(save.error)}</Alert></div>}
        <Field label="Full name *"><Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} autoFocus /></Field>
        <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} inputMode="tel" /></Field>
        <Field label="Email"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Date of birth"><Input type="date" value={f.dateOfBirth} onChange={(e) => setF({ ...f, dateOfBirth: e.target.value })} /></Field>
        <div className="sm:col-span-2"><Field label="Address"><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field></div>
        <Field label="Credit limit (0 = cash only)"><Input type="number" min="0" step="0.01" disabled={!can('customer:credit:manage')} value={f.creditLimit} onChange={(e) => setF({ ...f, creditLimit: e.target.value })} /></Field>
        {customer && <label className="flex items-end gap-2 pb-2 text-sm"><input type="checkbox" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} /> Active</label>}
        <div className="sm:col-span-2"><Field label="Notes (allergies, preferences…)"><Textarea value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} maxLength={1000} /></Field></div>
      </div>
    </Modal>
  );
}
