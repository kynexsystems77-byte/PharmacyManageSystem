'use client';

import { Trash2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { Forbidden, PageHeader, Select, useToast } from '@/components/kit';
import { BatchSelect, LocationSelect, ProductPicker } from '@/components/pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, num, qty } from '@/lib/format';
import { errorMessage, newKey, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { BatchRow, Location, Product, Transfer } from '@/lib/types';

interface Line { key: string; product: Product; batchId: string; batch?: BatchRow; quantity: string }
interface Destination { id: string; name: string; code: string; locations: Location[] }

export default function NewTransferPage() {
  const router = useRouter();
  const toast = useToast();
  const { can, branchId } = useAuth();
  const dests = useBranchQuery<Destination[]>('/inventory/transfer-destinations');
  const [fromLocationId, setFrom] = useState('');
  const [toBranchId, setToBranch] = useState('');
  const [toLocationId, setToLocation] = useState('');
  const [note, setNote] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const dest = useMemo(() => dests.data?.find((d) => d.id === toBranchId), [dests.data, toBranchId]);
  const create = useApiMutation<object, Transfer>('POST', '/inventory/transfers', {
    onSuccess: (t) => { toast.success(`${t.number} dispatched`); router.push(`/inventory/transfers/${t.id}`); },
  });
  if (!can('inventory:transfer')) return <Forbidden what="transfers" />;

  const setLine = (key: string, patch: Partial<Line>) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const valid = fromLocationId && toBranchId && lines.length > 0 && lines.every((l) => l.batchId && Number(l.quantity) > 0 && (!l.batch || Number(l.quantity) <= num(l.batch.quantity)));

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader back="/inventory/transfers" title="New stock transfer" subtitle="Dispatching removes the stock from the source location immediately." />
      <Card>
        <div className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="From location"><LocationSelect value={fromLocationId} onChange={(id) => { setFrom(id); setLines([]); }} /></Field>
          <Field label="To branch">
            <Select value={toBranchId} onChange={(e) => { setToBranch(e.target.value); setToLocation(''); }}>
              <option value="">Choose…</option>
              {dests.data?.map((d) => <option key={d.id} value={d.id}>{d.name}{d.id === branchId ? ' (this branch)' : ''}</option>)}
            </Select>
          </Field>
          <Field label="To location">
            <Select value={toLocationId} onChange={(e) => setToLocation(e.target.value)} disabled={!dest}>
              <option value="">Default location</option>
              {dest?.locations.filter((l) => l.id !== fromLocationId).map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </Select>
          </Field>
          <Field label="Note"><Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} /></Field>
        </div>
      </Card>
      <Card>
        <CardHeader title="Items" />
        <div className="space-y-3 p-4">
          <ProductPicker onPick={(p) => setLines((ls) => [...ls, { key: newKey(), product: p, batchId: '', quantity: '' }])} placeholder="Add a product (search or scan)" />
          {lines.map((l) => (
            <div key={l.key} className="grid items-end gap-2 rounded-lg border border-line p-3 md:grid-cols-[1.2fr_1.8fr_130px_auto]">
              <div className="pb-2 text-sm"><p className="font-medium">{l.product.brandName}</p><p className="text-xs text-fg-muted">{l.batch ? `${qty(num(l.batch.quantity))} available · exp ${dateOnly(l.batch.expiryDate)}` : l.product.sku}</p></div>
              <Field label="Batch"><BatchSelect productId={l.product.id} locationId={fromLocationId} value={l.batchId} onChange={(id, b) => setLine(l.key, { batchId: id, batch: b })} /></Field>
              <Field label={`Qty (${l.product.baseUnit})`}><Input type="number" min="0.001" step="0.001" value={l.quantity} onChange={(e) => setLine(l.key, { quantity: e.target.value })} /></Field>
              <button aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      </Card>
      {create.error && <Alert>{errorMessage(create.error)}</Alert>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
        <Button
          disabled={!valid}
          loading={create.isPending}
          onClick={() => create.mutate({ fromLocationId, toBranchId, toLocationId: toLocationId || undefined, note: note || undefined, items: lines.map((l) => ({ batchId: l.batchId, quantity: Number(l.quantity) })) })}
        >
          Dispatch transfer
        </Button>
      </div>
    </div>
  );
}
