import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { REPORTS, type ReportColumn, type ReportResult } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { hasPermission } from '../common/branch';
import { dec, money2, todayIn } from '../common/core';
import type { AuthContext } from '../common/request-context';
import { FinanceService } from '../finance/finance.service';

const REV = `('COMPLETED','PARTIALLY_RETURNED','RETURNED')`;

export interface ReportContext {
  tx: Prisma.TransactionClient;
  auth: AuthContext;
  branchIds: string[];
  branchNames: string;
  from: string;
  to: string;
  days: number;
  categoryId: string | null;
  timezone: string;
  currencyCode: string;
  /** Cost, profit and value columns are only included with report:financial:view in every covered branch. */
  financial: boolean;
}

type Row = Record<string, string | number | null>;
const col = (key: string, label: string, type: ReportColumn['type'] = 'text'): ReportColumn => ({ key, label, type });
const n = (v: unknown): number => (v === null || v === undefined ? 0 : Number(v));
const r2 = (v: unknown): number => Math.round(n(v) * 100) / 100;
const sum = (rows: Row[], key: string): number => r2(rows.reduce((a, r) => a + n(r[key]), 0));

@Injectable()
export class ReportsService {
  constructor(private readonly finance: FinanceService) {}

  definition(key: string) {
    const def = REPORTS.find((r) => r.key === key);
    if (!def) throw new NotFoundException('Unknown report');
    return def;
  }

  /** Branches covered: the selected one, or every branch where the user holds the report's permission. */
  branches(auth: AuthContext, permission: Parameters<typeof hasPermission>[1], current: string, scope: 'branch' | 'all'): string[] {
    if (scope === 'branch') {
      if (!hasPermission(auth, permission, current)) throw new ForbiddenException(`Missing permission: ${permission}`);
      return [current];
    }
    const ids = [...auth.branchIds].filter((b) => hasPermission(auth, permission, b));
    if (!ids.length) throw new ForbiddenException(`Missing permission: ${permission}`);
    return ids;
  }

  async run(key: string, ctx: ReportContext): Promise<ReportResult> {
    const def = this.definition(key);
    if (def.params.includes('range')) {
      if (!ctx.from || !ctx.to) throw new BadRequestException('from and to are required');
      if (ctx.from > ctx.to) throw new BadRequestException('from must be on or before to');
      const span = (Date.parse(ctx.to) - Date.parse(ctx.from)) / 86_400_000;
      if (span > 731) throw new BadRequestException('The period can be at most two years');
    }
    const fn: Record<string, (c: ReportContext) => Promise<Omit<ReportResult, 'key' | 'title' | 'subtitle' | 'currencyCode' | 'generatedAt'>>> = {
      'sales-daily': (c) => this.salesDaily(c),
      'sales-by-product': (c) => this.salesByProduct(c, 'product'),
      'sales-by-category': (c) => this.salesByProduct(c, 'category'),
      'sales-by-cashier': (c) => this.salesByCashier(c),
      'payments-by-method': (c) => this.paymentsByMethod(c),
      'profit-loss': (c) => this.profitLoss(c),
      tax: (c) => this.tax(c),
      expenses: (c) => this.expenses(c),
      'stock-valuation': (c) => this.stockValuation(c),
      expiry: (c) => this.expiry(c),
      reorder: (c) => this.reorder(c),
      'dead-stock': (c) => this.deadStock(c),
      'stock-movements': (c) => this.stockMovements(c),
      'receivables-aging': (c) => this.receivablesAging(c),
      'payables-aging': (c) => this.payablesAging(c),
      'purchases-by-supplier': (c) => this.purchasesBySupplier(c),
    };
    const out = await fn[key](ctx);
    const period = def.params.includes('range') ? `${ctx.from} to ${ctx.to}` : def.params.includes('days') ? `${ctx.days} days` : `as of ${todayIn(ctx.timezone)}`;
    return {
      key, title: def.title, subtitle: `${ctx.branchNames} · ${period}`, currencyCode: ctx.currencyCode, generatedAt: new Date().toISOString(), ...out,
    };
  }

  // ------------------------------------------------------------------------------------------ sales
  private async salesDaily(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH days AS (SELECT generate_series($2::date, $3::date, interval '1 day')::date AS day),
            s AS (SELECT (sold_at AT TIME ZONE $4::text)::date AS day, COUNT(*) AS invoices, SUM(subtotal) AS gross,
                         SUM(discount_total) AS discounts, SUM(tax_total) AS tax, SUM(grand_total) AS total
                  FROM sales WHERE branch_id = ANY($1::uuid[]) AND status IN ${REV}
                    AND (sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY 1),
            v AS (SELECT (voided_at AT TIME ZONE $4::text)::date AS day, COUNT(*) AS voids FROM sales
                  WHERE branch_id = ANY($1::uuid[]) AND status = 'VOIDED' AND (voided_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY 1),
            r AS (SELECT (return_date AT TIME ZONE $4::text)::date AS day, SUM(total) AS refunds FROM sales_returns
                  WHERE branch_id = ANY($1::uuid[]) AND status = 'POSTED' AND (return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY 1)
       SELECT to_char(d.day, 'YYYY-MM-DD') AS date, COALESCE(s.invoices, 0)::int AS invoices,
              ROUND(COALESCE(s.gross, 0), 2)::float8 AS gross, ROUND(COALESCE(s.discounts, 0), 2)::float8 AS discounts,
              ROUND(COALESCE(s.tax, 0), 2)::float8 AS tax, ROUND(COALESCE(s.total, 0), 2)::float8 AS total,
              ROUND(COALESCE(r.refunds, 0), 2)::float8 AS refunds, ROUND(COALESCE(s.total, 0) - COALESCE(r.refunds, 0), 2)::float8 AS net,
              COALESCE(v.voids, 0)::int AS voids
       FROM days d LEFT JOIN s ON s.day = d.day LEFT JOIN r ON r.day = d.day LEFT JOIN v ON v.day = d.day ORDER BY d.day`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    const columns = [
      col('date', 'Date', 'date'), col('invoices', 'Invoices', 'number'), col('gross', 'Gross', 'money'), col('discounts', 'Discounts', 'money'),
      col('tax', 'Tax', 'money'), col('total', 'Total sales', 'money'), col('refunds', 'Refunds', 'money'), col('net', 'Net received', 'money'), col('voids', 'Voids', 'number'),
    ];
    if (c.financial) {
      const daily = await this.finance.daily(c.tx, { from: c.from, to: c.to, timezone: c.timezone, branchIds: c.branchIds });
      const byDay = new Map(daily.map((d) => [d.day, d]));
      for (const r of rows) { const d = byDay.get(String(r.date)); r.profit = d ? d.profit : 0; }
      columns.push(col('profit', 'Gross profit', 'money'));
    }
    const totals: Row = { date: 'Total' };
    for (const k of ['invoices', 'gross', 'discounts', 'tax', 'total', 'refunds', 'net', 'voids', 'profit']) totals[k] = sum(rows, k);
    return { columns, rows, totals };
  }

  private async salesByProduct(c: ReportContext, by: 'product' | 'category') {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH s AS (
         SELECT si.product_id, SUM(si.base_quantity) AS qty, SUM(si.line_total - si.tax_amount) AS revenue, SUM(si.cost_total) AS cost, COUNT(DISTINCT s.id) AS invoices
         FROM sale_items si JOIN sales s ON s.id = si.sale_id
         WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REV} AND (s.sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
         GROUP BY si.product_id),
       r AS (
         SELECT ri.product_id, SUM(ri.quantity) AS qty, SUM(ri.line_total * (1 - si.tax_amount / NULLIF(si.line_total, 0))) AS revenue,
                SUM(ri.cost_total) FILTER (WHERE ri.restock) AS cost
         FROM sales_returns sr JOIN sales_return_items ri ON ri.return_id = sr.id JOIN sale_items si ON si.id = ri.sale_item_id
         WHERE sr.branch_id = ANY($1::uuid[]) AND sr.status = 'POSTED' AND (sr.return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
         GROUP BY ri.product_id),
       x AS (
         SELECT COALESCE(s.product_id, r.product_id) AS product_id, COALESCE(s.invoices, 0) AS invoices,
                COALESCE(s.qty, 0) - COALESCE(r.qty, 0) AS qty, COALESCE(r.qty, 0) AS returned,
                COALESCE(s.revenue, 0) - COALESCE(r.revenue, 0) AS revenue, COALESCE(s.cost, 0) - COALESCE(r.cost, 0) AS cost
         FROM s FULL JOIN r ON r.product_id = s.product_id)
       SELECT ${by === 'product' ? `p.sku, p.brand_name AS product, c.name AS category, p.base_unit AS unit,` : `c.name AS category,`}
              SUM(x.invoices)::int AS invoices, ROUND(SUM(x.qty), 3)::float8 AS quantity, ROUND(SUM(x.returned), 3)::float8 AS returned,
              ROUND(SUM(x.revenue), 2)::float8 AS revenue, ROUND(SUM(x.cost), 2)::float8 AS cost, ROUND(SUM(x.revenue - x.cost), 2)::float8 AS profit
       FROM x JOIN products p ON p.id = x.product_id JOIN categories c ON c.id = p.category_id
       WHERE ($5::uuid IS NULL OR p.category_id = $5::uuid OR c.parent_id = $5::uuid)
       GROUP BY ${by === 'product' ? 'p.id, p.sku, p.brand_name, c.name, p.base_unit' : 'c.id, c.name'}
       ORDER BY SUM(x.revenue) DESC`,
      c.branchIds, c.from, c.to, c.timezone, c.categoryId,
    );
    for (const r of rows) r.margin = n(r.revenue) ? Math.round((n(r.profit) / n(r.revenue)) * 1000) / 10 : null;
    const columns = by === 'product'
      ? [col('sku', 'SKU'), col('product', 'Product'), col('category', 'Category'), col('quantity', 'Qty sold (net)', 'quantity'), col('returned', 'Returned', 'quantity'), col('revenue', 'Revenue ex tax', 'money')]
      : [col('category', 'Category'), col('invoices', 'Invoices', 'number'), col('quantity', 'Qty sold (net)', 'quantity'), col('revenue', 'Revenue ex tax', 'money')];
    if (c.financial) columns.push(col('cost', 'Cost', 'money'), col('profit', 'Gross profit', 'money'), col('margin', 'Margin', 'percent'));
    const totals: Row = by === 'product' ? { sku: 'Total' } : { category: 'Total' };
    for (const k of ['revenue', 'cost', 'profit']) totals[k] = sum(rows, k);
    if (c.financial) totals.margin = n(totals.revenue) ? Math.round((n(totals.profit) / n(totals.revenue)) * 1000) / 10 : null;
    return { columns, rows: this.strip(rows, columns), totals, notes: ['Revenue excludes tax. Returns made in the period are deducted.'] };
  }

  private async salesByCashier(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH s AS (
         SELECT s.cashier_id, COUNT(*) FILTER (WHERE s.status IN ${REV}) AS invoices,
                SUM(s.grand_total) FILTER (WHERE s.status IN ${REV}) AS total,
                SUM(s.discount_total) FILTER (WHERE s.status IN ${REV}) AS discounts,
                COUNT(*) FILTER (WHERE s.status = 'VOIDED') AS voids,
                SUM(s.grand_total) FILTER (WHERE s.status = 'VOIDED') AS voided
         FROM sales s WHERE s.branch_id = ANY($1::uuid[]) AND s.status <> 'HELD' AND s.status <> 'DRAFT'
           AND (s.sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY s.cashier_id),
       r AS (
         SELECT created_by_id AS user_id, COUNT(*) AS returns, SUM(total) AS refunds FROM sales_returns
         WHERE branch_id = ANY($1::uuid[]) AND status = 'POSTED' AND (return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY 1)
       SELECT u.full_name AS cashier, COALESCE(s.invoices, 0)::int AS invoices, ROUND(COALESCE(s.total, 0), 2)::float8 AS total,
              ROUND(COALESCE(s.total, 0) / NULLIF(s.invoices, 0), 2)::float8 AS average, ROUND(COALESCE(s.discounts, 0), 2)::float8 AS discounts,
              COALESCE(s.voids, 0)::int AS voids, ROUND(COALESCE(s.voided, 0), 2)::float8 AS voided,
              COALESCE(r.returns, 0)::int AS returns, ROUND(COALESCE(r.refunds, 0), 2)::float8 AS refunds
       FROM users u LEFT JOIN s ON s.cashier_id = u.id LEFT JOIN r ON r.user_id = u.id
       WHERE s.cashier_id IS NOT NULL OR r.user_id IS NOT NULL
       ORDER BY COALESCE(s.total, 0) DESC`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    const columns = [
      col('cashier', 'Cashier'), col('invoices', 'Invoices', 'number'), col('total', 'Sales', 'money'), col('average', 'Average bill', 'money'),
      col('discounts', 'Discounts given', 'money'), col('voids', 'Voids', 'number'), col('voided', 'Voided value', 'money'), col('returns', 'Returns', 'number'), col('refunds', 'Refunded', 'money'),
    ];
    const totals: Row = { cashier: 'Total' };
    for (const k of ['invoices', 'total', 'discounts', 'voids', 'voided', 'returns', 'refunds']) totals[k] = sum(rows, k);
    return { columns, rows, totals };
  }

  private async paymentsByMethod(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `SELECT to_char((p.paid_at AT TIME ZONE $4::text)::date, 'YYYY-MM-DD') AS date, p.method::text AS method,
              ROUND(COALESCE(SUM(p.amount) FILTER (WHERE p.kind = 'SALE_PAYMENT'), 0), 2)::float8 AS sales,
              ROUND(COALESCE(SUM(p.amount) FILTER (WHERE p.kind = 'CUSTOMER_PAYMENT'), 0), 2)::float8 AS customer_payments,
              ROUND(COALESCE(SUM(p.amount) FILTER (WHERE p.kind = 'REFUND'), 0), 2)::float8 AS refunds,
              ROUND(COALESCE(SUM(p.amount) FILTER (WHERE p.kind = 'SUPPLIER_PAYMENT'), 0), 2)::float8 AS supplier_payments,
              COUNT(*)::int AS count
       FROM payments p
       WHERE p.branch_id = ANY($1::uuid[]) AND (p.paid_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
       GROUP BY 1, 2 ORDER BY 1, 2`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    for (const r of rows) r.net = r2(n(r.sales) + n(r.customer_payments) - n(r.refunds) - n(r.supplier_payments));
    const columns = [
      col('date', 'Date', 'date'), col('method', 'Method'), col('sales', 'Sales', 'money'), col('customer_payments', 'Customer payments', 'money'),
      col('refunds', 'Refunds', 'money'), col('supplier_payments', 'Paid to suppliers', 'money'), col('net', 'Net', 'money'),
    ];
    const totals: Row = { date: 'Total' };
    for (const k of ['sales', 'customer_payments', 'refunds', 'supplier_payments', 'net']) totals[k] = sum(rows, k);
    return { columns, rows, totals, notes: ['Customer credit is a promise to pay, not money received; it appears under Sales with method Customer credit.'] };
  }

  // ------------------------------------------------------------------------------------------ finance
  private async profitLoss(c: ReportContext) {
    const pl = await this.finance.profitAndLoss(c.tx, { from: c.from, to: c.to, timezone: c.timezone, branchIds: c.branchIds });
    const line = (label: string, amount: string | number, kind: 'line' | 'subtotal' | 'total' = 'line') => ({ label, amount: r2(amount), kind });
    const rows: Row[] = [
      line('Sales (before discounts)', pl.sales.gross),
      line('Discounts', -n(pl.sales.discounts)),
      line('Revenue excluding tax', pl.sales.revenueExTax, 'subtotal'),
      line('Customer returns (ex tax)', -n(pl.returns.exTax)),
      line('Net sales', pl.netSales, 'subtotal'),
      line('Cost of goods sold', -n(pl.cogs)),
      line('Gross profit', pl.grossProfit, 'subtotal'),
      line('Damaged stock', -n(pl.stockLoss.damage)),
      line('Expired stock written off', -n(pl.stockLoss.expired)),
      line('Count adjustments (net)', -(n(pl.stockLoss.adjustmentsOut) - n(pl.stockLoss.adjustmentsIn))),
      ...pl.expenses.byCategory.map((e) => line(`Expense: ${e.category}`, -n(e.amount))),
      line('Net profit', pl.netProfit, 'total'),
      line('Tax collected (owed to the tax authority)', pl.taxCollected),
    ];
    return {
      columns: [col('label', 'Line'), col('amount', 'Amount', 'money')],
      rows,
      notes: [`Gross margin ${pl.grossMarginPercent ?? '-'}%. ${pl.sales.invoices} invoices, ${pl.returns.count} returns.`],
    };
  }

  private async tax(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH s AS (
         SELECT si.tax_percent AS rate, SUM(si.line_total - si.tax_amount) AS taxable, SUM(si.tax_amount) AS tax
         FROM sale_items si JOIN sales s ON s.id = si.sale_id
         WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REV} AND (s.sold_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
         GROUP BY 1),
       r AS (
         SELECT si.tax_percent AS rate, SUM(ri.line_total * (1 - si.tax_amount / NULLIF(si.line_total, 0))) AS taxable,
                SUM(ri.line_total * si.tax_amount / NULLIF(si.line_total, 0)) AS tax
         FROM sales_returns sr JOIN sales_return_items ri ON ri.return_id = sr.id JOIN sale_items si ON si.id = ri.sale_item_id
         WHERE sr.branch_id = ANY($1::uuid[]) AND sr.status = 'POSTED' AND (sr.return_date AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
         GROUP BY 1)
       SELECT (COALESCE(s.rate, r.rate))::float8 AS rate,
              ROUND(COALESCE(s.taxable, 0), 2)::float8 AS taxable, ROUND(COALESCE(s.tax, 0), 2)::float8 AS tax,
              ROUND(COALESCE(r.taxable, 0), 2)::float8 AS returned_taxable, ROUND(COALESCE(r.tax, 0), 2)::float8 AS returned_tax,
              ROUND(COALESCE(s.tax, 0) - COALESCE(r.tax, 0), 2)::float8 AS net_tax
       FROM s FULL JOIN r ON r.rate = s.rate ORDER BY 1`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    const columns = [
      col('rate', 'Rate', 'percent'), col('taxable', 'Taxable sales', 'money'), col('tax', 'Tax charged', 'money'),
      col('returned_taxable', 'Returned (taxable)', 'money'), col('returned_tax', 'Tax refunded', 'money'), col('net_tax', 'Net tax', 'money'),
    ];
    const totals: Row = { rate: null };
    for (const k of ['taxable', 'tax', 'returned_taxable', 'returned_tax', 'net_tax']) totals[k] = sum(rows, k);
    return { columns, rows, totals };
  }

  private async expenses(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `SELECT to_char(e.expense_date, 'YYYY-MM-DD') AS date, b.name AS branch, ec.name AS category, e.description, e.payment_method::text AS method,
              e.reference, u.full_name AS entered_by, ROUND(e.amount, 2)::float8 AS amount
       FROM expenses e JOIN expense_categories ec ON ec.id = e.category_id JOIN branches b ON b.id = e.branch_id JOIN users u ON u.id = e.created_by_id
       WHERE e.branch_id = ANY($1::uuid[]) AND e.expense_date BETWEEN $2::date AND $3::date
       ORDER BY e.expense_date, e.created_at`,
      c.branchIds, c.from, c.to,
    );
    const columns = [col('date', 'Date', 'date'), col('branch', 'Branch'), col('category', 'Category'), col('description', 'Description'), col('method', 'Paid by'), col('reference', 'Reference'), col('entered_by', 'Entered by'), col('amount', 'Amount', 'money')];
    return { columns, rows, totals: { date: 'Total', amount: sum(rows, 'amount') } };
  }

  // ------------------------------------------------------------------------------------------ inventory
  private async stockValuation(c: ReportContext) {
    const today = todayIn(c.timezone);
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `SELECT p.sku, p.brand_name AS product, cat.name AS category, p.base_unit AS unit,
              ROUND(SUM(sl.quantity), 3)::float8 AS on_hand,
              ROUND(SUM(sl.quantity) FILTER (WHERE b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= $2::date)), 3)::float8 AS sellable,
              ROUND(SUM(sl.quantity * b.unit_cost), 2)::float8 AS cost_value,
              ROUND(SUM(sl.quantity * COALESCE(b.selling_price, bps.selling_price, p.selling_price)), 2)::float8 AS retail_value
       FROM stock_levels sl
       JOIN batches b ON b.id = sl.batch_id
       JOIN products p ON p.id = sl.product_id
       JOIN categories cat ON cat.id = p.category_id
       LEFT JOIN branch_product_settings bps ON bps.product_id = p.id AND bps.branch_id = sl.branch_id
       WHERE sl.branch_id = ANY($1::uuid[]) AND sl.quantity > 0 AND ($3::uuid IS NULL OR p.category_id = $3::uuid OR cat.parent_id = $3::uuid)
       GROUP BY p.id, p.sku, p.brand_name, cat.name, p.base_unit
       ORDER BY SUM(sl.quantity * b.unit_cost) DESC`,
      c.branchIds, today, c.categoryId,
    );
    const columns = [col('sku', 'SKU'), col('product', 'Product'), col('category', 'Category'), col('on_hand', 'On hand', 'quantity'), col('sellable', 'Sellable', 'quantity')];
    if (c.financial) columns.push(col('cost_value', 'Cost value', 'money'), col('retail_value', 'Retail value', 'money'));
    const totals: Row = { sku: 'Total', cost_value: sum(rows, 'cost_value'), retail_value: sum(rows, 'retail_value') };
    return { columns, rows: this.strip(rows, columns), totals: c.financial ? totals : undefined };
  }

  private async expiry(c: ReportContext) {
    const today = todayIn(c.timezone);
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `SELECT br.name AS branch, p.sku, p.brand_name AS product, b.batch_number AS batch, to_char(b.expiry_date, 'YYYY-MM-DD') AS expiry,
              (b.expiry_date - $2::date)::int AS days_left, ROUND(SUM(sl.quantity), 3)::float8 AS quantity,
              ROUND(SUM(sl.quantity * b.unit_cost), 2)::float8 AS cost_value, s.name AS supplier
       FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id JOIN products p ON p.id = sl.product_id
       JOIN branches br ON br.id = sl.branch_id LEFT JOIN suppliers s ON s.id = b.supplier_id
       WHERE sl.branch_id = ANY($1::uuid[]) AND sl.quantity > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <= $2::date + $3::int
       GROUP BY br.name, p.sku, p.brand_name, b.batch_number, b.expiry_date, s.name
       ORDER BY b.expiry_date, p.brand_name`,
      c.branchIds, today, c.days,
    );
    const columns = [col('branch', 'Branch'), col('sku', 'SKU'), col('product', 'Product'), col('batch', 'Batch'), col('expiry', 'Expiry', 'date'), col('days_left', 'Days left', 'number'), col('quantity', 'Quantity', 'quantity'), col('supplier', 'Supplier')];
    if (c.financial) columns.push(col('cost_value', 'Value at risk', 'money'));
    const expired = rows.filter((r) => n(r.days_left) < 0).length;
    return {
      columns, rows: this.strip(rows, columns), totals: c.financial ? { branch: 'Total', cost_value: sum(rows, 'cost_value') } : undefined,
      notes: [`${expired} batch(es) already expired; negative days left means past expiry. Write them off from Inventory → Adjustments.`],
    };
  }

  private async reorder(c: ReportContext) {
    const today = todayIn(c.timezone);
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH st AS (
         SELECT sl.branch_id, sl.product_id, SUM(sl.quantity) AS qty
         FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
         WHERE sl.branch_id = ANY($1::uuid[]) AND b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= $2::date)
         GROUP BY 1, 2),
       sold AS (
         SELECT s.branch_id, si.product_id, SUM(si.base_quantity) AS qty
         FROM sale_items si JOIN sales s ON s.id = si.sale_id
         WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REV} AND s.sold_at >= now() - interval '30 days'
         GROUP BY 1, 2)
       SELECT br.name AS branch, p.sku, p.brand_name AS product, p.base_unit AS unit, ROUND(COALESCE(st.qty, 0), 3)::float8 AS sellable,
              COALESCE(bps.reorder_level, p.reorder_level)::float8 AS reorder_level, ROUND(COALESCE(sold.qty, 0), 3)::float8 AS sold_30d,
              GREATEST(CEIL(GREATEST(COALESCE(bps.reorder_level, p.reorder_level) * 2, COALESCE(sold.qty, 0)) - COALESCE(st.qty, 0)), 0)::float8 AS suggested,
              sup.name AS supplier, ROUND(p.purchase_price, 2)::float8 AS last_cost
       FROM products p CROSS JOIN branches br
       LEFT JOIN st ON st.product_id = p.id AND st.branch_id = br.id
       LEFT JOIN sold ON sold.product_id = p.id AND sold.branch_id = br.id
       LEFT JOIN branch_product_settings bps ON bps.product_id = p.id AND bps.branch_id = br.id
       LEFT JOIN suppliers sup ON sup.id = p.preferred_supplier_id
       WHERE br.id = ANY($1::uuid[]) AND p.deleted_at IS NULL AND p.is_active AND COALESCE(bps.is_available, true)
         AND COALESCE(bps.reorder_level, p.reorder_level) > 0 AND COALESCE(st.qty, 0) <= COALESCE(bps.reorder_level, p.reorder_level)
         AND ($3::uuid IS NULL OR p.category_id = $3::uuid)
       ORDER BY sup.name NULLS LAST, COALESCE(st.qty, 0) / COALESCE(bps.reorder_level, p.reorder_level), p.brand_name`,
      c.branchIds, today, c.categoryId,
    );
    for (const r of rows) r.order_value = r2(n(r.suggested) * n(r.last_cost));
    const columns = [col('branch', 'Branch'), col('supplier', 'Preferred supplier'), col('sku', 'SKU'), col('product', 'Product'), col('sellable', 'Sellable', 'quantity'), col('reorder_level', 'Reorder level', 'quantity'), col('sold_30d', 'Sold (30 days)', 'quantity'), col('suggested', 'Suggested order', 'quantity')];
    if (c.financial) columns.push(col('last_cost', 'Last cost', 'money'), col('order_value', 'Order value', 'money'));
    return {
      columns, rows: this.strip(rows, columns), totals: c.financial ? { branch: 'Total', order_value: sum(rows, 'order_value') } : undefined,
      notes: ['Suggested order = the larger of twice the reorder level or the last 30 days of sales, minus sellable stock.'],
    };
  }

  private async deadStock(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH st AS (
         SELECT sl.product_id, SUM(sl.quantity) AS qty, SUM(sl.quantity * b.unit_cost) AS value
         FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id WHERE sl.branch_id = ANY($1::uuid[]) AND sl.quantity > 0 GROUP BY 1),
       last AS (
         SELECT si.product_id, MAX(s.sold_at) AS last_sold FROM sale_items si JOIN sales s ON s.id = si.sale_id
         WHERE s.branch_id = ANY($1::uuid[]) AND s.status IN ${REV} GROUP BY 1)
       SELECT p.sku, p.brand_name AS product, c.name AS category, ROUND(st.qty, 3)::float8 AS on_hand, ROUND(st.value, 2)::float8 AS cost_value,
              to_char(last.last_sold AT TIME ZONE $3::text, 'YYYY-MM-DD') AS last_sold,
              CASE WHEN last.last_sold IS NULL THEN NULL ELSE (now()::date - (last.last_sold AT TIME ZONE $3::text)::date) END AS days_since
       FROM st JOIN products p ON p.id = st.product_id JOIN categories c ON c.id = p.category_id LEFT JOIN last ON last.product_id = p.id
       WHERE last.last_sold IS NULL OR last.last_sold < now() - make_interval(days => $2::int)
       ORDER BY st.value DESC`,
      c.branchIds, c.days, c.timezone,
    );
    const columns = [col('sku', 'SKU'), col('product', 'Product'), col('category', 'Category'), col('on_hand', 'On hand', 'quantity'), col('last_sold', 'Last sold', 'date'), col('days_since', 'Days since sale', 'number')];
    if (c.financial) columns.push(col('cost_value', 'Tied-up value', 'money'));
    return { columns, rows: this.strip(rows, columns), totals: c.financial ? { sku: 'Total', cost_value: sum(rows, 'cost_value') } : undefined, notes: ['"Last sold" empty = never sold in the selected branches.'] };
  }

  private async stockMovements(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `SELECT p.sku, p.brand_name AS product, p.base_unit AS unit,
              ROUND(COALESCE(SUM(m.quantity_delta) FILTER (WHERE m.movement_type IN ('PURCHASE_RECEIPT', 'OPENING_BALANCE')), 0), 3)::float8 AS received,
              ROUND(COALESCE(-SUM(m.quantity_delta) FILTER (WHERE m.movement_type = 'SALE'), 0), 3)::float8 AS sold,
              ROUND(COALESCE(SUM(m.quantity_delta) FILTER (WHERE m.movement_type = 'SALE_RETURN'), 0), 3)::float8 AS customer_returns,
              ROUND(COALESCE(-SUM(m.quantity_delta) FILTER (WHERE m.movement_type = 'PURCHASE_RETURN'), 0), 3)::float8 AS supplier_returns,
              ROUND(COALESCE(SUM(m.quantity_delta) FILTER (WHERE m.movement_type IN ('TRANSFER_IN', 'TRANSFER_OUT')), 0), 3)::float8 AS transfers_net,
              ROUND(COALESCE(SUM(m.quantity_delta) FILTER (WHERE m.movement_type IN ('ADJUSTMENT_IN', 'ADJUSTMENT_OUT')), 0), 3)::float8 AS adjustments_net,
              ROUND(COALESCE(-SUM(m.quantity_delta) FILTER (WHERE m.movement_type IN ('DAMAGE', 'EXPIRED_WRITE_OFF')), 0), 3)::float8 AS written_off,
              ROUND(SUM(m.quantity_delta), 3)::float8 AS net_change
       FROM inventory_movements m JOIN products p ON p.id = m.product_id
       WHERE m.branch_id = ANY($1::uuid[]) AND (m.occurred_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date
       GROUP BY p.id, p.sku, p.brand_name, p.base_unit
       ORDER BY p.brand_name`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    const columns = [
      col('sku', 'SKU'), col('product', 'Product'), col('received', 'Received', 'quantity'), col('sold', 'Sold', 'quantity'), col('customer_returns', 'Customer returns', 'quantity'),
      col('supplier_returns', 'Returned to suppliers', 'quantity'), col('transfers_net', 'Transfers (net)', 'quantity'), col('adjustments_net', 'Adjustments (net)', 'quantity'),
      col('written_off', 'Written off', 'quantity'), col('net_change', 'Net change', 'quantity'),
    ];
    return { columns, rows, notes: ['Quantities are in each product\'s base unit.'] };
  }

  // ------------------------------------------------------------------------------------------ parties
  /** Customer credit aged FIFO: payments and credits settle the oldest credit sales first. */
  private async receivablesAging(c: ReportContext) {
    const today = Date.parse(todayIn(c.timezone));
    const entries = await c.tx.$queryRawUnsafe<{ customer_id: string; name: string; phone: string | null; amount: string; created_at: Date }[]>(
      `SELECT l.customer_id, cu.full_name AS name, cu.phone, l.amount::text AS amount, l.created_at
       FROM party_ledger_entries l JOIN customers cu ON cu.id = l.customer_id
       WHERE l.customer_id IN (SELECT customer_id FROM party_ledger_entries WHERE customer_id IS NOT NULL GROUP BY customer_id HAVING SUM(amount) > 0)
       ORDER BY l.customer_id, l.created_at, l.id`,
    );
    const rows = this.age(entries.map((e) => ({ party: e.customer_id, name: e.name, phone: e.phone, amount: e.amount, at: e.created_at })), today, ['0-30', '31-60', '61-90', '90+']);
    return this.agingResult(rows, 'Customer', 'Age of the unpaid credit sales (days since the sale).');
  }

  private async payablesAging(c: ReportContext) {
    const today = todayIn(c.timezone);
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH inv AS (
         SELECT supplier_id, grand_total - paid_total AS open, ($1::date - due_date) AS late FROM purchases
         WHERE status = 'RECEIVED' AND paid_total < grand_total),
       bal AS (SELECT supplier_id, SUM(amount) AS balance FROM party_ledger_entries WHERE supplier_id IS NOT NULL GROUP BY 1)
       SELECT s.name, s.phone,
              ROUND(COALESCE(SUM(inv.open) FILTER (WHERE inv.late IS NULL OR inv.late <= 0), 0), 2)::float8 AS "current",
              ROUND(COALESCE(SUM(inv.open) FILTER (WHERE inv.late BETWEEN 1 AND 30), 0), 2)::float8 AS "1-30",
              ROUND(COALESCE(SUM(inv.open) FILTER (WHERE inv.late BETWEEN 31 AND 60), 0), 2)::float8 AS "31-60",
              ROUND(COALESCE(SUM(inv.open) FILTER (WHERE inv.late BETWEEN 61 AND 90), 0), 2)::float8 AS "61-90",
              ROUND(COALESCE(SUM(inv.open) FILTER (WHERE inv.late > 90), 0), 2)::float8 AS "90+",
              ROUND(COALESCE(bal.balance, 0) - COALESCE(SUM(inv.open), 0), 2)::float8 AS credits,
              ROUND(COALESCE(bal.balance, 0), 2)::float8 AS total
       FROM suppliers s LEFT JOIN inv ON inv.supplier_id = s.id LEFT JOIN bal ON bal.supplier_id = s.id
       WHERE s.deleted_at IS NULL
       GROUP BY s.id, s.name, s.phone, bal.balance
       HAVING COALESCE(bal.balance, 0) <> 0 OR COUNT(inv.open) > 0
       ORDER BY COALESCE(bal.balance, 0) DESC`,
      today,
    );
    const columns = [
      col('name', 'Supplier'), col('phone', 'Phone'), col('current', 'Not yet due', 'money'), col('1-30', '1-30 days late', 'money'), col('31-60', '31-60', 'money'),
      col('61-90', '61-90', 'money'), col('90+', 'Over 90', 'money'), col('credits', 'Returns / advances', 'money'), col('total', 'Balance', 'money'),
    ];
    const totals: Row = { name: 'Total' };
    for (const k of ['current', '1-30', '31-60', '61-90', '90+', 'credits', 'total']) totals[k] = sum(rows, k);
    return { columns, rows, totals, notes: ['Aged by invoice due date. Returns and unallocated advances reduce the balance but are not tied to an invoice.'] };
  }

  private async purchasesBySupplier(c: ReportContext) {
    const rows = await c.tx.$queryRawUnsafe<Row[]>(
      `WITH p AS (
         SELECT supplier_id, COUNT(*) AS invoices, SUM(grand_total) AS purchased, SUM(tax_total) AS tax FROM purchases
         WHERE branch_id = ANY($1::uuid[]) AND status = 'RECEIVED' AND purchase_date BETWEEN $2::date AND $3::date GROUP BY 1),
       r AS (
         SELECT supplier_id, SUM(total) AS returned FROM purchase_returns
         WHERE branch_id = ANY($1::uuid[]) AND status = 'POSTED' AND return_date BETWEEN $2::date AND $3::date GROUP BY 1),
       pay AS (
         SELECT supplier_id, SUM(amount) AS paid FROM payments
         WHERE kind = 'SUPPLIER_PAYMENT' AND branch_id = ANY($1::uuid[]) AND (paid_at AT TIME ZONE $4::text)::date BETWEEN $2::date AND $3::date GROUP BY 1),
       bal AS (SELECT supplier_id, SUM(amount) AS balance FROM party_ledger_entries WHERE supplier_id IS NOT NULL GROUP BY 1)
       SELECT s.name AS supplier, COALESCE(p.invoices, 0)::int AS invoices, ROUND(COALESCE(p.purchased, 0), 2)::float8 AS purchased,
              ROUND(COALESCE(p.tax, 0), 2)::float8 AS tax, ROUND(COALESCE(r.returned, 0), 2)::float8 AS returned,
              ROUND(COALESCE(pay.paid, 0), 2)::float8 AS paid, ROUND(COALESCE(bal.balance, 0), 2)::float8 AS balance
       FROM suppliers s LEFT JOIN p ON p.supplier_id = s.id LEFT JOIN r ON r.supplier_id = s.id LEFT JOIN pay ON pay.supplier_id = s.id LEFT JOIN bal ON bal.supplier_id = s.id
       WHERE s.deleted_at IS NULL AND (p.invoices IS NOT NULL OR r.returned IS NOT NULL OR pay.paid IS NOT NULL)
       ORDER BY COALESCE(p.purchased, 0) DESC`,
      c.branchIds, c.from, c.to, c.timezone,
    );
    const columns = [col('supplier', 'Supplier'), col('invoices', 'Invoices', 'number'), col('purchased', 'Purchased', 'money'), col('tax', 'Input tax', 'money'), col('returned', 'Returned', 'money'), col('paid', 'Paid', 'money'), col('balance', 'Balance now', 'money')];
    const totals: Row = { supplier: 'Total' };
    for (const k of ['invoices', 'purchased', 'tax', 'returned', 'paid', 'balance']) totals[k] = sum(rows, k);
    return { columns, rows, totals };
  }

  // ------------------------------------------------------------------------------------------ helpers
  private age(entries: { party: string; name: string; phone: string | null; amount: string; at: Date }[], today: number, buckets: string[]) {
    const out: Row[] = [];
    const byParty = new Map<string, typeof entries>();
    for (const e of entries) byParty.set(e.party, [...(byParty.get(e.party) ?? []), e]);
    for (const list of byParty.values()) {
      const open: { amount: ReturnType<typeof dec>; at: Date }[] = [];
      let credit = dec(0);
      for (const e of list) {
        let a = dec(e.amount);
        if (a.gt(0)) {
          // apply any earlier unused credit first
          const use = credit.gt(a) ? a : credit;
          a = a.minus(use);
          credit = credit.minus(use);
          if (a.gt(0)) open.push({ amount: a, at: e.at });
        } else {
          let pay = a.negated();
          while (pay.gt(0) && open.length) {
            const first = open[0];
            const take = first.amount.gt(pay) ? pay : first.amount;
            first.amount = first.amount.minus(take);
            pay = pay.minus(take);
            if (first.amount.lte(0)) open.shift();
          }
          credit = credit.plus(pay);
        }
      }
      const row: Row = { name: list[0].name, phone: list[0].phone };
      for (const b of buckets) row[b] = 0;
      for (const o of open) {
        const days = Math.floor((today - Date.UTC(o.at.getUTCFullYear(), o.at.getUTCMonth(), o.at.getUTCDate())) / 86_400_000);
        const b = days <= 30 ? buckets[0] : days <= 60 ? buckets[1] : days <= 90 ? buckets[2] : buckets[3];
        row[b] = r2(n(row[b]) + Number(money2(o.amount)));
      }
      row.total = r2(buckets.reduce((a, b) => a + n(row[b]), 0));
      if (n(row.total) > 0) out.push(row);
    }
    return out.sort((a, b) => n(b.total) - n(a.total));
  }

  private agingResult(rows: Row[], label: string, note: string) {
    const columns = [col('name', label), col('phone', 'Phone'), col('0-30', '0-30 days', 'money'), col('31-60', '31-60', 'money'), col('61-90', '61-90', 'money'), col('90+', 'Over 90', 'money'), col('total', 'Total', 'money')];
    const totals: Row = { name: 'Total' };
    for (const k of ['0-30', '31-60', '61-90', '90+', 'total']) totals[k] = sum(rows, k);
    return { columns, rows, totals, notes: [note] };
  }

  /** Removes values for columns the caller may not see (e.g. cost without financial access). */
  private strip(rows: Row[], columns: ReportColumn[]): Row[] {
    const keys = new Set(columns.map((c) => c.key));
    return rows.map((r) => Object.fromEntries(Object.entries(r).filter(([k]) => keys.has(k))));
  }
}
