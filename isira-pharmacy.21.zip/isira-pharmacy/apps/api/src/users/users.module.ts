import {
  BadRequestException, Body, Controller, ForbiddenException, Get, HttpCode, Module, NotFoundException, Param,
  ParseUUIDPipe, Patch, Post, Put, Query,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import {
  adminSetPasswordSchema, createUserSchema, listUsersQuerySchema, setUserBranchRolesSchema, updateUserSchema,
} from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { AccessService } from '../auth/access.service';
import { PasswordService } from '../auth/password.service';
import { AuditService } from '../audit/audit.service';
import { CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class CreateUserDto extends createZodDto(createUserSchema) {}
class UpdateUserDto extends createZodDto(updateUserSchema) {}
class SetBranchRolesDto extends createZodDto(setUserBranchRolesSchema) {}
class AdminSetPasswordDto extends createZodDto(adminSetPasswordSchema) {}
class ListUsersQueryDto extends createZodDto(listUsersQuerySchema) {}

const USER_SELECT = {
  id: true, email: true, fullName: true, phone: true, status: true, isOwner: true, lastLoginAt: true, createdAt: true, mfaEnabledAt: true,
  userBranchRoles: { select: { branchId: true, roleId: true, branch: { select: { name: true } }, role: { select: { name: true } } } },
} satisfies Prisma.UserSelect;

@ApiTags('Users')
@ApiCookieAuth()
@Controller('users')
export class UsersController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly access: AccessService,
    private readonly passwords: PasswordService,
  ) {}

  private async find(tx: Prisma.TransactionClient, id: string) {
    const user = await tx.user.findFirst({ where: { id, deletedAt: null }, select: USER_SELECT });
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  /** Validates branch/role ids and blocks privilege escalation. */
  private async checkAssignments(tx: Prisma.TransactionClient, auth: AuthContext, input: { branchId: string; roleId: string }[]) {
    const unique = [...new Map(input.map((a) => [`${a.branchId}:${a.roleId}`, a])).values()];
    const roleIds = [...new Set(unique.map((a) => a.roleId))];
    const branchIds = [...new Set(unique.map((a) => a.branchId))];
    const roles = await tx.role.findMany({
      where: { id: { in: roleIds } },
      select: { id: true, rolePermissions: { select: { permission: { select: { key: true } } } } },
    });
    if (roles.length !== roleIds.length) throw new BadRequestException('Unknown role');
    if ((await tx.branch.count({ where: { id: { in: branchIds }, deletedAt: null } })) !== branchIds.length) {
      throw new BadRequestException('Unknown branch');
    }
    this.access.assertCanGrant(auth, roles.flatMap((r) => r.rolePermissions.map((rp) => rp.permission.key)));
    return unique;
  }

  @Get()
  @RequirePermissions('user:read')
  async list(@Query() q: ListUsersQueryDto) {
    const where: Prisma.UserWhereInput = {
      deletedAt: null,
      ...(q.status ? { status: q.status } : {}),
      ...(q.search ? { OR: [{ fullName: { contains: q.search, mode: 'insensitive' } }, { email: { contains: q.search, mode: 'insensitive' } }] } : {}),
    };
    const tx = this.db.tx;
    const total = await tx.user.count({ where });
    const rows = await tx.user.findMany({ where, select: USER_SELECT, orderBy: { fullName: 'asc' }, ...skipTake(q.page, q.pageSize) });
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get(':id')
  @RequirePermissions('user:read')
  get(@Param('id', ParseUUIDPipe) id: string) {
    return this.find(this.db.tx, id);
  }

  @Post()
  @RequirePermissions('user:manage')
  async create(@Body() dto: CreateUserDto, @CurrentAuth() auth: AuthContext) {
    if (dto.isOwner && !auth.isOwner) throw new ForbiddenException('Only an owner can create another owner');
    const tx = this.db.tx;
    const assignments = await this.checkAssignments(tx, auth, dto.branchRoles);
    const user = await tx.user.create({
      data: {
        tenantId: auth.tenantId, email: dto.email, fullName: dto.fullName, phone: dto.phone, isOwner: dto.isOwner,
        passwordHash: await this.passwords.hash(dto.password),
      },
      select: { id: true },
    });
    if (assignments.length) {
      await tx.userBranchRole.createMany({ data: assignments.map((a) => ({ tenantId: auth.tenantId, userId: user.id, ...a })) });
    }
    const after = await this.find(tx, user.id);
    await this.audit.record({ action: 'user.created', entityType: 'user', entityId: user.id, after });
    return after;
  }

  @Patch(':id')
  @RequirePermissions('user:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateUserDto, @CurrentAuth() auth: AuthContext) {
    if (dto.status === 'DISABLED' && id === auth.userId) throw new ForbiddenException('You cannot disable your own account');
    const tx = this.db.tx;
    const before = await this.find(tx, id);
    if (before.isOwner && !auth.isOwner) throw new ForbiddenException('Only an owner can change an owner');
    await tx.user.update({ where: { id }, data: dto });
    if (dto.status === 'DISABLED') {
      await tx.session.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    }
    const after = await this.find(tx, id);
    await this.audit.record({ action: dto.status ? `user.${dto.status === 'DISABLED' ? 'disabled' : 'enabled'}` : 'user.updated', entityType: 'user', entityId: id, before, after });
    return after;
  }

  @Put(':id/branch-roles')
  @RequirePermissions('user:manage')
  async setBranchRoles(@Param('id', ParseUUIDPipe) id: string, @Body() dto: SetBranchRolesDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await this.find(tx, id);
    if (before.isOwner && !auth.isOwner) throw new ForbiddenException('Only an owner can change an owner');
    const assignments = await this.checkAssignments(tx, auth, dto.branchRoles);
    await tx.userBranchRole.deleteMany({ where: { userId: id } });
    if (assignments.length) {
      await tx.userBranchRole.createMany({ data: assignments.map((a) => ({ tenantId: auth.tenantId, userId: id, ...a })) });
    }
    const after = await this.find(tx, id);
    await this.audit.record({ action: 'user.roles_changed', entityType: 'user', entityId: id, before: before.userBranchRoles, after: after.userBranchRoles });
    return after;
  }

  @Post(':id/password')
  @HttpCode(204)
  @RequirePermissions('user:manage')
  async setPassword(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AdminSetPasswordDto, @CurrentAuth() auth: AuthContext): Promise<void> {
    const tx = this.db.tx;
    const target = await this.find(tx, id);
    if (target.isOwner && !auth.isOwner) throw new ForbiddenException('Only an owner can change an owner');
    await tx.user.update({ where: { id }, data: { passwordHash: await this.passwords.hash(dto.newPassword), failedLoginCount: 0, lockedUntil: null } });
    await tx.session.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    await this.audit.record({ action: 'user.password_set_by_admin', entityType: 'user', entityId: id });
  }

  /** For a user who lost their authenticator and recovery codes. Signs them out everywhere. */
  @Post(':id/mfa/reset')
  @HttpCode(204)
  @RequirePermissions('user:manage')
  async resetMfa(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext): Promise<void> {
    const tx = this.db.tx;
    const target = await this.find(tx, id);
    if (target.isOwner && !auth.isOwner) throw new ForbiddenException('Only an owner can change an owner');
    if (id === auth.userId) throw new ForbiddenException('Use your account page to change your own two-factor settings');
    await tx.user.update({ where: { id }, data: { mfaSecret: null, mfaEnabledAt: null, mfaRecoveryCodes: [], mfaLastStep: null } });
    await tx.session.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    await this.audit.record({ action: 'user.mfa_reset_by_admin', entityType: 'user', entityId: id });
  }
}

@Module({ controllers: [UsersController] })
export class UsersModule {}
