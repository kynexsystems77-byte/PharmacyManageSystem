import { randomUUID } from 'node:crypto';
import { hash } from '@node-rs/argon2';
import { PrismaClient } from '@prisma/client';
import { PERMISSIONS, SYSTEM_ROLES, type SystemRoleKey } from '../../contracts/src/permissions';
import { DEFAULT_CATEGORIES } from '../src/default-categories';
import { withTenant } from '../src/tenant-context';

/**
 * Provisions a real pharmacy (tenant) with its first branch, the system roles and the owner account.
 * Runs as the OWNER role (DIRECT_URL). Safe to run more than once: an existing slug is refused.
 *
 *   TENANT_NAME="City Pharmacy" TENANT_SLUG=city OWNER_EMAIL=me@city.lk OWNER_NAME="Ann Perera" \
 *   OWNER_PASSWORD='a-long-password' CURRENCY=LKR TIMEZONE=Asia/Colombo BRANCH_NAME="Main Branch" \
 *   pnpm --filter @kynex/database tenant:create
 */
function need(name: string): string {
  const v = process.env[name]?.trim();
  if (!v) throw new Error(`${name} is required`);
  return v;
}

async function main(): Promise<void> {
  const url = need('DIRECT_URL');
  const name = need('TENANT_NAME');
  const slug = need('TENANT_SLUG').toLowerCase();
  const ownerEmail = need('OWNER_EMAIL').toLowerCase();
  const ownerName = need('OWNER_NAME');
  const password = need('OWNER_PASSWORD');
  const currencyCode = (process.env.CURRENCY ?? 'USD').toUpperCase();
  const timezone = process.env.TIMEZONE ?? 'UTC';
  const branchName = process.env.BRANCH_NAME ?? 'Main Branch';
  const branchCode = (process.env.BRANCH_CODE ?? 'MAIN').toUpperCase();

  if (!/^[a-z0-9][a-z0-9-]{1,40}$/.test(slug)) throw new Error('TENANT_SLUG: use 2-40 lowercase letters, digits or dashes');
  if (password.length < 10) throw new Error('OWNER_PASSWORD must be at least 10 characters');
  if (!/^[A-Z]{3}$/.test(currencyCode)) throw new Error('CURRENCY must be a 3-letter ISO code');
  try {
    new Intl.DateTimeFormat('en', { timeZone: timezone });
  } catch {
    throw new Error(`TIMEZONE "${timezone}" is not a valid IANA time zone`);
  }

  const prisma = new PrismaClient({ datasourceUrl: url });
  try {
    for (const p of PERMISSIONS) {
      await prisma.permission.upsert({
        where: { key: p.key },
        update: { module: p.module, description: p.description },
        create: { key: p.key, module: p.module, description: p.description },
      });
    }
    const permissionId = new Map((await prisma.permission.findMany()).map((p) => [p.key, p.id]));

    if (await prisma.tenant.findUnique({ where: { slug } })) throw new Error(`A pharmacy with slug "${slug}" already exists`);
    const emailTaken = await prisma.$queryRaw<{ id: string }[]>`SELECT id FROM auth_find_user_by_email(${ownerEmail})`;
    if (emailTaken.length > 0) throw new Error(`${ownerEmail} is already used by another account`);

    const tenantId = randomUUID();
    const passwordHash = await hash(password);
    await withTenant(prisma, tenantId, async (tx) => {
      await tx.tenant.create({ data: { id: tenantId, name, slug, currencyCode, timezone } });
      const branch = await tx.branch.create({ data: { tenantId, name: branchName, code: branchCode, invoicePrefix: 'INV' } });
      await tx.location.create({ data: { tenantId, branchId: branch.id, name: 'Sales Floor', type: 'SALES_FLOOR', isDefault: true } });
      await tx.location.create({ data: { tenantId, branchId: branch.id, name: 'Store Room', type: 'WAREHOUSE' } });
      await tx.cashRegister.create({ data: { tenantId, branchId: branch.id, name: 'Register 1' } });

      for (const [key, def] of Object.entries(SYSTEM_ROLES) as [SystemRoleKey, (typeof SYSTEM_ROLES)[SystemRoleKey]][]) {
        const role = await tx.role.create({
          data: { tenantId, name: def.name, description: def.description, isSystem: true, systemKey: key, maxDiscountPercent: def.maxDiscountPercent },
        });
        await tx.rolePermission.createMany({
          data: def.permissions.map((perm) => {
            const id = permissionId.get(perm);
            if (!id) throw new Error(`Unknown permission ${perm}`);
            return { tenantId, roleId: role.id, permissionId: id };
          }),
        });
      }

      await tx.taxRate.create({ data: { tenantId, name: 'Zero rated', ratePercent: 0 } });
      for (const [parent, subs] of Object.entries(DEFAULT_CATEGORIES)) {
        const top = await tx.category.create({ data: { tenantId, name: parent } });
        for (const [i, sub] of subs.entries()) await tx.category.create({ data: { tenantId, name: sub, parentId: top.id, sortOrder: i } });
      }
      for (const c of ['Rent', 'Utilities', 'Salaries', 'Supplies', 'Other']) await tx.expenseCategory.create({ data: { tenantId, name: c } });
      await tx.user.create({ data: { tenantId, email: ownerEmail, fullName: ownerName, passwordHash, isOwner: true } });
    }, { timeout: 30_000 });

    console.log(`Created pharmacy "${name}" (slug ${slug}, id ${tenantId}). Sign in as ${ownerEmail}.`);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((err: unknown) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
