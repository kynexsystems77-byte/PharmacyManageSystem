import { Module } from '@nestjs/common';
import { StockService } from './stock.service';

/** Stock primitives shared by catalogue, inventory, purchasing and sales. */
@Module({ providers: [StockService], exports: [StockService] })
export class InventoryCoreModule {}
