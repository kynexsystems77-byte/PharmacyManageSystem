import { Body, Controller, Get, Module, NotFoundException, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { createBranchSchema, createLocationSchema, updateBranchSchema } from '@kynex/contracts';
import { AuditService } from '../audit/audit.service';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { getStore, type AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class CreateBranchDto extends createZodDto(createBranchSchema) {}
class UpdateBranchDto extends createZodDto(updateBranchSchema) {}
class CreateLocationDto extends createZodDto(createLocationSchema) {}

const BRANCH_SELECT = {
  id: true, name: true, code: true, address: true, phone: true, email: true, invoicePrefix: true,
  receiptHeader: true, receiptFooter: true, taxNumber: true, isActive: true, createdAt: true,
} as const;

@ApiTags('Branches')
@ApiCookieAuth()
@Controller('branches')
export class BranchesController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService) {}

  /** Users with branch:manage see every branch; everyone else only the branches they are assigned to. */
  private visibility(auth: AuthContext): { id?: { in: string[] } } {
    return auth.isOwner || auth.allPermissions.has('branch:manage') ? {} : { id: { in: [...auth.branchIds] } };
  }

  @Get()
  @RequirePermissions('branch:read')
  list(@CurrentAuth() auth: AuthContext) {
    return this.db.tx.branch.findMany({
      where: { deletedAt: null, ...this.visibility(auth) },
      select: { ...BRANCH_SELECT, locations: { select: { id: true, name: true, type: true, isDefault: true } } },
      orderBy: { name: 'asc' },
    });
  }

  /**
   * The branch named by X-Branch-Id (what the web app's branch switcher selects).
   * No branch:read needed: BranchGuard already proved the user is assigned to this branch (cashiers need its locations).
   */
  @Get('current')
  @BranchScoped()
  async current() {
    const { branchId } = getStore();
    const branch = await this.db.tx.branch.findFirst({
      where: { id: branchId, deletedAt: null },
      select: { ...BRANCH_SELECT, locations: { select: { id: true, name: true, type: true, isDefault: true } } },
    });
    if (!branch) throw new NotFoundException('Branch not found');
    return branch;
  }

  @Get(':id')
  @RequirePermissions('branch:read')
  async get(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const branch = await this.db.tx.branch.findFirst({
      where: { id, deletedAt: null, ...this.visibility(auth) },
      select: { ...BRANCH_SELECT, locations: true },
    });
    if (!branch) throw new NotFoundException('Branch not found');
    return branch;
  }

  @Post()
  @RequirePermissions('branch:manage')
  async create(@Body() dto: CreateBranchDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branch = await tx.branch.create({ data: { tenantId: auth.tenantId, ...dto }, select: BRANCH_SELECT });
    // every branch starts with a sales floor, a warehouse and a register
    await tx.location.create({ data: { tenantId: auth.tenantId, branchId: branch.id, name: 'Sales Floor', type: 'SALES_FLOOR', isDefault: true } });
    await tx.location.create({ data: { tenantId: auth.tenantId, branchId: branch.id, name: 'Warehouse', type: 'WAREHOUSE' } });
    await tx.cashRegister.create({ data: { tenantId: auth.tenantId, branchId: branch.id, name: 'Register 1' } });
    await this.audit.record({ action: 'branch.created', entityType: 'branch', entityId: branch.id, branchId: branch.id, after: branch });
    return branch;
  }

  @Patch(':id')
  @RequirePermissions('branch:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateBranchDto) {
    const tx = this.db.tx;
    const before = await tx.branch.findFirst({ where: { id, deletedAt: null }, select: BRANCH_SELECT });
    if (!before) throw new NotFoundException('Branch not found');
    const after = await tx.branch.update({ where: { id }, data: dto, select: BRANCH_SELECT });
    await this.audit.record({ action: 'branch.updated', entityType: 'branch', entityId: id, branchId: id, before, after });
    return after;
  }

  @Get(':id/locations')
  @RequirePermissions('branch:read')
  async locations(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const branch = await this.db.tx.branch.findFirst({ where: { id, deletedAt: null, ...this.visibility(auth) }, select: { id: true } });
    if (!branch) throw new NotFoundException('Branch not found');
    return this.db.tx.location.findMany({ where: { branchId: id }, orderBy: { name: 'asc' } });
  }

  @Post(':id/locations')
  @RequirePermissions('branch:manage')
  async addLocation(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateLocationDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branch = await tx.branch.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
    if (!branch) throw new NotFoundException('Branch not found');
    if (dto.isDefault) {
      await tx.location.updateMany({ where: { branchId: id, isDefault: true }, data: { isDefault: false } });
    }
    const location = await tx.location.create({ data: { tenantId: auth.tenantId, branchId: id, ...dto } });
    await this.audit.record({ action: 'location.created', entityType: 'location', entityId: location.id, branchId: id, after: location });
    return location;
  }
}

@Module({ controllers: [BranchesController] })
export class BranchesModule {}
