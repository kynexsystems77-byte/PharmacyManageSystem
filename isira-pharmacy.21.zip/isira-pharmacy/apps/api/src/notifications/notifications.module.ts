import { Controller, Get, Global, HttpCode, Injectable, Module, NotFoundException, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { z } from 'zod';
import { paginationSchema, type PermissionKey } from '@kynex/contracts';
import type { NotificationType, Prisma, Severity } from '@kynex/database';
import { CurrentAuth } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class ListNotificationsQueryDto extends createZodDto(paginationSchema.extend({ unread: z.enum(['true', 'false']).optional() })) {}

/** Who may see each kind of notification (in the notification's branch). */
export const NOTIFICATION_PERMISSION: Record<NotificationType, PermissionKey> = {
  LOW_STOCK: 'inventory:read',
  EXPIRING_SOON: 'inventory:read',
  EXPIRED: 'inventory:read',
  JOB_FAILED: 'notification:manage',
  FINANCIAL_EVENT: 'finance:read',
  SYSTEM: 'notification:manage',
};

export interface NewNotification {
  tenantId: string;
  type: NotificationType;
  severity?: Severity;
  title: string;
  body?: string;
  /** e.g. { link: '/inventory?filter=low' } */
  data?: Record<string, unknown>;
  branchId?: string | null;
  userId?: string | null;
  /** Same key = same alert: it is created once. */
  dedupeKey?: string;
}

@Injectable()
export class NotificationsService {
  /** Creates notifications, silently skipping ones whose dedupeKey already exists. Returns how many were new. */
  async create(tx: Prisma.TransactionClient, items: NewNotification[]): Promise<number> {
    if (!items.length) return 0;
    const res = await tx.notification.createMany({
      data: items.map((n) => ({
        tenantId: n.tenantId, type: n.type, severity: n.severity ?? 'INFO', title: n.title, body: n.body ?? null,
        data: (n.data ?? undefined) as Prisma.InputJsonValue | undefined, branchId: n.branchId ?? null, userId: n.userId ?? null, dedupeKey: n.dedupeKey ?? null,
      })),
      skipDuplicates: true,
    });
    return res.count;
  }

  /** Notifications this user may see: their own, plus branch-wide ones of types they have permission for. */
  visibleWhere(auth: AuthContext): Prisma.NotificationWhereInput {
    const or: Prisma.NotificationWhereInput[] = [{ userId: auth.userId }];
    for (const [type, perm] of Object.entries(NOTIFICATION_PERMISSION) as [NotificationType, PermissionKey][]) {
      const branches = [...auth.branchIds].filter((b) => auth.permissionsByBranch.get(b)?.has(perm));
      if (!branches.length) continue;
      or.push({ userId: null, type, OR: [{ branchId: { in: branches } }, { branchId: null }] });
    }
    return { OR: or };
  }

  unreadWhere(auth: AuthContext): Prisma.NotificationWhereInput {
    return { AND: [this.visibleWhere(auth), { reads: { none: { userId: auth.userId } } }] };
  }
}

@ApiTags('Notifications')
@ApiCookieAuth()
@Controller('notifications')
export class NotificationsController {
  constructor(private readonly db: TenantDb, private readonly notifications: NotificationsService) {}

  @Get()
  async list(@Query() q: ListNotificationsQueryDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const where = q.unread === 'true' ? this.notifications.unreadWhere(auth) : this.notifications.visibleWhere(auth);
    const [rows, total, unread] = await Promise.all([
      tx.notification.findMany({
        where, orderBy: { createdAt: 'desc' }, ...skipTake(q.page, q.pageSize),
        select: {
          id: true, type: true, severity: true, title: true, body: true, data: true, createdAt: true,
          branch: { select: { id: true, name: true } }, reads: { where: { userId: auth.userId }, select: { readAt: true } },
        },
      }),
      tx.notification.count({ where }),
      tx.notification.count({ where: this.notifications.unreadWhere(auth) }),
    ]);
    return { ...paged(rows.map(({ reads, ...n }) => ({ ...n, readAt: reads[0]?.readAt ?? null })), total, q.page, q.pageSize), unread };
  }

  @Get('unread-count')
  async unread(@CurrentAuth() auth: AuthContext) {
    return { unread: await this.db.tx.notification.count({ where: this.notifications.unreadWhere(auth) }) };
  }

  @Post(':id/read')
  @HttpCode(204)
  async read(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const n = await tx.notification.findFirst({ where: { AND: [{ id }, this.notifications.visibleWhere(auth)] }, select: { id: true } });
    if (!n) throw new NotFoundException('Notification not found');
    await tx.notificationRead.createMany({ data: [{ tenantId: auth.tenantId, notificationId: id, userId: auth.userId }], skipDuplicates: true });
  }

  @Post('read-all')
  @HttpCode(204)
  async readAll(@CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const ids = await tx.notification.findMany({ where: this.notifications.unreadWhere(auth), select: { id: true }, take: 1000 });
    if (ids.length) {
      await tx.notificationRead.createMany({ data: ids.map((n) => ({ tenantId: auth.tenantId, notificationId: n.id, userId: auth.userId })), skipDuplicates: true });
    }
  }
}

/** The service alone (used by the API and the worker). */
@Global()
@Module({ providers: [NotificationsService], exports: [NotificationsService] })
export class NotificationsCoreModule {}

@Module({ imports: [NotificationsCoreModule], controllers: [NotificationsController] })
export class NotificationsModule {}
