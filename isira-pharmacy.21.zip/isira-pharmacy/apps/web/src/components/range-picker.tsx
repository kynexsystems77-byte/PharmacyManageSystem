'use client';

import { todayIso } from '@/lib/format';
import { Select } from './kit';
import { Input } from './ui';

export interface DateRange { from: string; to: string }

function iso(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function preset(name: string): DateRange {
  const now = new Date();
  const t = todayIso();
  if (name === 'yesterday') { const y = new Date(now); y.setDate(y.getDate() - 1); return { from: iso(y), to: iso(y) }; }
  if (name === '7d') { const s = new Date(now); s.setDate(s.getDate() - 6); return { from: iso(s), to: t }; }
  if (name === '30d') { const s = new Date(now); s.setDate(s.getDate() - 29); return { from: iso(s), to: t }; }
  if (name === 'month') return { from: iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: t };
  if (name === 'lastMonth') return { from: iso(new Date(now.getFullYear(), now.getMonth() - 1, 1)), to: iso(new Date(now.getFullYear(), now.getMonth(), 0)) };
  if (name === 'year') return { from: iso(new Date(now.getFullYear(), 0, 1)), to: t };
  return { from: t, to: t };
}

const PRESETS = [
  { v: 'today', l: 'Today' }, { v: 'yesterday', l: 'Yesterday' }, { v: '7d', l: 'Last 7 days' }, { v: '30d', l: 'Last 30 days' },
  { v: 'month', l: 'This month' }, { v: 'lastMonth', l: 'Last month' }, { v: 'year', l: 'This year' },
];

export function RangePicker({ value, onChange }: { value: DateRange; onChange: (r: DateRange) => void }) {
  const match = PRESETS.find((p) => { const r = preset(p.v); return r.from === value.from && r.to === value.to; });
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select value={match?.v ?? 'custom'} onChange={(e) => e.target.value !== 'custom' && onChange(preset(e.target.value))} className="w-40" aria-label="Period">
        {PRESETS.map((p) => <option key={p.v} value={p.v}>{p.l}</option>)}
        <option value="custom">Custom</option>
      </Select>
      <Input type="date" value={value.from} max={value.to} onChange={(e) => onChange({ ...value, from: e.target.value })} className="w-40" aria-label="From" />
      <span className="text-fg-muted">to</span>
      <Input type="date" value={value.to} min={value.from} onChange={(e) => onChange({ ...value, to: e.target.value })} className="w-40" aria-label="To" />
    </div>
  );
}

export function ScopeToggle({ value, onChange }: { value: 'branch' | 'all'; onChange: (v: 'branch' | 'all') => void }) {
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value as 'branch' | 'all')} className="w-44" aria-label="Branches">
      <option value="branch">This branch</option>
      <option value="all">All my branches</option>
    </Select>
  );
}
