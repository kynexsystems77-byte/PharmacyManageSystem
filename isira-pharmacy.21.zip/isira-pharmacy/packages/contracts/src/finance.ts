import { z } from 'zod';
import { dateOnlySchema, moneySchema, nullableText, optionalText } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 9: finance (settings, expenses, P&L, reconciliation). */

export const tenantSettingsSchema = z
  .object({
    minDaysToExpiryForSale: z.coerce.number().int().min(0).max(3650),
    expiryWarningDays: z.coerce.number().int().min(1).max(3650),
    refundApprovalThreshold: moneySchema,
    cashRoundingStep: z.coerce.number().min(0).max(1000),
    requireOpenShiftForSale: z.boolean(),
    allowRxWithoutRecord: z.boolean(),
    lowStockAlerts: z.boolean(),
    expiryAlerts: z.boolean(),
  })
  .partial()
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const EXPENSE_METHODS = ['CASH', 'CARD', 'BANK_TRANSFER', 'OTHER'] as const;

export const createExpenseCategorySchema = z.object({ name: z.string().trim().min(2).max(60) });

export const createExpenseSchema = z.object({
  categoryId: uuidSchema,
  amount: moneySchema.refine((v) => v > 0, 'Amount must be positive'),
  paymentMethod: z.enum(EXPENSE_METHODS).default('CASH'),
  description: z.string().trim().min(2).max(300),
  expenseDate: dateOnlySchema.optional(),
  reference: optionalText(120),
  /** Cash paid out of the user's open register shift. */
  fromRegister: z.boolean().default(false),
});

export const updateExpenseSchema = z
  .object({
    categoryId: uuidSchema.optional(),
    description: z.string().trim().min(2).max(300).optional(),
    expenseDate: dateOnlySchema.optional(),
    reference: nullableText(120),
    /** Not allowed for expenses paid from a register (delete and re-enter instead). */
    amount: moneySchema.refine((v) => v > 0, 'Amount must be positive').optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const listExpensesQuerySchema = paginationSchema.extend({
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
  categoryId: uuidSchema.optional(),
});

/** Date range report query. scope=all covers every branch where the user holds the permission. */
export const dateRangeQuerySchema = z.object({
  from: dateOnlySchema,
  to: dateOnlySchema,
  scope: z.enum(['branch', 'all']).default('branch'),
});
