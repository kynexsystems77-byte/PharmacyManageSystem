import { randomBytes } from 'node:crypto';
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { ENV, loadEnv } from '../src/config/env';
import { configureApp } from '../src/setup';

/**
 * End-to-end tests against the REAL database (run `pnpm db:seed` first).
 * They exercise authentication, CSRF, RBAC, privilege-escalation protection and auditing.
 */
const PASSWORD = process.env.SEED_PASSWORD ?? 'ChangeMe123!';
const CSRF = { 'X-Kynex-Csrf': '1' };

describe('Kynex API', () => {
  let app: INestApplication;

  beforeAll(async () => {
    process.env.NODE_ENV = 'test';
    const env = loadEnv();
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    configureApp(app, moduleRef.get(ENV) ?? env);
    await app.init();
  });
  afterAll(async () => {
    await app.close();
  });

  async function login(email: string) {
    const agent = request.agent(app.getHttpServer());
    const res = await agent.post('/v1/auth/login').send({ email, password: PASSWORD });
    expect(res.status).toBe(200);
    return { agent, profile: res.body as { branches: { id: string; permissions: string[] }[] }, res };
  }

  it('GET /health is public and reports the database', async () => {
    const res = await request(app.getHttpServer()).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.database).toBe('up');
  });

  it('rejects unauthenticated requests', async () => {
    const res = await request(app.getHttpServer()).get('/v1/auth/me');
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('UNAUTHENTICATED');
  });

  it('rejects a wrong password with a generic message', async () => {
    const res = await request(app.getHttpServer()).post('/v1/auth/login').send({ email: 'cashier@demo.local', password: 'definitely-wrong-1' });
    expect(res.status).toBe(401);
    expect(res.body.error.message).toBe('Invalid email or password');
  });

  it('rejects an unknown email the same way', async () => {
    const res = await request(app.getHttpServer()).post('/v1/auth/login').send({ email: 'nobody@demo.local', password: 'whatever-123456' });
    expect(res.status).toBe(401);
    expect(res.body.error.message).toBe('Invalid email or password');
  });

  it('validates the request body', async () => {
    const res = await request(app.getHttpServer()).post('/v1/auth/login').send({ email: 'not-an-email' });
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('logs a cashier in with an httpOnly cookie and only cashier permissions', async () => {
    const { profile, res } = await login('cashier@demo.local');
    const cookie = (res.headers['set-cookie'] as unknown as string[]).join(';');
    expect(cookie).toMatch(/HttpOnly/i);
    expect(profile.branches.length).toBeGreaterThan(0);
    const perms = profile.branches[0]?.permissions ?? [];
    expect(perms).toContain('sale:create');
    expect(perms).not.toContain('user:manage');
  });

  it('denies a cashier a manager-only action (server-side RBAC)', async () => {
    const { agent } = await login('cashier@demo.local');
    const res = await agent.post('/v1/branches').set(CSRF).send({ name: 'Nope', code: 'NOPE' });
    expect(res.status).toBe(403);
    expect(res.body.error.message).toMatch(/Missing permission/);
  });

  it('requires the CSRF header on writes made with a session cookie', async () => {
    const { agent } = await login('owner@demo.local');
    const res = await agent.post('/v1/branches').send({ name: 'No CSRF', code: 'NOCSRF' });
    expect(res.status).toBe(403);
    expect(res.body.error.message).toMatch(/CSRF/);
  });

  it('enforces branch scoping through X-Branch-Id', async () => {
    const { agent, profile } = await login('cashier@demo.local');
    const branchId = profile.branches[0]?.id as string;
    expect((await agent.get('/v1/branches/current')).status).toBe(400);
    expect((await agent.get('/v1/branches/current').set('X-Branch-Id', '11111111-1111-4111-8111-111111111111')).status).toBe(403);
    const ok = await agent.get('/v1/branches/current').set('X-Branch-Id', branchId);
    expect(ok.status).toBe(200);
    expect(ok.body.id).toBe(branchId);
  });

  it('lets an owner create a branch, and reports duplicates as 409', async () => {
    const { agent } = await login('owner@demo.local');
    const code = `T${randomBytes(3).toString('hex').toUpperCase()}`;
    const created = await agent.post('/v1/branches').set(CSRF).send({ name: `Test ${code}`, code });
    expect(created.status).toBe(201);
    const list = await agent.get('/v1/branches');
    expect(list.body.some((b: { code: string }) => b.code === code)).toBe(true);
    const dup = await agent.post('/v1/branches').set(CSRF).send({ name: 'Dup', code });
    expect(dup.status).toBe(409);
  });

  it('blocks privilege escalation: a manager cannot hand out the Owner role', async () => {
    const owner = await login('owner@demo.local');
    const roles = await owner.agent.get('/v1/roles');
    const ownerRole = (roles.body as { id: string; systemKey: string }[]).find((r) => r.systemKey === 'OWNER');
    const manager = await login('manager@demo.local');
    const branchId = manager.profile.branches[0]?.id as string;
    const res = await manager.agent.post('/v1/users').set(CSRF).send({
      email: `esc-${randomBytes(4).toString('hex')}@demo.local`,
      fullName: 'Escalation Test',
      password: 'a-long-password-123',
      branchRoles: [{ branchId, roleId: ownerRole?.id }],
    });
    expect(res.status).toBe(403);
  });

  it('records audit entries for logins and changes', async () => {
    const { agent } = await login('owner@demo.local');
    const res = await agent.get('/v1/audit-logs').query({ action: 'auth.login', pageSize: 5 });
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0].action).toBe('auth.login');
  });

  it('does not allow system roles to be edited', async () => {
    const { agent } = await login('owner@demo.local');
    const roles = await agent.get('/v1/roles');
    const cashier = (roles.body as { id: string; systemKey: string }[]).find((r) => r.systemKey === 'CASHIER');
    const res = await agent.patch(`/v1/roles/${cashier?.id}`).set(CSRF).send({ name: 'Hacked' });
    expect(res.status).toBe(403);
  });

  it('logout revokes the session', async () => {
    const { agent } = await login('pharmacist@demo.local');
    expect((await agent.get('/v1/auth/me')).status).toBe(200);
    expect((await agent.post('/v1/auth/logout').set(CSRF)).status).toBe(204);
    expect((await agent.get('/v1/auth/me')).status).toBe(401);
  });
});
