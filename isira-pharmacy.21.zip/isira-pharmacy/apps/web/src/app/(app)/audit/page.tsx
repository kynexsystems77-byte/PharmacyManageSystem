'use client';

import { ChevronDown, ChevronRight } from 'lucide-react';
import { Fragment, useState } from 'react';
import { Forbidden, PageHeader, Pagination, SearchBox } from '@/components/kit';
import { Card, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { AuditRow } from '@/lib/types';

/** Fields that changed between before and after (shallow). */
function changes(before: unknown, after: unknown): { key: string; from: unknown; to: unknown }[] {
  const b = (before && typeof before === 'object' ? before : {}) as Record<string, unknown>;
  const a = (after && typeof after === 'object' ? after : {}) as Record<string, unknown>;
  const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])];
  return keys.filter((k) => JSON.stringify(b[k]) !== JSON.stringify(a[k])).map((k) => ({ key: k, from: b[k], to: a[k] }));
}
const show = (v: unknown) => (v === undefined ? '—' : typeof v === 'string' ? v : JSON.stringify(v));

export default function AuditPage() {
  const { can } = useAuth();
  const [action, setAction] = useState('');
  const [entityType, setEntityType] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const a = useDebounced(action);
  const e = useDebounced(entityType);
  const { page, setPage } = usePaging([a, e, from, to]);
  const { data, isLoading } = useBranchQuery<Paged<AuditRow>>(can('audit:read') ? `/audit-logs${qs({
    page, pageSize: 50, action: a, entityType: e,
    from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined, to: to ? new Date(`${to}T23:59:59.999`).toISOString() : undefined,
  })}` : null, { keepPrevious: true });
  if (!can('audit:read')) return <Forbidden what="the audit log" />;
  return (
    <div>
      <PageHeader title="Audit log" subtitle="Every change, who made it and when. Entries cannot be edited or deleted." />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_160px_160px]">
          <SearchBox value={action} onChange={setAction} placeholder="Action (e.g. sale.voided, price)" />
          <SearchBox value={entityType} onChange={setEntityType} placeholder="Entity type (sale, product, user…)" />
          <Input type="date" value={from} onChange={(ev) => setFrom(ev.target.value)} aria-label="From" />
          <Input type="date" value={to} onChange={(ev) => setTo(ev.target.value)} aria-label="To" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead><tr className="border-b border-line text-left text-xs uppercase tracking-wide text-fg-muted"><th className="w-8" /><th className="px-3 py-2 font-medium">When</th><th className="px-3 py-2 font-medium">Who</th><th className="px-3 py-2 font-medium">Action</th><th className="px-3 py-2 font-medium">Entity</th><th className="px-3 py-2 font-medium">IP</th></tr></thead>
            <tbody className="divide-y divide-line">
              {isLoading && <tr><td colSpan={6} className="px-4 py-6 text-center text-fg-muted">Loading…</td></tr>}
              {data?.data.map((r) => {
                const diff = changes(r.before, r.after);
                const isOpen = open === r.id;
                return (
                  <Fragment key={r.id}>
                    <tr className="cursor-pointer hover:bg-subtle/60" onClick={() => setOpen(isOpen ? null : r.id)}>
                      <td className="pl-3 text-fg-muted">{isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</td>
                      <td className="whitespace-nowrap px-3 py-2">{dateTime(r.createdAt)}</td>
                      <td className="px-3 py-2">{r.user?.fullName ?? 'System'}</td>
                      <td className="px-3 py-2 font-mono text-xs">{r.action}</td>
                      <td className="px-3 py-2"><span>{r.entityType}</span> <span className="font-mono text-[11px] text-fg-muted">{r.entityId?.slice(0, 8)}</span></td>
                      <td className="px-3 py-2 text-xs text-fg-muted">{r.ipAddress ?? ''}</td>
                    </tr>
                    {isOpen && (
                      <tr className="bg-subtle/40">
                        <td />
                        <td colSpan={5} className="px-3 py-3">
                          {diff.length === 0 ? <p className="text-xs text-fg-muted">No field-level details recorded.</p> : (
                            <table className="w-full text-xs">
                              <thead><tr className="text-left text-fg-muted"><th className="py-1 pr-3">Field</th><th className="py-1 pr-3">Before</th><th className="py-1">After</th></tr></thead>
                              <tbody>
                                {diff.slice(0, 40).map((d) => (
                                  <tr key={d.key} className="align-top"><td className="py-1 pr-3 font-mono">{d.key}</td><td className="max-w-[320px] break-words py-1 pr-3 text-danger">{show(d.from)}</td><td className="max-w-[320px] break-words py-1 text-success">{show(d.to)}</td></tr>
                                ))}
                              </tbody>
                            </table>
                          )}
                          {r.requestId && <p className="mt-2 text-[11px] text-fg-muted">Request {r.requestId}</p>}
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
