'use client';

import clsx from 'clsx';
import { Pill, ScanLine } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { dateOnly, expiryTone, num, qty, productName } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, type Paged } from '@/lib/hooks';
import type { BatchRow, CurrentBranch, Product } from '@/lib/types';
import { Spinner } from './kit';
import { Badge } from './ui';

/**
 * Search-as-you-type product picker (name, generic, SKU or exact barcode). Enter picks the first match,
 * so a barcode scanner (which types the code and presses Enter) works out of the box.
 */
export function ProductPicker({
  onPick, placeholder = 'Search medicine, SKU or scan barcode', autoFocus, withStock = true, clearOnPick = true, className,
}: {
  onPick: (p: Product) => void;
  placeholder?: string;
  autoFocus?: boolean;
  withStock?: boolean;
  clearOnPick?: boolean;
  className?: string;
}) {
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const search = useDebounced(text.trim(), 200);
  const box = useRef<HTMLDivElement>(null);
  const { data, isFetching } = useBranchQuery<Paged<Product>>(
    search ? `/products${qs({ search, pageSize: 10, withStock: withStock || undefined })}` : null,
    { staleTime: 5_000 },
  );
  const items = search ? (data?.data ?? []) : [];

  useEffect(() => setActive(0), [search]);
  // A barcode scanner types the code and presses Enter at once, before the search has answered.
  // Remember that Enter and pick the product as soon as the results for exactly that text arrive.
  const [pendingEnter, setPendingEnter] = useState<string | null>(null);
  useEffect(() => {
    if (!pendingEnter || search !== pendingEnter || isFetching || !data) return;
    const code = pendingEnter.toLowerCase();
    const exact = items.find((p) => p.barcode?.toLowerCase() === code || p.sku.toLowerCase() === code);
    const p = exact ?? (items.length === 1 ? items[0] : undefined);
    setPendingEnter(null);
    if (p) pick(p);
  }, [pendingEnter, search, isFetching, data]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const pick = (p: Product) => {
    onPick(p);
    if (clearOnPick) setText('');
    setOpen(false);
  };

  return (
    <div ref={box} className={clsx('relative', className)}>
      <ScanLine size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-fg-muted" />
      <input
        value={text}
        autoFocus={autoFocus}
        onChange={(e) => {
          setText(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            setActive((a) => Math.min(a + 1, items.length - 1));
          } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setActive((a) => Math.max(a - 1, 0));
          } else if (e.key === 'Enter') {
            e.preventDefault();
            const p = items[active];
            if (p && search === text.trim() && !isFetching) pick(p);
            else if (text.trim()) setPendingEnter(text.trim());
          } else if (e.key === 'Escape') setOpen(false);
        }}
        placeholder={placeholder}
        aria-label={placeholder}
        role="combobox"
        aria-expanded={open && items.length > 0}
        className="h-10 w-full rounded-lg border border-line bg-surface pl-9 pr-9 text-sm placeholder:text-fg-muted/70 focus-visible:border-brand"
      />
      {isFetching && <Spinner className="absolute right-3 top-3 text-fg-muted" />}
      {open && search && (
        <ul role="listbox" className="absolute z-40 mt-1 max-h-80 w-full overflow-y-auto rounded-lg border border-line bg-surface py-1 shadow-lg">
          {items.length === 0 && !isFetching && <li className="px-3 py-2 text-sm text-fg-muted">No matching products</li>}
          {items.map((p, i) => (
            <li
              key={p.id}
              role="option"
              aria-selected={i === active}
              onMouseEnter={() => setActive(i)}
              onMouseDown={(e) => {
                e.preventDefault();
                pick(p);
              }}
              className={clsx('flex cursor-pointer items-center gap-3 px-3 py-2 text-sm', i === active && 'bg-subtle')}
            >
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand"><Pill size={16} /></span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-medium">{productName(p.brandName, p.strength)}</span>
                <span className="block truncate text-xs text-fg-muted">{[p.genericName, p.sku, p.dosageForm.toLowerCase()].filter(Boolean).join(' · ')}</span>
              </span>
              {p.requiresPrescription && <Badge tone="warning">Rx</Badge>}
              {p.stock !== undefined && (
                <span className={clsx('tabular shrink-0 text-xs', num(p.stock) > 0 ? 'text-fg-muted' : 'text-danger')}>
                  {qty(num(p.stock))} {p.baseUnit}
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Batches of a product that have stock at a location (or anywhere in the branch). */
export function useBatches(productId: string | null, locationId?: string | null, inStock = true) {
  return useBranchQuery<Paged<BatchRow> & { today: string }>(
    productId ? `/inventory/batches${qs({ productId, locationId: locationId ?? undefined, inStock, pageSize: 100 })}` : null,
  );
}

export function BatchSelect({
  productId, locationId, value, onChange, includeEmpty = false, onlySellable = false,
}: {
  productId: string | null;
  locationId?: string | null;
  value: string;
  onChange: (batchId: string, batch: BatchRow | undefined) => void;
  includeEmpty?: boolean;
  onlySellable?: boolean;
}) {
  const { data, isLoading } = useBatches(productId, locationId, !includeEmpty);
  const rows = (data?.data ?? []).filter((b) => !onlySellable || b.sellable);
  return (
    <select
      value={value}
      disabled={!productId || isLoading}
      onChange={(e) => onChange(e.target.value, rows.find((b) => b.id === e.target.value))}
      className="h-10 w-full rounded-lg border border-line bg-surface px-2.5 text-sm"
      aria-label="Batch"
    >
      <option value="">{isLoading ? 'Loading batches…' : rows.length ? 'Choose a batch' : 'No batches with stock'}</option>
      {rows.map((b) => (
        <option key={b.id} value={b.id}>
          {b.batchNumber} · exp {dateOnly(b.expiryDate)} · {qty(num(b.quantity))} {b.baseUnit}
          {b.daysLeft !== null && b.daysLeft < 0 ? ' · EXPIRED' : ''}{b.status !== 'ACTIVE' ? ` · ${b.status}` : ''}
        </option>
      ))}
    </select>
  );
}

export function ExpiryBadge({ date, warnDays = 30 }: { date: string | null; warnDays?: number }) {
  if (!date) return <span className="text-fg-muted">No expiry</span>;
  const d = date.slice(0, 10);
  const [y, m, dd] = d.split('-').map(Number);
  const now = new Date();
  const days = Math.round((Date.UTC(y, m - 1, dd) - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86_400_000);
  const tone = expiryTone(days, warnDays);
  return (
    <span className="inline-flex items-center gap-1.5">
      <span>{dateOnly(d)}</span>
      {tone === 'danger' && <Badge tone="danger">Expired</Badge>}
      {tone === 'warning' && <Badge tone="warning">{days}d left</Badge>}
    </span>
  );
}

/** Locations of the selected branch (for location dropdowns). */
export function useCurrentBranch() {
  return useBranchQuery<CurrentBranch>('/branches/current', { staleTime: 60_000 });
}

export function LocationSelect({ value, onChange, allowAll }: { value: string; onChange: (id: string) => void; allowAll?: boolean }) {
  const { data } = useCurrentBranch();
  const locs = data?.locations ?? [];
  useEffect(() => {
    if (!allowAll && !value && locs.length) onChange((locs.find((l) => l.isDefault) ?? locs[0]).id);
  }, [allowAll, value, locs, onChange]);
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="h-10 w-full rounded-lg border border-line bg-surface px-2.5 text-sm" aria-label="Location">
      {allowAll && <option value="">All locations</option>}
      {locs.map((l) => (
        <option key={l.id} value={l.id}>{l.name}{l.isDefault ? ' (default)' : ''}</option>
      ))}
    </select>
  );
}
