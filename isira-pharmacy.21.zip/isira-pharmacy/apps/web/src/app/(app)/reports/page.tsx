'use client';

import { BarChart3, Boxes, Users, Wallet } from 'lucide-react';
import Link from 'next/link';
import type { ReportDefinition } from '@kynex/contracts';
import { Forbidden, PageHeader } from '@/components/kit';
import { Card, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { useBranchQuery } from '@/lib/hooks';

const ICONS = { Sales: BarChart3, Finance: Wallet, Inventory: Boxes, Parties: Users } as const;
const GROUPS = ['Sales', 'Finance', 'Inventory', 'Parties'] as const;

export default function ReportsPage() {
  const { canAny } = useAuth();
  const { data, isLoading } = useBranchQuery<{ canExport: boolean; reports: ReportDefinition[] }>('/reports');
  if (!canAny('report:sales:view', 'report:financial:view', 'report:inventory:view')) return <Forbidden what="reports" />;
  return (
    <div className="space-y-6">
      <PageHeader title="Reports" subtitle={data?.canExport ? 'Every report can be exported to CSV, Excel and PDF.' : 'Exporting files needs the report:export permission.'} />
      {isLoading && <Skeleton className="h-64" />}
      {GROUPS.map((g) => {
        const items = data?.reports.filter((r) => r.group === g) ?? [];
        if (!items.length) return null;
        const Icon = ICONS[g];
        return (
          <section key={g}>
            <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-fg-muted"><Icon size={16} /> {g === 'Parties' ? 'Customers & suppliers' : g}</h2>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {items.map((r) => (
                <Link key={r.key} href={`/reports/${r.key}`}>
                  <Card className="h-full p-4 transition hover:border-brand/50">
                    <p className="font-medium">{r.title}</p>
                    <p className="mt-1 text-sm text-fg-muted">{r.description}</p>
                  </Card>
                </Link>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
