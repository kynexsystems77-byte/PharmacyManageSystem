'use client';

import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query';
import clsx from 'clsx';
import { CreditCard, FileText, Minus, PauseCircle, Plus, Printer, Receipt, RotateCcw, Trash2, Wallet } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CustomerPicker } from '@/components/customer-picker';
import { ExpiryAlertModal, playExpiryAlert } from '@/components/expiry-alert';
import { Forbidden, Modal, Select, useToast } from '@/components/kit';
import { ProductPicker } from '@/components/pickers';
import { OpenShiftCard, ShiftModal, useMyShift } from '@/components/shift-panel';
import { Alert, Badge, Button, Card, Input, Skeleton } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, productName, qty, titleCase } from '@/lib/format';
import { errorMessage, newKey, qs, useApiMutation, useBranchQuery, useDebounced, useHotkey, type Paged } from '@/lib/hooks';
import { receiptUrl } from '@/lib/status';
import type { Customer, ExpiryCheck, Prescription, Product, Quote, Sale } from '@/lib/types';

interface Line {
  key: string;
  product: Product;
  unitId: string; // '' = base unit
  quantity: string;
  discountType: 'PERCENT' | 'AMOUNT';
  discount: string;
  batchId: string; // '' = FEFO
  prescriptionItemId?: string;
}
interface PayRow { key: string; method: string; amount: string; reference: string }

const METHODS = [
  { v: 'CASH', l: 'Cash', icon: Wallet },
  { v: 'CARD', l: 'Card', icon: CreditCard },
  { v: 'BANK_TRANSFER', l: 'Transfer', icon: Receipt },
  { v: 'CUSTOMER_CREDIT', l: 'Credit', icon: FileText },
];

function defaultUnit(p: Product): string {
  return p.productUnits.find((u) => u.isDefaultSaleUnit)?.id ?? '';
}

function lineBody(l: Line) {
  const d = num(l.discount);
  return {
    productId: l.product.id,
    productUnitId: l.unitId || undefined,
    quantity: num(l.quantity),
    batchId: l.batchId || undefined,
    prescriptionItemId: l.prescriptionItemId,
    ...(d > 0 ? (l.discountType === 'PERCENT' ? { discountPercent: d } : { discountAmount: d }) : {}),
  };
}

export default function PosPage() {
  const { can, profile, branchId } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const cur = profile.tenant.currencyCode;
  const fmt = (v: string | number) => money(num(v), cur);

  const shift = useMyShift();
  const [lines, setLines] = useState<Line[]>([]);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [prescriptionId, setPrescriptionId] = useState('');
  const [billType, setBillType] = useState<'PERCENT' | 'AMOUNT'>('PERCENT');
  const [billValue, setBillValue] = useState('');
  const [rxOverride, setRxOverride] = useState(false);
  const [notes, setNotes] = useState('');
  const [pays, setPays] = useState<PayRow[]>([{ key: newKey(), method: 'CASH', amount: '', reference: '' }]);
  const [heldSaleId, setHeldSaleId] = useState<string | null>(null);
  const [idemKey, setIdemKey] = useState(newKey);
  const [done, setDone] = useState<Sale | null>(null);
  const [showHeld, setShowHeld] = useState(false);
  const [showShift, setShowShift] = useState(false);
  const [expiryAlert, setExpiryAlert] = useState<{ product: Product; check: ExpiryCheck } | null>(null);
  /** Products whose expiry warning the cashier already accepted on this bill (no repeat popup on every scan). */
  const expiryAcked = useRef(new Set<string>());
  const searchRef = useRef<HTMLDivElement>(null);
  const customerRef = useRef<HTMLInputElement>(null);

  const focusSearch = useCallback(() => searchRef.current?.querySelector('input')?.focus(), []);
  useHotkey('F2', (e) => { e.preventDefault(); focusSearch(); }, true);
  useHotkey('F4', (e) => { e.preventDefault(); customerRef.current?.focus(); }, true);
  useHotkey('F9', (e) => { e.preventDefault(); setShowHeld(true); }, true);

  // ---- server-side pricing (the client never computes the bill on its own) -------------------
  const quoteBody = useMemo(() => {
    const items = lines.filter((l) => num(l.quantity) > 0).map(lineBody);
    if (items.length === 0) return null;
    return {
      items,
      customerId: customer?.id,
      prescriptionId: prescriptionId || undefined,
      rxOverride: rxOverride || undefined,
      billDiscount: num(billValue) > 0 ? { type: billType, value: num(billValue) } : undefined,
    };
  }, [lines, customer, prescriptionId, rxOverride, billType, billValue]);
  const debouncedBody = useDebounced(quoteBody, 200);
  const quote = useQuery({
    queryKey: [branchId, 'pos-quote', debouncedBody],
    queryFn: () => api<Quote>('/sales/quote', { method: 'POST', body: debouncedBody, branchId }),
    enabled: Boolean(debouncedBody && branchId),
    placeholderData: keepPreviousData,
    retry: false,
  });
  const q = quoteBody ? quote.data : undefined;
  const total = num(q?.grandTotal);
  const stale = quote.isFetching || JSON.stringify(quoteBody) !== JSON.stringify(debouncedBody);

  const prescriptions = useBranchQuery<Paged<Prescription>>(customer && can('prescription:read') ? `/prescriptions${qs({ customerId: customer.id, dispensable: true, pageSize: 20 })}` : null);

  // ---- cart editing --------------------------------------------------------------------------
  const addNow = (p: Product) => {
    setLines((ls) => {
      const unitId = defaultUnit(p);
      const same = ls.find((l) => l.product.id === p.id && l.unitId === unitId && !l.batchId);
      if (same) return ls.map((l) => (l === same ? { ...l, quantity: String(num(l.quantity) + 1) } : l));
      return [...ls, { key: newKey(), product: p, unitId, quantity: '1', discountType: 'PERCENT', discount: '', batchId: '' }];
    });
  };
  /** Scanning a product first asks the API which batch will be sold; near-expiry or expired stock opens a popup. */
  const add = async (p: Product) => {
    if (!p.trackExpiry || expiryAcked.current.has(p.id)) { addNow(p); return; }
    try {
      const check = await api<ExpiryCheck>(`/sales/expiry-check${qs({ productId: p.id })}`, { branchId });
      if (check.level === 'none') { addNow(p); return; }
      playExpiryAlert(check.level);
      setExpiryAlert({ product: p, check });
    } catch {
      addNow(p); // never block the till if the check itself fails; the sale is still validated server-side
    }
  };
  const setLine = (key: string, patch: Partial<Line>) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const reset = () => {
    setLines([]); setCustomer(null); setPrescriptionId(''); setBillValue(''); setRxOverride(false); setNotes('');
    setPays([{ key: newKey(), method: 'CASH', amount: '', reference: '' }]); setHeldSaleId(null); setIdemKey(newKey());
    expiryAcked.current.clear();
    setTimeout(focusSearch, 50);
  };

  // ---- payments ------------------------------------------------------------------------------
  const payRows = pays.map((p) => ({ ...p, value: p.amount === '' && pays.length === 1 ? total : num(p.amount) }));
  const paid = payRows.reduce((a, p) => a + p.value, 0);
  const nonCash = payRows.filter((p) => p.method !== 'CASH').reduce((a, p) => a + p.value, 0);
  const cash = paid - nonCash;
  const change = Math.max(0, Math.round((cash - Math.max(0, total - nonCash)) * 100) / 100);
  const remaining = Math.max(0, Math.round((total - paid) * 100) / 100);

  const complete = useApiMutation<object, Sale>('POST', '/sales', {
    onSuccess: (s) => {
      setDone(s);
      void qc.invalidateQueries();
      if (s.warnings?.length) toast.success(s.warnings.join(' · '));
    },
    invalidate: false,
  });
  const hold = useApiMutation<object, Sale>('POST', '/sales/hold', {
    onSuccess: () => { toast.success('Bill put on hold'); reset(); },
  });

  const canCharge = Boolean(q) && !stale && lines.length > 0 && remaining <= 0 && !quote.isError && !(q?.lines.some((l) => num(l.shortfall) > 0));
  const charge = () => {
    if (!canCharge || complete.isPending) return;
    complete.mutate({
      idempotencyKey: idemKey,
      customerId: customer?.id,
      prescriptionId: prescriptionId || undefined,
      rxOverride: rxOverride || undefined,
      notes: notes.trim() || undefined,
      billDiscount: num(billValue) > 0 ? { type: billType, value: num(billValue) } : undefined,
      items: lines.map(lineBody),
      payments: payRows.filter((p) => p.value > 0).map((p) => ({ method: p.method, amount: p.value, reference: p.reference.trim() || undefined })),
      heldSaleId: heldSaleId ?? undefined,
    });
  };
  useHotkey('F12', (e) => { e.preventDefault(); charge(); }, true);
  useHotkey('F8', (e) => {
    e.preventDefault();
    if (lines.length) hold.mutate({ items: lines.map(lineBody), customerId: customer?.id, notes: notes.trim() || undefined, heldSaleId: heldSaleId ?? undefined, billDiscount: num(billValue) > 0 ? { type: billType, value: num(billValue) } : undefined });
  }, true);

  useEffect(() => { if (!customer) setPrescriptionId(''); }, [customer]);

  if (!can('sale:create')) return <Forbidden what="the point of sale" />;
  if (shift.isLoading) return <Skeleton className="h-96" />;
  const current = shift.data?.current;
  if (!current) {
    return (
      <div className="py-10">
        <OpenShiftCard />
      </div>
    );
  }

  const quoteError = quote.error instanceof ApiError ? quote.error.message : quote.error ? 'Could not price the bill' : null;
  const quickCash = [total, ...[100, 500, 1000, 5000].map((s) => Math.ceil(total / s) * s)].filter((v, i, a) => v > 0 && a.indexOf(v) === i).slice(0, 4);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-xl font-semibold">Point of sale</h1>
          <p className="text-xs text-fg-muted">F2 search · F4 customer · F8 hold · F9 held bills · F12 charge</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {heldSaleId && <Badge tone="warning">Resumed held bill</Badge>}
          <Button variant="outline" onClick={() => setShowHeld(true)}><PauseCircle size={16} /> Held bills</Button>
          <Button variant="outline" onClick={() => setShowShift(true)}>
            <Wallet size={16} /> {current.shift.register.name} · {fmt(current.expectedCash)}
          </Button>
          {lines.length > 0 && <Button variant="ghost" onClick={reset}><RotateCcw size={16} /> Clear</Button>}
        </div>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1fr_400px]">
        {/* ---------------- cart ---------------- */}
        <Card className="flex min-h-[60vh] flex-col">
          <div ref={searchRef} className="border-b border-line p-3">
            <ProductPicker autoFocus onPick={add} placeholder="Scan a barcode or search medicine (F2)" />
          </div>
          <div className="flex-1 overflow-x-auto">
            {lines.length === 0 ? (
              <div className="grid h-full place-items-center p-10 text-center text-sm text-fg-muted">
                <div><Receipt className="mx-auto mb-2 opacity-40" size={36} />Scan or search to add items</div>
              </div>
            ) : (
              <table className="w-full min-w-[640px] text-sm">
                <thead>
                  <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-fg-muted">
                    <th className="px-3 py-2 font-medium">Item</th>
                    <th className="px-2 py-2 font-medium">Unit</th>
                    <th className="px-2 py-2 text-center font-medium">Qty</th>
                    <th className="px-2 py-2 text-right font-medium">Price</th>
                    <th className="px-2 py-2 font-medium">Discount</th>
                    <th className="px-3 py-2 text-right font-medium">Total</th>
                    <th />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {lines.map((l, i) => {
                    const ql = q?.lines.find((x) => x.index === i);
                    const short = ql && num(ql.shortfall) > 0;
                    return (
                      <tr key={l.key} className={clsx(short && 'bg-danger/5')}>
                        <td className="px-3 py-2 align-top">
                          <p className="flex items-center gap-1.5 font-medium">
                            <span>{productName(l.product.brandName, l.product.strength)}</span>
                            {l.product.requiresPrescription && <Badge tone="warning">Rx</Badge>}
                          </p>
                          <p className="text-xs text-fg-muted">
                            {ql?.allocations.length
                              ? ql.allocations.map((a) => `${a.batchNumber} ×${qty(num(a.quantity))} (exp ${dateOnly(a.expiryDate)})`).join(' · ')
                              : l.product.sku}
                          </p>
                          {short && <p className="text-xs font-medium text-danger">Short by {qty(num(ql!.shortfall))} {l.product.baseUnit}</p>}
                          {can('sale:batch:override') && (
                            <BatchOverride productId={l.product.id} value={l.batchId} onChange={(v) => setLine(l.key, { batchId: v })} />
                          )}
                        </td>
                        <td className="px-2 py-2 align-top">
                          {l.product.productUnits.length > 0 ? (
                            <select value={l.unitId} onChange={(e) => setLine(l.key, { unitId: e.target.value })} className="h-9 rounded-lg border border-line bg-surface px-2 text-sm" aria-label="Unit">
                              <option value="">{l.product.baseUnit}</option>
                              {l.product.productUnits.map((u) => <option key={u.id} value={u.id}>{u.name} ({qty(num(u.factorToBase))})</option>)}
                            </select>
                          ) : <span className="text-fg-muted">{l.product.baseUnit}</span>}
                        </td>
                        <td className="px-2 py-2 align-top">
                          <div className="flex items-center justify-center gap-1">
                            <button aria-label="Decrease" onClick={() => setLine(l.key, { quantity: String(Math.max(1, num(l.quantity) - 1)) })} className="grid h-9 w-8 place-items-center rounded-lg border border-line hover:bg-subtle"><Minus size={14} /></button>
                            <input value={l.quantity} onChange={(e) => setLine(l.key, { quantity: e.target.value })} inputMode="decimal" aria-label="Quantity" className="h-9 w-14 rounded-lg border border-line bg-surface text-center text-sm tabular" />
                            <button aria-label="Increase" onClick={() => setLine(l.key, { quantity: String(num(l.quantity) + 1) })} className="grid h-9 w-8 place-items-center rounded-lg border border-line hover:bg-subtle"><Plus size={14} /></button>
                          </div>
                        </td>
                        <td className="px-2 py-2 text-right align-top tabular">{ql ? fmt(ql.unitPrice) : '…'}</td>
                        <td className="px-2 py-2 align-top">
                          {can('sale:discount') ? (
                            <div className="flex">
                              <input value={l.discount} onChange={(e) => setLine(l.key, { discount: e.target.value })} inputMode="decimal" placeholder="0" aria-label="Line discount" className="h-9 w-16 rounded-l-lg border border-line bg-surface px-2 text-sm tabular" />
                              <button onClick={() => setLine(l.key, { discountType: l.discountType === 'PERCENT' ? 'AMOUNT' : 'PERCENT' })} className="h-9 rounded-r-lg border border-l-0 border-line px-2 text-xs text-fg-muted hover:bg-subtle" aria-label="Toggle discount type">
                                {l.discountType === 'PERCENT' ? '%' : cur}
                              </button>
                            </div>
                          ) : <span className="text-fg-muted">-</span>}
                        </td>
                        <td className="px-3 py-2 text-right align-top font-semibold tabular">{ql ? fmt(ql.lineTotal) : '…'}</td>
                        <td className="py-2 pr-2 align-top">
                          <button aria-label="Remove item" onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))} className="grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </Card>

        {/* ---------------- checkout ---------------- */}
        <div className="space-y-3">
          <Card className="space-y-3 p-3">
            <CustomerPicker ref={customerRef} value={customer} onChange={setCustomer} />
            {customer && (prescriptions.data?.data.length ?? 0) > 0 && (
              <Select value={prescriptionId} onChange={(e) => setPrescriptionId(e.target.value)} aria-label="Prescription">
                <option value="">No prescription attached</option>
                {prescriptions.data!.data.map((r) => <option key={r.id} value={r.id}>{r.prescriptionNumber ?? 'Rx'} · {r.doctorName} · {dateOnly(r.prescribedDate)}</option>)}
              </Select>
            )}
            {q?.needsPrescription && !prescriptionId && (
              <div className="rounded-lg border border-warning/40 bg-warning/10 p-2 text-xs">
                <p className="font-medium text-warning">Prescription medicine on this bill.</p>
                {can('prescription:manage') ? (
                  <label className="mt-1 flex items-center gap-2"><input type="checkbox" checked={rxOverride} onChange={(e) => setRxOverride(e.target.checked)} /> I have checked the prescription (pharmacist)</label>
                ) : <p className="mt-1">Attach the customer&apos;s prescription or ask a pharmacist.</p>}
              </div>
            )}
          </Card>

          <Card className="space-y-2 p-3 text-sm">
            <Row label="Subtotal" value={q ? fmt(q.subtotal) : '-'} />
            {can('sale:discount') && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-fg-muted">Bill discount</span>
                <div className="flex">
                  <input value={billValue} onChange={(e) => setBillValue(e.target.value)} inputMode="decimal" placeholder="0" aria-label="Bill discount" className="h-8 w-20 rounded-l-lg border border-line bg-surface px-2 text-right text-sm tabular" />
                  <button onClick={() => setBillType(billType === 'PERCENT' ? 'AMOUNT' : 'PERCENT')} className="h-8 rounded-r-lg border border-l-0 border-line px-2 text-xs text-fg-muted hover:bg-subtle">{billType === 'PERCENT' ? '%' : cur}</button>
                </div>
              </div>
            )}
            {q && num(q.discountTotal) > 0 && <Row label="Discounts" value={`- ${fmt(q.discountTotal)}`} />}
            {q && num(q.taxTotal) > 0 && <Row label={q.lines.every((l) => l.taxInclusive) ? 'Tax (included)' : 'Tax'} value={fmt(q.taxTotal)} />}
            {q && num(q.roundingAdjustment) !== 0 && <Row label="Rounding" value={fmt(q.roundingAdjustment)} />}
            <div className="flex items-end justify-between border-t border-line pt-2">
              <span className="font-medium">Total</span>
              <span className={clsx('tabular text-3xl font-bold', stale && 'opacity-60')}>{fmt(total)}</span>
            </div>
            {q && can('sale:discount') && <p className="text-right text-xs text-fg-muted">Your discount limit: {q.maxDiscountPercent}%</p>}
            {quoteError && <Alert>{quoteError}</Alert>}
            {q?.warnings.map((w) => <p key={w} className="rounded-lg bg-warning/10 px-2 py-1 text-xs text-warning">{w}</p>)}
          </Card>

          <Card className="space-y-2 p-3">
            {pays.map((p) => (
              <div key={p.key} className="space-y-1.5">
                <div className="grid grid-cols-4 gap-1">
                  {METHODS.map((m) => (
                    <button
                      key={m.v}
                      disabled={m.v === 'CUSTOMER_CREDIT' && !customer}
                      onClick={() => setPays((ps) => ps.map((x) => (x.key === p.key ? { ...x, method: m.v } : x)))}
                      className={clsx('flex h-9 items-center justify-center gap-1 rounded-lg border text-xs font-medium disabled:opacity-40', p.method === m.v ? 'border-brand bg-brand/10 text-brand' : 'border-line hover:bg-subtle')}
                    >
                      <m.icon size={14} /> {m.l}
                    </button>
                  ))}
                </div>
                <div className="flex gap-1">
                  <Input value={p.amount} onChange={(e) => setPays((ps) => ps.map((x) => (x.key === p.key ? { ...x, amount: e.target.value } : x)))} inputMode="decimal" placeholder={pays.length === 1 ? `Exact ${fmt(total)}` : 'Amount'} aria-label="Amount" className="tabular" />
                  {p.method !== 'CASH' && <Input value={p.reference} onChange={(e) => setPays((ps) => ps.map((x) => (x.key === p.key ? { ...x, reference: e.target.value } : x)))} placeholder="Ref" aria-label="Reference" className="w-28" />}
                  {pays.length > 1 && <button aria-label="Remove payment" onClick={() => setPays((ps) => ps.filter((x) => x.key !== p.key))} className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-fg-muted hover:bg-subtle"><Trash2 size={15} /></button>}
                </div>
                {p.method === 'CASH' && pays.length === 1 && total > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {quickCash.map((v) => <button key={v} onClick={() => setPays((ps) => ps.map((x) => (x.key === p.key ? { ...x, amount: String(v) } : x)))} className="rounded-md border border-line px-2 py-1 text-xs tabular hover:bg-subtle">{fmt(v)}</button>)}
                  </div>
                )}
              </div>
            ))}
            <button onClick={() => setPays((ps) => [...ps, { key: newKey(), method: 'CARD', amount: remaining > 0 ? String(remaining) : '', reference: '' }])} className="text-xs font-medium text-brand hover:underline">+ Split payment</button>
            <div className="space-y-1 border-t border-line pt-2 text-sm">
              {remaining > 0 ? <Row label="Remaining" value={fmt(remaining)} danger /> : <Row label="Change" value={fmt(change)} strong />}
            </div>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Note on the invoice (optional)" maxLength={500} />
            {complete.error && <Alert>{errorMessage(complete.error)}</Alert>}
            {hold.error && <Alert>{errorMessage(hold.error)}</Alert>}
            <div className="grid grid-cols-[auto_1fr] gap-2">
              <Button variant="outline" disabled={!lines.length} loading={hold.isPending} onClick={() => hold.mutate({ items: lines.map(lineBody), customerId: customer?.id, notes: notes.trim() || undefined, heldSaleId: heldSaleId ?? undefined, billDiscount: num(billValue) > 0 ? { type: billType, value: num(billValue) } : undefined })}>
                <PauseCircle size={16} /> Hold
              </Button>
              <Button className="h-12 text-base" disabled={!canCharge} loading={complete.isPending} onClick={charge}>
                Charge {fmt(total)} <span className="text-xs opacity-75">F12</span>
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {done && <DoneModal sale={done} onClose={() => { setDone(null); reset(); }} />}
      {expiryAlert && (
        <ExpiryAlertModal
          check={expiryAlert.check}
          onAdd={() => { expiryAcked.current.add(expiryAlert.product.id); addNow(expiryAlert.product); setExpiryAlert(null); setTimeout(focusSearch, 50); }}
          onCancel={() => { setExpiryAlert(null); setTimeout(focusSearch, 50); }}
        />
      )}
      {showHeld && (
        <HeldModal
          onClose={() => setShowHeld(false)}
          onResume={(s, products) => {
            setLines(s.saleItems.map((it) => ({
              key: newKey(), product: products.get(it.product.id)!, unitId: it.productUnit?.id ?? '', quantity: String(num(it.quantity)),
              discountType: 'AMOUNT' as const, discount: num(it.discountAmount) > 0 ? String(num(it.discountAmount)) : '', batchId: '',
            })).filter((l) => l.product));
            setCustomer(s.customer ? { ...s.customer, email: null, address: null, dateOfBirth: null, creditLimit: '0', notes: null, isActive: true, createdAt: '' } : null);
            setNotes(s.notes ?? '');
            setBillValue('');
            setHeldSaleId(s.id);
            setShowHeld(false);
          }}
        />
      )}
      {showShift && <ShiftModal summary={current} onClose={() => setShowShift(false)} />}
    </div>
  );
}

function Row({ label, value, strong, danger }: { label: string; value: string; strong?: boolean; danger?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className={strong ? 'font-medium' : 'text-fg-muted'}>{label}</span>
      <span className={clsx('tabular', strong && 'text-lg font-semibold text-success', danger && 'font-semibold text-danger')}>{value}</span>
    </div>
  );
}

function BatchOverride({ productId, value, onChange }: { productId: string; value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(Boolean(value));
  const { data } = useBranchQuery<{ data: { id: string; batchNumber: string; expiryDate: string | null; quantity: string; sellable: boolean }[] }>(open ? `/inventory/batches?productId=${productId}&inStock=true&pageSize=50` : null);
  if (!open) return <button onClick={() => setOpen(true)} className="mt-0.5 text-xs text-brand hover:underline">Choose batch</button>;
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="mt-1 h-8 max-w-full rounded-md border border-line bg-surface px-1 text-xs" aria-label="Batch">
      <option value="">FEFO (automatic)</option>
      {data?.data.filter((b) => b.sellable).map((b) => <option key={b.id} value={b.id}>{b.batchNumber} · exp {dateOnly(b.expiryDate)} · {qty(num(b.quantity))}</option>)}
    </select>
  );
}

function DoneModal({ sale, onClose }: { sale: Sale; onClose: () => void }) {
  const { profile, branchId } = useAuth();
  const fmt = (v: string) => money(num(v), profile.tenant.currencyCode);
  useHotkey('Enter', (e) => { e.preventDefault(); onClose(); }, true);
  const print = () => window.open(receiptUrl(sale.id, branchId, true), 'receipt', 'width=420,height=720');
  return (
    <Modal open onClose={onClose} title={`Sale complete · ${sale.invoiceNo}`} size="sm"
      footer={<><Button variant="outline" onClick={print}><Printer size={16} /> Print receipt</Button><Button onClick={onClose}>New sale (Enter)</Button></>}>
      <div className="space-y-3 text-center">
        <p className="text-sm text-fg-muted">Total {fmt(sale.grandTotal)}{num(sale.balanceDue) > 0 ? ` · ${fmt(sale.balanceDue)} on credit` : ''}</p>
        {num(sale.changeGiven) > 0 ? (
          <div><p className="text-sm font-medium">Change due</p><p className="tabular text-4xl font-bold text-success">{fmt(sale.changeGiven)}</p></div>
        ) : <p className="text-lg font-semibold text-success">Paid in full</p>}
        <p className="text-xs text-fg-muted">{sale.payments.map((p) => `${titleCase(p.method)} ${fmt(p.amount)}`).join(' · ')}</p>
      </div>
    </Modal>
  );
}

function HeldModal({ onClose, onResume }: { onClose: () => void; onResume: (s: Sale, products: Map<string, Product>) => void }) {
  const { profile, branchId } = useAuth();
  const toast = useToast();
  const held = useBranchQuery<Sale[]>('/sales/held');
  const [busy, setBusy] = useState<string | null>(null);
  const discard = useApiMutation<string>('DELETE', (id) => `/sales/held/${id}`, { onSuccess: () => toast.success('Held bill discarded') });
  const resume = async (s: Sale) => {
    setBusy(s.id);
    try {
      const ids = [...new Set(s.saleItems.map((i) => i.product.id))];
      const products = await Promise.all(ids.map((id) => api<Product>(`/products/${id}`, { branchId })));
      onResume(s, new Map(products.map((p) => [p.id, p])));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };
  return (
    <Modal open onClose={onClose} title="Held bills" size="lg">
      {held.isLoading && <Skeleton className="h-24" />}
      {held.data?.length === 0 && <p className="py-6 text-center text-sm text-fg-muted">No bills on hold.</p>}
      <ul className="divide-y divide-line">
        {held.data?.map((s) => (
          <li key={s.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
            <div className="min-w-0 flex-1">
              <p className="font-medium">{s.customer?.fullName ?? 'Walk-in customer'} · {money(num(s.grandTotal), profile.tenant.currencyCode)}</p>
              <p className="truncate text-xs text-fg-muted">{s.saleItems.map((i) => `${i.productName} ×${qty(num(i.quantity))}`).join(', ')}</p>
              <p className="text-xs text-fg-muted">Held {dateTime(s.heldAt)} by {s.cashier.fullName}{s.notes ? ` · ${s.notes}` : ''}</p>
            </div>
            <Button variant="outline" className="h-8 px-3" loading={discard.isPending && discard.variables === s.id} onClick={() => discard.mutate(s.id)}>Discard</Button>
            <Button className="h-8 px-3" loading={busy === s.id} onClick={() => resume(s)}>Resume</Button>
          </li>
        ))}
      </ul>
    </Modal>
  );
}
