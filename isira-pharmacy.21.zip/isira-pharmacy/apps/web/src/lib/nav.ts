import {
  BarChart3, Boxes, Building2, ClipboardList, LayoutDashboard, Pill, Receipt, ScrollText, ShieldCheck,
  ShoppingCart, Truck, UserCog, Users, Wallet, type LucideIcon,
} from 'lucide-react';
import type { PermissionKey } from '@kynex/contracts';

export interface NavItem {
  slug: string; // '' = dashboard
  label: string;
  icon: LucideIcon;
  /** Shown when the user holds ANY of these in the selected branch. Empty = everyone. */
  anyOf: PermissionKey[];
  group: 'Main' | 'Operations' | 'Administration';
}

export const NAV: NavItem[] = [
  { slug: '', label: 'Dashboard', icon: LayoutDashboard, anyOf: [], group: 'Main' },
  { slug: 'pos', label: 'Point of Sale', icon: ShoppingCart, anyOf: ['sale:create'], group: 'Main' },
  { slug: 'sales', label: 'Sales', icon: Receipt, anyOf: ['sale:read'], group: 'Main' },
  { slug: 'medicines', label: 'Products', icon: Pill, anyOf: ['product:read'], group: 'Operations' },
  { slug: 'inventory', label: 'Inventory', icon: Boxes, anyOf: ['inventory:read', 'batch:read'], group: 'Operations' },
  { slug: 'purchasing', label: 'Purchasing', icon: Truck, anyOf: ['purchase:read'], group: 'Operations' },
  { slug: 'customers', label: 'Customers', icon: Users, anyOf: ['customer:read'], group: 'Operations' },
  { slug: 'prescriptions', label: 'Prescriptions', icon: ClipboardList, anyOf: ['prescription:read'], group: 'Operations' },
  { slug: 'finance', label: 'Finance', icon: Wallet, anyOf: ['finance:read', 'register:read', 'expense:read', 'tenant:settings:manage'], group: 'Operations' },
  { slug: 'reports', label: 'Reports', icon: BarChart3, anyOf: ['report:sales:view', 'report:financial:view', 'report:inventory:view'], group: 'Operations' },
  { slug: 'branches', label: 'Branches', icon: Building2, anyOf: ['branch:read'], group: 'Administration' },
  { slug: 'users', label: 'Users', icon: UserCog, anyOf: ['user:read'], group: 'Administration' },
  { slug: 'roles', label: 'Roles', icon: ShieldCheck, anyOf: ['role:read'], group: 'Administration' },
  { slug: 'audit', label: 'Audit log', icon: ScrollText, anyOf: ['audit:read'], group: 'Administration' },
];

export function findNav(slug: string): NavItem | undefined {
  return NAV.find((n) => n.slug === slug);
}
