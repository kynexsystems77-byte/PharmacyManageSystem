'use client';

import { HandCoins, PiggyBank, Receipt, TrendingUp, Wallet } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { DataTable, Forbidden, PageHeader } from '@/components/kit';
import { preset, RangePicker, ScopeToggle, type DateRange } from '@/components/range-picker';
import { SeriesChart } from '@/components/series-chart';
import { Alert, Card, CardHeader, Skeleton, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num, titleCase } from '@/lib/format';
import { errorMessage, qs, useBranchQuery } from '@/lib/hooks';
import type { ProfitAndLoss } from '@/lib/types';

export default function FinancePage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [range, setRange] = useState<DateRange>(() => preset('month'));
  const [scope, setScope] = useState<'branch' | 'all'>('branch');
  useEffect(() => { if (!can('finance:read') && can('register:read')) router.replace('/finance/shifts'); }, [can, router]);
  const { data, isLoading, error } = useBranchQuery<ProfitAndLoss>(can('finance:read') ? `/finance/summary${qs({ ...range, scope })}` : null, { keepPrevious: true });
  if (!can('finance:read')) return <Forbidden what="financial summaries" />;
  const cur = data?.currencyCode ?? profile.tenant.currencyCode;
  const fmt = (v: string | number) => money(num(v), cur);
  return (
    <div className="space-y-4">
      <PageHeader title="Profit & loss" subtitle="Revenue and profit exclude tax. Returns, write-offs and expenses are deducted in the period they happen." actions={<><RangePicker value={range} onChange={setRange} /><ScopeToggle value={scope} onChange={setScope} /></>} />
      {error && <Alert>{errorMessage(error)}</Alert>}
      {isLoading && <Skeleton className="h-64" />}
      {data && (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <StatTile label="Net sales (ex tax)" value={fmt(data.netSales)} icon={<Receipt size={18} />} hint={`${data.sales.invoices} invoices · ${data.returns.count} returns`} />
            <StatTile label="Gross profit" value={fmt(data.grossProfit)} icon={<TrendingUp size={18} />} tone="success" hint={data.grossMarginPercent ? `${data.grossMarginPercent}% margin` : '—'} />
            <StatTile label="Expenses & losses" value={fmt(num(data.expenses.total) + num(data.stockLoss.total))} icon={<HandCoins size={18} />} tone="warning" hint={`Expenses ${fmt(data.expenses.total)} · stock ${fmt(data.stockLoss.total)}`} />
            <StatTile label="Net profit" value={fmt(data.netProfit)} icon={<PiggyBank size={18} />} tone={num(data.netProfit) < 0 ? 'danger' : 'success'} />
          </div>
          {data.daily.length > 1 && (
            <Card>
              <CardHeader title="Daily revenue and gross profit" />
              <div className="p-4"><SeriesChart data={data.daily} bars={(d) => d.revenue} line={(d) => d.profit} format={fmt} barLabel="Revenue" lineLabel="Gross profit" /></div>
            </Card>
          )}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader title="Statement" />
              <dl className="divide-y divide-line text-sm">
                <Line l="Sales (gross, before discounts)" v={fmt(data.sales.gross)} />
                <Line l="Discounts given" v={`- ${fmt(data.sales.discounts)}`} />
                <Line l="Revenue excluding tax" v={fmt(data.sales.revenueExTax)} />
                <Line l="Returns (excluding tax)" v={`- ${fmt(data.returns.exTax)}`} />
                <Line l="Net sales" v={fmt(data.netSales)} strong />
                <Line l="Cost of goods sold" v={`- ${fmt(data.cogs)}`} />
                <Line l="Gross profit" v={fmt(data.grossProfit)} strong />
                <Line l="Stock damaged / expired / count losses" v={`- ${fmt(data.stockLoss.total)}`} />
                <Line l="Operating expenses" v={`- ${fmt(data.expenses.total)}`} />
                <Line l="Net profit" v={fmt(data.netProfit)} strong tone={num(data.netProfit) < 0 ? 'danger' : 'success'} />
                <Line l="Tax collected (payable)" v={fmt(data.taxCollected)} />
              </dl>
            </Card>
            <div className="space-y-4">
              <Card>
                <CardHeader title="Money in and out" />
                <DataTable
                  rows={data.payments}
                  compact
                  rowKey={(p) => `${p.kind}-${p.method}`}
                  empty={<p className="px-4 py-6 text-center text-sm text-fg-muted">No payments in this period.</p>}
                  columns={[
                    { key: 'k', header: 'Type', cell: (p) => <span>{titleCase(p.kind)} <span className="text-fg-muted">· {titleCase(p.method)}</span></span> },
                    { key: 'c', header: 'Count', align: 'right', cell: (p) => p.count },
                    { key: 'a', header: 'Amount', align: 'right', cell: (p) => <span className={['REFUND', 'SUPPLIER_PAYMENT'].includes(p.kind) ? 'text-danger' : ''}>{fmt(p.amount)}</span> },
                  ]}
                />
              </Card>
              <Card>
                <CardHeader title="Expenses by category" />
                <DataTable
                  rows={data.expenses.byCategory}
                  compact
                  rowKey={(e) => e.category}
                  empty={<p className="px-4 py-6 text-center text-sm text-fg-muted">No expenses recorded.</p>}
                  columns={[
                    { key: 'c', header: 'Category', cell: (e) => e.category },
                    { key: 'n', header: 'Entries', align: 'right', cell: (e) => e.count },
                    { key: 'a', header: 'Amount', align: 'right', cell: (e) => fmt(e.amount) },
                  ]}
                />
              </Card>
              <div className="grid gap-3 sm:grid-cols-2">
                <Link href="/customers/receivables"><StatTile label="Customers owe us" value={fmt(data.receivables)} icon={<Wallet size={18} />} hint="All branches" /></Link>
                <Link href="/purchasing/payables"><StatTile label="We owe suppliers" value={fmt(data.payables)} icon={<Wallet size={18} />} tone="warning" hint="All branches" /></Link>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Line({ l, v, strong, tone }: { l: string; v: string; strong?: boolean; tone?: 'danger' | 'success' }) {
  return (
    <div className={`flex justify-between gap-3 px-4 py-2 ${strong ? 'bg-subtle/50 font-semibold' : ''}`}>
      <dt className={strong ? '' : 'text-fg-muted'}>{l}</dt>
      <dd className={`tabular ${tone === 'danger' ? 'text-danger' : tone === 'success' ? 'text-success' : ''}`}>{v}</dd>
    </div>
  );
}
