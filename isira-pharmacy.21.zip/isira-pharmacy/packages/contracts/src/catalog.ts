import { z } from 'zod';
import { nullableText, optionalText, percentSchema, priceSchema, quantitySchema, queryBoolSchema } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 5: catalogue (categories, manufacturers, tax rates, products and their sale units). */

export const DOSAGE_FORMS = [
  'TABLET', 'CAPSULE', 'SYRUP', 'SUSPENSION', 'INJECTION', 'CREAM', 'OINTMENT', 'GEL', 'DROPS', 'INHALER', 'SPRAY',
  'SUPPOSITORY', 'POWDER', 'PATCH', 'LOTION', 'OTHER',
] as const;
export type DosageFormKey = (typeof DOSAGE_FORMS)[number];

// ---- categories ----
export const createCategorySchema = z.object({
  name: z.string().trim().min(1).max(80),
  parentId: uuidSchema.nullable().optional(),
  sortOrder: z.coerce.number().int().min(0).max(10_000).default(0),
});
export const updateCategorySchema = z
  .object({
    name: z.string().trim().min(1).max(80).optional(),
    parentId: uuidSchema.nullable().optional(),
    sortOrder: z.coerce.number().int().min(0).max(10_000).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

// ---- manufacturers ----
export const createManufacturerSchema = z.object({
  name: z.string().trim().min(1).max(120),
  country: optionalText(80),
});
export const updateManufacturerSchema = z
  .object({ name: z.string().trim().min(1).max(120).optional(), country: nullableText(80), isActive: z.boolean().optional() })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

// ---- tax rates ----
export const createTaxRateSchema = z.object({
  name: z.string().trim().min(1).max(60),
  ratePercent: percentSchema,
  isInclusive: z.boolean().default(false),
});
export const updateTaxRateSchema = z
  .object({
    name: z.string().trim().min(1).max(60).optional(),
    ratePercent: percentSchema.optional(),
    isInclusive: z.boolean().optional(),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

// ---- products ----
export const productUnitSchema = z.object({
  id: uuidSchema.optional(),
  name: z.string().trim().min(1).max(40),
  /** How many base units one of this unit contains (e.g. strip = 10 tablets). */
  factorToBase: quantitySchema,
  barcode: optionalText(64),
  sellingPrice: priceSchema.nullable().optional(),
  isDefaultSaleUnit: z.boolean().default(false),
});

const productFields = {
  sku: z.string().trim().toUpperCase().regex(/^[A-Z0-9._-]{1,40}$/, 'Use 1-40 letters, digits, . _ or -').optional(),
  barcode: optionalText(64),
  brandName: z.string().trim().min(1).max(160),
  genericName: optionalText(160),
  strength: optionalText(60),
  dosageForm: z.enum(DOSAGE_FORMS).default('OTHER'),
  baseUnit: z.string().trim().min(1).max(20).default('unit'),
  requiresPrescription: z.boolean().default(false),
  isControlled: z.boolean().default(false),
  trackExpiry: z.boolean().default(true),
  purchasePrice: priceSchema.default(0),
  sellingPrice: priceSchema.default(0),
  wholesalePrice: priceSchema.nullable().optional(),
  reorderLevel: z.coerce.number().min(0).max(99_999_999).default(0),
  description: optionalText(2000),
  categoryId: uuidSchema,
  manufacturerId: uuidSchema.nullable().optional(),
  preferredSupplierId: uuidSchema.nullable().optional(),
  taxRateId: uuidSchema.nullable().optional(),
};

export const createProductSchema = z.object({
  ...productFields,
  units: z.array(productUnitSchema).max(10).default([]),
});

export const updateProductSchema = z
  .object({
    sku: productFields.sku,
    barcode: nullableText(64),
    brandName: productFields.brandName.optional(),
    genericName: nullableText(160),
    strength: nullableText(60),
    dosageForm: z.enum(DOSAGE_FORMS).optional(),
    baseUnit: z.string().trim().min(1).max(20).optional(),
    requiresPrescription: z.boolean().optional(),
    isControlled: z.boolean().optional(),
    trackExpiry: z.boolean().optional(),
    purchasePrice: priceSchema.optional(),
    sellingPrice: priceSchema.optional(),
    wholesalePrice: priceSchema.nullable().optional(),
    reorderLevel: z.coerce.number().min(0).max(99_999_999).optional(),
    description: nullableText(2000),
    categoryId: uuidSchema.optional(),
    manufacturerId: uuidSchema.nullable().optional(),
    preferredSupplierId: uuidSchema.nullable().optional(),
    taxRateId: uuidSchema.nullable().optional(),
    isActive: z.boolean().optional(),
    /** When present, replaces the product's sale units (ids keep existing units). */
    units: z.array(productUnitSchema).max(10).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const listProductsQuerySchema = paginationSchema.extend({
  categoryId: uuidSchema.optional(),
  /** Includes sub-categories of categoryId. */
  includeSubcategories: queryBoolSchema.optional(),
  manufacturerId: uuidSchema.optional(),
  supplierId: uuidSchema.optional(),
  requiresPrescription: queryBoolSchema.optional(),
  status: z.enum(['active', 'inactive', 'all']).default('active'),
  sort: z.enum(['name', 'sku', 'created', 'price']).default('name'),
  /** Adds branch stock (requires X-Branch-Id). */
  withStock: queryBoolSchema.optional(),
});

/** Branch-level overrides (price, reorder level, availability) for one product. */
export const branchProductSettingSchema = z.object({
  sellingPrice: priceSchema.nullable().optional(),
  reorderLevel: z.coerce.number().min(0).max(99_999_999).nullable().optional(),
  isAvailable: z.boolean().optional(),
});
