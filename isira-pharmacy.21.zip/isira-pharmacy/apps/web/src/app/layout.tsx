import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import { Providers } from './providers';
import './globals.css';
import { APP_NAME } from '@/lib/brand';

export const metadata: Metadata = { title: { default: APP_NAME, template: `%s | ${APP_NAME}` }, description: 'Pharmacy management and point of sale' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1 };

// Runs before first paint so there is no light/dark flash.
const themeScript = `try{var t=localStorage.getItem('kx_theme');if(t==='dark'||(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
