import { INestApplication } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { addStock, bootApp, createProduct, expectStatus, isoDay, login, uid, type Session } from './helpers';

const key = () => randomUUID().replace(/-/g, '');

describe('Expiry popup, supplier discounts and pharmacy details', () => {
  let app: INestApplication;
  let s: Session;
  beforeAll(async () => {
    app = await bootApp();
    const owner = await login(app, 'owner@demo.local');
    const code = `U${uid()}`.slice(0, 8);
    const b = await owner.agent.post('/v1/branches').set('X-Kynex-Csrf', '1').send({ name: `Zz Updates ${code}`, code });
    expectStatus(b, 201);
    s = await login(app, 'owner@demo.local', b.body.id);
  });
  afterAll(async () => {
    await app.close();
  });

  it('tells the POS when the batch being sold is close to expiry', async () => {
    const fresh = await createProduct(s);
    await addStock(s, fresh.id, { quantity: 10, expiryDate: isoDay(400) });
    const ok = await s.get(`/sales/expiry-check?productId=${fresh.id}`);
    expectStatus(ok, 200);
    expect(ok.body.level).toBe('none');

    const soon = await createProduct(s);
    await addStock(s, soon.id, { quantity: 5, expiryDate: isoDay(20), batchNumber: 'SOON-1' });
    await addStock(s, soon.id, { quantity: 5, expiryDate: isoDay(300), batchNumber: 'LATER-1' });
    const warn = await s.get(`/sales/expiry-check?productId=${soon.id}`);
    expect(warn.body.level).toBe('warning');
    expect(warn.body.next.batchNumber).toBe('SOON-1'); // FEFO: the earliest expiry is sold first
    expect(warn.body.batches.map((b: { state: string }) => b.state)).toEqual(['EXPIRING', 'OK']);

    const urgent = await createProduct(s);
    await addStock(s, urgent.id, { quantity: 3, expiryDate: isoDay(3), batchNumber: 'URG-1' });
    const danger = await s.get(`/sales/expiry-check?productId=${urgent.id}`);
    expect(danger.body.level).toBe('danger');
    expect(danger.body.message).toMatch(/expires in \d+ days?/);

    // with a 5-day minimum the same batch can no longer be sold at all
    const settings = (await s.get('/settings')).body.settings;
    expectStatus(await s.put('/settings', { ...settings, minDaysToExpiryForSale: 5 }), 200);
    try {
      const blocked = await s.get(`/sales/expiry-check?productId=${urgent.id}`);
      expect(blocked.body.level).toBe('danger');
      expect(blocked.body.next).toBeNull();
      expect(blocked.body.batches[0].state).toBe('TOO_CLOSE');
      expect(Number(blocked.body.unsellableQuantity)).toBe(3);
    } finally {
      expectStatus(await s.put('/settings', settings), 200);
    }

    // the cashier may run the check; products without expiry tracking never warn
    const cashier = await login(app, 'cashier@demo.local');
    expectStatus(await cashier.get(`/sales/expiry-check?productId=${fresh.id}`), 200);
    expect((await s.get(`/sales/expiry-check?productId=${randomUUID()}`)).status).toBe(404);
  });

  it('records a supplier discount so price 2,000 less 500 costs 1,500 and earns 500 per unit', async () => {
    const sup = await s.post('/suppliers', { name: `Discount Supplier ${uid()}` });
    expectStatus(sup, 201);
    const p = await createProduct(s, { purchasePrice: 2000, sellingPrice: 2000 });
    const res = await s.post('/purchases', {
      supplierId: sup.body.id, receive: true,
      items: [{ productId: p.id, batchNumber: `D-${uid()}`, expiryDate: isoDay(400), quantity: 4, unitCost: 2000, discountAmount: 4 * 500 }],
    });
    expectStatus(res, 201);
    expect(Number(res.body.subtotal)).toBe(8000);
    expect(Number(res.body.discountTotal)).toBe(2000);
    expect(Number(res.body.grandTotal)).toBe(6000);
    expect(Number(res.body.purchaseItems[0].product.sellingPrice)).toBe(2000);

    const stock = await s.get(`/products/${p.id}/stock`);
    expect(Number(stock.body.levels[0].batch.unitCost)).toBe(1500);
    expect(Number((await s.get(`/products/${p.id}`)).body.purchasePrice)).toBe(1500); // net cost, not the list price

    const regs = await s.get('/registers');
    expectStatus(await s.post(`/registers/${regs.body[0].id}/open`, { openingBalance: 0 }), 201);
    const sale = await s.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CARD', amount: 2000 }] });
    expectStatus(sale, 201);
    const detail = await s.get(`/sales/${sale.body.id}`);
    const item = detail.body.saleItems[0];
    expect(Number(item.lineTotal) - Number(item.costTotal)).toBe(500);
  });

  it('lets the owner rename the pharmacy and change a branch address', async () => {
    const tenant = (await s.get('/tenant')).body;
    const renamed = await s.patch('/tenant', { name: 'Isira Pharmacy Test' });
    expectStatus(renamed, 200);
    expect((await s.get('/auth/me')).body.tenant.name).toBe('Isira Pharmacy Test');
    expectStatus(await s.patch('/tenant', { name: tenant.name }), 200);

    const upd = await s.patch(`/branches/${s.branchId}`, { id: s.branchId, address: '25 Puttalam Road, Kurunegala', phone: '037 223 5566', receiptFooter: 'Get well soon' });
    expectStatus(upd, 200);
    const cur = await s.get('/branches/current');
    expect(cur.body.address).toBe('25 Puttalam Road, Kurunegala');
    expect(cur.body.phone).toBe('037 223 5566');
  });
});
