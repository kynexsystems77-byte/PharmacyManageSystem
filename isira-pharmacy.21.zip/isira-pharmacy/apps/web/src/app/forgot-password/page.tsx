'use client';

import Link from 'next/link';
import { useState, type FormEvent } from 'react';
import { Alert, Button, Card, Field, Input } from '@/components/ui';
import { api, ApiError } from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api('/auth/password/forgot', { method: 'POST', body: { email } });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center p-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 text-center text-xl font-semibold">Reset your password</h1>
        <p className="mb-6 text-center text-sm text-fg-muted">We will email you a reset link if the account exists.</p>
        <Card className="p-5">
          {done ? (
            <div className="space-y-4">
              <Alert tone="success">If that email belongs to an account, a reset link has been sent.</Alert>
              <Link href="/login" className="block text-center text-sm text-brand hover:underline">Back to sign in</Link>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              {error && <Alert>{error}</Alert>}
              <Field label="Email">
                <Input type="email" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} />
              </Field>
              <Button type="submit" className="w-full" loading={busy}>Send reset link</Button>
              <Link href="/login" className="block text-center text-sm text-brand hover:underline">Back to sign in</Link>
            </form>
          )}
        </Card>
      </div>
    </main>
  );
}
