'use client';

import { Textarea } from './kit';
import { Field, Input } from './ui';

export interface BranchDraft { name: string; code: string; address: string; phone: string; email: string; invoicePrefix: string; receiptHeader: string; receiptFooter: string; taxNumber: string }

export function BranchForm({ value, onChange, creating }: { value: BranchDraft; onChange: (v: BranchDraft) => void; creating: boolean }) {
  const set = (k: keyof BranchDraft, v: string) => onChange({ ...value, [k]: v });
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="Name *"><Input value={value.name} onChange={(e) => set('name', e.target.value)} /></Field>
      <Field label="Code *"><Input value={value.code} onChange={(e) => set('code', e.target.value.toUpperCase())} disabled={!creating} placeholder="KURU" /></Field>
      <Field label="Phone"><Input value={value.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
      <Field label="Email"><Input type="email" value={value.email} onChange={(e) => set('email', e.target.value)} /></Field>
      <div className="sm:col-span-2"><Field label="Address"><Input value={value.address} onChange={(e) => set('address', e.target.value)} /></Field></div>
      <Field label="Invoice prefix"><Input value={value.invoicePrefix} onChange={(e) => set('invoicePrefix', e.target.value.toUpperCase())} placeholder="INV" /></Field>
      <Field label="Tax / VAT number"><Input value={value.taxNumber} onChange={(e) => set('taxNumber', e.target.value)} /></Field>
      <Field label="Receipt header"><Textarea value={value.receiptHeader} onChange={(e) => set('receiptHeader', e.target.value)} className="min-h-[60px]" /></Field>
      <Field label="Receipt footer"><Textarea value={value.receiptFooter} onChange={(e) => set('receiptFooter', e.target.value)} className="min-h-[60px]" placeholder="Thank you. Get well soon!" /></Field>
    </div>
  );
}

export function branchBody(d: BranchDraft, creating: boolean) {
  const t = (v: string) => v.trim() || undefined;
  return {
    name: d.name.trim(), ...(creating ? { code: d.code.trim() } : {}), address: t(d.address), phone: t(d.phone), email: t(d.email),
    invoicePrefix: d.invoicePrefix.trim() || 'INV', receiptHeader: t(d.receiptHeader), receiptFooter: t(d.receiptFooter), taxNumber: t(d.taxNumber),
  };
}

