import type { Prisma, PrismaClient } from '@prisma/client';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export interface TenantTransactionOptions {
  timeout?: number;
  maxWait?: number;
  isolationLevel?: Prisma.TransactionIsolationLevel;
}

/**
 * Runs `fn` inside ONE database transaction whose Row-Level Security context is `tenantId`.
 *
 * `set_config(..., true)` is transaction-local, so the tenant can never leak to another request that
 * reuses the same pooled connection (also safe behind PgBouncer in transaction mode).
 *
 * Every tenant-scoped query in the application must go through this function (the API wraps it in a
 * request-scoped provider in Phase 3). Outside it, the application role sees ZERO tenant rows.
 */
export async function withTenant<T>(
  prisma: PrismaClient,
  tenantId: string,
  fn: (tx: Prisma.TransactionClient) => Promise<T>,
  options: TenantTransactionOptions = {},
): Promise<T> {
  if (!UUID_RE.test(tenantId)) {
    throw new Error('withTenant: tenantId must be a UUID');
  }
  return prisma.$transaction(
    async (tx) => {
      await tx.$queryRaw`SELECT set_config('app.tenant_id', ${tenantId}, true)`;
      return fn(tx);
    },
    {
      timeout: options.timeout ?? 15_000,
      maxWait: options.maxWait ?? 5_000,
      isolationLevel: options.isolationLevel,
    },
  );
}
