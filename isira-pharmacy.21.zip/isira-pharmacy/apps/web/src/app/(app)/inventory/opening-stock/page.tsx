'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Forbidden, PageHeader, useToast } from '@/components/kit';
import { LocationSelect, ProductPicker } from '@/components/pickers';
import { Alert, Button, Card, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Product } from '@/lib/types';

export default function OpeningStockPage() {
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const presetId = useSearchParams().get('productId');
  const preset = useBranchQuery<Product>(presetId ? `/products/${presetId}` : null);
  const [product, setProduct] = useState<Product | null>(null);
  const [f, setF] = useState({ locationId: '', batchNumber: '', expiryDate: '', manufactureDate: '', unitCost: '', sellingPrice: '', quantity: '', note: '' });
  useEffect(() => {
    if (preset.data && !product) {
      setProduct(preset.data);
      setF((x) => ({ ...x, unitCost: String(Number(preset.data.purchasePrice)) }));
    }
  }, [preset.data, product]);

  const save = useApiMutation<object, { batchId: string; balance: string }>('POST', '/inventory/opening-stock', {
    onSuccess: (r) => {
      toast.success(`Stock added. Batch balance is now ${Number(r.balance)}.`);
      router.push(`/inventory/batches/${r.batchId}`);
    },
  });
  if (!can('inventory:adjust')) return <Forbidden what="opening stock" />;

  const submit = () =>
    product &&
    save.mutate({
      locationId: f.locationId, productId: product.id, batchNumber: f.batchNumber.trim(), expiryDate: f.expiryDate || null,
      manufactureDate: f.manufactureDate || null, unitCost: Number(f.unitCost || 0), sellingPrice: f.sellingPrice ? Number(f.sellingPrice) : null,
      quantity: Number(f.quantity), note: f.note || undefined,
    });

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader back="/inventory" title="Add opening stock" subtitle="For stock you already had before using this system, or stock that did not come through a purchase. Purchases add stock automatically." />
      <Card className="space-y-4 p-4">
        {product ? (
          <div className="flex items-center justify-between rounded-lg border border-line bg-subtle/50 px-3 py-2 text-sm">
            <span><b>{product.brandName}</b> <span className="text-fg-muted">· {product.sku} · counted in {product.baseUnit}</span></span>
            <button className="text-brand hover:underline" onClick={() => setProduct(null)}>Change</button>
          </div>
        ) : (
          <ProductPicker autoFocus withStock={false} onPick={(p) => { setProduct(p); setF((x) => ({ ...x, unitCost: String(Number(p.purchasePrice)) })); }} />
        )}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Location"><LocationSelect value={f.locationId} onChange={(id) => setF((x) => ({ ...x, locationId: id }))} /></Field>
          <Field label="Batch number *"><Input value={f.batchNumber} onChange={(e) => setF({ ...f, batchNumber: e.target.value })} maxLength={60} /></Field>
          <Field label={`Expiry date${product?.trackExpiry === false ? '' : ' *'}`}><Input type="date" value={f.expiryDate} onChange={(e) => setF({ ...f, expiryDate: e.target.value })} /></Field>
          <Field label="Manufacture date"><Input type="date" value={f.manufactureDate} onChange={(e) => setF({ ...f, manufactureDate: e.target.value })} /></Field>
          <Field label={`Quantity (${product?.baseUnit ?? 'base units'}) *`}><Input type="number" min="0.001" step="0.001" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></Field>
          <Field label="Unit cost *"><Input type="number" min="0" step="0.0001" value={f.unitCost} onChange={(e) => setF({ ...f, unitCost: e.target.value })} /></Field>
          <Field label="Batch selling price (optional)"><Input type="number" min="0" step="0.0001" value={f.sellingPrice} onChange={(e) => setF({ ...f, sellingPrice: e.target.value })} placeholder="Use product price" /></Field>
          <Field label="Note"><Input value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} maxLength={300} /></Field>
        </div>
        {save.error && <Alert>{errorMessage(save.error)}</Alert>}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
          <Button disabled={!product || !f.batchNumber.trim() || !(Number(f.quantity) > 0) || !f.locationId} loading={save.isPending} onClick={submit}>Add stock</Button>
        </div>
      </Card>
    </div>
  );
}
