'use client';

import clsx from 'clsx';
import { CheckCheck } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { PageHeader, Pagination } from '@/components/kit';
import { SEVERITY_ICON, SEVERITY_TONE } from '@/components/notification-bell';
import { Button, Card } from '@/components/ui';
import { dateTime, titleCase } from '@/lib/format';
import { qs, useApiMutation, useBranchQuery, usePaging, type Paged } from '@/lib/hooks';
import type { AppNotification } from '@/lib/types';

export default function NotificationsPage() {
  const router = useRouter();
  const [unreadOnly, setUnreadOnly] = useState(false);
  const { page, setPage } = usePaging([unreadOnly]);
  const { data } = useBranchQuery<Paged<AppNotification> & { unread: number }>(`/notifications${qs({ page, pageSize: 30, unread: unreadOnly || undefined })}`, { keepPrevious: true });
  const read = useApiMutation<string>('POST', (id) => `/notifications/${id}/read`);
  const readAll = useApiMutation<object>('POST', '/notifications/read-all');
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader
        title="Notifications"
        subtitle={data ? `${data.unread} unread · alerts are checked hourly and right after each sale` : undefined}
        actions={<>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={unreadOnly} onChange={(e) => setUnreadOnly(e.target.checked)} /> Unread only</label>
          {Boolean(data?.unread) && <Button variant="outline" onClick={() => readAll.mutate({})}><CheckCheck size={16} /> Mark all read</Button>}
        </>}
      />
      <Card>
        <ul className="divide-y divide-line">
          {data?.data.length === 0 && <li className="px-4 py-10 text-center text-sm text-fg-muted">Nothing here.</li>}
          {data?.data.map((n) => {
            const Icon = SEVERITY_ICON[n.severity];
            return (
              <li key={n.id}>
                <button
                  onClick={() => { if (!n.readAt) read.mutate(n.id); if (n.data?.link) router.push(n.data.link); }}
                  className={clsx('flex w-full gap-3 px-4 py-3 text-left hover:bg-subtle', !n.readAt && 'bg-brand/5')}
                >
                  <Icon size={20} className={clsx('mt-0.5 shrink-0', SEVERITY_TONE[n.severity])} />
                  <span className="min-w-0 flex-1">
                    <span className={clsx('block', !n.readAt && 'font-semibold')}>{n.title}</span>
                    {n.body && <span className="block text-sm text-fg-muted">{n.body}</span>}
                    <span className="mt-0.5 block text-xs text-fg-muted">{titleCase(n.type)} · {dateTime(n.createdAt)}{n.branch ? ` · ${n.branch.name}` : ''}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
