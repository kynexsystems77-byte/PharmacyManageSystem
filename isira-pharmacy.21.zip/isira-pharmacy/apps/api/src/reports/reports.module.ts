import { Controller, Get, Module, NotFoundException, Param, ParseUUIDPipe, Query, Res } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import { createZodDto } from 'nestjs-zod';
import PDFDocument from 'pdfkit';
import { REPORTS, reportQuerySchema } from '@kynex/contracts';
import { AuditService } from '../audit/audit.service';
import { currentBranchId, hasPermission, requirePermission } from '../common/branch';
import { dec, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import type { AuthContext } from '../common/request-context';
import { FinanceModule } from '../finance/finance.module';
import { TenantDb } from '../prisma/prisma.service';
import { SALE_SELECT } from '../sales/sales.service';
import { toCsv, toPdf, toXlsx } from './exporters';
import { ReportsService } from './reports.service';

class ReportQueryDto extends createZodDto(reportQuerySchema) {}

const MIME = {
  csv: 'text/csv; charset=utf-8',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pdf: 'application/pdf',
} as const;

@ApiTags('Reports')
@ApiCookieAuth()
@Controller('reports')
export class ReportsController {
  constructor(
    private readonly db: TenantDb,
    private readonly reports: ReportsService,
    private readonly tenantInfo: TenantInfoService,
    private readonly audit: AuditService,
  ) {}

  /** Reports the caller may run in the selected branch. */
  @Get()
  @BranchScoped()
  catalogue(@CurrentAuth() auth: AuthContext) {
    const branchId = currentBranchId();
    return {
      canExport: hasPermission(auth, 'report:export', branchId),
      reports: REPORTS.filter((r) => hasPermission(auth, r.permission, branchId)),
    };
  }

  /** ?format=json (default) | csv | xlsx | pdf. File formats need report:export. */
  @Get(':key')
  @BranchScoped()
  async run(@Param('key') key: string, @Query() q: ReportQueryDto, @CurrentAuth() auth: AuthContext, @Res({ passthrough: true }) res: Response) {
    const tx = this.db.tx;
    const def = this.reports.definition(key);
    const branchId = currentBranchId();
    const branchIds = this.reports.branches(auth, def.permission, branchId, q.scope);
    if (q.format !== 'json') requirePermission(auth, 'report:export', branchId);
    const tenant = await this.tenantInfo.get(tx);
    const names = await tx.branch.findMany({ where: { id: { in: branchIds } }, select: { name: true }, orderBy: { name: 'asc' } });
    const today = todayIn(tenant.timezone);
    const result = await this.reports.run(key, {
      tx, auth, branchIds, branchNames: names.length > 2 ? `${names.length} branches` : names.map((b) => b.name).join(', '),
      from: q.from ?? today, to: q.to ?? today, days: q.days, categoryId: q.categoryId ?? null, timezone: tenant.timezone,
      currencyCode: tenant.currencyCode, financial: branchIds.every((b) => hasPermission(auth, 'report:financial:view', b)),
    });
    if (q.format === 'json') return result;

    await this.audit.record({ action: 'report.exported', entityType: 'report', entityId: key, after: { format: q.format, from: q.from, to: q.to, scope: q.scope } });
    const body = q.format === 'csv' ? toCsv(result) : q.format === 'xlsx' ? await toXlsx(result) : await toPdf(result, { tenantName: tenant.name });
    const file = `${key}-${q.from ?? today}${q.to && q.to !== q.from ? `_${q.to}` : ''}.${q.format}`;
    res.setHeader('Content-Type', MIME[q.format]);
    res.setHeader('Content-Disposition', `attachment; filename="${file}"`);
    res.setHeader('Cache-Control', 'no-store');
    res.send(body);
    return undefined;
  }
}

/** A4 tax invoice PDF for one sale (the 80 mm receipt is rendered by the web app). */
@ApiTags('Sales')
@ApiCookieAuth()
@Controller('sales')
export class InvoicePdfController {
  constructor(private readonly db: TenantDb, private readonly tenantInfo: TenantInfoService) {}

  @Get(':id/invoice.pdf')
  @BranchScoped()
  @RequirePermissions('sale:read')
  async pdf(@Param('id', ParseUUIDPipe) id: string, @Res() res: Response) {
    const tx = this.db.tx;
    const s = await tx.sale.findFirst({ where: { id, branchId: currentBranchId() }, select: SALE_SELECT });
    if (!s || !s.invoiceNo) throw new NotFoundException('Invoice not found');
    const t = await this.tenantInfo.get(tx);
    const money = (v: unknown) => dec(v as string).toFixed(2);
    const doc = new PDFDocument({ size: 'A4', margin: 48, info: { Title: s.invoiceNo, Author: t.name } });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${s.invoiceNo}.pdf"`);
    doc.pipe(res);
    const W = doc.page.width - 96;
    doc.font('Helvetica-Bold').fontSize(18).text(t.name);
    doc.font('Helvetica').fontSize(9).fillColor('#444').text([s.branch.name, s.branch.address, s.branch.phone ? `Tel ${s.branch.phone}` : null, s.branch.taxNumber ? `Tax no ${s.branch.taxNumber}` : null].filter(Boolean).join(' · '));
    doc.moveDown();
    doc.fillColor('#111').font('Helvetica-Bold').fontSize(13).text(s.status === 'VOIDED' ? 'INVOICE (VOIDED)' : 'TAX INVOICE');
    doc.font('Helvetica').fontSize(9);
    const when = s.soldAt ? new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium', timeStyle: 'short', timeZone: t.timezone }).format(s.soldAt) : '';
    doc.text(`Invoice ${s.invoiceNo}   ·   ${when}   ·   Cashier ${s.cashier.fullName}`);
    if (s.customer) doc.text(`Bill to: ${s.customer.fullName}${s.customer.phone ? `, ${s.customer.phone}` : ''}${s.customer.code ? ` (${s.customer.code})` : ''}`);
    if (s.prescription) doc.text(`Prescription: ${s.prescription.prescriptionNumber ?? ''} Dr. ${s.prescription.doctorName}`);
    doc.moveDown();
    const cols = [{ l: 'Item', w: 0.42 }, { l: 'Qty', w: 0.12 }, { l: 'Price', w: 0.12 }, { l: 'Disc.', w: 0.1 }, { l: 'Tax', w: 0.1 }, { l: 'Total', w: 0.14 }];
    const row = (cells: string[], bold = false) => {
      const y = doc.y;
      let x = 48;
      doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(9);
      const h = Math.max(...cells.map((c, i) => doc.heightOfString(c, { width: cols[i].w * W - 6 }))) + 6;
      cells.forEach((c, i) => { doc.text(c, x + 3, y + 3, { width: cols[i].w * W - 6, align: i === 0 ? 'left' : 'right' }); x += cols[i].w * W; });
      doc.moveTo(48, y + h).lineTo(48 + W, y + h).strokeColor('#ddd').stroke();
      doc.y = y + h;
    };
    row(cols.map((c) => c.l), true);
    for (const i of s.saleItems) {
      const batches = i.saleItemAllocations.map((a) => a.batch.batchNumber).join(', ');
      row([`${i.productName}${batches ? `\nBatch ${batches}` : ''}`, `${Number(i.quantity)} ${i.productUnit?.name ?? i.product.baseUnit}`, money(i.unitPrice), money(i.discountAmount), money(i.taxAmount), money(i.lineTotal)]);
    }
    doc.moveDown();
    const line = (l: string, v: string, bold = false) => {
      doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 11 : 9);
      const y = doc.y;
      doc.text(l, 48 + W * 0.55, y, { width: W * 0.25 });
      doc.text(v, 48 + W * 0.8, y, { width: W * 0.2, align: 'right' });
    };
    line('Subtotal', money(s.subtotal));
    if (dec(s.discountTotal).gt(0)) line('Discounts', `-${money(s.discountTotal)}`);
    if (dec(s.taxTotal).gt(0)) line('Tax', money(s.taxTotal));
    if (!dec(s.roundingAdjustment).isZero()) line('Rounding', money(s.roundingAdjustment));
    line(`Total (${t.currencyCode})`, money(s.grandTotal), true);
    for (const p of s.payments.filter((x) => x.kind === 'SALE_PAYMENT')) line(`Paid · ${p.method.replace('_', ' ').toLowerCase()}`, money(p.amount));
    if (dec(s.balanceDue).gt(0)) line('On account', money(s.balanceDue));
    if (s.branch.receiptFooter) { doc.moveDown(2); doc.font('Helvetica').fontSize(9).fillColor('#444').text(s.branch.receiptFooter, 48, undefined, { width: W, align: 'center' }); }
    doc.end();
    await new Promise<void>((resolve) => res.on('finish', () => resolve()));
  }
}

@Module({ imports: [FinanceModule], controllers: [ReportsController, InvoicePdfController], providers: [ReportsService] })
export class ReportsModule {}
