'use client';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { PermissionKey } from '@kynex/contracts';
import { api, ApiError } from './api';
import type { BranchAccess, Profile } from './types';

const BRANCH_KEY = 'kx_branch';

interface AuthState {
  profile: Profile;
  branch: BranchAccess | null;
  branchId: string | null;
  setBranchId: (id: string) => void;
  /** UI hint only (hides links/buttons). The server decides everything. */
  can: (permission: PermissionKey) => boolean;
  canAny: (...permissions: PermissionKey[]) => boolean;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthGate>');
  return ctx;
}

/** Loads the session profile; sends signed-out visitors to /login. Renders children only when signed in. */
export function AuthGate({ children }: { children: ReactNode }) {
  const router = useRouter();
  const qc = useQueryClient();
  const me = useQuery({ queryKey: ['me'], queryFn: () => api<Profile>('/auth/me'), retry: false, staleTime: 60_000 });
  const [branchId, setBranchIdState] = useState<string | null>(null);

  useEffect(() => {
    if (me.error instanceof ApiError && me.error.status === 401) {
      qc.clear();
      router.replace(`/login?next=${encodeURIComponent(window.location.pathname)}`);
    }
  }, [me.error, qc, router]);

  useEffect(() => {
    if (!me.data) return;
    const ids = me.data.branches.map((b) => b.id);
    let stored: string | null = null;
    try {
      stored = localStorage.getItem(BRANCH_KEY);
    } catch {
      /* storage unavailable: fall back to the first branch */
    }
    const chosen = stored && ids.includes(stored) ? stored : (ids[0] ?? null);
    setBranchIdState(chosen);
    try {
      if (chosen) localStorage.setItem(BRANCH_KEY, chosen); // print windows read it
    } catch {
      /* ignore */
    }
  }, [me.data]);

  const setBranchId = useCallback(
    (id: string) => {
      setBranchIdState(id);
      try {
        localStorage.setItem(BRANCH_KEY, id);
      } catch {
        /* ignore */
      }
      // everything branch-scoped must refetch for the new branch (query keys include the branch id)
    },
    [],
  );

  const logout = useCallback(async () => {
    try {
      await api<void>('/auth/logout', { method: 'POST' });
    } catch {
      /* the cookie may already be invalid; leave anyway */
    }
    qc.clear();
    router.replace('/login');
  }, [qc, router]);

  const value = useMemo<AuthState | null>(() => {
    if (!me.data) return null;
    const branch = me.data.branches.find((b) => b.id === branchId) ?? null;
    const perms = new Set(branch?.permissions ?? []);
    return {
      profile: me.data,
      branch,
      branchId: branch?.id ?? null,
      setBranchId,
      can: (p) => perms.has(p),
      canAny: (...ps) => ps.some((p) => perms.has(p)),
      logout,
    };
  }, [me.data, branchId, setBranchId, logout]);

  if (me.isError && !(me.error instanceof ApiError && me.error.status === 401)) {
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div>
          <p className="text-lg font-semibold">Cannot load your session</p>
          <p className="mt-1 text-sm text-fg-muted">{me.error instanceof Error ? me.error.message : 'Unknown error'}</p>
          <button className="mt-4 rounded-lg bg-brand px-4 py-2 text-sm font-medium text-brand-fg" onClick={() => me.refetch()}>
            Try again
          </button>
        </div>
      </div>
    );
  }
  if (!value) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-line border-t-brand" aria-label="Loading" />
      </div>
    );
  }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
