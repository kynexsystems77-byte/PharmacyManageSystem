import {
  Body, ConflictException, Controller, ForbiddenException, Get, Injectable, Module, NotFoundException, Param, ParseUUIDPipe,
  Post, Query,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { cashMovementSchema, closeShiftSchema, createRegisterSchema, listShiftsQuerySchema, openShiftSchema } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId, hasPermission } from '../common/branch';
import { openSessionFor, recordCash } from '../common/cash';
import { dec, money2, parseDateOnly, sumDec } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class CreateRegisterDto extends createZodDto(createRegisterSchema) {}
class OpenShiftDto extends createZodDto(openShiftSchema) {}
class CloseShiftDto extends createZodDto(closeShiftSchema) {}
class CashMovementDto extends createZodDto(cashMovementSchema) {}
class ListShiftsQueryDto extends createZodDto(listShiftsQuerySchema) {}

const SHIFT_SELECT = {
  id: true, status: true, openedAt: true, closedAt: true, openingBalance: true, expectedClosingBalance: true,
  countedClosingBalance: true, variance: true, notes: true,
  register: { select: { id: true, name: true, branchId: true } },
  openedBy: { select: { id: true, fullName: true } },
  closedBy: { select: { id: true, fullName: true } },
} satisfies Prisma.RegisterSessionSelect;

@Injectable()
export class ShiftService {
  constructor(private readonly db: TenantDb) {}

  /** Z-report figures for one shift. Works for open shifts too (X-report). */
  async summary(tx: Prisma.TransactionClient, sessionId: string) {
    const shift = await tx.registerSession.findFirst({ where: { id: sessionId }, select: SHIFT_SELECT });
    if (!shift) throw new NotFoundException('Shift not found');
    const cash = await tx.cashTransaction.groupBy({ by: ['type'], where: { registerSessionId: sessionId }, _sum: { amount: true }, _count: true });
    const pays = await tx.payment.groupBy({ by: ['kind', 'method'], where: { registerSessionId: sessionId }, _sum: { amount: true }, _count: true });
    const sales = await tx.sale.aggregate({
      where: { registerSessionId: sessionId, status: { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED'] } },
      _sum: { grandTotal: true, discountTotal: true, taxTotal: true }, _count: true,
    });
    const voided = await tx.sale.count({ where: { registerSessionId: sessionId, status: 'VOIDED' } });
    const returns = await tx.salesReturn.aggregate({ where: { registerSessionId: sessionId, status: 'POSTED' }, _sum: { total: true }, _count: true });
    const cashNet = sumDec(cash.map((c) => dec(c._sum.amount)));
    const expected = money2(dec(shift.openingBalance).plus(cashNet));
    return {
      shift,
      sales: {
        count: sales._count,
        total: dec(sales._sum.grandTotal).toFixed(2),
        discounts: dec(sales._sum.discountTotal).toFixed(2),
        tax: dec(sales._sum.taxTotal).toFixed(2),
        voided,
      },
      returns: { count: returns._count, total: dec(returns._sum.total).toFixed(2) },
      payments: pays.map((p) => ({ kind: p.kind, method: p.method, count: p._count, amount: dec(p._sum.amount).toFixed(2) })),
      cash: cash.map((c) => ({ type: c.type, count: c._count, amount: dec(c._sum.amount).toFixed(2) })),
      expectedCash: expected.toFixed(2),
    };
  }
}

@ApiTags('Registers')
@ApiCookieAuth()
@Controller('registers')
export class RegistersController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly shifts: ShiftService) {}

  @Get()
  @BranchScoped()
  @RequirePermissions('register:read')
  list() {
    return this.db.tx.cashRegister.findMany({
      where: { branchId: currentBranchId() },
      orderBy: { name: 'asc' },
      select: {
        id: true, name: true, isActive: true,
        registerSessions: { where: { status: 'OPEN' }, select: { id: true, openedAt: true, openingBalance: true, openedBy: { select: { id: true, fullName: true } } } },
      },
    });
  }

  @Post()
  @BranchScoped()
  @RequirePermissions('branch:manage')
  async create(@Body() dto: CreateRegisterDto, @CurrentAuth() auth: AuthContext) {
    const r = await this.db.tx.cashRegister.create({ data: { tenantId: auth.tenantId, branchId: currentBranchId(), name: dto.name } });
    await this.audit.record({ action: 'register.created', entityType: 'cash_register', entityId: r.id, after: r });
    return r;
  }

  /** The caller's open shift in this branch ({ current: null } when none), with live X-report figures. */
  @Get('my-shift')
  @BranchScoped()
  async myShift(@CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const s = await openSessionFor(tx, currentBranchId(), auth.userId);
    return { current: s ? await this.shifts.summary(tx, s.id) : null };
  }

  @Post(':id/open')
  @BranchScoped()
  @RequirePermissions('register:open')
  async open(@Param('id', ParseUUIDPipe) id: string, @Body() dto: OpenShiftDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const register = await tx.cashRegister.findFirst({ where: { id, branchId } });
    if (!register || !register.isActive) throw new NotFoundException('Register not found in this branch');
    if (await openSessionFor(tx, branchId, auth.userId)) throw new ConflictException('You already have an open shift in this branch. Close it first.');
    const busy = await tx.registerSession.findFirst({ where: { registerId: id, status: 'OPEN' }, select: { openedBy: { select: { fullName: true } } } });
    if (busy) throw new ConflictException(`${register.name} is already open (${busy.openedBy.fullName})`);
    // open_marker + unique(register_id, open_marker) guarantees one open shift per register even under races
    const s = await tx.registerSession.create({
      data: { tenantId: auth.tenantId, registerId: id, openedById: auth.userId, openingBalance: money2(dto.openingBalance), notes: dto.notes ?? null, openMarker: 'OPEN', status: 'OPEN' },
      select: SHIFT_SELECT,
    });
    await this.audit.record({ action: 'shift.opened', entityType: 'register_session', entityId: s.id, after: s });
    return s;
  }
}

@ApiTags('Registers')
@ApiCookieAuth()
@Controller('shifts')
export class ShiftsController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly shifts: ShiftService) {}

  private async load(id: string, auth: AuthContext, needOthers: 'register:read' | 'finance:reconcile') {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const s = await tx.registerSession.findFirst({ where: { id, register: { branchId } }, select: SHIFT_SELECT });
    if (!s) throw new NotFoundException('Shift not found in this branch');
    if (s.openedBy.id !== auth.userId && !hasPermission(auth, needOthers, branchId)) throw new ForbiddenException(`Missing permission: ${needOthers}`);
    return s;
  }

  @Get()
  @BranchScoped()
  @RequirePermissions('register:read')
  async list(@Query() q: ListShiftsQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.RegisterSessionWhereInput = {
      register: { branchId: currentBranchId() },
      ...(q.registerId ? { registerId: q.registerId } : {}),
      ...(q.status ? { status: q.status } : {}),
      ...(q.from || q.to
        ? { openedAt: { ...(q.from ? { gte: parseDateOnly(q.from) } : {}), ...(q.to ? { lt: new Date(parseDateOnly(q.to).getTime() + 86_400_000) } : {}) } }
        : {}),
    };
    const [rows, total] = await Promise.all([
      tx.registerSession.findMany({ where, orderBy: { openedAt: 'desc' }, select: SHIFT_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.registerSession.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get(':id')
  @BranchScoped()
  async get(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    await this.load(id, auth, 'register:read');
    return this.shifts.summary(this.db.tx, id);
  }

  @Post(':id/cash')
  @BranchScoped()
  @RequirePermissions('cash:movement')
  async cash(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CashMovementDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const s = await this.load(id, auth, 'finance:reconcile');
    if (s.status !== 'OPEN') throw new ConflictException('The shift is closed');
    if (dto.type === 'WITHDRAWAL') {
      const { expectedCash } = await this.shifts.summary(tx, id);
      if (dec(expectedCash).lt(dto.amount)) throw new ConflictException(`Only ${expectedCash} cash should be in the drawer`);
    }
    const t = await recordCash(tx, {
      tenantId: auth.tenantId, branchId: currentBranchId(), registerSessionId: id, userId: auth.userId, type: dto.type,
      amount: dto.type === 'DEPOSIT' ? dec(dto.amount) : dec(dto.amount).negated(), referenceType: 'cash_movement', note: dto.note,
    });
    await this.audit.record({ action: `cash.${dto.type.toLowerCase()}`, entityType: 'register_session', entityId: id, after: t });
    return this.shifts.summary(tx, id);
  }

  @Post(':id/close')
  @BranchScoped()
  @RequirePermissions('register:close')
  async close(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CloseShiftDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const s = await this.load(id, auth, 'finance:reconcile');
    // lock the shift so a concurrent sale cannot slip in while it closes
    await tx.$queryRaw`SELECT id FROM register_sessions WHERE id = ${id}::uuid FOR UPDATE`;
    const fresh = await tx.registerSession.findFirstOrThrow({ where: { id }, select: { status: true } });
    if (fresh.status !== 'OPEN') throw new ConflictException('The shift is already closed');
    const { expectedCash } = await this.shifts.summary(tx, id);
    const counted = money2(dto.countedClosingBalance);
    const variance = counted.minus(expectedCash);
    await tx.registerSession.update({
      where: { id },
      data: {
        status: 'CLOSED', closedAt: new Date(), closedById: auth.userId, openMarker: null,
        expectedClosingBalance: dec(expectedCash), countedClosingBalance: counted, variance,
        notes: [s.notes, dto.notes].filter(Boolean).join('\n') || null,
      },
    });
    const summary = await this.shifts.summary(tx, id);
    await this.audit.record({ action: 'shift.closed', entityType: 'register_session', entityId: id, before: s, after: summary });
    return summary;
  }
}

@Module({ controllers: [RegistersController, ShiftsController], providers: [ShiftService], exports: [ShiftService] })
export class RegistersModule {}
