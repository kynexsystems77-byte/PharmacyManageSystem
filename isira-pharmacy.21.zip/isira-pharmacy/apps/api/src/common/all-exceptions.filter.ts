import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';
import { Prisma } from '@kynex/database';
import type { Response } from 'express';
import { requestContext } from './request-context';

const CODES: Record<number, string> = {
  400: 'BAD_REQUEST', 401: 'UNAUTHENTICATED', 403: 'FORBIDDEN', 404: 'NOT_FOUND', 409: 'CONFLICT', 422: 'UNPROCESSABLE', 429: 'RATE_LIMITED',
};

/** One consistent error shape: { error: { code, message, details?, requestId } } */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger('Exceptions');

  catch(exception: unknown, host: ArgumentsHost): void {
    const res = host.switchToHttp().getResponse<Response>();
    const requestId = requestContext.getStore()?.requestId;
    let status = 500;
    let code = 'INTERNAL_ERROR';
    let message = 'Internal server error';
    let details: unknown;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const body = exception.getResponse();
      if (typeof body === 'string') {
        message = body;
      } else {
        const b = body as Record<string, unknown>;
        message = Array.isArray(b.message) ? b.message.join('; ') : typeof b.message === 'string' ? b.message : exception.message;
        if (Array.isArray(b.errors)) details = b.errors;
      }
      code = details ? 'VALIDATION_ERROR' : (CODES[status] ?? `HTTP_${status}`);
    } else if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      if (exception.code === 'P2002') {
        status = 409; code = 'CONFLICT'; message = 'A record with the same unique value already exists'; details = exception.meta?.target;
      } else if (exception.code === 'P2025') {
        status = 404; code = 'NOT_FOUND'; message = 'Record not found';
      } else if (exception.code === 'P2003') {
        status = 409; code = 'CONFLICT'; message = 'The record is referenced by other data or points to something that does not exist';
      } else if (exception.code === 'P2034') {
        status = 409; code = 'CONFLICT'; message = 'The operation conflicted with another request. Please retry.';
      }
    }

    if (status >= 500) {
      this.logger.error(`[${requestId}] ${exception instanceof Error ? (exception.stack ?? exception.message) : String(exception)}`);
    }
    res.status(status).json({ error: { code, message, ...(details !== undefined ? { details } : {}), requestId } });
  }
}
