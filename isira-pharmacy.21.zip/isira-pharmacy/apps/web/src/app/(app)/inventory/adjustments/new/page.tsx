'use client';

import { Trash2 } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { ADJUSTMENT_REASONS } from '@kynex/contracts';
import { Forbidden, PageHeader, Select, Textarea, useToast } from '@/components/kit';
import { BatchSelect, LocationSelect, ProductPicker } from '@/components/pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, num, qty, titleCase } from '@/lib/format';
import { errorMessage, newKey, useApiMutation } from '@/lib/hooks';
import type { Adjustment, BatchRow, Product } from '@/lib/types';

interface Line { key: string; product: Product; batchId: string; batch?: BatchRow; quantity: string; direction: 'in' | 'out'; note: string }

export default function NewAdjustmentPage() {
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const writeOff = useSearchParams().get('mode') === 'writeoff';
  const [locationId, setLocationId] = useState('');
  const [reason, setReason] = useState<string>(writeOff ? 'EXPIRED' : 'COUNT_CORRECTION');
  const [note, setNote] = useState('');
  const [lines, setLines] = useState<Line[]>([]);

  const submit = useApiMutation<object, Adjustment>('POST', writeOff ? '/inventory/write-offs' : '/inventory/adjustments', {
    onSuccess: (a) => {
      toast.success(`${a.number} posted`);
      router.push(`/inventory/adjustments/${a.id}`);
    },
  });

  if (!can(writeOff ? 'inventory:writeoff' : 'inventory:adjust')) return <Forbidden what={writeOff ? 'write-offs' : 'stock adjustments'} />;

  const setLine = (key: string, patch: Partial<Line>) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const valid = locationId && lines.length > 0 && lines.every((l) => l.batchId && Number(l.quantity) > 0);

  const post = () => {
    const items = lines.map((l) =>
      writeOff
        ? { batchId: l.batchId, quantity: Number(l.quantity) }
        : { batchId: l.batchId, quantityDelta: l.direction === 'out' ? -Number(l.quantity) : Number(l.quantity), note: l.note || undefined },
    );
    submit.mutate({ locationId, reason, note: note || undefined, items });
  };

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader
        back="/inventory/adjustments"
        title={writeOff ? 'Write off stock' : 'New stock adjustment'}
        subtitle={writeOff ? 'Removes expired or damaged stock from sale. Expired write-offs only accept batches past their expiry date.' : 'Corrects stock after a count, loss or find. Each line becomes a ledger entry.'}
      />
      <Card>
        <div className="grid gap-4 p-4 sm:grid-cols-3">
          <Field label="Location"><LocationSelect value={locationId} onChange={(id) => { setLocationId(id); setLines([]); }} /></Field>
          <Field label="Reason">
            <Select value={reason} onChange={(e) => setReason(e.target.value)}>
              {(writeOff ? (['EXPIRED', 'DAMAGED'] as const) : ADJUSTMENT_REASONS).map((r) => <option key={r} value={r}>{titleCase(r)}</option>)}
            </Select>
          </Field>
          <Field label="Note"><Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="Optional" /></Field>
        </div>
      </Card>
      <Card>
        <CardHeader title="Lines" />
        <div className="space-y-3 p-4">
          <ProductPicker
            onPick={(p) => setLines((ls) => [...ls, { key: newKey(), product: p, batchId: '', quantity: '', direction: writeOff ? 'out' : 'out', note: '' }])}
            placeholder="Add a product (search or scan)"
          />
          {lines.length === 0 && <p className="py-6 text-center text-sm text-fg-muted">Add the products to adjust.</p>}
          {lines.map((l) => (
            <div key={l.key} className="grid items-end gap-2 rounded-lg border border-line p-3 lg:grid-cols-[1.2fr_1.6fr_auto_120px_1fr_auto]">
              <div className="min-w-0 pb-2 text-sm">
                <p className="truncate font-medium">{l.product.brandName}</p>
                <p className="truncate text-xs text-fg-muted">{l.product.sku}</p>
              </div>
              <Field label="Batch">
                <BatchSelect productId={l.product.id} locationId={locationId} value={l.batchId} onChange={(id, b) => setLine(l.key, { batchId: id, batch: b })} />
              </Field>
              {!writeOff ? (
                <Field label="Direction">
                  <Select value={l.direction} onChange={(e) => setLine(l.key, { direction: e.target.value as 'in' | 'out' })} className="w-28">
                    <option value="out">Remove</option>
                    <option value="in">Add</option>
                  </Select>
                </Field>
              ) : <span />}
              <Field label={`Qty (${l.product.baseUnit})`}><Input type="number" min="0.001" step="0.001" value={l.quantity} onChange={(e) => setLine(l.key, { quantity: e.target.value })} /></Field>
              {!writeOff ? <Field label="Line note"><Input value={l.note} onChange={(e) => setLine(l.key, { note: e.target.value })} maxLength={300} /></Field> : (
                <p className="pb-2 text-xs text-fg-muted">{l.batch ? `On hand ${qty(num(l.batch.quantity))} · exp ${dateOnly(l.batch.expiryDate)}` : ''}</p>
              )}
              <button aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      </Card>
      {submit.error && <Alert>{errorMessage(submit.error)}</Alert>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
        <Button disabled={!valid} loading={submit.isPending} onClick={post}>{writeOff ? 'Post write-off' : 'Post adjustment'}</Button>
      </div>
    </div>
  );
}
