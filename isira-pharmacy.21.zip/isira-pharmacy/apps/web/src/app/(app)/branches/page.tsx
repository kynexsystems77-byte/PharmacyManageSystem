'use client';

import { Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { BranchForm, branchBody, type BranchDraft } from '@/components/branch-form';
import { DataTable, Forbidden, Modal, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { BranchRow } from '@/lib/types';

const EMPTY: BranchDraft = { name: '', code: '', address: '', phone: '', email: '', invoicePrefix: 'INV', receiptHeader: '', receiptFooter: '', taxNumber: '' };

export default function BranchesPage() {
  const router = useRouter();
  const { can } = useAuth();
  const toast = useToast();
  const { data, isLoading } = useBranchQuery<BranchRow[]>(can('branch:read') ? '/branches' : null);
  const [draft, setDraft] = useState<BranchDraft | null>(null);
  const create = useApiMutation<object, BranchRow>('POST', '/branches', {
    onSuccess: (b) => { toast.success(`${b.name} created with a sales floor, warehouse and register. Sign in again to work in it.`); setDraft(null); router.push(`/branches/${b.id}`); },
  });
  if (!can('branch:read')) return <Forbidden what="branches" />;
  return (
    <div>
      <PageHeader title="Branches" actions={can('branch:manage') && <Button onClick={() => setDraft(EMPTY)}><Plus size={16} /> New branch</Button>} />
      <Card>
        <DataTable
          rows={data}
          loading={isLoading}
          rowKey={(b) => b.id}
          onRowClick={(b) => router.push(`/branches/${b.id}`)}
          columns={[
            { key: 'n', header: 'Branch', cell: (b) => <div><p className="font-medium">{b.name}</p><p className="font-mono text-xs text-fg-muted">{b.code}</p></div> },
            { key: 'a', header: 'Address', cell: (b) => b.address ?? '-' },
            { key: 'p', header: 'Phone', cell: (b) => b.phone ?? '-' },
            { key: 'l', header: 'Locations', cell: (b) => b.locations.map((l) => l.name).join(', ') },
            { key: 'i', header: 'Invoice prefix', cell: (b) => <span className="font-mono text-xs">{b.invoicePrefix}</span> },
            { key: 's', header: '', cell: (b) => !b.isActive && <Badge>Inactive</Badge> },
          ]}
        />
      </Card>
      <Modal open={Boolean(draft)} onClose={() => setDraft(null)} title="New branch" size="lg"
        footer={<><Button variant="outline" onClick={() => setDraft(null)}>Cancel</Button><Button loading={create.isPending} disabled={!draft?.name.trim() || !draft?.code.trim()} onClick={() => draft && create.mutate(branchBody(draft, true))}>Create branch</Button></>}>
        {create.error && <div className="mb-3"><Alert>{errorMessage(create.error)}</Alert></div>}
        {draft && <BranchForm value={draft} onChange={setDraft} creating />}
      </Modal>
    </div>
  );
}
