import {
  BadRequestException, Body, ConflictException, Controller, Delete, Get, HttpCode, Module, NotFoundException, Param, ParseUUIDPipe,
  Patch, Post, Query, Res, UploadedFile, UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiConsumes, ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import { createZodDto } from 'nestjs-zod';
import { randomUUID } from 'node:crypto';
import {
  ATTACHMENT_MAX_BYTES, createPrescriptionSchema, listPrescriptionsQuerySchema, updatePrescriptionSchema,
} from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId } from '../common/branch';
import { dec, formatDateOnly, optionalDate, parseDateOnly, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { StorageService } from '../common/storage';
import { TenantDb } from '../prisma/prisma.service';

class CreatePrescriptionDto extends createZodDto(createPrescriptionSchema) {}
class UpdatePrescriptionDto extends createZodDto(updatePrescriptionSchema) {}
class ListPrescriptionsQueryDto extends createZodDto(listPrescriptionsQuerySchema) {}

const RX_SELECT = {
  id: true, prescriptionNumber: true, doctorName: true, doctorRegistration: true, prescribedDate: true, validUntil: true, notes: true,
  status: true, createdAt: true,
  customer: { select: { id: true, fullName: true, phone: true, code: true } },
  branch: { select: { id: true, name: true } },
  createdBy: { select: { id: true, fullName: true } },
  prescriptionItems: {
    orderBy: { createdAt: 'asc' },
    select: {
      id: true, medicineName: true, dosage: true, frequency: true, durationDays: true, quantityPrescribed: true, quantityDispensed: true, instructions: true,
      product: { select: { id: true, brandName: true, strength: true, baseUnit: true, sku: true } },
    },
  },
} satisfies Prisma.PrescriptionSelect;

/** Detects the real file type from its first bytes (the browser-supplied MIME type is not trusted). */
function sniff(buf: Buffer): string | null {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length >= 12 && buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
  if (buf.length >= 5 && buf.subarray(0, 5).toString('ascii') === '%PDF-') return 'application/pdf';
  return null;
}

function safeFileName(name: string): string {
  const cleaned = name.normalize('NFKD').replace(/[^\w.\- ]+/g, '').replace(/\s+/g, '_').slice(-80);
  return cleaned || 'file';
}

@ApiTags('Prescriptions')
@ApiCookieAuth()
@Controller('prescriptions')
export class PrescriptionsController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly tenantInfo: TenantInfoService,
    private readonly storage: StorageService,
  ) {}

  /** ACTIVE/PARTIALLY_DISPENSED prescriptions past their validity are reported as EXPIRED. */
  private effective<T extends { status: string; validUntil: Date | null }>(rx: T, today: Date): T & { dispensable: boolean } {
    const expired = rx.validUntil !== null && rx.validUntil < today && ['ACTIVE', 'PARTIALLY_DISPENSED'].includes(rx.status);
    const status = expired ? 'EXPIRED' : rx.status;
    return { ...rx, status, dispensable: ['ACTIVE', 'PARTIALLY_DISPENSED'].includes(status) };
  }

  @Get()
  @RequirePermissions('prescription:read')
  async list(@Query() q: ListPrescriptionsQueryDto) {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const today = parseDateOnly(todayIn(timezone));
    const where: Prisma.PrescriptionWhereInput = {
      deletedAt: null,
      ...(q.customerId ? { customerId: q.customerId } : {}),
      ...(q.status ? { status: q.status } : {}),
      ...(q.dispensable === 'true' ? { status: { in: ['ACTIVE', 'PARTIALLY_DISPENSED'] }, OR: [{ validUntil: null }, { validUntil: { gte: today } }] } : {}),
      ...(q.search
        ? { AND: [{ OR: [{ prescriptionNumber: { contains: q.search, mode: 'insensitive' } }, { doctorName: { contains: q.search, mode: 'insensitive' } }, { customer: { fullName: { contains: q.search, mode: 'insensitive' } } }, { customer: { phone: { contains: q.search } } }] }] }
        : {}),
    };
    const [rows, total] = await Promise.all([
      tx.prescription.findMany({ where, orderBy: [{ prescribedDate: 'desc' }, { createdAt: 'desc' }], select: RX_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.prescription.count({ where }),
    ]);
    return paged(rows.map((r) => this.effective(r, today)), total, q.page, q.pageSize);
  }

  @Get(':id')
  @RequirePermissions('prescription:read')
  async get(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const rx = await tx.prescription.findFirst({ where: { id, deletedAt: null }, select: RX_SELECT });
    if (!rx) throw new NotFoundException('Prescription not found');
    const { timezone } = await this.tenantInfo.get(tx);
    const [attachments, sales] = await Promise.all([
      tx.attachment.findMany({ where: { ownerType: 'prescription', ownerId: id }, orderBy: { createdAt: 'asc' }, select: { id: true, fileName: true, mimeType: true, sizeBytes: true, createdAt: true, uploadedBy: { select: { fullName: true } } } }),
      tx.sale.findMany({ where: { prescriptionId: id, branchId: { in: [...auth.branchIds] } }, orderBy: { soldAt: 'desc' }, select: { id: true, invoiceNo: true, status: true, soldAt: true, grandTotal: true, branch: { select: { name: true } } } }),
    ]);
    return { ...this.effective(rx, parseDateOnly(todayIn(timezone))), attachments, sales };
  }

  private async assertProducts(tx: Prisma.TransactionClient, ids: (string | null | undefined)[]) {
    const list = [...new Set(ids.filter((x): x is string => Boolean(x)))];
    if (list.length && (await tx.product.count({ where: { id: { in: list }, deletedAt: null } })) !== list.length) throw new BadRequestException('Unknown product on an item');
  }

  @Post()
  @BranchScoped()
  @RequirePermissions('prescription:manage')
  async create(@Body() dto: CreatePrescriptionDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const customer = await tx.customer.findFirst({ where: { id: dto.customerId, deletedAt: null }, select: { id: true } });
    if (!customer) throw new BadRequestException('Customer not found');
    if (dto.validUntil && dto.validUntil < dto.prescribedDate) throw new BadRequestException('Valid-until is before the prescription date');
    await this.assertProducts(tx, dto.items.map((i) => i.productId));
    const rx = await tx.prescription.create({
      data: {
        tenantId: auth.tenantId, customerId: dto.customerId, branchId: currentBranchId(), createdById: auth.userId,
        prescriptionNumber: dto.prescriptionNumber ?? null, doctorName: dto.doctorName, doctorRegistration: dto.doctorRegistration ?? null,
        prescribedDate: parseDateOnly(dto.prescribedDate), validUntil: optionalDate(dto.validUntil) ?? null, notes: dto.notes ?? null,
        prescriptionItems: {
          create: dto.items.map((i) => ({
            tenantId: auth.tenantId, medicineName: i.medicineName, productId: i.productId ?? null, dosage: i.dosage ?? null, frequency: i.frequency ?? null,
            durationDays: i.durationDays ?? null, quantityPrescribed: i.quantityPrescribed === undefined ? null : dec(i.quantityPrescribed), instructions: i.instructions ?? null,
          })),
        },
      },
      select: RX_SELECT,
    });
    await this.audit.record({ action: 'prescription.created', entityType: 'prescription', entityId: rx.id, after: rx });
    return rx;
  }

  @Patch(':id')
  @RequirePermissions('prescription:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePrescriptionDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await tx.prescription.findFirst({ where: { id, deletedAt: null }, select: RX_SELECT });
    if (!before) throw new NotFoundException('Prescription not found');
    if (!['ACTIVE', 'PARTIALLY_DISPENSED'].includes(before.status)) throw new ConflictException(`A ${before.status.toLowerCase()} prescription cannot be edited`);
    const prescribed = dto.prescribedDate ?? formatDateOnly(before.prescribedDate)!;
    const validUntil = dto.validUntil === undefined ? formatDateOnly(before.validUntil) : dto.validUntil;
    if (validUntil && validUntil < prescribed) throw new BadRequestException('Valid-until is before the prescription date');
    if (dto.items) {
      await this.assertProducts(tx, dto.items.map((i) => i.productId));
      const keep = new Set(dto.items.map((i) => i.id).filter(Boolean));
      for (const old of before.prescriptionItems) {
        if (!keep.has(old.id) && dec(old.quantityDispensed).gt(0)) throw new ConflictException(`${old.medicineName} has been dispensed and cannot be removed`);
      }
      for (const i of dto.items) {
        if (i.id && !before.prescriptionItems.some((x) => x.id === i.id)) throw new BadRequestException('Unknown prescription item');
      }
      await tx.prescriptionItem.deleteMany({ where: { prescriptionId: id, id: { notIn: [...keep] as string[] } } });
      for (const i of dto.items) {
        const data = {
          medicineName: i.medicineName, productId: i.productId ?? null, dosage: i.dosage ?? null, frequency: i.frequency ?? null,
          durationDays: i.durationDays ?? null, quantityPrescribed: i.quantityPrescribed === undefined ? null : dec(i.quantityPrescribed), instructions: i.instructions ?? null,
        };
        if (i.id) await tx.prescriptionItem.update({ where: { id: i.id }, data });
        else await tx.prescriptionItem.create({ data: { ...data, tenantId: auth.tenantId, prescriptionId: id } });
      }
    }
    const { items: _i, prescribedDate, validUntil: vu, ...rest } = dto;
    await tx.prescription.update({
      where: { id },
      data: { ...rest, prescribedDate: prescribedDate ? parseDateOnly(prescribedDate) : undefined, validUntil: optionalDate(vu) },
    });
    const after = await tx.prescription.findFirstOrThrow({ where: { id }, select: RX_SELECT });
    await this.audit.record({ action: 'prescription.updated', entityType: 'prescription', entityId: id, before, after });
    return after;
  }

  @Post(':id/cancel')
  @RequirePermissions('prescription:manage')
  async cancel(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.prescription.findFirst({ where: { id, deletedAt: null }, select: RX_SELECT });
    if (!before) throw new NotFoundException('Prescription not found');
    if (before.status === 'CANCELLED' || before.status === 'DISPENSED') throw new ConflictException(`The prescription is already ${before.status.toLowerCase()}`);
    const after = await tx.prescription.update({ where: { id }, data: { status: 'CANCELLED' }, select: RX_SELECT });
    await this.audit.record({ action: 'prescription.cancelled', entityType: 'prescription', entityId: id, before, after });
    return after;
  }

  @Post(':id/attachments')
  @ApiConsumes('multipart/form-data')
  @RequirePermissions('prescription:manage')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: ATTACHMENT_MAX_BYTES, files: 1 } }))
  async upload(@Param('id', ParseUUIDPipe) id: string, @UploadedFile() file: Express.Multer.File | undefined, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    if (!file) throw new BadRequestException('Attach a file in the "file" field');
    const rx = await tx.prescription.findFirst({ where: { id, deletedAt: null }, select: { id: true } });
    if (!rx) throw new NotFoundException('Prescription not found');
    const mime = sniff(file.buffer);
    if (!mime) throw new BadRequestException('Only JPEG, PNG, WEBP images and PDF files are accepted');
    if ((await tx.attachment.count({ where: { ownerType: 'prescription', ownerId: id } })) >= 10) throw new ConflictException('A prescription can have at most 10 files');
    const name = safeFileName(file.originalname);
    const key = `${auth.tenantId}/prescriptions/${id}/${randomUUID()}-${name}`;
    await this.storage.put(key, file.buffer, mime);
    const a = await tx.attachment.create({
      data: { tenantId: auth.tenantId, ownerType: 'prescription', ownerId: id, storageKey: key, fileName: name, mimeType: mime, sizeBytes: file.size, uploadedById: auth.userId },
      select: { id: true, fileName: true, mimeType: true, sizeBytes: true, createdAt: true },
    });
    await this.audit.record({ action: 'prescription.attachment_added', entityType: 'prescription', entityId: id, after: a });
    return a;
  }
}

@ApiTags('Prescriptions')
@ApiCookieAuth()
@Controller('attachments')
export class AttachmentsController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly storage: StorageService) {}

  /** Streams the file through the API (same origin, permission-checked, tenant-isolated by RLS). */
  @Get(':id/download')
  @RequirePermissions('prescription:read')
  async download(@Param('id', ParseUUIDPipe) id: string, @Res() res: Response) {
    const a = await this.db.tx.attachment.findFirst({ where: { id }, select: { storageKey: true, fileName: true, mimeType: true } });
    if (!a) throw new NotFoundException('File not found');
    const obj = await this.storage.get(a.storageKey);
    res.setHeader('Content-Type', a.mimeType);
    res.setHeader('Content-Disposition', `inline; filename="${a.fileName.replace(/"/g, '')}"`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, max-age=300');
    if (obj.size) res.setHeader('Content-Length', String(obj.size));
    await new Promise<void>((resolve, reject) => {
      obj.stream.on('error', reject);
      res.on('finish', resolve);
      obj.stream.pipe(res);
    });
  }

  @Delete(':id')
  @HttpCode(204)
  @RequirePermissions('prescription:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const a = await tx.attachment.findFirst({ where: { id } });
    if (!a) throw new NotFoundException('File not found');
    await tx.attachment.delete({ where: { id } });
    await this.storage.delete(a.storageKey).catch(() => undefined);
    await this.audit.record({ action: 'attachment.deleted', entityType: a.ownerType, entityId: a.ownerId, before: { fileName: a.fileName } });
  }
}

@Module({ controllers: [PrescriptionsController, AttachmentsController] })
export class PrescriptionsModule {}
