import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { Client } from 'pg';

/** Applies prisma/security.sql as the OWNER role. Idempotent; run after every migration. */
async function main(): Promise<void> {
  const raw = process.env.DIRECT_URL;
  if (!raw) {
    throw new Error('DIRECT_URL is not set (see .env.example)');
  }
  const url = new URL(raw);
  url.searchParams.delete('schema');

  const sql = readFileSync(join(__dirname, '..', 'prisma', 'security.sql'), 'utf8');
  const client = new Client({ connectionString: url.toString() });
  await client.connect();
  try {
    await client.query(sql); // simple-query protocol: the whole file runs as one implicit transaction
    console.log('Database hardening applied (RLS, tenant triggers, append-only ledgers, checks, grants).');
  } finally {
    await client.end();
  }
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
