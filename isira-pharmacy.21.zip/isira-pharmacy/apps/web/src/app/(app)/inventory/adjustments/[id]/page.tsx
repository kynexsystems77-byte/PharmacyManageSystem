'use client';

import { DataTable, KeyValue, PageHeader } from '@/components/kit';
import { Alert, Card, CardHeader, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, qty, titleCase } from '@/lib/format';
import { errorMessage, useBranchQuery } from '@/lib/hooks';
import type { Adjustment } from '@/lib/types';

export default function AdjustmentPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const { data: a, isLoading, error } = useBranchQuery<Adjustment>(`/inventory/adjustments/${params.id}`);
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !a) return <Alert>{errorMessage(error) || 'Not found'}</Alert>;
  const value = a.stockAdjustmentItems.reduce((s, i) => s + num(i.quantityDelta) * num(i.unitCost), 0);
  return (
    <div className="space-y-4">
      <PageHeader back="/inventory/adjustments" title={a.number} subtitle={titleCase(a.reason)} />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Posted', value: dateTime(a.postedAt ?? a.createdAt) },
          { label: 'Location', value: a.location.name },
          { label: 'By', value: a.createdBy.fullName },
          ...(can('report:financial:view') ? [{ label: 'Value impact (cost)', value: money(value, profile.tenant.currencyCode) }] : []),
          { label: 'Note', value: a.note },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Lines" />
        <DataTable
          rows={a.stockAdjustmentItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => i.product.brandName },
            { key: 'b', header: 'Batch', cell: (i) => <span className="font-mono text-xs">{i.batch.batchNumber}</span> },
            { key: 'e', header: 'Expiry', cell: (i) => dateOnly(i.batch.expiryDate) },
            { key: 'n', header: 'Note', cell: (i) => i.note ?? '-' },
            { key: 'q', header: 'Change', align: 'right', cell: (i) => <span className={num(i.quantityDelta) < 0 ? 'text-danger' : 'text-success'}>{num(i.quantityDelta) > 0 ? '+' : ''}{qty(num(i.quantityDelta))} {i.product.baseUnit}</span> },
          ]}
        />
      </Card>
    </div>
  );
}
