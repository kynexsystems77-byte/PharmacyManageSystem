'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function InventoryLayout({ children }: { children: ReactNode }) {
  const { can, canAny } = useAuth();
  if (!canAny('inventory:read', 'batch:read')) return <Forbidden what="inventory" />;
  const items = [
    can('inventory:read') && { href: '/inventory', label: 'Stock', exact: true },
    can('batch:read') && { href: '/inventory/batches', label: 'Batches & expiry' },
    can('inventory:read') && { href: '/inventory/ledger', label: 'Stock ledger' },
    can('inventory:read') && { href: '/inventory/adjustments', label: 'Adjustments' },
    can('inventory:read') && { href: '/inventory/transfers', label: 'Transfers' },
  ].filter(Boolean) as { href: string; label: string; exact?: boolean }[];
  return (
    <div>
      <SubNav items={items} />
      {children}
    </div>
  );
}
