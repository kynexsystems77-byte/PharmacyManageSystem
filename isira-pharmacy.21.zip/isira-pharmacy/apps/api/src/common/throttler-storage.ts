import { Module, Logger, type OnModuleDestroy } from '@nestjs/common';
import { ThrottlerStorageService, type ThrottlerStorage } from '@nestjs/throttler';
import type { ThrottlerStorageRecord } from '@nestjs/throttler/dist/throttler-storage-record.interface';
import Redis from 'ioredis';
import { ENV, type Env } from '../config/env';
import { redisConnection } from '../jobs/queue';

/**
 * Atomic fixed-window counter with optional blocking, shared by every API instance.
 * KEYS[1] hit counter, KEYS[2] block flag; ARGV ttl ms, limit, block ms.
 */
const SCRIPT = `
local blockTtl = redis.call('PTTL', KEYS[2])
if blockTtl > 0 then
  return {tonumber(redis.call('GET', KEYS[1]) or '0'), math.max(redis.call('PTTL', KEYS[1]), 0), 1, blockTtl}
end
local hits = redis.call('INCR', KEYS[1])
if hits == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end
local ttl = redis.call('PTTL', KEYS[1])
if ttl < 0 then redis.call('PEXPIRE', KEYS[1], ARGV[1]); ttl = tonumber(ARGV[1]) end
if hits > tonumber(ARGV[2]) then
  redis.call('SET', KEYS[2], '1', 'PX', ARGV[3])
  return {hits, ttl, 1, tonumber(ARGV[3])}
end
return {hits, ttl, 0, 0}
`;

/** Rate-limit counters in Redis so limits hold across several API replicas. Falls back to memory if Redis is down. */
export class RedisThrottlerStorage implements ThrottlerStorage, OnModuleDestroy {
  private readonly logger = new Logger('Throttler');
  private readonly redis: Redis;
  private readonly fallback = new ThrottlerStorageService();
  private warned = false;

  constructor(url: string) {
    this.redis = new Redis({ ...redisConnection(url), maxRetriesPerRequest: 1, enableOfflineQueue: false, lazyConnect: false });
    this.redis.on('error', (e) => {
      if (!this.warned) this.logger.warn(`Redis unavailable for rate limiting, using in-memory counters: ${e.message}`);
      this.warned = true;
    });
    this.redis.on('ready', () => { this.warned = false; });
  }

  async increment(key: string, ttl: number, limit: number, blockDuration: number, throttlerName: string): Promise<ThrottlerStorageRecord> {
    const base = `kx:throttle:${throttlerName}:${key}`;
    try {
      const [hits, ttlMs, blocked, blockMs] = (await this.redis.eval(SCRIPT, 2, `${base}:hits`, `${base}:block`, ttl, limit, blockDuration || ttl)) as number[];
      return { totalHits: hits, timeToExpire: Math.ceil(ttlMs / 1000), isBlocked: blocked === 1, timeToBlockExpire: Math.ceil(blockMs / 1000) };
    } catch {
      return this.fallback.increment(key, ttl, limit, blockDuration, throttlerName);
    }
  }

  /** Resolves once the Redis connection is usable (until then the in-memory fallback is used). */
  async waitUntilReady(timeoutMs = 5_000): Promise<boolean> {
    if (this.redis.status === 'ready') return true;
    return new Promise((resolve) => {
      const t = setTimeout(() => resolve(false), timeoutMs);
      this.redis.once('ready', () => { clearTimeout(t); resolve(true); });
    });
  }

  async onModuleDestroy(): Promise<void> {
    this.fallback.onApplicationShutdown();
    await this.redis.quit().catch(() => undefined);
  }
}

export const THROTTLER_STORE = Symbol('THROTTLER_STORE');

/** Provides the rate-limit store as a managed provider so its Redis connection is closed on shutdown. */
@Module({
  providers: [{
    provide: THROTTLER_STORE,
    inject: [ENV],
    useFactory: (env: Env): ThrottlerStorage => (env.REDIS_URL ? new RedisThrottlerStorage(env.REDIS_URL) : new ThrottlerStorageService()),
  }],
  exports: [THROTTLER_STORE],
})
export class ThrottlerStoreModule {}
