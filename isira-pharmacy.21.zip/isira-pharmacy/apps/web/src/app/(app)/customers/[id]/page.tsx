'use client';

import { ClipboardList, CreditCard, Pencil, Receipt, ShoppingBag, Wallet } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { CustomerFormModal } from '@/components/customer-form';
import { DataTable, KeyValue, Modal, PageHeader, Pagination, Select, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, titleCase } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery, usePaging, type Paged } from '@/lib/hooks';
import { RX_TONE, SALE_TONE } from '@/lib/status';
import type { CustomerDetail, LedgerEntry } from '@/lib/types';

export default function CustomerPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const toast = useToast();
  const cur = profile.tenant.currencyCode;
  const fmt = (v: string | number) => money(num(v), cur);
  const { data: c, isLoading, error } = useBranchQuery<CustomerDetail>(`/customers/${params.id}`);
  const { page, setPage } = usePaging([params.id]);
  const ledger = useBranchQuery<Paged<LedgerEntry>>(`/customers/${params.id}/ledger${qs({ page, pageSize: 15 })}`, { keepPrevious: true });
  const [editing, setEditing] = useState(false);
  const [paying, setPaying] = useState(false);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('CASH');
  const [reference, setReference] = useState('');
  const pay = useApiMutation<object, { balance: string }>('POST', `/customers/${params.id}/payments`, {
    onSuccess: (r) => { toast.success(`Payment received. Balance now ${fmt(r.balance)}.`); setPaying(false); setAmount(''); setReference(''); },
  });
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !c) return <Alert>{errorMessage(error) || 'Customer not found'}</Alert>;
  const owes = num(c.balance);
  return (
    <div className="space-y-4">
      <PageHeader
        back="/customers"
        title={c.fullName}
        subtitle={<span className="flex items-center gap-2"><span className="font-mono">{c.code}</span>{!c.isActive && <Badge>Inactive</Badge>}</span>}
        actions={
          <>
            {can('prescription:manage') && <Link href={`/prescriptions/new?customerId=${c.id}`}><Button variant="outline"><ClipboardList size={16} /> Add prescription</Button></Link>}
            {can('customer:manage') && <Button variant="outline" onClick={() => setEditing(true)}><Pencil size={16} /> Edit</Button>}
            {can('customer:credit:manage') && owes > 0 && <Button onClick={() => { setAmount(String(owes)); setPaying(true); }}><Wallet size={16} /> Receive payment</Button>}
          </>
        }
      />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Owes" value={fmt(c.balance)} icon={<Wallet size={18} />} tone={owes > 0 ? 'warning' : 'success'} hint={owes < 0 ? 'Store credit available' : 'Credit balance'} />
        <StatTile label="Credit available" value={num(c.creditLimit) > 0 ? fmt(c.availableCredit) : 'Cash only'} icon={<CreditCard size={18} />} hint={num(c.creditLimit) > 0 ? `Limit ${fmt(c.creditLimit)}` : 'No credit limit set'} />
        <StatTile label="Total spent" value={fmt(c.stats.totalSpent)} icon={<ShoppingBag size={18} />} hint={`${c.stats.visits} visits`} />
        <StatTile label="Last visit" value={c.stats.lastVisit ? dateOnly(c.stats.lastVisit) : 'Never'} icon={<Receipt size={18} />} />
      </div>
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Phone', value: c.phone }, { label: 'Email', value: c.email }, { label: 'Address', value: c.address },
          { label: 'Date of birth', value: c.dateOfBirth ? dateOnly(c.dateOfBirth) : null }, { label: 'Notes', value: c.notes },
        ]} />
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Recent purchases" action={<Link className="text-xs text-brand hover:underline" href={`/sales?search=${encodeURIComponent(c.phone ?? c.fullName)}`}>All invoices</Link>} />
          <DataTable
            rows={c.recentSales}
            rowKey={(s) => s.id}
            empty={<p className="px-4 py-6 text-center text-sm text-fg-muted">No purchases yet.</p>}
            columns={[
              { key: 'n', header: 'Invoice', cell: (s) => <Link className="font-mono text-xs text-brand hover:underline" href={`/sales/${s.id}`}>{s.invoiceNo}</Link> },
              { key: 'd', header: 'Date', cell: (s) => dateOnly(s.soldAt) },
              { key: 's', header: 'Status', cell: (s) => <Badge tone={SALE_TONE[s.status]}>{titleCase(s.status)}</Badge> },
              { key: 't', header: 'Total', align: 'right', cell: (s) => fmt(s.grandTotal) },
            ]}
          />
        </Card>
        <Card>
          <CardHeader title="Prescriptions" />
          <DataTable
            rows={c.prescriptions}
            rowKey={(p) => p.id}
            empty={<p className="px-4 py-6 text-center text-sm text-fg-muted">No prescriptions recorded.</p>}
            columns={[
              { key: 'd', header: 'Date', cell: (p) => <Link className="text-brand hover:underline" href={`/prescriptions/${p.id}`}>{dateOnly(p.prescribedDate)}</Link> },
              { key: 'doc', header: 'Doctor', cell: (p) => p.doctorName },
              { key: 'i', header: 'Items', align: 'right', cell: (p) => p.itemCount },
              { key: 's', header: 'Status', cell: (p) => <Badge tone={RX_TONE[p.status]}>{titleCase(p.status)}</Badge> },
            ]}
          />
        </Card>
      </div>
      <Card>
        <CardHeader title="Account statement" action={<span className="text-xs text-fg-muted">Positive = customer owes</span>} />
        <DataTable
          rows={ledger.data?.data}
          loading={ledger.isLoading}
          rowKey={(e) => e.id}
          empty={<p className="px-4 py-6 text-center text-sm text-fg-muted">No credit activity.</p>}
          columns={[
            { key: 'd', header: 'Date', cell: (e) => dateTime(e.createdAt) },
            { key: 't', header: 'Entry', cell: (e) => titleCase(e.entryType) },
            { key: 'x', header: 'Details', cell: (e) => (e.referenceType === 'sale' && e.referenceId ? <Link className="text-brand hover:underline" href={`/sales/${e.referenceId}`}>{e.description}</Link> : e.description ?? '-') },
            { key: 'a', header: 'Amount', align: 'right', cell: (e) => <span className={num(e.amount) < 0 ? 'text-success' : ''}>{fmt(e.amount)}</span> },
            { key: 'b', header: 'Balance', align: 'right', cell: (e) => <span className="font-medium">{fmt(e.balance)}</span> },
          ]}
        />
        {ledger.data && <Pagination page={ledger.data.meta.page} totalPages={ledger.data.meta.totalPages} total={ledger.data.meta.total} onPage={setPage} />}
      </Card>
      {editing && <CustomerFormModal customer={c} onClose={() => setEditing(false)} />}
      <Modal open={paying} onClose={() => setPaying(false)} size="sm" title={`Receive payment from ${c.fullName}`}
        footer={<><Button variant="outline" onClick={() => setPaying(false)}>Cancel</Button><Button loading={pay.isPending} disabled={!(num(amount) > 0)} onClick={() => pay.mutate({ amount: num(amount), method, reference: reference.trim() || undefined })}>Record payment</Button></>}>
        <div className="space-y-3">
          {pay.error && <Alert>{errorMessage(pay.error)}</Alert>}
          <Field label="Amount"><Input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus /></Field>
          <Field label="Method"><Select value={method} onChange={(e) => setMethod(e.target.value)}><option value="CASH">Cash (into your open shift)</option><option value="CARD">Card</option><option value="BANK_TRANSFER">Bank transfer</option><option value="OTHER">Other</option></Select></Field>
          <Field label="Reference"><Input value={reference} onChange={(e) => setReference(e.target.value)} /></Field>
        </div>
      </Modal>
    </div>
  );
}
