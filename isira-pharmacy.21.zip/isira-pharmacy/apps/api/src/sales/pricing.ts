import { BadRequestException, ForbiddenException, Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import type { z } from 'zod';
import type { billDiscountSchema, saleLineSchema } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { hasPermission } from '../common/branch';
import { dec, Decimal, money2, parseDateOnly, price4, qty3, sumDec, todayIn, type Dec, type TenantInfo } from '../common/core';
import type { AuthContext } from '../common/request-context';
import { StockService, type Allocation } from '../inventory/stock.service';

export type SaleLineInput = z.infer<typeof saleLineSchema>;
export type BillDiscount = z.infer<typeof billDiscountSchema>;

/** quote = preview (no locks, problems become warnings); hold = no stock; commit = locks stock, problems are errors. */
export type PricingMode = 'quote' | 'hold' | 'commit';

export interface PricedLine {
  index: number;
  input: SaleLineInput;
  product: { id: string; brandName: string; strength: string | null; sku: string; baseUnit: string; requiresPrescription: boolean; isControlled: boolean };
  unit: { id: string; name: string; factor: Dec } | null;
  quantity: Dec;
  baseQuantity: Dec;
  unitPrice: Dec;
  gross: Dec;
  lineDiscount: Dec;
  billDiscount: Dec;
  discount: Dec;
  taxPercent: Dec;
  taxInclusive: boolean;
  tax: Dec;
  lineTotal: Dec;
  cost: Dec;
  allocations: (Allocation & { locationId: string })[];
  shortfall: Dec;
}

export interface Priced {
  locationId: string;
  lines: PricedLine[];
  subtotal: Dec;
  discountTotal: Dec;
  taxTotal: Dec;
  roundingAdjustment: Dec;
  grandTotal: Dec;
  costTotal: Dec;
  needsPrescription: boolean;
  prescription: { id: string; customerId: string } | null;
  rxOverride: boolean;
  maxDiscountPercent: number;
  warnings: string[];
}

const PRODUCT_SELECT = {
  id: true, brandName: true, strength: true, sku: true, baseUnit: true, sellingPrice: true, isActive: true, deletedAt: true,
  requiresPrescription: true, isControlled: true,
  taxRate: { select: { ratePercent: true, isInclusive: true, isActive: true } },
  productUnits: { select: { id: true, name: true, factorToBase: true, sellingPrice: true } },
} satisfies Prisma.ProductSelect;

@Injectable()
export class PricingService {
  constructor(private readonly stock: StockService) {}

  /** Highest discount % this user may give in the branch without sale:discount:override. */
  async maxDiscountPercent(tx: Prisma.TransactionClient, auth: AuthContext, branchId: string): Promise<number> {
    if (auth.isOwner) return 100;
    const roles = await tx.userBranchRole.findMany({ where: { userId: auth.userId, branchId }, select: { role: { select: { maxDiscountPercent: true } } } });
    return roles.reduce((m, r) => Math.max(m, Number(r.role.maxDiscountPercent)), 0);
  }

  async price(
    tx: Prisma.TransactionClient,
    ctx: { auth: AuthContext; branchId: string; tenant: TenantInfo; mode: PricingMode },
    input: { items: SaleLineInput[]; billDiscount?: BillDiscount; locationId?: string; customerId?: string; prescriptionId?: string; rxOverride?: boolean },
  ): Promise<Priced> {
    const { auth, branchId, tenant, mode } = ctx;
    const warnings: string[] = [];
    const problem = (msg: string, kind: 'unprocessable' | 'forbidden' = 'unprocessable') => {
      if (mode === 'quote') warnings.push(msg);
      else if (kind === 'forbidden') throw new ForbiddenException(msg);
      else throw new UnprocessableEntityException(msg);
    };

    const location = input.locationId ? await this.stock.assertLocation(tx, branchId, input.locationId) : await this.stock.defaultLocation(tx, branchId);

    // ---- products, units, branch prices --------------------------------------------------
    const ids = [...new Set(input.items.map((i) => i.productId))];
    const products = await tx.product.findMany({ where: { id: { in: ids } }, select: PRODUCT_SELECT });
    const byId = new Map(products.map((p) => [p.id, p]));
    const branchSettings = await tx.branchProductSetting.findMany({ where: { branchId, productId: { in: ids } } });
    const bps = new Map(branchSettings.map((b) => [b.productId, b]));
    for (const id of ids) {
      const p = byId.get(id);
      if (!p || p.deletedAt) throw new NotFoundException('A product on the bill no longer exists');
      if (!p.isActive) throw new UnprocessableEntityException(`${p.brandName} is inactive and cannot be sold`);
      if (bps.get(id)?.isAvailable === false) throw new UnprocessableEntityException(`${p.brandName} is not sold in this branch`);
    }

    const canOverrideBatch = hasPermission(auth, 'sale:batch:override', branchId);
    const reserved = new Map<string, Dec>();
    const allocated = new Map<number, { allocations: (Allocation & { locationId: string })[]; shortfall: Dec }>();

    const prepared = input.items.map((item, index) => {
      const p = byId.get(item.productId)!;
      let unit: PricedLine['unit'] = null;
      if (item.productUnitId) {
        const u = p.productUnits.find((x) => x.id === item.productUnitId);
        if (!u) throw new BadRequestException(`That unit does not belong to ${p.brandName}`);
        unit = { id: u.id, name: u.name, factor: dec(u.factorToBase) };
      }
      const quantity = qty3(item.quantity);
      const baseQuantity = qty3(quantity.times(unit?.factor ?? 1));
      if (baseQuantity.lte(0)) throw new BadRequestException('Quantity must be positive');
      return { item, index, p, unit, quantity, baseQuantity };
    });

    // ---- stock allocation (FEFO), in product order so concurrent sales lock rows consistently ----
    if (mode !== 'hold') {
      const order = [...prepared].sort((a, b) => (a.p.id < b.p.id ? -1 : a.p.id > b.p.id ? 1 : a.index - b.index));
      for (const l of order) {
        if (l.item.batchId) {
          if (!canOverrideBatch) problem(`Choosing a batch for ${l.p.brandName} needs sale:batch:override`, 'forbidden');
          try {
            const a = await this.stock.allocateBatch(tx, {
              locationId: location.id, productId: l.p.id, batchId: l.item.batchId, quantity: l.baseQuantity, timezone: tenant.timezone,
              minDaysToExpiry: tenant.settings.minDaysToExpiryForSale, reserved,
            });
            reserved.set(a.batchId, (reserved.get(a.batchId) ?? dec(0)).plus(a.quantity));
            allocated.set(l.index, { allocations: [{ ...a, locationId: location.id }], shortfall: dec(0) });
          } catch (e) {
            if (mode !== 'quote') throw e;
            warnings.push(e instanceof Error ? e.message : String(e));
            allocated.set(l.index, { allocations: [], shortfall: l.baseQuantity });
          }
          continue;
        }
        const { allocations, shortfall } = await this.stock.allocateFefo(tx, {
          locationId: location.id, productId: l.p.id, quantity: l.baseQuantity, timezone: tenant.timezone,
          minDaysToExpiry: tenant.settings.minDaysToExpiryForSale, lock: mode === 'commit', reserved,
        });
        for (const a of allocations) reserved.set(a.batchId, (reserved.get(a.batchId) ?? dec(0)).plus(a.quantity));
        if (shortfall.gt(0)) {
          const have = l.baseQuantity.minus(shortfall);
          problem(`Not enough sellable stock of ${l.p.brandName}: ${have.toString()} ${l.p.baseUnit} available, ${l.baseQuantity.toString()} needed`);
        }
        allocated.set(l.index, { allocations: allocations.map((a) => ({ ...a, locationId: location.id })), shortfall });
      }
    }

    // ---- prices and line discounts ------------------------------------------------------------
    const lines: PricedLine[] = prepared.map((l) => {
      const fallback = dec(bps.get(l.p.id)?.sellingPrice ?? l.p.sellingPrice);
      const al = allocated.get(l.index) ?? { allocations: [], shortfall: dec(0) };
      const explicitUnitPrice = l.unit ? l.p.productUnits.find((u) => u.id === l.unit!.id)?.sellingPrice ?? null : null;
      let gross: Dec;
      if (explicitUnitPrice !== null) {
        gross = money2(l.quantity.times(explicitUnitPrice));
      } else {
        // per base unit: batch price (e.g. MRP printed on that batch) else branch price else product price
        const priced = al.allocations.reduce((acc, a) => acc.plus(a.quantity.times(a.sellingPrice ?? fallback)), dec(0));
        const unpriced = l.baseQuantity.minus(sumDec(al.allocations.map((a) => a.quantity)));
        gross = money2(priced.plus(Decimal.max(unpriced, 0).times(fallback)));
      }
      let lineDiscount = dec(0);
      if (l.item.discountPercent !== undefined) lineDiscount = money2(gross.times(l.item.discountPercent).div(100));
      if (l.item.discountAmount !== undefined) lineDiscount = money2(l.item.discountAmount);
      if (lineDiscount.gt(gross)) throw new BadRequestException(`The discount on ${l.p.brandName} is larger than the line amount`);
      const tax = l.p.taxRate && l.p.taxRate.isActive ? l.p.taxRate : null;
      return {
        index: l.index, input: l.item,
        product: { id: l.p.id, brandName: l.p.brandName, strength: l.p.strength, sku: l.p.sku, baseUnit: l.p.baseUnit, requiresPrescription: l.p.requiresPrescription, isControlled: l.p.isControlled },
        unit: l.unit, quantity: l.quantity, baseQuantity: l.baseQuantity,
        unitPrice: price4(gross.div(l.quantity)), gross, lineDiscount, billDiscount: dec(0), discount: lineDiscount,
        taxPercent: dec(tax?.ratePercent ?? 0), taxInclusive: tax?.isInclusive ?? false, tax: dec(0), lineTotal: dec(0),
        cost: money2(al.allocations.reduce((acc, a) => acc.plus(a.quantity.times(a.unitCost)), dec(0))),
        allocations: al.allocations, shortfall: al.shortfall,
      };
    });

    // ---- bill discount, spread over lines in proportion to their net amount -------------------
    const afterLine = lines.map((l) => l.gross.minus(l.lineDiscount));
    const base = sumDec(afterLine);
    let bill = dec(0);
    if (input.billDiscount && input.billDiscount.value > 0) {
      bill = input.billDiscount.type === 'PERCENT'
        ? money2(base.times(Math.min(input.billDiscount.value, 100)).div(100))
        : money2(input.billDiscount.value);
      if (bill.gt(base)) throw new BadRequestException('The bill discount is larger than the bill');
    }
    if (bill.gt(0)) {
      let left = bill;
      const last = afterLine.map((v, i) => (v.gt(0) ? i : -1)).filter((i) => i >= 0).pop() ?? -1;
      lines.forEach((l, i) => {
        if (afterLine[i].lte(0)) return;
        const share = i === last ? left : money2(bill.times(afterLine[i]).div(base));
        l.billDiscount = Decimal.min(share, afterLine[i]);
        left = left.minus(l.billDiscount);
      });
    }

    // ---- discount authority -------------------------------------------------------------------
    const maxPct = await this.maxDiscountPercent(tx, auth, branchId);
    const anyDiscount = lines.some((l) => l.lineDiscount.gt(0)) || bill.gt(0);
    if (anyDiscount && !hasPermission(auth, 'sale:discount', branchId)) problem('Giving discounts needs sale:discount', 'forbidden');
    for (const l of lines) {
      l.discount = l.lineDiscount.plus(l.billDiscount);
      if (l.gross.gt(0) && l.discount.gt(0)) {
        const pct = l.discount.div(l.gross).times(100);
        if (pct.gt(maxPct) && !hasPermission(auth, 'sale:discount:override', branchId)) {
          problem(`The ${pct.toFixed(1)}% discount on ${l.product.brandName} is above your ${maxPct}% limit (needs sale:discount:override)`, 'forbidden');
        }
      }
    }

    // ---- tax ----------------------------------------------------------------------------------
    for (const l of lines) {
      const net = l.gross.minus(l.discount);
      if (l.taxPercent.gt(0)) {
        l.tax = l.taxInclusive ? money2(net.times(l.taxPercent).div(l.taxPercent.plus(100))) : money2(net.times(l.taxPercent).div(100));
        l.lineTotal = l.taxInclusive ? net : net.plus(l.tax);
      } else {
        l.lineTotal = net;
      }
    }

    // ---- totals and cash rounding -------------------------------------------------------------
    const raw = sumDec(lines.map((l) => l.lineTotal));
    const step = tenant.settings.cashRoundingStep;
    const grand = step > 0 ? money2(raw.div(step).toDecimalPlaces(0, Decimal.ROUND_HALF_UP).times(step)) : raw;

    // ---- prescription rule ----------------------------------------------------------------------
    const needsPrescription = lines.some((l) => l.product.requiresPrescription);
    let prescription: Priced['prescription'] = null;
    let rxOverride = false;
    if (input.prescriptionId) {
      const rx = await tx.prescription.findFirst({
        where: { id: input.prescriptionId, deletedAt: null },
        select: { id: true, customerId: true, status: true, validUntil: true, prescriptionItems: { select: { id: true } } },
      });
      if (!rx) throw new NotFoundException('Prescription not found');
      if (input.customerId && rx.customerId !== input.customerId) throw new BadRequestException('The prescription belongs to another customer');
      if (!['ACTIVE', 'PARTIALLY_DISPENSED'].includes(rx.status)) problem(`The prescription is ${rx.status.toLowerCase().replace('_', ' ')}`);
      if (rx.validUntil && rx.validUntil < parseDateOnly(todayIn(tenant.timezone))) problem('The prescription has expired');
      for (const l of lines) {
        if (l.input.prescriptionItemId && !rx.prescriptionItems.some((i) => i.id === l.input.prescriptionItemId)) {
          throw new BadRequestException('A line points to an item of a different prescription');
        }
      }
      prescription = { id: rx.id, customerId: rx.customerId };
    } else if (needsPrescription) {
      const rxNames = lines.filter((l) => l.product.requiresPrescription).map((l) => l.product.brandName).join(', ');
      if (tenant.settings.allowRxWithoutRecord) {
        warnings.push(`Prescription items (${rxNames}) sold without a recorded prescription (allowed by settings)`);
      } else if (input.rxOverride && hasPermission(auth, 'prescription:manage', branchId)) {
        rxOverride = true;
        warnings.push(`Pharmacist confirmed a prescription for ${rxNames}`);
      } else {
        problem(`A prescription is required for ${rxNames}. Attach the customer's prescription, or ask a pharmacist to confirm it.`);
      }
    }

    return {
      locationId: location.id,
      lines,
      subtotal: sumDec(lines.map((l) => l.gross)),
      discountTotal: sumDec(lines.map((l) => l.discount)),
      taxTotal: sumDec(lines.map((l) => l.tax)),
      roundingAdjustment: grand.minus(raw),
      grandTotal: grand,
      costTotal: sumDec(lines.map((l) => l.cost)),
      needsPrescription,
      prescription,
      rxOverride,
      maxDiscountPercent: maxPct,
      warnings,
    };
  }
}

/** JSON-friendly view of a priced bill (for /sales/quote and the POS screen). */
export function quoteView(p: Priced) {
  return {
    locationId: p.locationId,
    lines: p.lines.map((l) => ({
      index: l.index,
      productId: l.product.id,
      name: l.product.brandName,
      strength: l.product.strength,
      sku: l.product.sku,
      baseUnit: l.product.baseUnit,
      requiresPrescription: l.product.requiresPrescription,
      unit: l.unit ? { id: l.unit.id, name: l.unit.name, factor: l.unit.factor.toString() } : null,
      quantity: l.quantity.toString(),
      baseQuantity: l.baseQuantity.toString(),
      unitPrice: l.unitPrice.toFixed(2),
      gross: l.gross.toFixed(2),
      discount: l.discount.toFixed(2),
      taxPercent: l.taxPercent.toString(),
      taxInclusive: l.taxInclusive,
      tax: l.tax.toFixed(2),
      lineTotal: l.lineTotal.toFixed(2),
      shortfall: l.shortfall.toString(),
      allocations: l.allocations.map((a) => ({ batchId: a.batchId, batchNumber: a.batchNumber, expiryDate: a.expiryDate, quantity: a.quantity.toString() })),
    })),
    subtotal: p.subtotal.toFixed(2),
    discountTotal: p.discountTotal.toFixed(2),
    taxTotal: p.taxTotal.toFixed(2),
    roundingAdjustment: p.roundingAdjustment.toFixed(2),
    grandTotal: p.grandTotal.toFixed(2),
    needsPrescription: p.needsPrescription,
    maxDiscountPercent: p.maxDiscountPercent,
    warnings: p.warnings,
  };
}
