'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function FinanceLayout({ children }: { children: ReactNode }) {
  const { can, canAny } = useAuth();
  if (!canAny('finance:read', 'register:read', 'expense:read', 'tenant:settings:manage')) return <Forbidden what="finance" />;
  const items = [
    can('finance:read') && { href: '/finance', label: 'Profit & loss', exact: true },
    can('register:read') && { href: '/finance/shifts', label: 'Shifts & cash' },
    can('expense:read') && { href: '/finance/expenses', label: 'Expenses' },
    can('tenant:settings:manage') && { href: '/finance/settings', label: 'Settings' },
  ].filter(Boolean) as { href: string; label: string; exact?: boolean }[];
  return (
    <div>
      <SubNav items={items} />
      {children}
    </div>
  );
}
