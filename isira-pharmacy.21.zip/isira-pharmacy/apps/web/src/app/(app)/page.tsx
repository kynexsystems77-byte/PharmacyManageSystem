'use client';

import { useQuery } from '@tanstack/react-query';
import {
  AlertTriangle, Banknote, CalendarClock, PackageX, PauseCircle, Receipt, TrendingDown, TrendingUp, Wallet,
} from 'lucide-react';
import { SalesBars } from '@/components/bar-chart';
import { Alert, Badge, Card, CardHeader, EmptyState, Skeleton, StatTile } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateTime, money, pctChange, qty } from '@/lib/format';
import type { Dashboard } from '@/lib/types';

const STATUS_TONE: Record<string, 'success' | 'warning' | 'danger' | 'neutral'> = {
  COMPLETED: 'success', PARTIALLY_RETURNED: 'warning', RETURNED: 'neutral', VOIDED: 'danger',
};

function Delta({ current, previous }: { current: number; previous: number }) {
  const pct = pctChange(current, previous);
  if (pct === null) return <span>New activity today</span>;
  const up = pct >= 0;
  const Icon = up ? TrendingUp : TrendingDown;
  return (
    <span className={`inline-flex items-center gap-1 ${up ? 'text-success' : 'text-danger'}`}>
      <Icon size={14} /> {Math.abs(pct).toFixed(0)}% vs yesterday
    </span>
  );
}

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

export default function DashboardPage() {
  const { profile, branch, branchId } = useAuth();

  const { data, error, isLoading } = useQuery({
    queryKey: ['dashboard', branchId],
    queryFn: () => api<Dashboard>('/dashboard', { branchId }),
    enabled: Boolean(branchId),
    refetchInterval: 30_000, // near-live until WebSocket push arrives in a later phase
  });

  if (!branch) {
    return <Alert>Your account is not assigned to any branch yet. Ask your administrator to assign you one.</Alert>;
  }

  const cur = data?.currencyCode ?? profile.tenant.currencyCode;
  const fmt = (v: number) => money(v, cur);
  const firstName = profile.user.fullName.split(' ')[0];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">{greeting()}, {firstName}</h1>
        <p className="text-sm text-fg-muted">
          {branch.name} {data && <>· updated {dateTime(data.generatedAt, data.timezone)}</>}
        </p>
      </div>

      {error && <Alert>{error instanceof ApiError ? error.message : 'Could not load the dashboard.'}</Alert>}

      {isLoading && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
      )}

      {data?.sales && (
        <section aria-label="Sales" className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatTile
              label="Sales today"
              value={fmt(data.sales.today.total)}
              icon={<Banknote size={18} />}
              hint={<Delta current={data.sales.today.total} previous={data.sales.yesterday.total} />}
            />
            <StatTile
              label="Invoices today"
              value={String(data.sales.today.count)}
              icon={<Receipt size={18} />}
              hint={data.sales.today.count > 0 ? `Average ${fmt(data.sales.today.average)}` : 'No invoices yet'}
            />
            {data.sales.profitToday !== null && (
              <StatTile label="Gross profit today" value={fmt(data.sales.profitToday)} icon={<Wallet size={18} />} tone="success" hint="Sales minus cost of goods sold" />
            )}
            <StatTile
              label="Held bills"
              value={String(data.sales.heldBills)}
              icon={<PauseCircle size={18} />}
              tone={data.sales.heldBills > 0 ? 'warning' : 'neutral'}
              hint="Waiting to be resumed at the POS"
            />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader title="Sales, last 7 days" />
              <div className="p-4">
                <SalesBars data={data.sales.last7Days} format={fmt} />
              </div>
            </Card>
            <Card>
              <CardHeader title="Top products (7 days)" />
              {data.sales.topProducts.length === 0 ? (
                <EmptyState title="No sales yet" hint="Best sellers appear here once the POS is in use." />
              ) : (
                <ul className="divide-y divide-line">
                  {data.sales.topProducts.map((p, i) => (
                    <li key={p.productId} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                      <span className="w-4 text-fg-muted">{i + 1}</span>
                      <span className="min-w-0 flex-1 truncate">{p.name}</span>
                      <span className="tabular text-fg-muted">{qty(p.quantity)}</span>
                      <span className="tabular w-24 text-right font-medium">{fmt(p.revenue)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </section>
      )}

      {data?.inventory && (
        <section aria-label="Inventory" className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatTile label="Low stock items" value={String(data.inventory.lowStockCount)} icon={<AlertTriangle size={18} />} tone={data.inventory.lowStockCount > 0 ? 'warning' : 'neutral'} hint="At or below reorder level" />
            <StatTile label="Expiring in 30 days" value={String(data.inventory.expiringSoonCount)} icon={<CalendarClock size={18} />} tone={data.inventory.expiringSoonCount > 0 ? 'warning' : 'neutral'} hint="Batches with stock on hand" />
            <StatTile label="Expired batches" value={String(data.inventory.expiredCount)} icon={<PackageX size={18} />} tone={data.inventory.expiredCount > 0 ? 'danger' : 'neutral'} hint="Cannot be sold. Write off when ready." />
            {data.inventory.stockValue !== null && (
              <StatTile label="Stock value (at cost)" value={fmt(data.inventory.stockValue)} icon={<Wallet size={18} />} hint="Quantity x batch cost" />
            )}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader title="Needs reordering" />
              {data.inventory.lowStock.length === 0 ? (
                <EmptyState title="Stock levels look healthy" />
              ) : (
                <ul className="divide-y divide-line">
                  {data.inventory.lowStock.map((p) => (
                    <li key={p.productId} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium">{p.name}</p>
                        <p className="text-xs text-fg-muted">{p.sku}</p>
                      </div>
                      <Badge tone={p.quantity <= 0 ? 'danger' : 'warning'}>{qty(p.quantity)} left</Badge>
                      <span className="tabular w-20 text-right text-xs text-fg-muted">min {qty(p.reorderLevel)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            <Card>
              <CardHeader title="Expiry watch" />
              {data.inventory.expiring.length === 0 ? (
                <EmptyState title="Nothing expires in the next 30 days" />
              ) : (
                <ul className="divide-y divide-line">
                  {data.inventory.expiring.map((b) => (
                    <li key={b.batchId} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium">{b.name}</p>
                        <p className="text-xs text-fg-muted">Batch {b.batchNumber} · {qty(b.quantity)} in stock · {b.expiryDate}</p>
                      </div>
                      <Badge tone={b.daysLeft < 0 ? 'danger' : 'warning'}>
                        {b.daysLeft < 0 ? `Expired ${Math.abs(b.daysLeft)}d ago` : b.daysLeft === 0 ? 'Expires today' : `${b.daysLeft}d left`}
                      </Badge>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </section>
      )}

      {data?.sales && (
        <Card>
          <CardHeader title="Recent invoices" />
          {data.sales.recent.length === 0 ? (
            <EmptyState title="No invoices yet" hint="Completed sales will be listed here (POS arrives in Phase 7)." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-fg-muted">
                    <th className="px-4 py-2 font-medium">Invoice</th>
                    <th className="px-4 py-2 font-medium">When</th>
                    <th className="px-4 py-2 font-medium">Customer</th>
                    <th className="px-4 py-2 font-medium">Cashier</th>
                    <th className="px-4 py-2 text-right font-medium">Total</th>
                    <th className="px-4 py-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {data.sales.recent.map((s) => (
                    <tr key={s.id}>
                      <td className="px-4 py-2.5 font-medium">{s.invoiceNo ?? '-'}</td>
                      <td className="px-4 py-2.5 text-fg-muted">{dateTime(s.soldAt, data.timezone)}</td>
                      <td className="px-4 py-2.5">{s.customer ?? 'Walk-in'}</td>
                      <td className="px-4 py-2.5">{s.cashier}</td>
                      <td className="tabular px-4 py-2.5 text-right font-medium">{fmt(s.total)}</td>
                      <td className="px-4 py-2.5"><Badge tone={STATUS_TONE[s.status] ?? 'neutral'}>{s.status.replace('_', ' ').toLowerCase()}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {data && !data.sales && !data.inventory && (
        <Card><EmptyState title="Nothing to show here yet" hint="Your role does not include sales or inventory views for this branch." /></Card>
      )}
    </div>
  );
}
