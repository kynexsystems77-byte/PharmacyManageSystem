import {
  BadRequestException, Body, ConflictException, Controller, Delete, Get, Headers, HttpCode, Module, NotFoundException,
  Param, ParseUUIDPipe, Patch, Post, Put, Query,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { z } from 'zod';
import {
  branchProductSettingSchema, createCategorySchema, createManufacturerSchema, createProductSchema, createTaxRateSchema,
  listProductsQuerySchema, paginationSchema, productUnitSchema, queryBoolSchema, updateCategorySchema, updateManufacturerSchema,
  updateProductSchema, updateTaxRateSchema,
} from '@kynex/contracts';
import { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId, optionalBranchId, requirePermission } from '../common/branch';
import { dec, SequenceService, TenantInfoService } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { InventoryCoreModule } from '../inventory/inventory-core.module';
import { StockService } from '../inventory/stock.service';
import { TenantDb } from '../prisma/prisma.service';

class CreateCategoryDto extends createZodDto(createCategorySchema) {}
class UpdateCategoryDto extends createZodDto(updateCategorySchema) {}
class CreateManufacturerDto extends createZodDto(createManufacturerSchema) {}
class UpdateManufacturerDto extends createZodDto(updateManufacturerSchema) {}
class CreateTaxRateDto extends createZodDto(createTaxRateSchema) {}
class UpdateTaxRateDto extends createZodDto(updateTaxRateSchema) {}
class CreateProductDto extends createZodDto(createProductSchema) {}
class UpdateProductDto extends createZodDto(updateProductSchema) {}
class ListProductsQueryDto extends createZodDto(listProductsQuerySchema) {}
class BranchProductSettingDto extends createZodDto(branchProductSettingSchema) {}
class SimpleListQueryDto extends createZodDto(paginationSchema.extend({ includeInactive: queryBoolSchema.optional() })) {}

type UnitInput = z.infer<typeof productUnitSchema>;

/** Null-aware decimal equality (undefined counts as "no value"). */
function sameDec(a: Prisma.Decimal.Value | null | undefined, b: Prisma.Decimal.Value | null | undefined): boolean {
  const an = a === undefined || a === null, bn = b === undefined || b === null;
  if (an || bn) return an && bn;
  return dec(a).equals(dec(b));
}

// =============================================================================================
// Categories
// =============================================================================================
@ApiTags('Catalogue')
@ApiCookieAuth()
@Controller('categories')
export class CategoriesController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService) {}

  /** Flat list (with parentId) plus product counts; the web app builds the tree. */
  @Get()
  @RequirePermissions('product:read')
  async list(@Query('includeInactive') includeInactive?: string) {
    const rows = await this.db.tx.category.findMany({
      where: { deletedAt: null, ...(includeInactive === 'true' ? {} : { isActive: true }) },
      orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
      select: {
        id: true, name: true, parentId: true, sortOrder: true, isActive: true,
        _count: { select: { products: { where: { deletedAt: null } } } },
      },
    });
    return rows.map(({ _count, ...c }) => ({ ...c, productCount: _count.products }));
  }

  private async assertParent(tx: Prisma.TransactionClient, parentId: string | null | undefined, selfId?: string) {
    if (!parentId) return;
    if (parentId === selfId) throw new BadRequestException('A category cannot be its own parent');
    const parent = await tx.category.findFirst({ where: { id: parentId, deletedAt: null }, select: { id: true, parentId: true } });
    if (!parent) throw new BadRequestException('Parent category not found');
    // prevent cycles: walk up from the new parent
    let cursor: string | null = parent.parentId;
    for (let depth = 0; cursor && depth < 20; depth++) {
      if (cursor === selfId) throw new BadRequestException('That would create a category loop');
      const next: { parentId: string | null } | null = await tx.category.findFirst({ where: { id: cursor }, select: { parentId: true } });
      cursor = next?.parentId ?? null;
    }
  }

  @Post()
  @RequirePermissions('category:manage')
  async create(@Body() dto: CreateCategoryDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    await this.assertParent(tx, dto.parentId);
    const dupe = await tx.category.findFirst({ where: { name: { equals: dto.name, mode: 'insensitive' }, parentId: dto.parentId ?? null, deletedAt: null } });
    if (dupe) throw new ConflictException('A category with this name already exists here');
    const category = await tx.category.create({ data: { tenantId: auth.tenantId, name: dto.name, parentId: dto.parentId ?? null, sortOrder: dto.sortOrder } });
    await this.audit.record({ action: 'category.created', entityType: 'category', entityId: category.id, after: category });
    return category;
  }

  @Patch(':id')
  @RequirePermissions('category:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateCategoryDto) {
    const tx = this.db.tx;
    const before = await tx.category.findFirst({ where: { id, deletedAt: null } });
    if (!before) throw new NotFoundException('Category not found');
    if (dto.parentId !== undefined) await this.assertParent(tx, dto.parentId, id);
    const after = await tx.category.update({ where: { id }, data: dto });
    await this.audit.record({ action: 'category.updated', entityType: 'category', entityId: id, before, after });
    return after;
  }

  /** Soft delete. Refused while the category still has products or sub-categories. */
  @Delete(':id')
  @HttpCode(204)
  @RequirePermissions('category:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.category.findFirst({ where: { id, deletedAt: null } });
    if (!before) throw new NotFoundException('Category not found');
    if (await tx.category.count({ where: { parentId: id, deletedAt: null } })) {
      throw new ConflictException('Move or delete the sub-categories first');
    }
    if (await tx.product.count({ where: { categoryId: id, deletedAt: null } })) {
      throw new ConflictException('Move the products to another category first');
    }
    await tx.category.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
    await this.audit.record({ action: 'category.deleted', entityType: 'category', entityId: id, before });
  }
}

// =============================================================================================
// Manufacturers and tax rates (small reference lists)
// =============================================================================================
@ApiTags('Catalogue')
@ApiCookieAuth()
@Controller('manufacturers')
export class ManufacturersController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService) {}

  @Get()
  @RequirePermissions('product:read')
  async list(@Query() q: SimpleListQueryDto) {
    const where: Prisma.ManufacturerWhereInput = {
      ...(q.includeInactive ? {} : { isActive: true }),
      ...(q.search ? { name: { contains: q.search, mode: 'insensitive' } } : {}),
    };
    const [rows, total] = await Promise.all([
      this.db.tx.manufacturer.findMany({ where, orderBy: { name: 'asc' }, ...skipTake(q.page, q.pageSize) }),
      this.db.tx.manufacturer.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Post()
  @RequirePermissions('product:create')
  async create(@Body() dto: CreateManufacturerDto, @CurrentAuth() auth: AuthContext) {
    const m = await this.db.tx.manufacturer.create({ data: { tenantId: auth.tenantId, ...dto } });
    await this.audit.record({ action: 'manufacturer.created', entityType: 'manufacturer', entityId: m.id, after: m });
    return m;
  }

  @Patch(':id')
  @RequirePermissions('product:update')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateManufacturerDto) {
    const before = await this.db.tx.manufacturer.findFirst({ where: { id } });
    if (!before) throw new NotFoundException('Manufacturer not found');
    const after = await this.db.tx.manufacturer.update({ where: { id }, data: dto });
    await this.audit.record({ action: 'manufacturer.updated', entityType: 'manufacturer', entityId: id, before, after });
    return after;
  }
}

@ApiTags('Catalogue')
@ApiCookieAuth()
@Controller('tax-rates')
export class TaxRatesController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService) {}

  @Get()
  @RequirePermissions('product:read')
  list(@Query('includeInactive') includeInactive?: string) {
    return this.db.tx.taxRate.findMany({ where: includeInactive === 'true' ? {} : { isActive: true }, orderBy: { name: 'asc' } });
  }

  @Post()
  @RequirePermissions('tenant:settings:manage')
  async create(@Body() dto: CreateTaxRateDto, @CurrentAuth() auth: AuthContext) {
    const t = await this.db.tx.taxRate.create({ data: { tenantId: auth.tenantId, name: dto.name, ratePercent: dec(dto.ratePercent), isInclusive: dto.isInclusive } });
    await this.audit.record({ action: 'tax_rate.created', entityType: 'tax_rate', entityId: t.id, after: t });
    return t;
  }

  @Patch(':id')
  @RequirePermissions('tenant:settings:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateTaxRateDto) {
    const before = await this.db.tx.taxRate.findFirst({ where: { id } });
    if (!before) throw new NotFoundException('Tax rate not found');
    const after = await this.db.tx.taxRate.update({
      where: { id },
      data: { ...dto, ratePercent: dto.ratePercent === undefined ? undefined : dec(dto.ratePercent) },
    });
    await this.audit.record({ action: 'tax_rate.updated', entityType: 'tax_rate', entityId: id, before, after });
    return after;
  }
}

// =============================================================================================
// Products
// =============================================================================================
export const PRODUCT_SELECT = {
  id: true, sku: true, barcode: true, brandName: true, genericName: true, strength: true, dosageForm: true, baseUnit: true,
  requiresPrescription: true, isControlled: true, trackExpiry: true, purchasePrice: true, sellingPrice: true,
  wholesalePrice: true, reorderLevel: true, description: true, isActive: true, createdAt: true, updatedAt: true,
  categoryId: true, manufacturerId: true, preferredSupplierId: true, taxRateId: true,
  category: { select: { id: true, name: true, parentId: true } },
  manufacturer: { select: { id: true, name: true } },
  preferredSupplier: { select: { id: true, name: true } },
  taxRate: { select: { id: true, name: true, ratePercent: true, isInclusive: true } },
  productUnits: {
    select: { id: true, name: true, factorToBase: true, barcode: true, sellingPrice: true, isDefaultSaleUnit: true },
    orderBy: { factorToBase: 'asc' },
  },
} satisfies Prisma.ProductSelect;

@ApiTags('Catalogue')
@ApiCookieAuth()
@Controller('products')
export class ProductsController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly sequences: SequenceService,
    private readonly tenantInfo: TenantInfoService,
    private readonly stock: StockService,
  ) {}

  private async categoryIds(tx: Prisma.TransactionClient, rootId: string): Promise<string[]> {
    const all = await tx.category.findMany({ where: { deletedAt: null }, select: { id: true, parentId: true } });
    const ids = new Set([rootId]);
    let grew = true;
    while (grew) {
      grew = false;
      for (const c of all) {
        if (c.parentId && ids.has(c.parentId) && !ids.has(c.id)) {
          ids.add(c.id);
          grew = true;
        }
      }
    }
    return [...ids];
  }

  @Get()
  @RequirePermissions('product:read')
  async list(@Query() q: ListProductsQueryDto, @CurrentAuth() auth: AuthContext, @Headers('x-branch-id') branchHeader?: string) {
    const tx = this.db.tx;
    const where: Prisma.ProductWhereInput = { deletedAt: null };
    if (q.status === 'active') where.isActive = true;
    if (q.status === 'inactive') where.isActive = false;
    if (q.categoryId) where.categoryId = q.includeSubcategories ? { in: await this.categoryIds(tx, q.categoryId) } : q.categoryId;
    if (q.manufacturerId) where.manufacturerId = q.manufacturerId;
    if (q.supplierId) where.preferredSupplierId = q.supplierId;
    if (q.requiresPrescription !== undefined) where.requiresPrescription = q.requiresPrescription;
    if (q.search) {
      const s = q.search;
      where.OR = [
        { brandName: { contains: s, mode: 'insensitive' } },
        { genericName: { contains: s, mode: 'insensitive' } },
        { sku: { contains: s, mode: 'insensitive' } },
        { barcode: s },
        { productUnits: { some: { barcode: s } } },
      ];
    }
    const orderBy: Prisma.ProductOrderByWithRelationInput =
      q.sort === 'sku' ? { sku: 'asc' } : q.sort === 'created' ? { createdAt: 'desc' } : q.sort === 'price' ? { sellingPrice: 'asc' } : { brandName: 'asc' };
    const [rows, total] = await Promise.all([
      tx.product.findMany({ where, orderBy: [orderBy, { id: 'asc' }], select: PRODUCT_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.product.count({ where }),
    ]);

    const branchId = q.withStock ? optionalBranchId(auth, branchHeader) : null;
    if (!branchId) return paged(rows, total, q.page, q.pageSize);

    const { timezone } = await this.tenantInfo.get(tx);
    const ids = rows.map((r) => r.id);
    const sellable = await this.stock.sellableByProduct(tx, branchId, ids, timezone);
    const settings = await tx.branchProductSetting.findMany({ where: { branchId, productId: { in: ids } } });
    const byProduct = new Map(settings.map((s) => [s.productId, s]));
    return paged(
      rows.map((r) => {
        const bps = byProduct.get(r.id);
        return {
          ...r,
          stock: (sellable.get(r.id) ?? dec(0)).toString(),
          branchSellingPrice: bps?.sellingPrice ?? null,
          branchReorderLevel: bps?.reorderLevel ?? null,
          availableInBranch: bps?.isAvailable ?? true,
        };
      }),
      total,
      q.page,
      q.pageSize,
    );
  }

  /** Exact barcode match on a product or one of its units (scanner input at the POS / goods receipt). */
  @Get('barcode/:code')
  @RequirePermissions('product:read')
  async byBarcode(@Param('code') code: string) {
    const tx = this.db.tx;
    const c = code.trim();
    const product = await tx.product.findFirst({ where: { barcode: c, deletedAt: null }, select: PRODUCT_SELECT });
    if (product) return { product, unitId: null };
    const unit = await tx.productUnit.findFirst({ where: { barcode: c, product: { deletedAt: null } }, select: { id: true, productId: true } });
    if (!unit) throw new NotFoundException('No product has this barcode');
    const p = await tx.product.findFirstOrThrow({ where: { id: unit.productId }, select: PRODUCT_SELECT });
    return { product: p, unitId: unit.id };
  }

  @Get(':id')
  @RequirePermissions('product:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const p = await this.db.tx.product.findFirst({ where: { id, deletedAt: null }, select: PRODUCT_SELECT });
    if (!p) throw new NotFoundException('Product not found');
    return p;
  }

  /** Stock of one product in the selected branch, per location and batch. */
  @Get(':id/stock')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async productStock(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const product = await tx.product.findFirst({ where: { id, deletedAt: null }, select: { id: true, brandName: true, baseUnit: true, reorderLevel: true } });
    if (!product) throw new NotFoundException('Product not found');
    const { timezone, settings } = await this.tenantInfo.get(tx);
    const levels = await tx.stockLevel.findMany({
      where: { branchId, productId: id, quantity: { gt: 0 } },
      select: {
        quantity: true,
        location: { select: { id: true, name: true, type: true } },
        batch: { select: { id: true, batchNumber: true, expiryDate: true, unitCost: true, sellingPrice: true, status: true, receivedAt: true } },
      },
      orderBy: [{ batch: { expiryDate: 'asc' } }, { batch: { receivedAt: 'asc' } }],
    });
    const sellable = (await this.stock.sellableByProduct(tx, branchId, [id], timezone)).get(id) ?? dec(0);
    const total = levels.reduce((a, l) => a.plus(l.quantity), dec(0));
    return { product, timezone, expiryWarningDays: settings.expiryWarningDays, total: total.toString(), sellable: sellable.toString(), levels };
  }

  private validateUnits(units: UnitInput[]) {
    const names = new Set<string>();
    let defaults = 0;
    for (const u of units) {
      const key = u.name.toLowerCase();
      if (names.has(key)) throw new BadRequestException(`Duplicate unit name "${u.name}"`);
      names.add(key);
      if (u.isDefaultSaleUnit) defaults++;
    }
    if (defaults > 1) throw new BadRequestException('Only one unit can be the default sale unit');
  }

  private async assertBarcodesFree(tx: Prisma.TransactionClient, codes: (string | null | undefined)[], productId?: string) {
    const list = codes.filter((c): c is string => Boolean(c));
    if (new Set(list).size !== list.length) throw new BadRequestException('The same barcode is used twice');
    if (list.length === 0) return;
    const p = await tx.product.findFirst({
      where: { barcode: { in: list }, deletedAt: null, ...(productId ? { id: { not: productId } } : {}) },
      select: { brandName: true, barcode: true },
    });
    if (p) throw new ConflictException(`Barcode ${p.barcode} is already used by ${p.brandName}`);
    const u = await tx.productUnit.findFirst({
      where: { barcode: { in: list }, product: { deletedAt: null }, ...(productId ? { productId: { not: productId } } : {}) },
      select: { barcode: true, product: { select: { brandName: true } } },
    });
    if (u) throw new ConflictException(`Barcode ${u.barcode} is already used by ${u.product.brandName}`);
  }

  private async assertRefs(tx: Prisma.TransactionClient, dto: { categoryId?: string; manufacturerId?: string | null; preferredSupplierId?: string | null; taxRateId?: string | null }) {
    if (dto.categoryId && !(await tx.category.count({ where: { id: dto.categoryId, deletedAt: null } }))) throw new BadRequestException('Category not found');
    if (dto.manufacturerId && !(await tx.manufacturer.count({ where: { id: dto.manufacturerId } }))) throw new BadRequestException('Manufacturer not found');
    if (dto.preferredSupplierId && !(await tx.supplier.count({ where: { id: dto.preferredSupplierId, deletedAt: null } }))) throw new BadRequestException('Supplier not found');
    if (dto.taxRateId && !(await tx.taxRate.count({ where: { id: dto.taxRateId } }))) throw new BadRequestException('Tax rate not found');
  }

  @Post()
  @RequirePermissions('product:create')
  async create(@Body() dto: CreateProductDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    this.validateUnits(dto.units);
    await this.assertRefs(tx, dto);
    await this.assertBarcodesFree(tx, [dto.barcode, ...dto.units.map((u) => u.barcode)]);
    const sku = dto.sku ?? (await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'PRODUCT', scopeKey: 'tenant', prefix: 'SKU', yearless: true }));
    if (await tx.product.count({ where: { sku } })) throw new ConflictException(`SKU ${sku} is already used`);

    const { units, purchasePrice, sellingPrice, wholesalePrice, reorderLevel, ...rest } = dto;
    const product = await tx.product.create({
      data: {
        ...rest,
        tenantId: auth.tenantId,
        sku,
        barcode: dto.barcode ?? null,
        purchasePrice: dec(purchasePrice),
        sellingPrice: dec(sellingPrice),
        wholesalePrice: wholesalePrice === undefined || wholesalePrice === null ? null : dec(wholesalePrice),
        reorderLevel: dec(reorderLevel),
        productUnits: {
          create: units.map((u) => ({
            tenantId: auth.tenantId,
            name: u.name,
            factorToBase: dec(u.factorToBase),
            barcode: u.barcode ?? null,
            sellingPrice: u.sellingPrice === undefined || u.sellingPrice === null ? null : dec(u.sellingPrice),
            isDefaultSaleUnit: u.isDefaultSaleUnit,
          })),
        },
      },
      select: PRODUCT_SELECT,
    });
    await this.audit.record({ action: 'product.created', entityType: 'product', entityId: product.id, after: product });
    return product;
  }

  @Patch(':id')
  @RequirePermissions('product:update')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateProductDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await tx.product.findFirst({ where: { id, deletedAt: null }, select: PRODUCT_SELECT });
    if (!before) throw new NotFoundException('Product not found');

    const priceChanged =
      (dto.purchasePrice !== undefined && !dec(dto.purchasePrice).equals(before.purchasePrice)) ||
      (dto.sellingPrice !== undefined && !dec(dto.sellingPrice).equals(before.sellingPrice)) ||
      (dto.wholesalePrice !== undefined && !sameDec(dto.wholesalePrice, before.wholesalePrice)) ||
      (dto.units?.some((u) => !sameDec(u.sellingPrice, before.productUnits.find((x) => x.id === u.id)?.sellingPrice)) ?? false);
    if (priceChanged) requirePermission(auth, 'product:price:update');
    if (dto.isActive === false) requirePermission(auth, 'product:deactivate');

    await this.assertRefs(tx, dto);
    if (dto.sku && dto.sku !== before.sku && (await tx.product.count({ where: { sku: dto.sku } }))) {
      throw new ConflictException(`SKU ${dto.sku} is already used`);
    }
    if (dto.units) this.validateUnits(dto.units);
    await this.assertBarcodesFree(tx, [dto.barcode === undefined ? before.barcode : dto.barcode, ...(dto.units ?? before.productUnits).map((u) => u.barcode)], id);

    const { units, purchasePrice, sellingPrice, wholesalePrice, reorderLevel, ...rest } = dto;
    await tx.product.update({
      where: { id },
      data: {
        ...rest,
        purchasePrice: purchasePrice === undefined ? undefined : dec(purchasePrice),
        sellingPrice: sellingPrice === undefined ? undefined : dec(sellingPrice),
        wholesalePrice: wholesalePrice === undefined ? undefined : wholesalePrice === null ? null : dec(wholesalePrice),
        reorderLevel: reorderLevel === undefined ? undefined : dec(reorderLevel),
      },
    });

    if (units) {
      const keepIds = units.map((u) => u.id).filter((x): x is string => Boolean(x));
      for (const uid of keepIds) {
        if (!before.productUnits.some((u) => u.id === uid)) throw new BadRequestException('Unknown unit id');
      }
      const removed = before.productUnits.filter((u) => !keepIds.includes(u.id)).map((u) => u.id);
      if (removed.length) {
        if (await tx.saleItem.count({ where: { productUnitId: { in: removed } } })) {
          throw new ConflictException('A unit that has been used on invoices cannot be removed');
        }
        await tx.productUnit.deleteMany({ where: { id: { in: removed } } });
      }
      for (const u of units) {
        const data = {
          name: u.name,
          factorToBase: dec(u.factorToBase),
          barcode: u.barcode ?? null,
          sellingPrice: u.sellingPrice === undefined || u.sellingPrice === null ? null : dec(u.sellingPrice),
          isDefaultSaleUnit: u.isDefaultSaleUnit,
        };
        if (u.id) await tx.productUnit.update({ where: { id: u.id }, data });
        else await tx.productUnit.create({ data: { ...data, tenantId: auth.tenantId, productId: id } });
      }
    }

    const after = await tx.product.findFirstOrThrow({ where: { id }, select: PRODUCT_SELECT });
    await this.audit.record({ action: priceChanged ? 'product.price_changed' : 'product.updated', entityType: 'product', entityId: id, before, after });
    return after;
  }

  /** Soft delete: the product disappears from lists but history (invoices, ledger) keeps it. */
  @Delete(':id')
  @HttpCode(204)
  @RequirePermissions('product:deactivate')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.product.findFirst({ where: { id, deletedAt: null }, select: PRODUCT_SELECT });
    if (!before) throw new NotFoundException('Product not found');
    const onHand = await tx.stockLevel.aggregate({ where: { productId: id, quantity: { gt: 0 } }, _sum: { quantity: true } });
    if (onHand._sum.quantity && dec(onHand._sum.quantity).gt(0)) {
      throw new ConflictException('This product still has stock. Write it off or transfer it before deleting, or deactivate it instead.');
    }
    // free the barcodes so they can be reused by a new product
    await tx.product.update({ where: { id }, data: { deletedAt: new Date(), isActive: false, barcode: null } });
    await tx.productUnit.updateMany({ where: { productId: id }, data: { barcode: null } });
    await this.audit.record({ action: 'product.deleted', entityType: 'product', entityId: id, before });
  }

  @Get(':id/branch-settings')
  @BranchScoped()
  @RequirePermissions('product:read')
  async getBranchSettings(@Param('id', ParseUUIDPipe) id: string) {
    const s = await this.db.tx.branchProductSetting.findFirst({ where: { branchId: currentBranchId(), productId: id } });
    return s ?? { sellingPrice: null, reorderLevel: null, isAvailable: true };
  }

  @Put(':id/branch-settings')
  @BranchScoped()
  @RequirePermissions('product:price:update')
  async setBranchSettings(@Param('id', ParseUUIDPipe) id: string, @Body() dto: BranchProductSettingDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    if (!(await tx.product.count({ where: { id, deletedAt: null } }))) throw new NotFoundException('Product not found');
    const before = await tx.branchProductSetting.findFirst({ where: { branchId, productId: id } });
    const data = {
      sellingPrice: dto.sellingPrice === undefined ? undefined : dto.sellingPrice === null ? null : dec(dto.sellingPrice),
      reorderLevel: dto.reorderLevel === undefined ? undefined : dto.reorderLevel === null ? null : dec(dto.reorderLevel),
      isAvailable: dto.isAvailable,
    };
    const after = before
      ? await tx.branchProductSetting.update({ where: { id: before.id }, data })
      : await tx.branchProductSetting.create({ data: { tenantId: auth.tenantId, branchId, productId: id, ...data } });
    await this.audit.record({ action: 'product.branch_settings_changed', entityType: 'product', entityId: id, before, after });
    return after;
  }
}

@Module({
  imports: [InventoryCoreModule],
  controllers: [CategoriesController, ManufacturersController, TaxRatesController, ProductsController],
})
export class CatalogModule {}
