'use client';

import { useQueryClient } from '@tanstack/react-query';
import { FileText, Paperclip, Pencil, Trash2, XCircle } from 'lucide-react';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { ConfirmDialog, DataTable, KeyValue, PageHeader, useToast } from '@/components/kit';
import { PrescriptionForm, rxBody, rxFromPrescription } from '@/components/prescription-form';
import { Alert, Badge, Button, Card, CardHeader, Skeleton } from '@/components/ui';
import { uploadFile } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, qty, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import { RX_TONE } from '@/lib/status';
import type { Prescription } from '@/lib/types';

export default function PrescriptionPage({ params }: { params: { id: string } }) {
  const { can, profile, branchId } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const { data: p, isLoading, error } = useBranchQuery<Prescription>(`/prescriptions/${params.id}`);
  const [editing, setEditing] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const update = useApiMutation<object>('PATCH', `/prescriptions/${params.id}`, { onSuccess: () => { toast.success('Prescription saved'); setEditing(false); } });
  const cancel = useApiMutation<object>('POST', `/prescriptions/${params.id}/cancel`, { onSuccess: () => { toast.success('Prescription cancelled'); setConfirmCancel(false); } });
  const removeFile = useApiMutation<string>('DELETE', (id) => `/attachments/${id}`, { onSuccess: () => toast.success('File removed') });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !p) return <Alert>{errorMessage(error) || 'Prescription not found'}</Alert>;
  const manage = can('prescription:manage');
  const editable = manage && ['ACTIVE', 'PARTIALLY_DISPENSED'].includes(p.status);

  if (editing) {
    return (
      <div className="mx-auto max-w-5xl">
        <PageHeader title="Edit prescription" />
        <PrescriptionForm mode="update" initial={rxFromPrescription(p)} submitting={update.isPending} error={update.error} onSubmit={(d) => update.mutate(rxBody(d, 'update'))} onCancel={() => setEditing(false)} />
      </div>
    );
  }

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    setUploading(true);
    try {
      await uploadFile(`/prescriptions/${p.id}/attachments`, f, { branchId });
      await qc.invalidateQueries();
      toast.success('File attached');
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader
        back="/prescriptions"
        title={`Prescription · ${p.customer.fullName}`}
        subtitle={<span className="flex items-center gap-2"><Badge tone={RX_TONE[p.status]}>{titleCase(p.status)}</Badge>{p.prescriptionNumber && <span>No. {p.prescriptionNumber}</span>}</span>}
        actions={
          <>
            {editable && <Button variant="outline" onClick={() => setConfirmCancel(true)}><XCircle size={16} /> Cancel</Button>}
            {editable && <Button onClick={() => setEditing(true)}><Pencil size={16} /> Edit</Button>}
          </>
        }
      />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Patient', value: <Link className="text-brand hover:underline" href={`/customers/${p.customer.id}`}>{p.customer.fullName}</Link> },
          { label: 'Doctor', value: `${p.doctorName}${p.doctorRegistration ? ` (${p.doctorRegistration})` : ''}` },
          { label: 'Prescribed', value: dateOnly(p.prescribedDate) },
          { label: 'Valid until', value: dateOnly(p.validUntil) },
          { label: 'Recorded', value: `${dateTime(p.createdAt)} by ${p.createdBy.fullName}${p.branch ? ` at ${p.branch.name}` : ''}` },
          { label: 'Notes', value: p.notes },
        ]} />
        {p.dispensable && <p className="mt-3 text-xs text-fg-muted">To dispense: open the POS, choose {p.customer.fullName} as the customer and pick this prescription.</p>}
      </Card>
      <Card>
        <CardHeader title="Medicines" />
        <DataTable
          rows={p.prescriptionItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'm', header: 'Medicine', cell: (i) => <div><p className="font-medium">{i.product ? <Link className="hover:underline" href={`/medicines/${i.product.id}`}>{i.medicineName}</Link> : i.medicineName}</p>{i.instructions && <p className="text-xs text-fg-muted">{i.instructions}</p>}</div> },
            { key: 'd', header: 'Dosage', cell: (i) => [i.dosage, i.frequency, i.durationDays ? `${i.durationDays} days` : null].filter(Boolean).join(' · ') || '-' },
            { key: 'q', header: 'Prescribed', align: 'right', cell: (i) => (i.quantityPrescribed ? qty(num(i.quantityPrescribed)) : '-') },
            { key: 'x', header: 'Dispensed', align: 'right', cell: (i) => <span className={i.quantityPrescribed && num(i.quantityDispensed) >= num(i.quantityPrescribed) ? 'text-success' : ''}>{qty(num(i.quantityDispensed))}</span> },
          ]}
        />
      </Card>
      <Card>
        <CardHeader
          title="Scans and documents"
          action={manage && (
            <>
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
              <Button variant="outline" className="h-8 px-3" loading={uploading} onClick={() => fileRef.current?.click()}><Paperclip size={14} /> Attach file</Button>
            </>
          )}
        />
        {p.attachments?.length ? (
          <ul className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
            {p.attachments.map((a) => (
              <li key={a.id} className="overflow-hidden rounded-lg border border-line">
                <a href={`/api/attachments/${a.id}/download`} target="_blank" rel="noreferrer" className="block">
                  {a.mimeType.startsWith('image/') ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={`/api/attachments/${a.id}/download`} alt={a.fileName} className="h-36 w-full bg-subtle object-cover" />
                  ) : (
                    <div className="grid h-36 place-items-center bg-subtle text-fg-muted"><FileText size={36} /></div>
                  )}
                </a>
                <div className="flex items-center gap-2 px-2 py-1.5 text-xs">
                  <span className="min-w-0 flex-1 truncate" title={a.fileName}>{a.fileName}</span>
                  {manage && <button aria-label="Remove file" onClick={() => removeFile.mutate(a.id)} className="text-fg-muted hover:text-danger"><Trash2 size={14} /></button>}
                </div>
              </li>
            ))}
          </ul>
        ) : <p className="px-4 py-6 text-center text-sm text-fg-muted">No files. Attach a photo or PDF of the prescription (max 10 MB).</p>}
      </Card>
      {p.sales && p.sales.length > 0 && (
        <Card>
          <CardHeader title="Dispensed on" />
          <ul className="divide-y divide-line text-sm">
            {p.sales.map((s) => (
              <li key={s.id} className="flex justify-between px-4 py-2.5">
                <Link className="font-mono text-xs text-brand hover:underline" href={`/sales/${s.id}`}>{s.invoiceNo}</Link>
                <span className="text-fg-muted">{dateTime(s.soldAt)} · {s.branch.name}</span>
                <span className="tabular">{money(num(s.grandTotal), profile.tenant.currencyCode)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <ConfirmDialog open={confirmCancel} title="Cancel this prescription?" danger confirmLabel="Cancel prescription" loading={cancel.isPending} onClose={() => setConfirmCancel(false)} onConfirm={() => cancel.mutate({})} body={<p>It can no longer be used to dispense medicines.</p>} />
    </div>
  );
}
