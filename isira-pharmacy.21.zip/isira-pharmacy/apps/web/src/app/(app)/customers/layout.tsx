'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function CustomersLayout({ children }: { children: ReactNode }) {
  const { can } = useAuth();
  if (!can('customer:read')) return <Forbidden what="customers" />;
  return (
    <div>
      <SubNav items={[{ href: '/customers', label: 'Customers', exact: true }, { href: '/customers/receivables', label: 'Receivables' }]} />
      {children}
    </div>
  );
}
