'use client';

import Link from 'next/link';
import { DataTable, KeyValue, PageHeader } from '@/components/kit';
import { Alert, Badge, Card, CardHeader, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num, qty, titleCase } from '@/lib/format';
import { errorMessage, useBranchQuery } from '@/lib/hooks';
import type { SalesReturn } from '@/lib/types';

export default function SalesReturnPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const fmt = (v: string) => money(num(v), profile.tenant.currencyCode);
  const { data: r, isLoading, error } = useBranchQuery<SalesReturn>(`/sales-returns/${params.id}`);
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !r) return <Alert>{errorMessage(error) || 'Return not found'}</Alert>;
  return (
    <div className="space-y-4">
      <PageHeader back="/sales/returns" title={r.number} subtitle={`Refund ${fmt(r.total)} by ${titleCase(r.refundMethod ?? '')}`} />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Invoice', value: <Link className="text-brand hover:underline" href={`/sales/${r.sale.id}`}>{r.sale.invoiceNo}</Link> },
          { label: 'Customer', value: r.sale.customer?.fullName },
          { label: 'Processed', value: `${dateTime(r.createdAt)} by ${r.createdBy.fullName}` },
          { label: 'Approved by', value: r.approvedBy?.fullName },
          { label: 'Reason', value: r.reason },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Lines" />
        <DataTable
          rows={r.salesReturnItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => i.saleItem.productName },
            { key: 'b', header: 'Batch', cell: (i) => <span className="font-mono text-xs">{i.batch.batchNumber}</span> },
            { key: 'q', header: 'Qty', align: 'right', cell: (i) => `${qty(num(i.quantity))} ${i.product.baseUnit}` },
            { key: 's', header: 'Stock', cell: (i) => (i.restock ? <Badge tone="success">Restocked</Badge> : <Badge tone="danger">Damaged</Badge>) },
            ...(can('report:financial:view') ? [{ key: 'c', header: 'Cost', align: 'right' as const, cell: (i: SalesReturn['salesReturnItems'][number]) => fmt(i.costTotal) }] : []),
            { key: 't', header: 'Refund', align: 'right', cell: (i) => fmt(i.lineTotal) },
          ]}
        />
      </Card>
    </div>
  );
}
