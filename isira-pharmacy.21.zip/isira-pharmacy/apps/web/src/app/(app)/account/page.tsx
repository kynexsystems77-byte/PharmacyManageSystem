'use client';

import { Copy, Download, KeyRound, ShieldCheck, ShieldOff } from 'lucide-react';
import QRCode from 'qrcode';
import { useEffect, useState, type FormEvent } from 'react';
import { KeyValue, Modal, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { MfaStatus } from '@/lib/types';

function PasswordCard() {
  const toast = useToast();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const change = useApiMutation<object>('POST', '/auth/password/change', {
    invalidate: false,
    onSuccess: () => { toast.success('Password changed. Other devices were signed out.'); setForm({ currentPassword: '', newPassword: '', confirm: '' }); },
  });
  const mismatch = form.confirm.length > 0 && form.confirm !== form.newPassword;
  function submit(e: FormEvent) {
    e.preventDefault();
    if (mismatch) return;
    change.mutate({ currentPassword: form.currentPassword, newPassword: form.newPassword });
  }
  return (
    <Card>
      <CardHeader title="Password" />
      <form onSubmit={submit} className="space-y-3 p-4">
        {change.error && <Alert>{errorMessage(change.error)}</Alert>}
        <Field label="Current password">
          <Input type="password" autoComplete="current-password" required value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="New password (10+ characters)">
            <Input type="password" autoComplete="new-password" required minLength={10} value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} />
          </Field>
          <Field label="Repeat new password" error={mismatch ? 'Passwords do not match' : undefined}>
            <Input type="password" autoComplete="new-password" required value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} />
          </Field>
        </div>
        <div className="flex justify-end">
          <Button type="submit" loading={change.isPending} disabled={form.newPassword.length < 10 || mismatch}><KeyRound size={16} /> Change password</Button>
        </div>
      </form>
    </Card>
  );
}

function RecoveryCodes({ codes, onDone }: { codes: string[]; onDone: () => void }) {
  const { profile } = useAuth();
  const toast = useToast();
  const text = `${profile.tenant.name} recovery codes\nEach code can be used once.\n\n${codes.join('\n')}\n`;
  function download() {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'kynex-recovery-codes.txt';
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <Modal open onClose={onDone} title="Save your recovery codes" size="sm"
      footer={<Button onClick={onDone}>I have saved them</Button>}>
      <div className="space-y-3">
        <p className="text-sm text-fg-muted">If you lose your phone, each of these codes lets you sign in once. Store them somewhere safe. They will not be shown again.</p>
        <ul className="grid grid-cols-2 gap-2 rounded-lg bg-subtle p-3 font-mono text-sm">
          {codes.map((c) => <li key={c}>{c}</li>)}
        </ul>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigator.clipboard?.writeText(text).then(() => toast.success('Copied'))}><Copy size={16} /> Copy</Button>
          <Button variant="outline" onClick={download}><Download size={16} /> Download</Button>
        </div>
      </div>
    </Modal>
  );
}

function TwoFactorCard() {
  const toast = useToast();
  const { data, isLoading, refetch } = useBranchQuery<MfaStatus>('/auth/mfa');
  const [setup, setSetup] = useState<{ secret: string; otpauthUrl: string } | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [codes, setCodes] = useState<string[] | null>(null);
  const [disable, setDisable] = useState<{ password: string; code: string } | null>(null);
  const [regen, setRegen] = useState<string | null>(null);

  useEffect(() => {
    if (!setup) { setQr(null); return; }
    QRCode.toDataURL(setup.otpauthUrl, { margin: 1, width: 200 }).then(setQr).catch(() => setQr(null));
  }, [setup]);

  const start = useApiMutation<object, { secret: string; otpauthUrl: string }>('POST', '/auth/mfa/setup', { invalidate: false, onSuccess: (r) => { setSetup(r); setCode(''); } });
  const enable = useApiMutation<object, { recoveryCodes: string[] }>('POST', '/auth/mfa/enable', {
    onSuccess: (r) => { setSetup(null); setCodes(r.recoveryCodes); void refetch(); },
  });
  const turnOff = useApiMutation<object>('POST', '/auth/mfa/disable', { onSuccess: () => { setDisable(null); toast.success('Two-factor authentication turned off'); void refetch(); } });
  const regenerate = useApiMutation<object, { recoveryCodes: string[] }>('POST', '/auth/mfa/recovery-codes', {
    onSuccess: (r) => { setRegen(null); setCodes(r.recoveryCodes); void refetch(); },
  });

  if (isLoading || !data) return <Skeleton className="h-40" />;
  return (
    <Card>
      <CardHeader title="Two-factor authentication" action={data.enabled ? <Badge tone="success">On</Badge> : <Badge>Off</Badge>} />
      <div className="space-y-3 p-4 text-sm">
        {data.enabled ? (
          <>
            <KeyValue items={[{ label: 'Turned on', value: dateTime(data.enabledAt) }, { label: 'Recovery codes left', value: String(data.recoveryCodesLeft) }]} />
            {data.recoveryCodesLeft <= 3 && <Alert>You are running low on recovery codes. Create a new set.</Alert>}
            <div className="flex flex-wrap justify-end gap-2">
              <Button variant="outline" onClick={() => setRegen('')}>New recovery codes</Button>
              <Button variant="outline" onClick={() => setDisable({ password: '', code: '' })}><ShieldOff size={16} /> Turn off</Button>
            </div>
          </>
        ) : setup ? (
          <div className="grid gap-4 sm:grid-cols-[auto,1fr]">
            <div className="grid h-[200px] w-[200px] place-items-center rounded-lg border border-line bg-white">
              {qr ? <img src={qr} alt="QR code for your authenticator app" width={200} height={200} /> : <Skeleton className="h-40 w-40" />}
            </div>
            <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); enable.mutate({ code }); }}>
              <ol className="list-decimal space-y-1 pl-5 text-fg-muted">
                <li>Install an authenticator app (Google Authenticator, Microsoft Authenticator, 1Password, Authy…).</li>
                <li>Scan the QR code, or enter this key manually:</li>
              </ol>
              <code className="block break-all rounded bg-subtle px-2 py-1 font-mono text-xs">{setup.secret.replace(/(.{4})/g, '$1 ').trim()}</code>
              {enable.error && <Alert>{errorMessage(enable.error)}</Alert>}
              <Field label="3. Enter the 6-digit code shown in the app">
                <Input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                  className="w-40 text-center font-mono tracking-[0.3em]" autoFocus />
              </Field>
              <div className="flex gap-2">
                <Button type="submit" loading={enable.isPending} disabled={code.length !== 6}>Turn on</Button>
                <Button type="button" variant="outline" onClick={() => setSetup(null)}>Cancel</Button>
              </div>
            </form>
          </div>
        ) : (
          <>
            <p className="text-fg-muted">Protect your account with a code from your phone in addition to your password. Recommended for owners, managers and anyone who handles money.</p>
            {start.error && <Alert>{errorMessage(start.error)}</Alert>}
            <div className="flex justify-end"><Button loading={start.isPending} onClick={() => start.mutate({})}><ShieldCheck size={16} /> Set up</Button></div>
          </>
        )}
      </div>
      {codes && <RecoveryCodes codes={codes} onDone={() => setCodes(null)} />}
      <Modal open={Boolean(disable)} onClose={() => setDisable(null)} title="Turn off two-factor authentication" size="sm"
        footer={<><Button variant="outline" onClick={() => setDisable(null)}>Cancel</Button><Button loading={turnOff.isPending} disabled={!disable?.password || !disable?.code} onClick={() => disable && turnOff.mutate(disable)}>Turn off</Button></>}>
        {disable && (
          <div className="space-y-3">
            {turnOff.error && <Alert>{errorMessage(turnOff.error)}</Alert>}
            <Field label="Password"><Input type="password" autoComplete="current-password" value={disable.password} onChange={(e) => setDisable({ ...disable, password: e.target.value })} autoFocus /></Field>
            <Field label="Authenticator or recovery code"><Input autoComplete="one-time-code" value={disable.code} onChange={(e) => setDisable({ ...disable, code: e.target.value })} /></Field>
          </div>
        )}
      </Modal>
      <Modal open={regen !== null} onClose={() => setRegen(null)} title="New recovery codes" size="sm"
        footer={<><Button variant="outline" onClick={() => setRegen(null)}>Cancel</Button><Button loading={regenerate.isPending} disabled={(regen ?? '').length !== 6} onClick={() => regenerate.mutate({ code: regen })}>Create</Button></>}>
        <div className="space-y-3">
          <p className="text-sm text-fg-muted">Your old recovery codes stop working.</p>
          {regenerate.error && <Alert>{errorMessage(regenerate.error)}</Alert>}
          <Field label="Code from your authenticator app"><Input inputMode="numeric" maxLength={6} value={regen ?? ''} onChange={(e) => setRegen(e.target.value.replace(/\D/g, ''))} autoFocus /></Field>
        </div>
      </Modal>
    </Card>
  );
}

export default function AccountPage() {
  const { profile } = useAuth();
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="Your account" subtitle="Sign-in details and security" />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Name', value: profile.user.fullName },
          { label: 'Email', value: profile.user.email },
          { label: 'Pharmacy', value: profile.tenant.name },
          { label: 'Role', value: profile.user.isOwner ? 'Owner' : profile.branches.map((b) => b.name).join(', ') },
        ]} />
      </Card>
      <PasswordCard />
      <TwoFactorCard />
    </div>
  );
}
