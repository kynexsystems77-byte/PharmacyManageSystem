import { Injectable, Global, Module } from '@nestjs/common';
import { Prisma } from '@kynex/database';
import { TenantDb } from '../prisma/prisma.service';
import { requestContext } from '../common/request-context';

export interface AuditEntry {
  action: string;
  entityType: string;
  entityId?: string | null;
  before?: unknown;
  after?: unknown;
  /** Overrides, for events outside an authenticated request (login, password reset). */
  tenantId?: string;
  userId?: string | null;
  branchId?: string | null;
}

const SECRET_KEYS = new Set(['passwordHash', 'pinHash', 'tokenHash', 'password', 'newPassword', 'currentPassword', 'token']);

function toJson(value: unknown): Prisma.InputJsonValue | undefined {
  if (value === undefined || value === null) return undefined;
  return JSON.parse(
    JSON.stringify(value, (key, v: unknown) => (SECRET_KEYS.has(key) ? '[REDACTED]' : v)),
  ) as Prisma.InputJsonValue;
}

@Injectable()
export class AuditService {
  constructor(private readonly db: TenantDb) {}

  /** Writes an immutable audit record. Pass `tx` when called outside the request transaction. */
  async record(entry: AuditEntry, tx?: Prisma.TransactionClient): Promise<void> {
    const store = requestContext.getStore();
    const tenantId = entry.tenantId ?? store?.auth?.tenantId;
    if (!tenantId) {
      throw new Error('audit: cannot determine tenant');
    }
    await (tx ?? this.db.tx).auditLog.create({
      data: {
        tenantId,
        userId: entry.userId !== undefined ? entry.userId : (store?.auth?.userId ?? null),
        branchId: entry.branchId !== undefined ? entry.branchId : (store?.branchId ?? null),
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId ?? null,
        before: toJson(entry.before),
        after: toJson(entry.after),
        ipAddress: store?.ip ?? null,
        userAgent: store?.userAgent ?? null,
        requestId: store?.requestId ?? null,
      },
    });
  }
}

@Global()
@Module({ providers: [AuditService], exports: [AuditService] })
export class AuditModule {}
