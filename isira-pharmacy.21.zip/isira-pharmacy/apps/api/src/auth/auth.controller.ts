import { Body, Controller, Get, HttpCode, Post, Res } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import type { Response } from 'express';
import { Inject } from '@nestjs/common';
import { createZodDto } from 'nestjs-zod';
import { changePasswordSchema, forgotPasswordSchema, loginSchema, mfaDisableSchema, mfaEnableSchema, mfaLoginSchema, resetPasswordSchema } from '@kynex/contracts';
import { CurrentAuth, Public } from '../common/decorators';
import type { AuthContext } from '../common/request-context';
import { ENV, type Env } from '../config/env';
import { AuthService } from './auth.service';
import { SessionService } from './session.service';

class LoginDto extends createZodDto(loginSchema) {}
class ForgotPasswordDto extends createZodDto(forgotPasswordSchema) {}
class ResetPasswordDto extends createZodDto(resetPasswordSchema) {}
class ChangePasswordDto extends createZodDto(changePasswordSchema) {}
class MfaLoginDto extends createZodDto(mfaLoginSchema) {}
class MfaEnableDto extends createZodDto(mfaEnableSchema) {}
class MfaDisableDto extends createZodDto(mfaDisableSchema) {}

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly sessions: SessionService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Public()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('login')
  @HttpCode(200)
  async login(@Body() body: LoginDto, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.login(body.email, body.password);
    if (result.mfaRequired) return { mfaRequired: true, challenge: result.challenge };
    res.cookie(this.env.COOKIE_NAME, result.token, this.sessions.cookieOptions());
    return result.profile;
  }

  /** Second step when two-factor authentication is on: authenticator code or a recovery code. */
  @Public()
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @Post('login/mfa')
  @HttpCode(200)
  async loginMfa(@Body() body: MfaLoginDto, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.loginMfa(body.challenge, body.code);
    res.cookie(this.env.COOKIE_NAME, result.token, this.sessions.cookieOptions());
    return result.profile;
  }

  @ApiCookieAuth()
  @Get('mfa')
  mfaStatus(@CurrentAuth() auth: AuthContext) {
    return this.auth.mfaStatus(auth);
  }

  @ApiCookieAuth()
  @Post('mfa/setup')
  @HttpCode(200)
  mfaSetup(@CurrentAuth() auth: AuthContext) {
    return this.auth.mfaSetup(auth);
  }

  @ApiCookieAuth()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('mfa/enable')
  @HttpCode(200)
  mfaEnable(@CurrentAuth() auth: AuthContext, @Body() body: MfaEnableDto) {
    return this.auth.mfaEnable(auth, body.code);
  }

  @ApiCookieAuth()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('mfa/recovery-codes')
  @HttpCode(200)
  mfaRecoveryCodes(@CurrentAuth() auth: AuthContext, @Body() body: MfaEnableDto) {
    return this.auth.mfaRegenerateCodes(auth, body.code);
  }

  @ApiCookieAuth()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('mfa/disable')
  @HttpCode(204)
  async mfaDisable(@CurrentAuth() auth: AuthContext, @Body() body: MfaDisableDto): Promise<void> {
    await this.auth.mfaDisable(auth, body.password, body.code);
  }

  @ApiCookieAuth()
  @Post('logout')
  @HttpCode(204)
  async logout(@CurrentAuth() auth: AuthContext, @Res({ passthrough: true }) res: Response): Promise<void> {
    await this.auth.logout(auth);
    res.clearCookie(this.env.COOKIE_NAME, { ...this.sessions.cookieOptions(), maxAge: undefined });
  }

  @ApiCookieAuth()
  @Get('me')
  me(@CurrentAuth() auth: AuthContext) {
    return this.auth.me(auth);
  }

  @Public()
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @Post('password/forgot')
  @HttpCode(202)
  async forgot(@Body() body: ForgotPasswordDto) {
    await this.auth.forgotPassword(body.email);
    return { message: 'If that email belongs to an account, a reset link has been sent.' };
  }

  @Public()
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('password/reset')
  @HttpCode(204)
  async reset(@Body() body: ResetPasswordDto): Promise<void> {
    await this.auth.resetPassword(body.token, body.newPassword);
  }

  @ApiCookieAuth()
  @Post('password/change')
  @HttpCode(204)
  async change(@CurrentAuth() auth: AuthContext, @Body() body: ChangePasswordDto): Promise<void> {
    await this.auth.changePassword(auth, body.currentPassword, body.newPassword);
  }
}
