import type { CashTxnType, Prisma } from '@kynex/database';
import { dec } from './core';

/**
 * Cash drawer helpers shared by purchasing (cash paid to suppliers), sales (cash taken) and finance.
 * Sign convention for cash_transactions.amount: positive = cash INTO the drawer, negative = cash OUT.
 */

/** The open register shift this user is working in at a branch (latest first), or null. */
export async function openSessionFor(tx: Prisma.TransactionClient, branchId: string, userId: string) {
  return tx.registerSession.findFirst({
    where: { status: 'OPEN', openedById: userId, register: { branchId } },
    orderBy: { openedAt: 'desc' },
    select: { id: true, registerId: true, openedAt: true, register: { select: { id: true, name: true } } },
  });
}

export async function recordCash(
  tx: Prisma.TransactionClient,
  input: {
    tenantId: string;
    branchId: string;
    registerSessionId: string;
    userId: string;
    type: CashTxnType;
    /** Signed: + in, - out. */
    amount: Prisma.Decimal.Value;
    referenceType?: string;
    referenceId?: string;
    note?: string | null;
  },
) {
  const amount = dec(input.amount);
  if (amount.isZero()) return null;
  return tx.cashTransaction.create({
    data: {
      tenantId: input.tenantId,
      branchId: input.branchId,
      registerSessionId: input.registerSessionId,
      createdById: input.userId,
      type: input.type,
      amount,
      referenceType: input.referenceType ?? null,
      referenceId: input.referenceId ?? null,
      note: input.note ?? null,
    },
  });
}

/**
 * Party ledger sign convention (party_ledger_entries.amount):
 *   customers: + = the customer owes us more (credit sale),  - = owes less (payment, return credit)
 *   suppliers: + = we owe the supplier more (purchase),      - = we owe less (payment, purchase return)
 * A party's balance is SUM(amount).
 */
export async function partyBalance(tx: Prisma.TransactionClient, party: { customerId?: string; supplierId?: string }) {
  const agg = await tx.partyLedgerEntry.aggregate({ where: party, _sum: { amount: true } });
  return dec(agg._sum.amount);
}
