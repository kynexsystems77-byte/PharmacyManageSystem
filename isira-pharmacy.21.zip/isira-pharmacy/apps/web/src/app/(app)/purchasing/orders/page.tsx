'use client';

import { Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import { PO_TONE } from '@/lib/status';
import type { PurchaseOrder } from '@/lib/types';

export default function OrdersPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<PurchaseOrder>>(`/purchase-orders${qs({ page, pageSize: 25, search: s, status })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader
        title="Purchase orders"
        subtitle="What you asked suppliers to deliver. Receiving against an order tracks what is still open."
        actions={can('purchase_order:manage') && <Link href="/purchasing/orders/new"><Button><Plus size={16} /> New order</Button></Link>}
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_220px]">
          <SearchBox value={search} onChange={setSearch} placeholder="PO number or supplier" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">Any status</option>
            {['DRAFT', 'ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED'].map((x) => <option key={x} value={x}>{titleCase(x)}</option>)}
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(o) => o.id}
          onRowClick={(o) => router.push(`/purchasing/orders/${o.id}`)}
          columns={[
            { key: 'n', header: 'PO', cell: (o) => <span className="font-mono text-xs">{o.number}</span> },
            { key: 'd', header: 'Ordered', cell: (o) => dateOnly(o.orderDate) },
            { key: 's', header: 'Supplier', cell: (o) => <span className="font-medium">{o.supplier.name}</span> },
            { key: 'e', header: 'Expected', cell: (o) => dateOnly(o.expectedDate) },
            { key: 'st', header: 'Status', cell: (o) => <Badge tone={PO_TONE[o.status]}>{titleCase(o.status)}</Badge> },
            { key: 'i', header: 'Lines', align: 'right', cell: (o) => o.purchaseOrderItems.length },
            { key: 't', header: 'Total', align: 'right', cell: (o) => money(num(o.grandTotal), profile.tenant.currencyCode) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
