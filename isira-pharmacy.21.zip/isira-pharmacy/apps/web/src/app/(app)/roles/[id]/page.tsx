'use client';

import { Trash2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { ConfirmDialog, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { num } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { PermissionRow, RoleRow } from '@/lib/types';

export default function RolePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { can, profile } = useAuth();
  const toast = useToast();
  const { data: role, isLoading, error } = useBranchQuery<RoleRow>(`/roles/${params.id}`);
  const perms = useBranchQuery<PermissionRow[]>('/permissions');
  const [selected, setSelected] = useState<Set<string> | null>(null);
  const [meta, setMeta] = useState({ name: '', description: '', maxDiscountPercent: '0' });
  const [confirmDelete, setConfirmDelete] = useState(false);
  useEffect(() => {
    if (role) {
      setSelected(new Set(role.permissions));
      setMeta({ name: role.name, description: role.description ?? '', maxDiscountPercent: String(num(role.maxDiscountPercent)) });
    }
  }, [role]);
  const byModule = useMemo(() => {
    const m = new Map<string, PermissionRow[]>();
    for (const p of perms.data ?? []) m.set(p.module, [...(m.get(p.module) ?? []), p]);
    return [...m.entries()];
  }, [perms.data]);
  const savePerms = useApiMutation<object>('PUT', `/roles/${params.id}/permissions`, { onSuccess: () => toast.success('Permissions saved. Users get them at their next sign-in.') });
  const saveMeta = useApiMutation<object>('PATCH', `/roles/${params.id}`, { onSuccess: () => toast.success('Role saved') });
  const remove = useApiMutation<object>('DELETE', `/roles/${params.id}`, { onSuccess: () => { toast.success('Role deleted'); router.push('/roles'); } });
  if (isLoading || !selected) return <Skeleton className="h-64" />;
  if (error || !role) return <Alert>{errorMessage(error) || 'Role not found'}</Alert>;
  const editable = can('role:manage') && !role.isSystem;
  // a user may only grant what they hold (the server enforces this too)
  const mine = new Set(profile.branches.flatMap((b) => b.permissions));
  const toggle = (k: string) => setSelected((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; });
  return (
    <div className="space-y-4">
      <PageHeader
        back="/roles"
        title={role.name}
        subtitle={<span className="flex items-center gap-2">{role.isSystem ? <Badge>System role (read-only)</Badge> : <Badge tone="success">Custom role</Badge>}{role.assignedUsers} assignments</span>}
        actions={editable && <Button variant="outline" onClick={() => setConfirmDelete(true)}><Trash2 size={16} /> Delete</Button>}
      />
      {editable && (
        <Card className="grid gap-3 p-4 sm:grid-cols-[1fr_1fr_160px_auto] sm:items-end">
          <Field label="Name"><Input value={meta.name} onChange={(e) => setMeta({ ...meta, name: e.target.value })} /></Field>
          <Field label="Description"><Input value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} /></Field>
          <Field label="Max discount %"><Input type="number" min="0" max="100" value={meta.maxDiscountPercent} onChange={(e) => setMeta({ ...meta, maxDiscountPercent: e.target.value })} /></Field>
          <Button variant="outline" loading={saveMeta.isPending} onClick={() => saveMeta.mutate({ name: meta.name.trim(), description: meta.description.trim() || null, maxDiscountPercent: Number(meta.maxDiscountPercent || 0) })}>Save details</Button>
        </Card>
      )}
      {(saveMeta.error || savePerms.error) && <Alert>{errorMessage(saveMeta.error ?? savePerms.error)}</Alert>}
      <div className="grid gap-4 lg:grid-cols-2">
        {byModule.map(([module, list]) => (
          <Card key={module}>
            <CardHeader title={module} action={<span className="text-xs text-fg-muted">{list.filter((p) => selected.has(p.key)).length}/{list.length}</span>} />
            <ul className="divide-y divide-line">
              {list.map((p) => {
                const allowed = editable && (profile.user.isOwner || mine.has(p.key));
                return (
                  <li key={p.key}>
                    <label className={`flex items-start gap-3 px-4 py-2 text-sm ${allowed ? 'cursor-pointer hover:bg-subtle/60' : 'opacity-80'}`}>
                      <input type="checkbox" className="mt-0.5 h-4 w-4" disabled={!allowed} checked={selected.has(p.key)} onChange={() => toggle(p.key)} />
                      <span><span className="block">{p.description}</span><span className="font-mono text-[11px] text-fg-muted">{p.key}</span></span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </Card>
        ))}
      </div>
      {editable && <div className="sticky bottom-4 flex justify-end"><Button loading={savePerms.isPending} onClick={() => savePerms.mutate({ permissions: [...selected] })}>Save permissions ({selected.size})</Button></div>}
      <ConfirmDialog open={confirmDelete} title={`Delete ${role.name}?`} danger confirmLabel="Delete" loading={remove.isPending} onClose={() => setConfirmDelete(false)} onConfirm={() => remove.mutate({}, { onError: (e) => { toast.error(errorMessage(e)); setConfirmDelete(false); } })} body={<p>Roles still assigned to users cannot be deleted.</p>} />
    </div>
  );
}
