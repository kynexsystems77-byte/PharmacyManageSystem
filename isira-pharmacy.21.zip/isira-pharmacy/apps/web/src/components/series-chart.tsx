import { shortDay } from '@/lib/format';

/** Dependency-free bar chart with an optional second series drawn as a line (e.g. revenue bars + profit line). */
export function SeriesChart<T extends { day: string }>({
  data, bars, line, format, barLabel, lineLabel,
}: {
  data: T[];
  bars: (d: T) => number;
  line?: (d: T) => number;
  format: (v: number) => string;
  barLabel: string;
  lineLabel?: string;
}) {
  const W = 760, H = 220, padX = 14, padTop = 14, padBottom = 30;
  const values = data.flatMap((d) => [bars(d), line ? line(d) : 0]);
  const max = Math.max(1, ...values);
  const min = Math.min(0, ...values);
  const span = max - min || 1;
  const plotH = H - padTop - padBottom;
  const y = (v: number) => padTop + ((max - v) / span) * plotH;
  const slot = (W - padX * 2) / Math.max(1, data.length);
  const barW = Math.max(2, Math.min(36, slot * 0.6));
  const labelEvery = Math.ceil(data.length / 12);
  const pts = line ? data.map((d, i) => `${padX + i * slot + slot / 2},${y(line(d))}`).join(' ') : '';
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={barLabel} className="h-auto w-full">
        <line x1={padX} x2={W - padX} y1={y(0)} y2={y(0)} className="stroke-line" />
        {data.map((d, i) => {
          const v = bars(d);
          const x = padX + i * slot + (slot - barW) / 2;
          return (
            <g key={d.day}>
              <title>{`${d.day}: ${barLabel} ${format(v)}${line ? ` · ${lineLabel} ${format(line(d))}` : ''}`}</title>
              <rect x={x} y={Math.min(y(v), y(0))} width={barW} height={Math.max(Math.abs(y(v) - y(0)), v !== 0 ? 2 : 0)} rx={3} className="fill-brand/40" />
              {i % labelEvery === 0 && (
                <text x={x + barW / 2} y={H - 10} textAnchor="middle" className="fill-fg-muted text-[11px]">
                  {data.length <= 14 ? shortDay(d.day) : d.day.slice(5)}
                </text>
              )}
            </g>
          );
        })}
        {line && <polyline points={pts} fill="none" className="stroke-success" strokeWidth={2.5} strokeLinejoin="round" />}
        {line && data.map((d, i) => <circle key={d.day} cx={padX + i * slot + slot / 2} cy={y(line(d))} r={2.5} className="fill-success" />)}
      </svg>
      <div className="mt-1 flex gap-4 text-xs text-fg-muted">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-brand/40" />{barLabel}</span>
        {line && <span className="flex items-center gap-1.5"><span className="h-0.5 w-3 bg-success" />{lineLabel}</span>}
      </div>
    </div>
  );
}
