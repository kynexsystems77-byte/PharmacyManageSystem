import { Controller, Get, Query } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { listAuditQuerySchema } from '@kynex/contracts';
import { Prisma } from '@kynex/database';
import { RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import { TenantDb } from '../prisma/prisma.service';

class ListAuditQueryDto extends createZodDto(listAuditQuerySchema) {}

@ApiTags('Audit')
@ApiCookieAuth()
@Controller('audit-logs')
export class AuditController {
  constructor(private readonly db: TenantDb) {}

  @Get()
  @RequirePermissions('audit:read')
  async list(@Query() q: ListAuditQueryDto) {
    const where: Prisma.AuditLogWhereInput = {
      ...(q.entityType ? { entityType: q.entityType } : {}),
      ...(q.entityId ? { entityId: q.entityId } : {}),
      ...(q.userId ? { userId: q.userId } : {}),
      ...(q.action ? { action: { contains: q.action, mode: 'insensitive' } } : {}),
      ...(q.from || q.to ? { createdAt: { ...(q.from ? { gte: q.from } : {}), ...(q.to ? { lte: q.to } : {}) } } : {}),
    };
    const tx = this.db.tx;
    const total = await tx.auditLog.count({ where });
    const rows = await tx.auditLog.findMany({ where, orderBy: { createdAt: 'desc' }, ...skipTake(q.page, q.pageSize) });
    const userIds = [...new Set(rows.map((r) => r.userId).filter((id): id is string => Boolean(id)))];
    const users = userIds.length
      ? await tx.user.findMany({ where: { id: { in: userIds } }, select: { id: true, fullName: true, email: true } })
      : [];
    const byId = new Map(users.map((u) => [u.id, u]));
    return paged(
      rows.map((r) => ({ ...r, user: r.userId ? (byId.get(r.userId) ?? null) : null })),
      total,
      q.page,
      q.pageSize,
    );
  }
}
