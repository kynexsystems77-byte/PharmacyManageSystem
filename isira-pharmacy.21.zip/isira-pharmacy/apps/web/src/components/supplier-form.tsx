'use client';

import { useState } from 'react';
import { errorMessage, useApiMutation } from '@/lib/hooks';
import type { Supplier } from '@/lib/types';
import { Modal, Textarea, useToast } from './kit';
import { Alert, Button, Field, Input } from './ui';

export function SupplierFormModal({ open, onClose, supplier, onSaved }: { open: boolean; onClose: () => void; supplier?: Supplier; onSaved?: (s: Supplier) => void }) {
  const toast = useToast();
  const [f, setF] = useState(() => ({
    name: supplier?.name ?? '', contactName: supplier?.contactName ?? '', phone: supplier?.phone ?? '', email: supplier?.email ?? '',
    address: supplier?.address ?? '', taxNumber: supplier?.taxNumber ?? '', paymentTermsDays: String(supplier?.paymentTermsDays ?? 30), notes: supplier?.notes ?? '',
    isActive: supplier?.isActive ?? true,
  }));
  const save = useApiMutation<object, Supplier>(supplier ? 'PATCH' : 'POST', supplier ? `/suppliers/${supplier.id}` : '/suppliers', {
    onSuccess: (s) => { toast.success('Supplier saved'); onSaved?.(s); onClose(); },
  });
  const body = () => {
    const t = (v: string) => (v.trim() === '' ? (supplier ? null : undefined) : v.trim());
    return {
      name: f.name.trim(), contactName: t(f.contactName), phone: t(f.phone), email: f.email.trim() === '' ? (supplier ? null : undefined) : f.email.trim(),
      address: t(f.address), taxNumber: t(f.taxNumber), paymentTermsDays: Number(f.paymentTermsDays || 0), notes: t(f.notes),
      ...(supplier ? { isActive: f.isActive } : {}),
    };
  };
  return (
    <Modal open={open} onClose={onClose} title={supplier ? `Edit ${supplier.name}` : 'New supplier'} size="lg"
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button loading={save.isPending} disabled={f.name.trim().length < 2} onClick={() => save.mutate(body())}>Save</Button></>}>
      <div className="grid gap-3 sm:grid-cols-2">
        {save.error && <div className="sm:col-span-2"><Alert>{errorMessage(save.error)}</Alert></div>}
        <Field label="Name *"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} maxLength={160} /></Field>
        <Field label="Contact person"><Input value={f.contactName} onChange={(e) => setF({ ...f, contactName: e.target.value })} maxLength={120} /></Field>
        <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} maxLength={40} /></Field>
        <Field label="Email"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} maxLength={254} /></Field>
        <Field label="Tax / VAT number"><Input value={f.taxNumber} onChange={(e) => setF({ ...f, taxNumber: e.target.value })} maxLength={60} /></Field>
        <Field label="Payment terms (days)"><Input type="number" min="0" max="365" value={f.paymentTermsDays} onChange={(e) => setF({ ...f, paymentTermsDays: e.target.value })} /></Field>
        <div className="sm:col-span-2"><Field label="Address"><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} maxLength={300} /></Field></div>
        <div className="sm:col-span-2"><Field label="Notes"><Textarea value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} maxLength={1000} /></Field></div>
        {supplier && <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} /> Active</label>}
      </div>
    </Modal>
  );
}
