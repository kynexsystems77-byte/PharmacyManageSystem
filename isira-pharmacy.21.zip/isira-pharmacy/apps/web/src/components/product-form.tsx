'use client';

import { Plus, Trash2 } from 'lucide-react';
import { useMemo, useState, type FormEvent } from 'react';
import { DOSAGE_FORMS } from '@kynex/contracts';
import { errorMessage, useBranchQuery, type Paged } from '@/lib/hooks';
import { titleCase } from '@/lib/format';
import type { Category, Manufacturer, Product, TaxRate } from '@/lib/types';
import { Checkbox, Select, Textarea } from './kit';
import { Alert, Button, Card, CardHeader, Field, Input } from './ui';

export interface UnitDraft { id?: string; name: string; factorToBase: string; barcode: string; sellingPrice: string; isDefaultSaleUnit: boolean }

export interface ProductDraft {
  sku: string; barcode: string; brandName: string; genericName: string; strength: string; dosageForm: string; baseUnit: string;
  requiresPrescription: boolean; isControlled: boolean; trackExpiry: boolean; purchasePrice: string; sellingPrice: string;
  wholesalePrice: string; reorderLevel: string; description: string; categoryId: string; manufacturerId: string;
  preferredSupplierId: string; taxRateId: string; isActive: boolean; units: UnitDraft[];
}

export function emptyDraft(): ProductDraft {
  return {
    sku: '', barcode: '', brandName: '', genericName: '', strength: '', dosageForm: 'TABLET', baseUnit: 'tablet',
    requiresPrescription: false, isControlled: false, trackExpiry: true, purchasePrice: '0', sellingPrice: '0', wholesalePrice: '',
    reorderLevel: '0', description: '', categoryId: '', manufacturerId: '', preferredSupplierId: '', taxRateId: '', isActive: true, units: [],
  };
}

export function draftFromProduct(p: Product): ProductDraft {
  return {
    sku: p.sku, barcode: p.barcode ?? '', brandName: p.brandName, genericName: p.genericName ?? '', strength: p.strength ?? '',
    dosageForm: p.dosageForm, baseUnit: p.baseUnit, requiresPrescription: p.requiresPrescription, isControlled: p.isControlled,
    trackExpiry: p.trackExpiry, purchasePrice: String(Number(p.purchasePrice)), sellingPrice: String(Number(p.sellingPrice)),
    wholesalePrice: p.wholesalePrice === null ? '' : String(Number(p.wholesalePrice)), reorderLevel: String(Number(p.reorderLevel)),
    description: p.description ?? '', categoryId: p.categoryId, manufacturerId: p.manufacturerId ?? '',
    preferredSupplierId: p.preferredSupplierId ?? '', taxRateId: p.taxRateId ?? '', isActive: p.isActive,
    units: p.productUnits.map((u) => ({
      id: u.id, name: u.name, factorToBase: String(Number(u.factorToBase)), barcode: u.barcode ?? '',
      sellingPrice: u.sellingPrice === null ? '' : String(Number(u.sellingPrice)), isDefaultSaleUnit: u.isDefaultSaleUnit,
    })),
  };
}

/** Converts the form draft to the API body (create or update). Empty optional fields become null/undefined. */
export function draftToBody(d: ProductDraft, mode: 'create' | 'update') {
  const opt = (v: string) => (v.trim() === '' ? (mode === 'update' ? null : undefined) : v.trim());
  const optId = (v: string) => (v === '' ? null : v);
  return {
    sku: d.sku.trim() === '' ? undefined : d.sku.trim(),
    barcode: opt(d.barcode),
    brandName: d.brandName.trim(),
    genericName: opt(d.genericName),
    strength: opt(d.strength),
    dosageForm: d.dosageForm,
    baseUnit: d.baseUnit.trim() || 'unit',
    requiresPrescription: d.requiresPrescription,
    isControlled: d.isControlled,
    trackExpiry: d.trackExpiry,
    purchasePrice: Number(d.purchasePrice || 0),
    sellingPrice: Number(d.sellingPrice || 0),
    wholesalePrice: d.wholesalePrice.trim() === '' ? null : Number(d.wholesalePrice),
    reorderLevel: Number(d.reorderLevel || 0),
    description: opt(d.description),
    categoryId: d.categoryId,
    manufacturerId: optId(d.manufacturerId),
    preferredSupplierId: optId(d.preferredSupplierId),
    taxRateId: optId(d.taxRateId),
    ...(mode === 'update' ? { isActive: d.isActive } : {}),
    units: d.units.map((u) => ({
      ...(u.id ? { id: u.id } : {}),
      name: u.name.trim(),
      factorToBase: Number(u.factorToBase || 1),
      barcode: u.barcode.trim() || undefined,
      sellingPrice: u.sellingPrice.trim() === '' ? null : Number(u.sellingPrice),
      isDefaultSaleUnit: u.isDefaultSaleUnit,
    })),
  };
}

/** "Medicine › Antibiotics" style labels, in tree order. */
export function categoryOptions(categories: Category[] | undefined): { id: string; label: string; depth: number }[] {
  if (!categories) return [];
  const children = new Map<string | null, Category[]>();
  for (const c of categories) {
    const k = c.parentId ?? null;
    children.set(k, [...(children.get(k) ?? []), c]);
  }
  const out: { id: string; label: string; depth: number }[] = [];
  const walk = (parent: string | null, prefix: string, depth: number) => {
    for (const c of children.get(parent) ?? []) {
      const label = prefix ? `${prefix} › ${c.name}` : c.name;
      out.push({ id: c.id, label, depth });
      walk(c.id, label, depth + 1);
    }
  };
  walk(null, '', 0);
  return out;
}

export function ProductForm({
  initial, mode, canEditPrices, canDeactivate, submitting, error, onSubmit, onCancel,
}: {
  initial: ProductDraft;
  mode: 'create' | 'update';
  canEditPrices: boolean;
  canDeactivate: boolean;
  submitting: boolean;
  error: unknown;
  onSubmit: (d: ProductDraft) => void;
  onCancel: () => void;
}) {
  const [d, setD] = useState<ProductDraft>(initial);
  const set = <K extends keyof ProductDraft>(k: K, v: ProductDraft[K]) => setD((x) => ({ ...x, [k]: v }));
  const cats = useBranchQuery<Category[]>('/categories', { staleTime: 60_000 });
  const taxes = useBranchQuery<TaxRate[]>('/tax-rates', { staleTime: 60_000 });
  const mfrs = useBranchQuery<Paged<Manufacturer>>('/manufacturers?pageSize=100', { staleTime: 60_000 });
  const sups = useBranchQuery<Paged<{ id: string; name: string }>>('/suppliers?pageSize=100', { staleTime: 60_000, retry: false });
  const catOpts = useMemo(() => categoryOptions(cats.data), [cats.data]);
  const priceLocked = mode === 'update' && !canEditPrices;

  const margin = useMemo(() => {
    const cost = Number(d.purchasePrice), sell = Number(d.sellingPrice);
    if (!(cost > 0) || !(sell > 0)) return null;
    return ((sell - cost) / sell) * 100;
  }, [d.purchasePrice, d.sellingPrice]);

  const setUnit = (i: number, patch: Partial<UnitDraft>) =>
    setD((x) => ({
      ...x,
      units: x.units.map((u, j) => (j === i ? { ...u, ...patch } : patch.isDefaultSaleUnit ? { ...u, isDefaultSaleUnit: false } : u)),
    }));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit(d);
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      {error ? <Alert>{errorMessage(error)}</Alert> : null}

      <Card>
        <CardHeader title="Identity" />
        <div className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Brand / product name *"><Input required value={d.brandName} onChange={(e) => set('brandName', e.target.value)} maxLength={160} /></Field>
          <Field label="Generic name"><Input value={d.genericName} onChange={(e) => set('genericName', e.target.value)} maxLength={160} /></Field>
          <Field label="Strength"><Input value={d.strength} onChange={(e) => set('strength', e.target.value)} placeholder="e.g. 500 mg" maxLength={60} /></Field>
          <Field label="Category *">
            <Select required value={d.categoryId} onChange={(e) => set('categoryId', e.target.value)}>
              <option value="">Choose…</option>
              {catOpts.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </Select>
          </Field>
          <Field label="Dosage form">
            <Select value={d.dosageForm} onChange={(e) => set('dosageForm', e.target.value)}>
              {DOSAGE_FORMS.map((f) => <option key={f} value={f}>{titleCase(f)}</option>)}
            </Select>
          </Field>
          <Field label="Base unit (smallest unit sold)"><Input value={d.baseUnit} onChange={(e) => set('baseUnit', e.target.value)} placeholder="tablet, ml, piece" maxLength={20} /></Field>
          <Field label="SKU"><Input value={d.sku} onChange={(e) => set('sku', e.target.value.toUpperCase())} placeholder={mode === 'create' ? 'Leave empty to generate' : ''} maxLength={40} /></Field>
          <Field label="Barcode"><Input value={d.barcode} onChange={(e) => set('barcode', e.target.value)} placeholder="Scan or type" maxLength={64} /></Field>
          <Field label="Manufacturer">
            <Select value={d.manufacturerId} onChange={(e) => set('manufacturerId', e.target.value)}>
              <option value="">—</option>
              {mfrs.data?.data.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </Select>
          </Field>
          <Field label="Preferred supplier">
            <Select value={d.preferredSupplierId} onChange={(e) => set('preferredSupplierId', e.target.value)}>
              <option value="">—</option>
              {sups.data?.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
        </div>
        <div className="grid gap-3 border-t border-line p-4 sm:grid-cols-2 lg:grid-cols-4">
          <Checkbox label="Prescription required" hint="POS asks for a prescription" checked={d.requiresPrescription} onChange={(v) => set('requiresPrescription', v)} />
          <Checkbox label="Controlled substance" checked={d.isControlled} onChange={(v) => set('isControlled', v)} />
          <Checkbox label="Track expiry" hint="Batches must have an expiry date" checked={d.trackExpiry} onChange={(v) => set('trackExpiry', v)} />
          {mode === 'update' && (
            <Checkbox label="Active" hint={canDeactivate ? 'Inactive products cannot be sold' : 'Needs product:deactivate'} checked={d.isActive} onChange={(v) => canDeactivate && set('isActive', v)} />
          )}
        </div>
      </Card>

      <Card>
        <CardHeader title="Pricing and stock" action={priceLocked ? <span className="text-xs text-fg-muted">Prices are read-only for your role</span> : null} />
        <div className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Purchase price (per base unit)"><Input type="number" step="0.0001" min="0" disabled={priceLocked} value={d.purchasePrice} onChange={(e) => set('purchasePrice', e.target.value)} /></Field>
          <Field label="Selling price (per base unit)"><Input type="number" step="0.0001" min="0" disabled={priceLocked} value={d.sellingPrice} onChange={(e) => set('sellingPrice', e.target.value)} /></Field>
          <Field label="Wholesale price"><Input type="number" step="0.0001" min="0" disabled={priceLocked} value={d.wholesalePrice} onChange={(e) => set('wholesalePrice', e.target.value)} /></Field>
          <Field label="Tax">
            <Select value={d.taxRateId} onChange={(e) => set('taxRateId', e.target.value)}>
              <option value="">No tax</option>
              {taxes.data?.map((t) => <option key={t.id} value={t.id}>{t.name} ({Number(t.ratePercent)}%{t.isInclusive ? ', inclusive' : ''})</option>)}
            </Select>
          </Field>
          <Field label="Reorder level (base units)"><Input type="number" step="0.001" min="0" value={d.reorderLevel} onChange={(e) => set('reorderLevel', e.target.value)} /></Field>
          <div className="text-sm sm:col-span-2 lg:col-span-3">
            <span className="mb-1 block font-medium">Margin</span>
            <span className={margin !== null && margin < 0 ? 'text-danger' : 'text-fg-muted'}>{margin === null ? '—' : `${margin.toFixed(1)}% of the selling price`}</span>
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader
          title="Sale units"
          action={
            <Button type="button" variant="outline" className="h-8 px-3" onClick={() => setD((x) => ({ ...x, units: [...x.units, { name: '', factorToBase: '10', barcode: '', sellingPrice: '', isDefaultSaleUnit: false }] }))}>
              <Plus size={14} /> Add unit
            </Button>
          }
        />
        <div className="p-4">
          <p className="mb-3 text-xs text-fg-muted">
            Stock is always counted in the base unit ({d.baseUnit || 'unit'}). Add packs such as a strip of 10 or a box of 100; leave the price empty to use base price × size.
          </p>
          {d.units.length === 0 && <p className="text-sm text-fg-muted">Sold by the {d.baseUnit || 'unit'} only.</p>}
          <div className="space-y-3">
            {d.units.map((u, i) => (
              <div key={u.id ?? i} className="grid items-end gap-2 rounded-lg border border-line p-3 sm:grid-cols-[1fr_110px_1fr_120px_auto_auto]">
                <Field label="Unit name"><Input required value={u.name} onChange={(e) => setUnit(i, { name: e.target.value })} placeholder="Strip" maxLength={40} /></Field>
                <Field label={`Size (${d.baseUnit || 'unit'}s)`}><Input required type="number" step="0.001" min="0.001" value={u.factorToBase} onChange={(e) => setUnit(i, { factorToBase: e.target.value })} /></Field>
                <Field label="Barcode"><Input value={u.barcode} onChange={(e) => setUnit(i, { barcode: e.target.value })} maxLength={64} /></Field>
                <Field label="Price"><Input type="number" step="0.0001" min="0" disabled={priceLocked} value={u.sellingPrice} onChange={(e) => setUnit(i, { sellingPrice: e.target.value })} /></Field>
                <div className="pb-2"><Checkbox label="Default" checked={u.isDefaultSaleUnit} onChange={(v) => setUnit(i, { isDefaultSaleUnit: v })} /></div>
                <button type="button" aria-label="Remove unit" onClick={() => setD((x) => ({ ...x, units: x.units.filter((_, j) => j !== i) }))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger">
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <Card>
        <CardHeader title="Notes" />
        <div className="p-4"><Textarea value={d.description} onChange={(e) => set('description', e.target.value)} maxLength={2000} placeholder="Usage notes, storage instructions…" /></div>
      </Card>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit" loading={submitting}>{mode === 'create' ? 'Create product' : 'Save changes'}</Button>
      </div>
    </form>
  );
}
