import { Body, Controller, Delete, Get, HttpCode, Module, NotFoundException, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import {
  createSaleSchema, createSalesReturnSchema, expiryCheckQuerySchema, holdSaleSchema, listSalesQuerySchema, listSalesReturnsQuerySchema, quoteSaleSchema, voidSaleSchema,
} from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { currentBranchId } from '../common/branch';
import { formatDateOnly, parseDateOnly, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { InventoryCoreModule } from '../inventory/inventory-core.module';
import { StockService } from '../inventory/stock.service';
import { TenantDb } from '../prisma/prisma.service';
import { PricingService } from './pricing';
import { SALE_SELECT, SALES_RETURN_SELECT, SalesService } from './sales.service';

class QuoteSaleDto extends createZodDto(quoteSaleSchema) {}
class CreateSaleDto extends createZodDto(createSaleSchema) {}
class HoldSaleDto extends createZodDto(holdSaleSchema) {}
class VoidSaleDto extends createZodDto(voidSaleSchema) {}
class CreateSalesReturnDto extends createZodDto(createSalesReturnSchema) {}
class ListSalesQueryDto extends createZodDto(listSalesQuerySchema) {}
class ListSalesReturnsQueryDto extends createZodDto(listSalesReturnsQuerySchema) {}
class ExpiryCheckQueryDto extends createZodDto(expiryCheckQuerySchema) {}

/** Day range [from, to] in the tenant's calendar, as UTC instants. */
function dayRange(timezone: string, from?: string, to?: string): { gte?: Date; lt?: Date } | undefined {
  if (!from && !to) return undefined;
  const offsetMs = (d: Date) => {
    const local = new Date(d.toLocaleString('en-US', { timeZone: timezone }));
    const utc = new Date(d.toLocaleString('en-US', { timeZone: 'UTC' }));
    return local.getTime() - utc.getTime();
  };
  const start = (v: string) => { const d = parseDateOnly(v); return new Date(d.getTime() - offsetMs(d)); };
  return {
    ...(from ? { gte: start(from) } : {}),
    ...(to ? { lt: new Date(start(to).getTime() + 86_400_000) } : {}),
  };
}

@ApiTags('Sales')
@ApiCookieAuth()
@Controller('sales')
export class SalesController {
  constructor(
    private readonly db: TenantDb,
    private readonly sales: SalesService,
    private readonly tenantInfo: TenantInfoService,
    private readonly stock: StockService,
  ) {}

  /** Prices a bill exactly like checkout would (FEFO batches, discounts, tax, rounding) without saving anything. */
  @Post('quote')
  @HttpCode(200)
  @BranchScoped()
  @RequirePermissions('sale:create')
  quote(@Body() dto: QuoteSaleDto, @CurrentAuth() auth: AuthContext) {
    return this.sales.quote(auth, currentBranchId(), dto);
  }

  /** Completes a sale. Send a fresh idempotencyKey per bill; retries with the same key return the same invoice. */
  @Post()
  @BranchScoped()
  @RequirePermissions('sale:create')
  create(@Body() dto: CreateSaleDto, @CurrentAuth() auth: AuthContext) {
    return this.sales.create(auth, currentBranchId(), dto);
  }

  @Post('hold')
  @BranchScoped()
  @RequirePermissions('sale:create')
  hold(@Body() dto: HoldSaleDto, @CurrentAuth() auth: AuthContext) {
    return this.sales.hold(auth, currentBranchId(), dto);
  }

  /**
   * Called by the POS when a product is scanned. Lists the batches on the selling location in FEFO order
   * and says whether the cashier should be warned: the next batch to be sold is close to expiry, or
   * expired / blocked stock is still on the shelf.
   */
  @Get('expiry-check')
  @BranchScoped()
  @RequirePermissions('sale:create')
  async expiryCheck(@Query() q: ExpiryCheckQueryDto) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const { timezone, settings } = await this.tenantInfo.get(tx);
    const today = todayIn(timezone);
    const product = await tx.product.findFirst({
      where: { id: q.productId, deletedAt: null },
      select: { id: true, brandName: true, strength: true, baseUnit: true, trackExpiry: true },
    });
    if (!product) throw new NotFoundException('Product not found');
    const location = await this.stock.defaultLocation(tx, branchId);
    const rows = await tx.$queryRaw<{ id: string; batch_number: string; expiry_date: Date | null; status: string; days_left: number | null; quantity: string }[]>`
      SELECT b.id, b.batch_number, b.expiry_date, b.status::text AS status,
             (b.expiry_date - ${today}::date)::int AS days_left, SUM(s.quantity)::text AS quantity
      FROM stock_levels s JOIN batches b ON b.id = s.batch_id
      WHERE s.location_id = ${location.id}::uuid AND s.product_id = ${product.id}::uuid AND s.quantity > 0
      GROUP BY b.id
      ORDER BY b.expiry_date ASC NULLS LAST, b.received_at ASC, b.id ASC`;
    const minDays = settings.minDaysToExpiryForSale;
    const warnDays = settings.expiryWarningDays;
    const batches = rows.map((r) => {
      const days = r.days_left === null ? null : Number(r.days_left);
      const state = days !== null && days < 0 ? 'EXPIRED'
        : r.status !== 'ACTIVE' ? 'BLOCKED'
        : days !== null && days < minDays ? 'TOO_CLOSE'
        : days !== null && days <= warnDays ? 'EXPIRING'
        : 'OK';
      return { id: r.id, batchNumber: r.batch_number, expiryDate: formatDateOnly(r.expiry_date), daysLeft: days, quantity: r.quantity, state };
    });
    const sellable = batches.filter((b) => b.state === 'EXPIRING' || b.state === 'OK');
    const unsellable = batches.filter((b) => !sellable.includes(b));
    const next = sellable[0] ?? null;
    const total = (bs: typeof batches) => bs.reduce((a, b) => a + Number(b.quantity), 0);
    let level: 'none' | 'warning' | 'danger' = 'none';
    let message = '';
    if (product.trackExpiry) {
      if (!next && unsellable.length) {
        level = 'danger';
        message = 'All stock of this product is expired or too close to expiry, so it cannot be sold. Remove it from the shelf.';
      } else if (next && next.daysLeft !== null && next.daysLeft <= Math.min(7, warnDays)) {
        level = 'danger';
        message = next.daysLeft === 0 ? 'The batch being sold expires today.' : `The batch being sold expires in ${next.daysLeft} day${next.daysLeft === 1 ? '' : 's'}.`;
      } else if (next && next.state === 'EXPIRING') {
        level = 'warning';
        message = `The batch being sold expires in ${next.daysLeft} days. Tell the customer the expiry date.`;
      } else if (unsellable.length) {
        level = 'warning';
        message = 'Expired stock of this product is still on the shelf. The till will not sell it; write it off.';
      }
    }
    return {
      product, today, level, message, warningDays: warnDays, minDaysToExpiryForSale: minDays,
      next, sellableQuantity: String(total(sellable)), unsellableQuantity: String(total(unsellable)), batches,
    };
  }

  @Get('held')
  @BranchScoped()
  @RequirePermissions('sale:create')
  held() {
    return this.db.tx.sale.findMany({ where: { branchId: currentBranchId(), status: 'HELD' }, orderBy: { heldAt: 'desc' }, select: SALE_SELECT });
  }

  @Delete('held/:id')
  @HttpCode(204)
  @BranchScoped()
  @RequirePermissions('sale:create')
  async cancelHeld(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    await this.sales.cancelHeld(auth, currentBranchId(), id);
  }

  @Get()
  @BranchScoped()
  @RequirePermissions('sale:read')
  async list(@Query() q: ListSalesQueryDto) {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const range = dayRange(timezone, q.from, q.to);
    const where: Prisma.SaleWhereInput = {
      branchId: currentBranchId(),
      status: q.status ? q.status : { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED', 'VOIDED'] },
      ...(range ? { soldAt: range } : {}),
      ...(q.cashierId ? { cashierId: q.cashierId } : {}),
      ...(q.customerId ? { customerId: q.customerId } : {}),
      ...(q.registerSessionId ? { registerSessionId: q.registerSessionId } : {}),
      ...(q.search
        ? { OR: [{ invoiceNo: { contains: q.search, mode: 'insensitive' } }, { customer: { fullName: { contains: q.search, mode: 'insensitive' } } }, { customer: { phone: { contains: q.search } } }] }
        : {}),
    };
    const [rows, total, sums] = await Promise.all([
      tx.sale.findMany({
        where, orderBy: [{ soldAt: 'desc' }, { createdAt: 'desc' }], ...skipTake(q.page, q.pageSize),
        select: {
          id: true, invoiceNo: true, status: true, grandTotal: true, paidTotal: true, balanceDue: true, discountTotal: true, soldAt: true,
          cashier: { select: { id: true, fullName: true } }, customer: { select: { id: true, fullName: true } },
          payments: { where: { kind: 'SALE_PAYMENT' }, select: { method: true } }, _count: { select: { saleItems: true } },
        },
      }),
      tx.sale.count({ where }),
      tx.sale.aggregate({ where: { ...where, status: { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED'] } }, _sum: { grandTotal: true } }),
    ]);
    return {
      ...paged(
        rows.map(({ _count, payments, ...r }) => ({ ...r, itemCount: _count.saleItems, methods: [...new Set(payments.map((p) => p.method))] })),
        total, q.page, q.pageSize,
      ),
      totalSales: sums._sum.grandTotal?.toFixed(2) ?? '0.00',
    };
  }

  @Get(':id')
  @BranchScoped()
  @RequirePermissions('sale:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const s = await this.db.tx.sale.findFirst({ where: { id, branchId: currentBranchId() }, select: SALE_SELECT });
    if (!s) throw new NotFoundException('Sale not found');
    return s;
  }

  /** Everything a printed receipt needs. */
  @Get(':id/receipt')
  @BranchScoped()
  @RequirePermissions('sale:read')
  async receipt(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const s = await tx.sale.findFirst({ where: { id, branchId: currentBranchId() }, select: SALE_SELECT });
    if (!s) throw new NotFoundException('Sale not found');
    const tenant = await this.tenantInfo.get(tx);
    return { sale: s, tenant: { name: tenant.name, currencyCode: tenant.currencyCode, timezone: tenant.timezone } };
  }

  @Post(':id/void')
  @BranchScoped()
  @RequirePermissions('sale:void')
  void(@Param('id', ParseUUIDPipe) id: string, @Body() dto: VoidSaleDto, @CurrentAuth() auth: AuthContext) {
    return this.sales.void(auth, currentBranchId(), id, dto.reason);
  }

  @Post(':id/returns')
  @BranchScoped()
  @RequirePermissions('sale:return')
  createReturn(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateSalesReturnDto, @CurrentAuth() auth: AuthContext) {
    return this.sales.createReturn(auth, currentBranchId(), id, dto);
  }
}

@ApiTags('Sales')
@ApiCookieAuth()
@Controller('sales-returns')
export class SalesReturnsController {
  constructor(private readonly db: TenantDb, private readonly tenantInfo: TenantInfoService) {}

  @Get()
  @BranchScoped()
  @RequirePermissions('sale:read')
  async list(@Query() q: ListSalesReturnsQueryDto) {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const range = dayRange(timezone, q.from, q.to);
    const where: Prisma.SalesReturnWhereInput = {
      branchId: currentBranchId(),
      ...(range ? { returnDate: range } : {}),
      ...(q.search ? { OR: [{ number: { contains: q.search, mode: 'insensitive' } }, { sale: { invoiceNo: { contains: q.search, mode: 'insensitive' } } }] } : {}),
    };
    const [rows, total] = await Promise.all([
      tx.salesReturn.findMany({ where, orderBy: { createdAt: 'desc' }, select: SALES_RETURN_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.salesReturn.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get(':id')
  @BranchScoped()
  @RequirePermissions('sale:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const r = await this.db.tx.salesReturn.findFirst({ where: { id, branchId: currentBranchId() }, select: SALES_RETURN_SELECT });
    if (!r) throw new NotFoundException('Return not found');
    return r;
  }
}

@Module({
  imports: [InventoryCoreModule],
  controllers: [SalesController, SalesReturnsController],
  providers: [SalesService, PricingService],
  exports: [SalesService],
})
export class SalesModule {}
