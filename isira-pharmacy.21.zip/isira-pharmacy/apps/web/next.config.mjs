/** @type {import('next').NextConfig} */
const API_URL = process.env.API_URL ?? 'http://localhost:4000';

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Same-origin API: the browser only ever talks to the web app, which forwards /api/* to NestJS.
  // That keeps the session cookie httpOnly + SameSite and avoids CORS entirely.
  async rewrites() {
    return [{ source: '/api/:path*', destination: `${API_URL}/v1/:path*` }];
  },
  async headers() {
    const prod = process.env.NODE_ENV === 'production';
    // HSTS and upgrade-insecure-requests only when the site is actually served over HTTPS.
    const https = prod && (process.env.WEB_ORIGIN ?? '').startsWith('https://');
    // Next.js injects small inline bootstrap scripts, hence 'unsafe-inline' for scripts; everything else is same-origin only.
    const csp = [
      "default-src 'self'",
      `script-src 'self' 'unsafe-inline'${prod ? '' : " 'unsafe-eval'"}`,
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob:",
      "font-src 'self' data:",
      `connect-src 'self'${prod ? '' : ' ws: wss:'}`,
      "frame-src 'self' blob:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
      ...(https ? ['upgrade-insecure-requests'] : []),
    ].join('; ');
    const headers = [
      { key: 'Content-Security-Policy', value: csp },
      { key: 'X-Frame-Options', value: 'DENY' },
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=(), usb=()' },
      { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
    ];
    if (https) {
      headers.push({ key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains' });
    }
    return [{ source: '/:path*', headers }];
  },
};

export default nextConfig;
