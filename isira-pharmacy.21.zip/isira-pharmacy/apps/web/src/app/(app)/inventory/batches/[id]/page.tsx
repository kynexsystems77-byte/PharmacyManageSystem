'use client';

import Link from 'next/link';
import { useState } from 'react';
import { DataTable, KeyValue, Modal, PageHeader, Select, Textarea, useToast } from '@/components/kit';
import { ExpiryBadge } from '@/components/pickers';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, qty, titleCase, productName } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';

interface BatchDetail {
  id: string; batchNumber: string; expiryDate: string | null; manufactureDate: string | null; unitCost: string; sellingPrice: string | null;
  status: string; receivedAt: string; notes: string | null;
  product: { id: string; brandName: string; sku: string; baseUnit: string; genericName: string | null; strength: string | null };
  supplier: { id: string; name: string } | null;
  levels: { quantity: string; location: { id: string; name: string; type: string } }[];
  movements: { id: string; movementType: string; quantityDelta: string; unitCost: string; referenceType: string | null; reason: string | null; occurredAt: string; location: { name: string }; createdBy: { fullName: string } | null }[];
}

export default function BatchPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const toast = useToast();
  const cur = profile.tenant.currencyCode;
  const { data: b, isLoading, error } = useBranchQuery<BatchDetail>(`/inventory/batches/${params.id}`);
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({ status: 'ACTIVE', expiryDate: '', manufactureDate: '', notes: '' });
  const save = useApiMutation<object>('PATCH', `/inventory/batches/${params.id}`, { onSuccess: () => { toast.success('Batch updated'); setEdit(false); } });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !b) return <Alert>{errorMessage(error) || 'Batch not found'}</Alert>;
  const total = b.levels.reduce((a, l) => a + num(l.quantity), 0);

  return (
    <div className="space-y-4">
      <PageHeader
        back="/inventory/batches"
        title={`Batch ${b.batchNumber}`}
        subtitle={<Link className="text-brand hover:underline" href={`/medicines/${b.product.id}`}>{productName(b.product.brandName, b.product.strength)}</Link>}
        actions={can('inventory:adjust') && (
          <Button variant="outline" onClick={() => { setForm({ status: b.status === 'EXPIRED' ? 'ACTIVE' : b.status, expiryDate: b.expiryDate ?? '', manufactureDate: b.manufactureDate ?? '', notes: b.notes ?? '' }); setEdit(true); }}>
            Edit batch
          </Button>
        )}
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Batch" />
          <div className="p-4">
            <KeyValue items={[
              { label: 'Status', value: <Badge tone={b.status === 'ACTIVE' ? 'success' : 'warning'}>{titleCase(b.status)}</Badge> },
              { label: 'Expiry', value: <ExpiryBadge date={b.expiryDate} /> },
              { label: 'Manufactured', value: dateOnly(b.manufactureDate) },
              { label: 'Received', value: dateTime(b.receivedAt) },
              { label: 'Supplier', value: b.supplier?.name },
              ...(can('report:financial:view') ? [{ label: 'Unit cost', value: money(num(b.unitCost), cur) }] : []),
              { label: 'Batch selling price', value: b.sellingPrice ? money(num(b.sellingPrice), cur) : 'Product price' },
              { label: 'Notes', value: b.notes },
            ]} />
          </div>
        </Card>
        <Card>
          <CardHeader title="On hand in this branch" action={<b className="tabular">{qty(total)} {b.product.baseUnit}</b>} />
          <ul className="divide-y divide-line text-sm">
            {b.levels.map((l) => (
              <li key={l.location.id} className="flex justify-between px-4 py-2.5"><span>{l.location.name}</span><span className="tabular">{qty(num(l.quantity))}</span></li>
            ))}
            {b.levels.length === 0 && <li className="px-4 py-6 text-center text-fg-muted">No stock here</li>}
          </ul>
        </Card>
      </div>
      <Card>
        <CardHeader title="Movements (latest 50)" />
        <DataTable
          rows={b.movements}
          rowKey={(m) => m.id}
          columns={[
            { key: 't', header: 'When', cell: (m) => dateTime(m.occurredAt) },
            { key: 'type', header: 'Type', cell: (m) => titleCase(m.movementType) },
            { key: 'loc', header: 'Location', cell: (m) => m.location.name },
            { key: 'r', header: 'Reference / reason', cell: (m) => <span className="text-fg-muted">{m.reason ?? m.referenceType ?? '-'}</span> },
            { key: 'u', header: 'By', cell: (m) => m.createdBy?.fullName ?? 'System' },
            { key: 'q', header: 'Quantity', align: 'right', cell: (m) => <span className={num(m.quantityDelta) < 0 ? 'text-danger' : 'text-success'}>{num(m.quantityDelta) > 0 ? '+' : ''}{qty(num(m.quantityDelta))}</span> },
          ]}
        />
      </Card>

      <Modal open={edit} onClose={() => setEdit(false)} title="Edit batch" size="sm"
        footer={<><Button variant="outline" onClick={() => setEdit(false)}>Cancel</Button>
          <Button loading={save.isPending} onClick={() => save.mutate({ status: form.status, expiryDate: form.expiryDate || null, manufactureDate: form.manufactureDate || null, notes: form.notes || null })}>Save</Button></>}>
        <div className="space-y-3">
          {save.error && <Alert>{errorMessage(save.error)}</Alert>}
          <Field label="Status">
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              <option value="ACTIVE">Active (sellable)</option>
              <option value="QUARANTINED">Quarantined (blocked from sale)</option>
              <option value="RECALLED">Recalled (blocked from sale)</option>
            </Select>
          </Field>
          <Field label="Expiry date"><Input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} /></Field>
          <Field label="Manufacture date"><Input type="date" value={form.manufactureDate} onChange={(e) => setForm({ ...form, manufactureDate: e.target.value })} /></Field>
          <Field label="Notes"><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} maxLength={500} /></Field>
          <p className="text-xs text-fg-muted">Changes are recorded in the audit log.</p>
        </div>
      </Modal>
    </div>
  );
}
