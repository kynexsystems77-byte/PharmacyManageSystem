import { Injectable } from '@nestjs/common';
import { hash, verify } from '@node-rs/argon2';

/** Argon2id (the library default). */
@Injectable()
export class PasswordService {
  private dummyHash?: Promise<string>;

  hash(password: string): Promise<string> {
    return hash(password);
  }

  async verify(storedHash: string, password: string): Promise<boolean> {
    try {
      return await verify(storedHash, password);
    } catch {
      return false;
    }
  }

  /** Burns the same CPU time as a real check so response time does not reveal whether an email exists. */
  async verifyDummy(password: string): Promise<void> {
    this.dummyHash ??= hash('kynex-dummy-password');
    await this.verify(await this.dummyHash, password);
  }
}
