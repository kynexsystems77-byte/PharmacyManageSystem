import { randomUUID } from 'node:crypto';
import { hash } from '@node-rs/argon2';
import { PrismaClient } from '@prisma/client';
import { PERMISSIONS, SYSTEM_ROLES, type SystemRoleKey } from '../../contracts/src/permissions';
import { withTenant } from '../src/tenant-context';
import { DEFAULT_CATEGORIES } from '../src/default-categories';

/**
 * Seeds the global permission catalogue and one demo tenant.
 * Runs as the OWNER role (DIRECT_URL). Tenant tables have FORCE RLS, so every tenant write
 * still goes through withTenant(), exactly like the real application does.
 */
const url = process.env.DIRECT_URL;
if (!url) {
  throw new Error('DIRECT_URL is not set (see .env.example)');
}
const prisma = new PrismaClient({ datasourceUrl: url });

const SLUG = process.env.SEED_TENANT_SLUG ?? 'demo';
const PASSWORD = process.env.SEED_PASSWORD ?? 'ChangeMe123!';

/** Midnight UTC, `n` days from today (negative = in the past). */
function day(n: number): Date {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() + n);
  return d;
}

function must<T>(value: T | undefined, what: string): T {
  if (value === undefined) {
    throw new Error(`seed: missing ${what}`);
  }
  return value;
}

async function main(): Promise<void> {
  // 1. Global permission catalogue (no tenant, idempotent)
  for (const p of PERMISSIONS) {
    await prisma.permission.upsert({
      where: { key: p.key },
      update: { module: p.module, description: p.description },
      create: { key: p.key, module: p.module, description: p.description },
    });
  }
  const permissionId = new Map((await prisma.permission.findMany()).map((p) => [p.key, p.id]));

  // 2. Demo tenant (skipped if it already exists)
  const existing = await prisma.tenant.findUnique({ where: { slug: SLUG } });
  if (existing) {
    // Upgrades: give system roles of EVERY tenant any permissions added in later versions.
    const tenants = await prisma.tenant.findMany({ select: { id: true } });
    let added = 0;
    for (const t of tenants) {
      added += await withTenant(prisma, t.id, async (tx) => {
        let n = 0;
        const roles = await tx.role.findMany({ where: { isSystem: true, systemKey: { not: null } }, select: { id: true, systemKey: true } });
        for (const role of roles) {
          const def = SYSTEM_ROLES[role.systemKey as SystemRoleKey];
          if (!def) continue;
          const res = await tx.rolePermission.createMany({
            data: def.permissions.map((perm) => ({ tenantId: t.id, roleId: role.id, permissionId: must(permissionId.get(perm), `permission ${perm}`) })),
            skipDuplicates: true,
          });
          n += res.count;
        }
        return n;
      });
    }
    console.log(`Tenant "${SLUG}" already exists - demo data not re-seeded. System roles synced (+${added} permissions). Use "pnpm db:reset" to start over.`);
    return;
  }

  const tenantId = randomUUID();
  const passwordHash = await hash(PASSWORD);

  await withTenant(
    prisma,
    tenantId,
    async (tx) => {
      await tx.tenant.create({
        data: {
          id: tenantId,
          name: 'Isira Pharmacy',
          slug: SLUG,
          currencyCode: process.env.SEED_CURRENCY ?? 'USD',
          timezone: process.env.SEED_TIMEZONE ?? 'UTC',
        },
      });

      // Branch, locations, register
      const branch = await tx.branch.create({
        data: {
          tenantId, name: 'Kurunegala Main', code: 'MAIN', invoicePrefix: 'INV', address: '42 Colombo Road, Kurunegala', phone: '037 222 1450',
          receiptFooter: 'Thank you. Get well soon!\nMedicines are returnable within 7 days with this receipt.',
        },
      });
      const floor = await tx.location.create({
        data: { tenantId, branchId: branch.id, name: 'Sales Floor', type: 'SALES_FLOOR', isDefault: true },
      });
      await tx.location.create({ data: { tenantId, branchId: branch.id, name: 'Warehouse', type: 'WAREHOUSE' } });
      await tx.cashRegister.create({ data: { tenantId, branchId: branch.id, name: 'Main Register' } });

      // Roles + permissions
      const roleId = new Map<SystemRoleKey, string>();
      for (const [key, def] of Object.entries(SYSTEM_ROLES) as [SystemRoleKey, (typeof SYSTEM_ROLES)[SystemRoleKey]][]) {
        const role = await tx.role.create({
          data: {
            tenantId,
            name: def.name,
            description: def.description,
            isSystem: true,
            systemKey: key,
            maxDiscountPercent: def.maxDiscountPercent,
          },
        });
        roleId.set(key, role.id);
        await tx.rolePermission.createMany({
          data: def.permissions.map((perm) => ({
            tenantId,
            roleId: role.id,
            permissionId: must(permissionId.get(perm), `permission ${perm}`),
          })),
        });
      }

      // Users
      const people: { email: string; fullName: string; isOwner: boolean; role?: SystemRoleKey }[] = [
        { email: 'owner@demo.local', fullName: 'Demo Owner', isOwner: true },
        { email: 'manager@demo.local', fullName: 'Demo Manager', isOwner: false, role: 'MANAGER' },
        { email: 'pharmacist@demo.local', fullName: 'Demo Pharmacist', isOwner: false, role: 'PHARMACIST' },
        { email: 'cashier@demo.local', fullName: 'Demo Cashier', isOwner: false, role: 'CASHIER' },
      ];
      for (const p of people) {
        const user = await tx.user.create({
          data: { tenantId, email: p.email, fullName: p.fullName, passwordHash, isOwner: p.isOwner },
        });
        if (p.role) {
          await tx.userBranchRole.create({
            data: { tenantId, userId: user.id, branchId: branch.id, roleId: must(roleId.get(p.role), `role ${p.role}`) },
          });
        }
      }

      // Categories: Medicine and Groceries with sub-categories, plus Cosmetics
      const categoryId = new Map<string, string>();
      for (const [parent, subs] of Object.entries(DEFAULT_CATEGORIES)) {
        const top = await tx.category.create({ data: { tenantId, name: parent } });
        categoryId.set(parent, top.id);
        for (const [i, name] of subs.entries()) {
          const sub = await tx.category.create({ data: { tenantId, name, parentId: top.id, sortOrder: i } });
          categoryId.set(name, sub.id);
        }
      }

      const zeroTax = await tx.taxRate.create({ data: { tenantId, name: 'Zero rated', ratePercent: 0 } });
      const supplier = await tx.supplier.create({
        data: { tenantId, name: 'Demo Wholesale Supplies', contactName: 'Sales Desk', paymentTermsDays: 30 },
      });
      for (const name of ['Rent', 'Utilities', 'Salaries', 'Supplies', 'Other']) {
        await tx.expenseCategory.create({ data: { tenantId, name } });
      }

      // Demo products with batches. One batch is deliberately expired so FEFO/expiry blocking can be tested.
      const demo = [
        {
          sku: 'AMX500', barcode: '8900000000011', brandName: 'Amoxicillin 500mg', genericName: 'Amoxicillin', strength: '500 mg',
          dosageForm: 'CAPSULE' as const, category: 'Antibiotics', rx: true, price: 25, cost: 15, reorder: 50, expiry: true,
          batches: [{ no: 'AMX-A1', exp: day(25), qty: 40 }, { no: 'AMX-A2', exp: day(300), qty: 120 }],
        },
        {
          sku: 'OME20', barcode: '8900000000028', brandName: 'Omeprazole 20mg', genericName: 'Omeprazole', strength: '20 mg',
          dosageForm: 'CAPSULE' as const, category: 'Antacid', rx: false, price: 12, cost: 7, reorder: 40, expiry: true,
          batches: [{ no: 'OME-B1', exp: day(-10), qty: 30 }, { no: 'OME-B2', exp: day(400), qty: 200 }],
        },
        {
          sku: 'FCR50', barcode: '8900000000035', brandName: 'Face Cream 50g', genericName: null, strength: null,
          dosageForm: 'CREAM' as const, category: 'Cosmetics', rx: false, price: 450, cost: 300, reorder: 10, expiry: true,
          batches: [{ no: 'FC-1', exp: day(500), qty: 25 }],
        },
        // Groceries: sold through the same POS, with expiry tracking for food
        {
          sku: 'GRMP400', barcode: '8900000000042', brandName: 'Full Cream Milk Powder 400g', genericName: null, strength: null,
          dosageForm: 'OTHER' as const, category: 'Milk powder & baby food', rx: false, price: 1150, cost: 1020, reorder: 12, expiry: true,
          batches: [{ no: 'MP-2409', exp: day(18), qty: 18 }, { no: 'MP-2502', exp: day(320), qty: 24 }],
        },
        {
          sku: 'GRBIS100', barcode: '8900000000059', brandName: 'Marie Biscuits 100g', genericName: null, strength: null,
          dosageForm: 'OTHER' as const, category: 'Biscuits & snacks', rx: false, price: 120, cost: 96, reorder: 30, expiry: true,
          batches: [{ no: 'MB-0911', exp: day(150), qty: 60 }],
        },
        {
          sku: 'GRDW500', barcode: '8900000000066', brandName: 'Dishwash Liquid 500ml', genericName: null, strength: null,
          dosageForm: 'OTHER' as const, category: 'Household', rx: false, price: 390, cost: 310, reorder: 10, expiry: false,
          batches: [{ no: 'DW-001', exp: null, qty: 20 }],
        },
      ];

      for (const d of demo) {
        const product = await tx.product.create({
          data: {
            tenantId,
            sku: d.sku,
            barcode: d.barcode,
            brandName: d.brandName,
            genericName: d.genericName,
            strength: d.strength,
            dosageForm: d.dosageForm,
            categoryId: must(categoryId.get(d.category), `category ${d.category}`),
            taxRateId: zeroTax.id,
            preferredSupplierId: supplier.id,
            requiresPrescription: d.rx,
            trackExpiry: d.expiry,
            baseUnit: 'unit',
            sellingPrice: d.price,
            purchasePrice: d.cost,
            reorderLevel: d.reorder,
          },
        });
        for (const b of d.batches) {
          const batch = await tx.batch.create({
            data: {
              tenantId, productId: product.id, supplierId: supplier.id, batchNumber: b.no,
              expiryDate: b.exp, unitCost: d.cost, sellingPrice: d.price,
            },
          });
          await tx.stockLevel.create({
            data: { tenantId, branchId: branch.id, locationId: floor.id, productId: product.id, batchId: batch.id, quantity: b.qty },
          });
          await tx.inventoryMovement.create({
            data: {
              tenantId, branchId: branch.id, locationId: floor.id, productId: product.id, batchId: batch.id,
              movementType: 'OPENING_BALANCE', quantityDelta: b.qty, unitCost: d.cost, referenceType: 'SEED', reason: 'Seed opening balance',
            },
          });
        }
      }
    },
    { timeout: 120_000, maxWait: 20_000 },
  );

  console.log('');
  console.log(`Seeded demo tenant "${SLUG}" (id ${tenantId}).`);
  console.log('Users (all use the seed password):');
  console.log('  owner@demo.local | manager@demo.local | pharmacist@demo.local | cashier@demo.local');
  console.log(`Password: ${PASSWORD}   <- change it before any real use`);
}

main()
  .catch((err: unknown) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
