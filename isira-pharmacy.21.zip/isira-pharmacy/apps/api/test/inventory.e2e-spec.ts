import { INestApplication } from '@nestjs/common';
import { addStock, bootApp, createProduct, defaultLocationId, expectStatus, isoDay, login, uid } from './helpers';

describe('Catalogue and inventory (Phase 5)', () => {
  let app: INestApplication;
  beforeAll(async () => {
    app = await bootApp();
  });
  afterAll(async () => {
    await app.close();
  });

  it('creates a product with sale units and an automatic SKU, and blocks duplicate barcodes', async () => {
    const owner = await login(app, 'owner@demo.local');
    const barcode = `99${Date.now()}`;
    const p = await createProduct(owner, {
      barcode,
      units: [
        { name: 'Strip', factorToBase: 10, sellingPrice: 45, isDefaultSaleUnit: true },
        { name: 'Box', factorToBase: 100, barcode: `${barcode}9` },
      ],
    });
    expect(p.sku).toMatch(/^SKU-\d{6}$/);
    expect(p.productUnits.map((u) => u.name)).toEqual(['Strip', 'Box']);

    const dupe = await owner.post('/products', { brandName: 'Dupe', categoryId: (await owner.get('/categories')).body[0].id, barcode });
    expect(dupe.status).toBe(409);

    const byUnit = await owner.get(`/products/barcode/${barcode}9`);
    expectStatus(byUnit, 200);
    expect(byUnit.body.product.id).toBe(p.id);
    expect(byUnit.body.unitId).toBeTruthy();
  });

  it('enforces catalogue permissions (cashier cannot create, pharmacist cannot change prices)', async () => {
    const owner = await login(app, 'owner@demo.local');
    const p = await createProduct(owner);
    const cashier = await login(app, 'cashier@demo.local');
    const c = await cashier.post('/products', { brandName: 'X', categoryId: (await owner.get('/categories')).body[0].id });
    expect(c.status).toBe(403);

    const pharmacist = await login(app, 'pharmacist@demo.local');
    const rename = await pharmacist.patch(`/products/${p.id}`, { genericName: 'Renamed' });
    expectStatus(rename, 200);
    const price = await pharmacist.patch(`/products/${p.id}`, { sellingPrice: 99 });
    expect(price.status).toBe(403);
    expect(price.body.error.message).toMatch(/product:price:update/);
  });

  it('lists products with branch stock and searches by name', async () => {
    const owner = await login(app, 'owner@demo.local');
    const res = await owner.get('/products?search=amoxicillin&withStock=true');
    expectStatus(res, 200);
    expect(res.body.data[0].brandName).toMatch(/Amoxicillin/);
    expect(Number(res.body.data[0].stock)).toBeGreaterThan(0);
  });

  it('allocates FEFO: earliest expiry first, expired batches skipped', async () => {
    const owner = await login(app, 'owner@demo.local');
    const p = await createProduct(owner);
    const expired = await addStock(owner, p.id, { batchNumber: `EXP-${uid()}`, quantity: 50, expiryDate: isoDay(-5) });
    const soon = await addStock(owner, p.id, { batchNumber: `SOON-${uid()}`, quantity: 10, expiryDate: isoDay(20) });
    const later = await addStock(owner, p.id, { batchNumber: `LATE-${uid()}`, quantity: 100, expiryDate: isoDay(400) });

    const res = await owner.get(`/inventory/fefo?productId=${p.id}&quantity=25`);
    expectStatus(res, 200);
    expect(res.body.fulfilled).toBe(true);
    expect(res.body.allocations.map((a: { batchId: string; quantity: string }) => [a.batchId, Number(a.quantity)])).toEqual([
      [soon, 10],
      [later, 15],
    ]);
    expect(res.body.allocations.some((a: { batchId: string }) => a.batchId === expired)).toBe(false);

    const short = await owner.get(`/inventory/fefo?productId=${p.id}&quantity=500`);
    expect(Number(short.body.shortfall)).toBe(390);
  });

  it('records adjustments in the ledger and never lets stock go negative', async () => {
    const owner = await login(app, 'owner@demo.local');
    const p = await createProduct(owner);
    const locationId = await defaultLocationId(owner);
    const batchId = await addStock(owner, p.id, { quantity: 20, locationId });

    const tooMuch = await owner.post('/inventory/adjustments', { locationId, reason: 'LOST', items: [{ batchId, quantityDelta: -21 }] });
    expect(tooMuch.status).toBe(422);

    const ok = await owner.post('/inventory/adjustments', { locationId, reason: 'COUNT_CORRECTION', note: 'cycle count', items: [{ batchId, quantityDelta: -3 }] });
    expectStatus(ok, 201);
    expect(ok.body.number).toMatch(/^ADJ-\d{4}-\d{6}$/);

    const stock = await owner.get(`/products/${p.id}/stock`);
    expect(Number(stock.body.total)).toBe(17);

    const ledger = await owner.get(`/inventory/movements?productId=${p.id}`);
    expect(ledger.body.data.map((m: { movementType: string }) => m.movementType).sort()).toEqual(['ADJUSTMENT_OUT', 'OPENING_BALANCE']);
  });

  it('serialises concurrent stock-outs on the same batch (no overselling)', async () => {
    const owner = await login(app, 'owner@demo.local');
    const p = await createProduct(owner);
    const locationId = await defaultLocationId(owner);
    const batchId = await addStock(owner, p.id, { quantity: 10, locationId });
    const body = { locationId, reason: 'LOST', items: [{ batchId, quantityDelta: -7 }] };
    const results = await Promise.all([owner.post('/inventory/adjustments', body), owner.post('/inventory/adjustments', body)]);
    expect(results.map((r) => r.status).sort()).toEqual([201, 422]);
    const stock = await owner.get(`/products/${p.id}/stock`);
    expect(Number(stock.body.total)).toBe(3);
  });

  it('writes off expired stock only when it has actually expired', async () => {
    const owner = await login(app, 'owner@demo.local');
    const p = await createProduct(owner);
    const locationId = await defaultLocationId(owner);
    const expired = await addStock(owner, p.id, { quantity: 8, expiryDate: isoDay(-1), locationId });
    const fresh = await addStock(owner, p.id, { quantity: 8, expiryDate: isoDay(100), locationId });

    const wrong = await owner.post('/inventory/write-offs', { locationId, reason: 'EXPIRED', items: [{ batchId: fresh, quantity: 1 }] });
    expect(wrong.status).toBe(422);

    const res = await owner.post('/inventory/write-offs', { locationId, reason: 'EXPIRED', items: [{ batchId: expired, quantity: 8 }] });
    expectStatus(res, 201);
    const batch = await owner.get(`/inventory/batches/${expired}`);
    expect(batch.body.status).toBe('EXPIRED');
    expect(batch.body.movements[0].movementType).toBe('EXPIRED_WRITE_OFF');
  });

  it('shows the stock overview with expired filter', async () => {
    const owner = await login(app, 'owner@demo.local');
    const res = await owner.get('/inventory/stock?filter=expired&search=Omeprazole');
    expectStatus(res, 200);
    expect(res.body.data[0].brandName).toMatch(/Omeprazole/);
    expect(res.body.totals.onHandValue).not.toBeNull();

    const cashier = await login(app, 'cashier@demo.local');
    const c = await cashier.get('/inventory/stock');
    expectStatus(c, 200);
    expect(c.body.data[0].value).toBeNull(); // no report:financial:view
  });

  it('transfers stock between branches: dispatch, receive, and no double receipt', async () => {
    const owner = await login(app, 'owner@demo.local');
    const code = `T${uid()}`.slice(0, 8);
    const branch = await owner.agent.post('/v1/branches').set('X-Kynex-Csrf', '1').send({ name: `Zz Transfer Test ${code}`, code });
    expectStatus(branch, 201);
    const p = await createProduct(owner);
    const fromLocationId = await defaultLocationId(owner);
    const batchId = await addStock(owner, p.id, { quantity: 30, locationId: fromLocationId });

    const t = await owner.post('/inventory/transfers', { fromLocationId, toBranchId: branch.body.id, items: [{ batchId, quantity: 12 }] });
    expectStatus(t, 201);
    expect(t.body.status).toBe('DISPATCHED');
    expect(Number((await owner.get(`/products/${p.id}/stock`)).body.total)).toBe(18);

    const owner2 = await login(app, 'owner@demo.local', branch.body.id);
    const item = t.body.stockTransferItems[0];
    const r = await owner2.post(`/inventory/transfers/${t.body.id}/receive`, { items: [{ itemId: item.id, receivedQuantity: 11 }] });
    expectStatus(r, 201);
    expect(r.body.status).toBe('RECEIVED');
    expect(Number((await owner2.get(`/products/${p.id}/stock`)).body.total)).toBe(11);

    const again = await owner2.post(`/inventory/transfers/${t.body.id}/receive`, {});
    expect(again.status).toBe(409);
    const cancel = await owner.post(`/inventory/transfers/${t.body.id}/cancel`);
    expect(cancel.status).toBe(409);
  });

  it('manages categories and refuses to delete one that has products', async () => {
    const owner = await login(app, 'owner@demo.local');
    const parent = await owner.post('/categories', { name: `Cat ${uid()}` });
    expectStatus(parent, 201);
    const child = await owner.post('/categories', { name: 'Child', parentId: parent.body.id });
    expectStatus(child, 201);
    const loop = await owner.patch(`/categories/${parent.body.id}`, { parentId: child.body.id });
    expect(loop.status).toBe(400);
    await createProduct(owner, { categoryId: child.body.id });
    expect((await owner.del(`/categories/${child.body.id}`)).status).toBe(409);
    expect((await owner.del(`/categories/${parent.body.id}`)).status).toBe(409);
  });
});
