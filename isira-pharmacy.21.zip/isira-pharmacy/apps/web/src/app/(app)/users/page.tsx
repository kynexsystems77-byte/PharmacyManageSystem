'use client';

import { Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { BranchRolesEditor, type BranchRole } from '@/components/branch-roles-editor';
import { Checkbox, DataTable, Forbidden, Modal, PageHeader, Pagination, SearchBox, Select, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, titleCase } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { UserRow } from '@/lib/types';

export default function UsersPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<UserRow>>(can('user:read') ? `/users${qs({ page, pageSize: 25, search: s, status })}` : null, { keepPrevious: true });
  const [form, setForm] = useState<{ email: string; fullName: string; phone: string; password: string; isOwner: boolean; branchRoles: BranchRole[] } | null>(null);
  const create = useApiMutation<object, UserRow>('POST', '/users', { onSuccess: (u) => { toast.success(`${u.fullName} can now sign in`); setForm(null); router.push(`/users/${u.id}`); } });
  if (!can('user:read')) return <Forbidden what="users" />;
  return (
    <div>
      <PageHeader title="Users" actions={can('user:manage') && <Button onClick={() => setForm({ email: '', fullName: '', phone: '', password: '', isOwner: false, branchRoles: [] })}><Plus size={16} /> New user</Button>} />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_180px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Name or email" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status"><option value="">Any status</option><option value="ACTIVE">Active</option><option value="DISABLED">Disabled</option></Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(u) => u.id}
          onRowClick={(u) => router.push(`/users/${u.id}`)}
          columns={[
            { key: 'n', header: 'User', cell: (u) => <div><p className="font-medium">{u.fullName}</p><p className="text-xs text-fg-muted">{u.email}</p></div> },
            { key: 'r', header: 'Access', cell: (u) => (u.isOwner ? <Badge tone="success">Owner · all branches</Badge> : <span className="text-fg-muted">{u.userBranchRoles.map((r) => `${r.role.name} @ ${r.branch.name}`).join(', ') || 'No access'}</span>) },
            { key: 's', header: 'Status', cell: (u) => <Badge tone={u.status === 'ACTIVE' ? 'success' : 'danger'}>{titleCase(u.status)}</Badge> },
            { key: 'l', header: 'Last sign-in', cell: (u) => dateTime(u.lastLoginAt) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
      <Modal open={Boolean(form)} onClose={() => setForm(null)} title="New user" size="lg"
        footer={<><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button loading={create.isPending} disabled={!form?.email || (form?.fullName.trim().length ?? 0) < 2 || (form?.password.length ?? 0) < 10} onClick={() => form && create.mutate({ ...form, phone: form.phone.trim() || undefined, branchRoles: form.branchRoles.filter((r) => r.branchId && r.roleId) })}>Create user</Button></>}>
        {form && (
          <div className="space-y-4">
            {create.error && <Alert>{errorMessage(create.error)}</Alert>}
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Full name *"><Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} autoFocus /></Field>
              <Field label="Email (sign-in) *"><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
              <Field label="Phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
              <Field label="Temporary password * (10+ characters)"><Input type="password" autoComplete="new-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
            </div>
            {profile.user.isOwner && <Checkbox label="Owner" hint="Full access to every branch, including settings and roles" checked={form.isOwner} onChange={(v) => setForm({ ...form, isOwner: v })} />}
            {!form.isOwner && <div><p className="mb-2 text-sm font-medium">Branch access</p><BranchRolesEditor value={form.branchRoles} onChange={(v) => setForm({ ...form, branchRoles: v })} /></div>}
            <p className="text-xs text-fg-muted">You can only grant permissions you hold yourself.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}
