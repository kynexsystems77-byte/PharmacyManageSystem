import {
  BadRequestException, Body, ConflictException, Controller, Delete, ForbiddenException, Get, HttpCode, Module,
  NotFoundException, Param, ParseUUIDPipe, Patch, Post, Put,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { createRoleSchema, setRolePermissionsSchema, updateRoleSchema } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { AccessService } from '../auth/access.service';
import { AuditService } from '../audit/audit.service';
import { CurrentAuth, RequirePermissions } from '../common/decorators';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class CreateRoleDto extends createZodDto(createRoleSchema) {}
class UpdateRoleDto extends createZodDto(updateRoleSchema) {}
class SetRolePermissionsDto extends createZodDto(setRolePermissionsSchema) {}

const SYSTEM_ROLE_MSG = 'System roles cannot be changed. Create a custom role instead.';

@ApiTags('Roles')
@ApiCookieAuth()
@Controller()
export class RolesController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly access: AccessService) {}

  private async view(tx: Prisma.TransactionClient, id: string) {
    const role = await tx.role.findUnique({
      where: { id },
      select: {
        id: true, name: true, description: true, isSystem: true, systemKey: true, maxDiscountPercent: true,
        rolePermissions: { select: { permission: { select: { key: true } } } },
        _count: { select: { userBranchRoles: true } },
      },
    });
    if (!role) throw new NotFoundException('Role not found');
    const { rolePermissions, _count, ...rest } = role;
    return { ...rest, permissions: rolePermissions.map((rp) => rp.permission.key).sort(), assignedUsers: _count.userBranchRoles };
  }

  private async writePermissions(tx: Prisma.TransactionClient, tenantId: string, roleId: string, keys: readonly string[]) {
    const found = await tx.permission.findMany({ where: { key: { in: [...keys] } }, select: { id: true, key: true } });
    if (found.length !== new Set(keys).size) throw new BadRequestException('Unknown permission key');
    await tx.rolePermission.deleteMany({ where: { roleId } });
    await tx.rolePermission.createMany({ data: found.map((p) => ({ tenantId, roleId, permissionId: p.id })) });
  }

  @Get('permissions')
  @RequirePermissions('role:read')
  permissions() {
    return this.db.tx.permission.findMany({ orderBy: [{ module: 'asc' }, { key: 'asc' }] });
  }

  @Get('roles')
  @RequirePermissions('role:read')
  async list() {
    const ids = await this.db.tx.role.findMany({ select: { id: true }, orderBy: [{ isSystem: 'desc' }, { name: 'asc' }] });
    const out = [];
    for (const { id } of ids) out.push(await this.view(this.db.tx, id));
    return out;
  }

  @Get('roles/:id')
  @RequirePermissions('role:read')
  get(@Param('id', ParseUUIDPipe) id: string) {
    return this.view(this.db.tx, id);
  }

  @Post('roles')
  @RequirePermissions('role:manage')
  async create(@Body() dto: CreateRoleDto, @CurrentAuth() auth: AuthContext) {
    this.access.assertCanGrant(auth, dto.permissions);
    const tx = this.db.tx;
    const role = await tx.role.create({
      data: { tenantId: auth.tenantId, name: dto.name, description: dto.description, maxDiscountPercent: dto.maxDiscountPercent },
    });
    await this.writePermissions(tx, auth.tenantId, role.id, dto.permissions);
    const after = await this.view(tx, role.id);
    await this.audit.record({ action: 'role.created', entityType: 'role', entityId: role.id, after });
    return after;
  }

  @Patch('roles/:id')
  @RequirePermissions('role:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateRoleDto) {
    const tx = this.db.tx;
    const before = await this.view(tx, id);
    if (before.isSystem) throw new ForbiddenException(SYSTEM_ROLE_MSG);
    await tx.role.update({ where: { id }, data: dto });
    const after = await this.view(tx, id);
    await this.audit.record({ action: 'role.updated', entityType: 'role', entityId: id, before, after });
    return after;
  }

  @Put('roles/:id/permissions')
  @RequirePermissions('role:manage')
  async setPermissions(@Param('id', ParseUUIDPipe) id: string, @Body() dto: SetRolePermissionsDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await this.view(tx, id);
    if (before.isSystem) throw new ForbiddenException(SYSTEM_ROLE_MSG);
    this.access.assertCanGrant(auth, dto.permissions);
    await this.writePermissions(tx, auth.tenantId, id, dto.permissions);
    const after = await this.view(tx, id);
    await this.audit.record({ action: 'role.permissions_changed', entityType: 'role', entityId: id, before, after });
    return after;
  }

  @Delete('roles/:id')
  @HttpCode(204)
  @RequirePermissions('role:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string): Promise<void> {
    const tx = this.db.tx;
    const before = await this.view(tx, id);
    if (before.isSystem) throw new ForbiddenException(SYSTEM_ROLE_MSG);
    if (before.assignedUsers > 0) throw new ConflictException('This role is still assigned to users');
    await tx.role.delete({ where: { id } });
    await this.audit.record({ action: 'role.deleted', entityType: 'role', entityId: id, before });
  }
}

@Module({ controllers: [RolesController] })
export class RolesModule {}
