# Isira Pharmacy

Multi-tenant pharmacy management and point-of-sale SaaS. It's a pnpm monorepo:

| Package | What it is |
|---|---|
| `apps/api` | NestJS REST API (`/v1`). It has a second entry point, the background **worker** (`dist/worker/main.js`). |
| `apps/web` | Next.js 14 web app. It proxies `/api/*` to the API, so the session cookie stays httpOnly and same-origin. |
| `packages/database` | Prisma schema and committed migrations. Also holds `security.sql` (Row-Level Security, triggers and grants), the seed script and the tenant-provisioning script. |
| `packages/contracts` | Zod schemas, permission keys and report definitions, shared by the API and the web app. |

## Features by phase

| Phase | Area | What you get |
|---|---|---|
| 2 | Database | 53 models and PostgreSQL RLS tenant isolation. Same-tenant foreign-key triggers, append-only ledgers, and CHECK constraints such as stock never going below zero. |
| 3 | API core | Sessions (Argon2id, lockout), per-branch RBAC, branches, users, roles, audit log, Swagger, rate limits. |
| 4 | Web shell | Login, branch switcher, dark/light theme, permission-aware navigation, dashboard. |
| 5 | Medicines and inventory | Catalogue covering categories, generic and brand names, units and conversions, barcodes and tax rates. Batches with expiry dates, stock levels per location, adjustments with approval, and transfers between branches. Stock moves through a FEFO ledger. |
| 6 | Purchasing | Suppliers and purchase orders. Goods receipts create batches and stock. Also purchase returns and supplier payments, with a supplier ledger. |
| 7 | POS and billing | Fast POS with keyboard shortcuts and FEFO batch picking. Supports split payments, hold/resume, discounts within role limits and cash-register shifts. Prints an 80 mm receipt and an A4 invoice PDF. Handles returns and refunds and voiding a sale. |
| 8 | Customers and prescriptions | Customers with credit limits, a ledger and payments. Prescriptions carry scanned attachments (S3/MinIO or local disk) and are linked to sales. |
| 9 | Finance | Expenses, profit and loss net of returns, cash reconciliation per shift, and finance settings. |
| 10 | Reports | 15+ reports: sales, stock valuation, expiry, slow movers, receivables aging, profit and more. Each exports to **CSV, Excel and PDF**. |
| 11 | Notifications and jobs | Low-stock and expiry alerts with per-user read state, plus a transactional outbox. A BullMQ worker on Redis handles them (a timer fallback runs without Redis). Emails are queued. |
| 12 | Hardening and deploy | TOTP two-factor sign-in with recovery codes, Redis-backed rate limits, CSP/HSTS security headers and the committed init migration. Also Docker images, a production compose file, CI, tenant provisioning, a k6 load script and the `docs/` guides. |

## Latest updates

- **Name and addresses:** the app is branded **Isira Pharmacy**. Change the pharmacy name in *Finance → Settings → Company*. Change each branch's address, phone and receipt footer in *Finance → Settings → Branch addresses*. The sign-in page name comes from `NEXT_PUBLIC_APP_NAME`.
- **Expiry popup at the POS:** when a product is scanned, the till checks which batch will be sold (earliest expiry first). If that batch expires within the warning days (*Settings → Warn at the POS…*, default 30), a popup shows the batch, its expiry date and the days left, with an alert sound. The popup is red when 7 days or fewer are left, or when expired stock is still on the shelf. Stock that cannot be sold is never added. A popup accepted once does not repeat for the same product on that bill. API: `GET /v1/sales/expiry-check?productId=…`.
- **Supplier discount on Receive goods:** enter the supplier price and a discount as a %, an amount per unit, or a total for the line. Example: price 2,000 less 500 per unit gives a cost of 1,500. The form shows cost per unit, selling price, profit per unit with margin, profit for the line, and "Profit when all sold" for the whole invoice. The net cost becomes the batch cost and the product's purchase price, so sales profit is correct (2,000 − 1,500 = 500). The purchase detail page shows net cost and profit per unit.

## Run it locally

Prerequisites: Node.js 20+, pnpm 9 (`corepack enable`) and Docker Desktop.

```bash
cp .env.example .env              # Windows: copy .env.example .env
pnpm install
pnpm infra:up                     # PostgreSQL, Redis, MinIO (wait ~15 s; check with: docker compose ps)
pnpm db:generate                  # Prisma client
pnpm db:deploy                    # applies prisma/migrations, then the RLS/security layer (db:harden)
pnpm db:seed                      # demo pharmacy and logins (password ChangeMe123!)
pnpm dev                          # API on :4000 and web on :3000
pnpm --filter @kynex/api worker:dev   # second terminal: alerts, outbox, queued email
```

Open http://localhost:3000 and sign in with one of these demo accounts:

| Account | Role |
|---|---|
| `owner@demo.local` | Owner: everything |
| `manager@demo.local` | Manager |
| `pharmacist@demo.local` | Pharmacist |
| `cashier@demo.local` | Cashier: POS only, no costs or profit |

All use the password `ChangeMe123!`.

Useful extras:
- Swagger UI: http://localhost:4000/docs. Health check: http://localhost:4000/health.
- MinIO console: http://localhost:9001. Without `S3_ENDPOINT`, uploads go to `./storage`.
- With `SMTP_HOST` empty, password-reset links are printed in the API (or worker) log.

**Schema changes:** edit `schema.prisma`, run `pnpm db:migrate` (it creates a new migration; commit it), then run `pnpm db:harden`. `pnpm db:reset` wipes and rebuilds the development database.

## Create a real pharmacy (tenant)

```bash
TENANT_NAME="City Pharmacy" TENANT_SLUG=city OWNER_EMAIL=owner@city.lk OWNER_NAME="Ann Perera" \
OWNER_PASSWORD='use-a-long-password' CURRENCY=LKR TIMEZONE=Asia/Colombo pnpm tenant:create
```

This creates:
- the tenant
- the first branch, with a sales floor, a store room and one register
- the system roles
- a zero-rated tax rate
- the expense categories
- the owner account

The owner then adds branches, users, products and suppliers from the web app.

## Tests

```bash
pnpm typecheck          # every package
pnpm db:test            # database guarantees: RLS isolation, cross-tenant refs, append-only ledgers
pnpm api:test           # 73 end-to-end API tests against the real database
```

The API suites are:

| Suite | Covers |
|---|---|
| `api` | Sign-in, sessions and tenant isolation through the API |
| `dashboard` | Dashboard figures and permission filtering |
| `inventory` | Stock, batches, adjustments, transfers, FEFO |
| `purchasing` | Orders, receipts, returns, supplier payments |
| `sales` | POS sales, refunds, voids, shifts |
| `customers` | Customers, credit, payments, prescriptions |
| `finance` | Expenses, P&L, reconciliation |
| `reports` | Every report and its exports |
| `notifications` | Alerts and the outbox, including BullMQ when `REDIS_URL` is set |
| `security` | Two-factor sign-in, Redis rate limits, security headers |
| `pharmacy-updates` | Expiry popup check, supplier discount and profit, pharmacy name and branch address |

Load test against a staging copy (it creates real sales): `k6 run -e BASE_URL=https://staging.example.com tools/load/k6-pos.js`.

## Deploy with Docker

```bash
cp .env.production.example .env.production      # set every CHANGE value
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
# behind Caddy with automatic HTTPS (set DOMAIN, and TRUST_PROXY=2):
docker compose -f docker-compose.prod.yml --env-file .env.production --profile tls up -d --build
```

The stack has these services:

| Service | What it does |
|---|---|
| `postgres` | Database. On first start it creates the two roles: `kynex_owner` for migrations and `kynex_app` for the API, which cannot bypass RLS. |
| `redis` | Queue and rate-limit store. |
| `migrate` | One-shot job: runs `prisma migrate deploy`, then the security layer. With `SEED_DEMO=true` it also loads the demo data. |
| `api` | The API. Waits for `migrate` to finish. |
| `worker` | Background jobs. Waits for `migrate` to finish. |
| `web` | The web app on `WEB_PORT`. |
| `caddy` | Optional, `tls` profile. Puts automatic HTTPS in front. |

Create the first pharmacy inside the stack:

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production run --rm \
  -e TENANT_NAME="City Pharmacy" -e TENANT_SLUG=city -e OWNER_EMAIL=owner@city.lk -e OWNER_NAME="Ann Perera" \
  -e OWNER_PASSWORD='use-a-long-password' -e CURRENCY=LKR -e TIMEZONE=Asia/Colombo \
  migrate sh -c "cd /app/packages/database && ./node_modules/.bin/tsx scripts/create-tenant.ts"
```

To upgrade, pull the new code and run the same `up -d --build`. The `migrate` job applies new migrations before the API starts.

For backups, monitoring and the go-live checklist, see [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). The security model is in [docs/SECURITY.md](docs/SECURITY.md).

## Environment variables

| Variable | Used by | Notes |
|---|---|---|
| `DATABASE_URL` | api, worker | `kynex_app` role (RLS enforced) |
| `DIRECT_URL` | migrate, seed, tenant:create | `kynex_owner` role |
| `WEB_ORIGIN` | api, web build | Public URL. `https://` turns on HSTS and Secure cookies. |
| `API_URL` | web build | Where `/api/*` is proxied. Baked in at build time. |
| `REDIS_URL` | api, worker | Queue and shared rate limits. Optional in development. |
| `MFA_ENCRYPTION_KEY` | api | **Required in production.** 32+ random characters. |
| `COOKIE_SECURE` | api | `auto`, `true` or `false` |
| `TRUST_PROXY` | api | Number of reverse proxies in front of the API: 1 for web only, 2 with Caddy |
| `S3_*` / `STORAGE_DIR` | api | Prescription attachments |
| `SMTP_*`, `MAIL_FROM` | worker | Password-reset email |
| `ALERT_SCAN_MINUTES` | worker | Low-stock and expiry scan interval |
| `SESSION_IDLE_MINUTES`, `SESSION_MAX_HOURS`, `LOGIN_MAX_ATTEMPTS`, `LOGIN_LOCK_MINUTES` | api | Session and lockout policy |

## API overview (`/v1`, session cookie and `X-Kynex-Csrf: 1` on writes; branch routes need `X-Branch-Id`)

| Area | Main endpoints |
|---|---|
| Auth | `auth/login`, `auth/login/mfa`, `auth/logout`, `auth/me`, `auth/password/{forgot,reset,change}`, `auth/mfa`, `auth/mfa/{setup,enable,disable,recovery-codes}` |
| Admin | `tenant`, `branches`, `users` (`/:id/password`, `/:id/mfa/reset`), `roles`, `permissions`, `audit-logs` |
| Catalogue | `categories`, `manufacturers`, `products` (units and barcodes nested), `tax-rates` |
| Inventory | `inventory/{stock,batches,movements,fefo,opening-stock,write-offs,adjustments,transfers}` |
| Purchasing | `suppliers`, `purchase-orders`, `purchases`, `purchase-returns`, `suppliers/:id/payments` |
| Sales | `registers`, `sales`, `sales/held`, `sales/:id/receipt`, `sales/:id/invoice.pdf`, `sales-returns` |
| Customers | `customers`, `customers/:id/payments`, `prescriptions`, `attachments` |
| Finance | `finance/{summary,expenses,expense-categories,reconciliation}`, `settings`, `shifts` |
| Reports | `reports`, `reports/:key?format=json|csv|xlsx|pdf` |
| Notifications | `notifications`, `notifications/unread-count`, `notifications/:id/read`, `notifications/read-all` |
| System | `GET /health` (public) |

Errors look like `{ "error": { "code", "message", "details?", "requestId" } }`. Lists return `{ data, meta }`.

## Troubleshooting

- **Port 5432, 6379 or 9000 already in use:** stop the local service, or change the port in `docker-compose.yml` and `.env`.
- **Passwords changed after the first `infra:up`:** run `pnpm infra:reset` (it deletes development data), then start again.
- **`permission denied` after a migration:** run `pnpm db:harden`.
- **API refuses to start in production with `MFA_ENCRYPTION_KEY: is required`:** set it as shown in `.env.production.example`.
- **Login works over HTTPS but not over plain-HTTP LAN:** keep `COOKIE_SECURE=auto` and set `WEB_ORIGIN` to the `http://` address.
- **Windows:** keep `infra/postgres/01-init.sh` and `infra/docker/migrate.sh` with LF line endings (`.gitattributes` handles this).
