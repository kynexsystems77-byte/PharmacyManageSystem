import {
  BadRequestException, Body, ConflictException, Controller, Delete, Get, HttpCode, Module, NotFoundException, Param,
  ParseUUIDPipe, Patch, Post, Query,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import {
  createPurchaseOrderSchema, createPurchaseReturnSchema, createPurchaseSchema, createSupplierPaymentSchema, createSupplierSchema,
  listPurchaseOrdersQuerySchema, listPurchaseReturnsQuerySchema, listPurchasesQuerySchema, listSuppliersQuerySchema,
  paginationSchema, receivePurchaseSchema, updatePurchaseOrderSchema, updatePurchaseSchema, updateSupplierSchema,
} from '@kynex/contracts';
import { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId } from '../common/branch';
import { partyBalance } from '../common/cash';
import { dec, money2, optionalDate, parseDateOnly, SequenceService, sumDec, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { InventoryCoreModule } from '../inventory/inventory-core.module';
import { StockService } from '../inventory/stock.service';
import { TenantDb } from '../prisma/prisma.service';
import { computeLines, PURCHASE_RETURN_SELECT, PURCHASE_SELECT, PurchasingService } from './purchasing.service';

class CreateSupplierDto extends createZodDto(createSupplierSchema) {}
class UpdateSupplierDto extends createZodDto(updateSupplierSchema) {}
class ListSuppliersQueryDto extends createZodDto(listSuppliersQuerySchema) {}
class CreatePurchaseOrderDto extends createZodDto(createPurchaseOrderSchema) {}
class UpdatePurchaseOrderDto extends createZodDto(updatePurchaseOrderSchema) {}
class ListPurchaseOrdersQueryDto extends createZodDto(listPurchaseOrdersQuerySchema) {}
class CreatePurchaseDto extends createZodDto(createPurchaseSchema) {}
class UpdatePurchaseDto extends createZodDto(updatePurchaseSchema) {}
class ReceivePurchaseDto extends createZodDto(receivePurchaseSchema) {}
class ListPurchasesQueryDto extends createZodDto(listPurchasesQuerySchema) {}
class CreateSupplierPaymentDto extends createZodDto(createSupplierPaymentSchema) {}
class CreatePurchaseReturnDto extends createZodDto(createPurchaseReturnSchema) {}
class ListPurchaseReturnsQueryDto extends createZodDto(listPurchaseReturnsQuerySchema) {}
class PageQueryDto extends createZodDto(paginationSchema) {}

const SUPPLIER_SELECT = {
  id: true, name: true, contactName: true, phone: true, email: true, address: true, taxNumber: true,
  paymentTermsDays: true, notes: true, isActive: true, createdAt: true,
} satisfies Prisma.SupplierSelect;

// =============================================================================================
// Suppliers, their ledger (statement) and payments
// =============================================================================================
@ApiTags('Purchasing')
@ApiCookieAuth()
@Controller('suppliers')
export class SuppliersController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly purchasing: PurchasingService,
    private readonly tenantInfo: TenantInfoService,
  ) {}

  @Get()
  @RequirePermissions('supplier:read')
  async list(@Query() q: ListSuppliersQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.SupplierWhereInput = {
      deletedAt: null,
      ...(q.status === 'active' ? { isActive: true } : q.status === 'inactive' ? { isActive: false } : {}),
      ...(q.search
        ? { OR: [{ name: { contains: q.search, mode: 'insensitive' } }, { phone: { contains: q.search } }, { contactName: { contains: q.search, mode: 'insensitive' } }] }
        : {}),
    };
    const [rows, total] = await Promise.all([
      tx.supplier.findMany({ where, orderBy: { name: 'asc' }, select: SUPPLIER_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.supplier.count({ where }),
    ]);
    if (q.withBalance !== 'true') return paged(rows, total, q.page, q.pageSize);
    const sums = await tx.partyLedgerEntry.groupBy({ by: ['supplierId'], where: { supplierId: { in: rows.map((r) => r.id) } }, _sum: { amount: true } });
    const bal = new Map(sums.map((s) => [s.supplierId, dec(s._sum.amount).toFixed(2)]));
    return paged(rows.map((r) => ({ ...r, balance: bal.get(r.id) ?? '0.00' })), total, q.page, q.pageSize);
  }

  /** Suppliers we owe money to, with overdue amounts (by invoice due date). */
  @Get('payables')
  @RequirePermissions('supplier:read')
  async payables() {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const today = todayIn(timezone);
    const rows = await tx.$queryRaw<{ id: string; name: string; phone: string | null; balance: string; overdue: string; open_invoices: number; oldest_due: Date | null }[]>`
      WITH bal AS (SELECT supplier_id, SUM(amount) AS balance FROM party_ledger_entries WHERE supplier_id IS NOT NULL GROUP BY supplier_id),
           inv AS (
             SELECT supplier_id,
                    SUM(grand_total - paid_total) FILTER (WHERE due_date < ${today}::date) AS overdue,
                    COUNT(*)::int AS open_invoices,
                    MIN(due_date) AS oldest_due
             FROM purchases WHERE status = 'RECEIVED' AND paid_total < grand_total GROUP BY supplier_id)
      SELECT s.id, s.name, s.phone, ROUND(COALESCE(bal.balance, 0), 2)::text AS balance,
             ROUND(COALESCE(inv.overdue, 0), 2)::text AS overdue, COALESCE(inv.open_invoices, 0)::int AS open_invoices, inv.oldest_due
      FROM suppliers s
      LEFT JOIN bal ON bal.supplier_id = s.id
      LEFT JOIN inv ON inv.supplier_id = s.id
      WHERE s.deleted_at IS NULL AND (COALESCE(bal.balance, 0) <> 0 OR inv.open_invoices > 0)
      ORDER BY COALESCE(inv.overdue, 0) DESC, COALESCE(bal.balance, 0) DESC`;
    const total = sumDec(rows.map((r) => r.balance));
    const overdue = sumDec(rows.map((r) => r.overdue));
    return {
      today,
      totalPayable: total.toFixed(2),
      totalOverdue: overdue.toFixed(2),
      suppliers: rows.map((r) => ({ id: r.id, name: r.name, phone: r.phone, balance: r.balance, overdue: r.overdue, openInvoices: r.open_invoices, oldestDue: r.oldest_due?.toISOString().slice(0, 10) ?? null })),
    };
  }

  @Get(':id')
  @RequirePermissions('supplier:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const s = await tx.supplier.findFirst({ where: { id, deletedAt: null }, select: SUPPLIER_SELECT });
    if (!s) throw new NotFoundException('Supplier not found');
    const { timezone } = await this.tenantInfo.get(tx);
    const today = parseDateOnly(todayIn(timezone));
    const open = await tx.purchase.findMany({
      where: { supplierId: id, status: 'RECEIVED', paidTotal: { lt: tx.purchase.fields.grandTotal } },
      orderBy: { purchaseDate: 'asc' },
      select: { id: true, number: true, supplierInvoiceNo: true, purchaseDate: true, dueDate: true, grandTotal: true, paidTotal: true },
    });
    const balance = await partyBalance(tx, { supplierId: id });
    const overdue = sumDec(open.filter((p) => p.dueDate && p.dueDate < today).map((p) => dec(p.grandTotal).minus(p.paidTotal)));
    return {
      ...s,
      balance: balance.toFixed(2),
      overdue: overdue.toFixed(2),
      openInvoices: open.map((p) => ({ ...p, outstanding: dec(p.grandTotal).minus(p.paidTotal).toFixed(2), overdue: Boolean(p.dueDate && p.dueDate < today) })),
    };
  }

  /** Statement: every ledger entry with a running balance (newest first). */
  @Get(':id/ledger')
  @RequirePermissions('supplier:read')
  async ledger(@Param('id', ParseUUIDPipe) id: string, @Query() q: PageQueryDto) {
    const tx = this.db.tx;
    const { skip, take } = skipTake(q.page, q.pageSize);
    const rows = await tx.$queryRaw<{ id: string; entry_type: string; amount: string; description: string | null; reference_type: string | null; reference_id: string | null; created_at: Date; balance: string; total: number }[]>`
      SELECT id, entry_type::text, amount::text, description, reference_type, reference_id, created_at,
             SUM(amount) OVER (ORDER BY created_at, id ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)::text AS balance,
             COUNT(*) OVER ()::int AS total
      FROM party_ledger_entries WHERE supplier_id = ${id}::uuid
      ORDER BY created_at DESC, id DESC LIMIT ${take} OFFSET ${skip}`;
    return paged(
      rows.map((r) => ({ id: r.id, entryType: r.entry_type, amount: r.amount, description: r.description, referenceType: r.reference_type, referenceId: r.reference_id, createdAt: r.created_at, balance: r.balance })),
      rows[0]?.total ?? 0,
      q.page,
      q.pageSize,
    );
  }

  @Post()
  @RequirePermissions('supplier:manage')
  async create(@Body() dto: CreateSupplierDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    if (await tx.supplier.count({ where: { name: { equals: dto.name, mode: 'insensitive' }, deletedAt: null } })) {
      throw new ConflictException('A supplier with this name already exists');
    }
    const s = await tx.supplier.create({ data: { tenantId: auth.tenantId, ...dto }, select: SUPPLIER_SELECT });
    await this.audit.record({ action: 'supplier.created', entityType: 'supplier', entityId: s.id, after: s });
    return s;
  }

  @Patch(':id')
  @RequirePermissions('supplier:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateSupplierDto) {
    const tx = this.db.tx;
    const before = await tx.supplier.findFirst({ where: { id, deletedAt: null }, select: SUPPLIER_SELECT });
    if (!before) throw new NotFoundException('Supplier not found');
    const after = await tx.supplier.update({ where: { id }, data: dto, select: SUPPLIER_SELECT });
    await this.audit.record({ action: 'supplier.updated', entityType: 'supplier', entityId: id, before, after });
    return after;
  }

  @Delete(':id')
  @HttpCode(204)
  @RequirePermissions('supplier:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.supplier.findFirst({ where: { id, deletedAt: null }, select: SUPPLIER_SELECT });
    if (!before) throw new NotFoundException('Supplier not found');
    if (!(await partyBalance(tx, { supplierId: id })).isZero()) throw new ConflictException('Settle the supplier balance before deleting');
    await tx.supplier.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
    await this.audit.record({ action: 'supplier.deleted', entityType: 'supplier', entityId: id, before });
  }

  @Post(':id/payments')
  @BranchScoped()
  @RequirePermissions('supplier:payment')
  pay(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateSupplierPaymentDto, @CurrentAuth() auth: AuthContext) {
    return this.purchasing.paySupplier(auth, currentBranchId(), id, dto);
  }
}

// =============================================================================================
// Purchase orders
// =============================================================================================
const PO_SELECT = {
  id: true, number: true, status: true, orderDate: true, expectedDate: true, subtotal: true, taxTotal: true, grandTotal: true,
  notes: true, createdAt: true,
  supplier: { select: { id: true, name: true, phone: true, email: true } },
  createdBy: { select: { id: true, fullName: true } },
  purchaseOrderItems: {
    orderBy: { createdAt: 'asc' },
    select: {
      id: true, orderedQuantity: true, receivedQuantity: true, unitCost: true, taxPercent: true, lineTotal: true,
      product: { select: { id: true, brandName: true, strength: true, sku: true, baseUnit: true, trackExpiry: true, sellingPrice: true } },
    },
  },
  purchases: { select: { id: true, number: true, status: true, receivedAt: true } },
} satisfies Prisma.PurchaseOrderSelect;

@ApiTags('Purchasing')
@ApiCookieAuth()
@Controller('purchase-orders')
export class PurchaseOrdersController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly sequences: SequenceService,
    private readonly purchasing: PurchasingService,
    private readonly tenantInfo: TenantInfoService,
  ) {}

  private lines(tenantId: string, items: CreatePurchaseOrderDto['items']) {
    const rows = items.map((i) => {
      const net = money2(dec(i.orderedQuantity).times(i.unitCost));
      const tax = money2(net.times(i.taxPercent ?? 0).div(100));
      return { tenantId, productId: i.productId, orderedQuantity: dec(i.orderedQuantity), unitCost: dec(i.unitCost), taxPercent: dec(i.taxPercent ?? 0), lineTotal: net.plus(tax), net, tax };
    });
    return {
      rows: rows.map(({ net: _n, tax: _t, ...r }) => r),
      subtotal: sumDec(rows.map((r) => r.net)),
      taxTotal: sumDec(rows.map((r) => r.tax)),
      grandTotal: sumDec(rows.map((r) => r.lineTotal)),
    };
  }

  private async assertProducts(tx: Prisma.TransactionClient, ids: string[]) {
    const unique = [...new Set(ids)];
    if ((await tx.product.count({ where: { id: { in: unique }, deletedAt: null } })) !== unique.length) throw new BadRequestException('Unknown product on a line');
  }

  @Get()
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async list(@Query() q: ListPurchaseOrdersQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.PurchaseOrderWhereInput = {
      branchId: currentBranchId(),
      ...(q.status ? { status: q.status } : {}),
      ...(q.supplierId ? { supplierId: q.supplierId } : {}),
      ...(q.search ? { OR: [{ number: { contains: q.search, mode: 'insensitive' } }, { supplier: { name: { contains: q.search, mode: 'insensitive' } } }] } : {}),
    };
    const [rows, total] = await Promise.all([
      tx.purchaseOrder.findMany({ where, orderBy: { createdAt: 'desc' }, select: PO_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.purchaseOrder.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get(':id')
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const po = await this.db.tx.purchaseOrder.findFirst({ where: { id, branchId: currentBranchId() }, select: PO_SELECT });
    if (!po) throw new NotFoundException('Purchase order not found');
    return po;
  }

  @Post()
  @BranchScoped()
  @RequirePermissions('purchase_order:manage')
  async create(@Body() dto: CreatePurchaseOrderDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    await this.purchasing.assertSupplier(tx, dto.supplierId);
    await this.assertProducts(tx, dto.items.map((i) => i.productId));
    const { timezone } = await this.tenantInfo.get(tx);
    const l = this.lines(auth.tenantId, dto.items);
    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'PURCHASE_ORDER', scopeKey: branchId, prefix: 'PO' });
    const po = await tx.purchaseOrder.create({
      data: {
        tenantId: auth.tenantId, number, status: 'DRAFT', orderDate: parseDateOnly(dto.orderDate ?? todayIn(timezone)),
        expectedDate: optionalDate(dto.expectedDate) ?? null, subtotal: l.subtotal, taxTotal: l.taxTotal, grandTotal: l.grandTotal,
        notes: dto.notes ?? null, supplierId: dto.supplierId, branchId, createdById: auth.userId,
        purchaseOrderItems: { create: l.rows },
      },
      select: PO_SELECT,
    });
    await this.audit.record({ action: 'purchase_order.created', entityType: 'purchase_order', entityId: po.id, after: po });
    return po;
  }

  @Patch(':id')
  @BranchScoped()
  @RequirePermissions('purchase_order:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePurchaseOrderDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await tx.purchaseOrder.findFirst({ where: { id, branchId: currentBranchId() }, select: PO_SELECT });
    if (!before) throw new NotFoundException('Purchase order not found');
    if (before.status !== 'DRAFT') throw new ConflictException('Only a draft purchase order can be edited');
    if (dto.supplierId) await this.purchasing.assertSupplier(tx, dto.supplierId);
    const data: Prisma.PurchaseOrderUncheckedUpdateInput = {
      ...(dto.supplierId ? { supplierId: dto.supplierId } : {}),
      ...(dto.orderDate ? { orderDate: parseDateOnly(dto.orderDate) } : {}),
      ...(dto.expectedDate !== undefined ? { expectedDate: optionalDate(dto.expectedDate) } : {}),
      ...(dto.notes !== undefined ? { notes: dto.notes ?? null } : {}),
    };
    if (dto.items) {
      await this.assertProducts(tx, dto.items.map((i) => i.productId));
      const l = this.lines(auth.tenantId, dto.items);
      await tx.purchaseOrderItem.deleteMany({ where: { orderId: id } });
      await tx.purchaseOrderItem.createMany({ data: l.rows.map((r) => ({ ...r, orderId: id })) });
      Object.assign(data, { subtotal: l.subtotal, taxTotal: l.taxTotal, grandTotal: l.grandTotal });
    }
    const after = await tx.purchaseOrder.update({ where: { id }, data, select: PO_SELECT });
    await this.audit.record({ action: 'purchase_order.updated', entityType: 'purchase_order', entityId: id, before, after });
    return after;
  }

  /** DRAFT -> ORDERED (sent to the supplier). */
  @Post(':id/order')
  @BranchScoped()
  @RequirePermissions('purchase_order:manage')
  async markOrdered(@Param('id', ParseUUIDPipe) id: string) {
    return this.transition(id, ['DRAFT'], 'ORDERED', 'purchase_order.ordered');
  }

  @Post(':id/cancel')
  @BranchScoped()
  @RequirePermissions('purchase_order:manage')
  async cancel(@Param('id', ParseUUIDPipe) id: string) {
    return this.transition(id, ['DRAFT', 'ORDERED'], 'CANCELLED', 'purchase_order.cancelled');
  }

  /** Closes a partially received order (the rest will not be delivered). */
  @Post(':id/close')
  @BranchScoped()
  @RequirePermissions('purchase_order:manage')
  async close(@Param('id', ParseUUIDPipe) id: string) {
    return this.transition(id, ['PARTIALLY_RECEIVED'], 'RECEIVED', 'purchase_order.closed');
  }

  private async transition(id: string, from: string[], to: 'ORDERED' | 'CANCELLED' | 'RECEIVED', action: string) {
    const tx = this.db.tx;
    const before = await tx.purchaseOrder.findFirst({ where: { id, branchId: currentBranchId() }, select: PO_SELECT });
    if (!before) throw new NotFoundException('Purchase order not found');
    if (!from.includes(before.status)) throw new ConflictException(`A ${before.status.toLowerCase().replace('_', ' ')} order cannot become ${to.toLowerCase()}`);
    const after = await tx.purchaseOrder.update({ where: { id }, data: { status: to }, select: PO_SELECT });
    await this.audit.record({ action, entityType: 'purchase_order', entityId: id, before, after });
    return after;
  }
}

// =============================================================================================
// Purchases (supplier invoice + goods received note)
// =============================================================================================
@ApiTags('Purchasing')
@ApiCookieAuth()
@Controller('purchases')
export class PurchasesController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly sequences: SequenceService,
    private readonly purchasing: PurchasingService,
    private readonly tenantInfo: TenantInfoService,
    private readonly stock: StockService,
  ) {}

  @Get()
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async list(@Query() q: ListPurchasesQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.PurchaseWhereInput = {
      branchId: currentBranchId(),
      ...(q.status ? { status: q.status } : {}),
      ...(q.supplierId ? { supplierId: q.supplierId } : {}),
      ...(q.unpaid === 'true' ? { status: 'RECEIVED', paidTotal: { lt: tx.purchase.fields.grandTotal } } : {}),
      ...(q.from || q.to ? { purchaseDate: { ...(q.from ? { gte: parseDateOnly(q.from) } : {}), ...(q.to ? { lte: parseDateOnly(q.to) } : {}) } } : {}),
      ...(q.search
        ? { OR: [{ number: { contains: q.search, mode: 'insensitive' } }, { supplierInvoiceNo: { contains: q.search, mode: 'insensitive' } }, { supplier: { name: { contains: q.search, mode: 'insensitive' } } }] }
        : {}),
    };
    const [rows, total] = await Promise.all([
      tx.purchase.findMany({
        where, orderBy: [{ purchaseDate: 'desc' }, { createdAt: 'desc' }], ...skipTake(q.page, q.pageSize),
        select: {
          id: true, number: true, supplierInvoiceNo: true, status: true, purchaseDate: true, dueDate: true, grandTotal: true, paidTotal: true,
          receivedAt: true, supplier: { select: { id: true, name: true } }, _count: { select: { purchaseItems: true } },
        },
      }),
      tx.purchase.count({ where }),
    ]);
    return paged(rows.map(({ _count, ...r }) => ({ ...r, itemCount: _count.purchaseItems })), total, q.page, q.pageSize);
  }

  @Get(':id')
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const p = await this.db.tx.purchase.findFirst({ where: { id, branchId: currentBranchId() }, select: PURCHASE_SELECT });
    if (!p) throw new NotFoundException('Purchase not found');
    return p;
  }

  @Post()
  @BranchScoped()
  @RequirePermissions('purchase:create')
  async create(@Body() dto: CreatePurchaseDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    if (dto.receive && !auth.permissionsByBranch.get(branchId)?.has('purchase:receive')) {
      throw new BadRequestException('You may save this purchase as a draft; receiving it needs purchase:receive');
    }
    if (dto.payment && !dto.receive) throw new BadRequestException('A payment can only be recorded when the goods are received');
    if (dto.payment && !auth.permissionsByBranch.get(branchId)?.has('supplier:payment')) throw new BadRequestException('Recording a payment needs supplier:payment');
    const supplier = await this.purchasing.assertSupplier(tx, dto.supplierId);
    const { timezone } = await this.tenantInfo.get(tx);
    const location = dto.locationId ? await this.stock.assertLocation(tx, branchId, dto.locationId) : await this.stock.defaultLocation(tx, branchId);
    await this.purchasing.validateItems(tx, dto.items, false, timezone);
    if (dto.orderId) {
      const po = await tx.purchaseOrder.findFirst({ where: { id: dto.orderId, branchId }, select: { status: true, supplierId: true } });
      if (!po) throw new BadRequestException('Purchase order not found in this branch');
      if (po.supplierId !== dto.supplierId) throw new BadRequestException('The purchase order belongs to another supplier');
      if (!['ORDERED', 'PARTIALLY_RECEIVED'].includes(po.status)) throw new ConflictException(`The purchase order is ${po.status.toLowerCase()}`);
    }
    const computed = computeLines(dto.items);
    const purchaseDate = parseDateOnly(dto.purchaseDate ?? todayIn(timezone));
    const dueDate =
      dto.dueDate !== undefined ? (optionalDate(dto.dueDate) ?? null) : new Date(purchaseDate.getTime() + supplier.paymentTermsDays * 86_400_000);
    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'PURCHASE', scopeKey: branchId, prefix: 'GRN' });
    const p = await tx.purchase.create({
      data: {
        tenantId: auth.tenantId, number, supplierInvoiceNo: dto.supplierInvoiceNo ?? null, status: 'DRAFT', purchaseDate, dueDate,
        subtotal: computed.subtotal, discountTotal: computed.discountTotal, taxTotal: computed.taxTotal, grandTotal: computed.grandTotal,
        notes: dto.notes ?? null, supplierId: dto.supplierId, branchId, locationId: location.id, orderId: dto.orderId ?? null, createdById: auth.userId,
        purchaseItems: { create: this.purchasing.itemRows(auth.tenantId, computed) },
      },
      select: { id: true },
    });
    await this.audit.record({ action: 'purchase.created', entityType: 'purchase', entityId: p.id, after: { number, grandTotal: computed.grandTotal } });
    if (dto.receive) return this.purchasing.receive(auth, branchId, p.id, dto.payment);
    return tx.purchase.findFirstOrThrow({ where: { id: p.id }, select: PURCHASE_SELECT });
  }

  @Patch(':id')
  @BranchScoped()
  @RequirePermissions('purchase:create')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePurchaseDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const before = await tx.purchase.findFirst({ where: { id, branchId }, select: PURCHASE_SELECT });
    if (!before) throw new NotFoundException('Purchase not found');
    if (before.status !== 'DRAFT') throw new ConflictException('Only a draft purchase can be edited. Use a purchase return to correct received goods.');
    if (dto.supplierId) await this.purchasing.assertSupplier(tx, dto.supplierId);
    if (dto.locationId) await this.stock.assertLocation(tx, branchId, dto.locationId);
    const data: Prisma.PurchaseUncheckedUpdateInput = {
      ...(dto.supplierId ? { supplierId: dto.supplierId } : {}),
      ...(dto.locationId ? { locationId: dto.locationId } : {}),
      ...(dto.supplierInvoiceNo !== undefined ? { supplierInvoiceNo: dto.supplierInvoiceNo } : {}),
      ...(dto.purchaseDate ? { purchaseDate: parseDateOnly(dto.purchaseDate) } : {}),
      ...(dto.dueDate !== undefined ? { dueDate: optionalDate(dto.dueDate) } : {}),
      ...(dto.notes !== undefined ? { notes: dto.notes } : {}),
    };
    if (dto.items) {
      const { timezone } = await this.tenantInfo.get(tx);
      await this.purchasing.validateItems(tx, dto.items, false, timezone);
      const computed = computeLines(dto.items);
      await tx.purchaseItem.deleteMany({ where: { purchaseId: id } });
      await tx.purchaseItem.createMany({ data: this.purchasing.itemRows(auth.tenantId, computed).map((r) => ({ ...r, purchaseId: id })) });
      Object.assign(data, { subtotal: computed.subtotal, discountTotal: computed.discountTotal, taxTotal: computed.taxTotal, grandTotal: computed.grandTotal });
    }
    await tx.purchase.update({ where: { id }, data });
    const after = await tx.purchase.findFirstOrThrow({ where: { id }, select: PURCHASE_SELECT });
    await this.audit.record({ action: 'purchase.updated', entityType: 'purchase', entityId: id, before, after });
    return after;
  }

  @Post(':id/receive')
  @BranchScoped()
  @RequirePermissions('purchase:receive')
  receive(@Param('id', ParseUUIDPipe) id: string, @Body() dto: ReceivePurchaseDto, @CurrentAuth() auth: AuthContext) {
    const branchId = currentBranchId();
    if (dto.payment && !auth.permissionsByBranch.get(branchId)?.has('supplier:payment')) throw new BadRequestException('Recording a payment needs supplier:payment');
    return this.purchasing.receive(auth, branchId, id, dto.payment);
  }

  @Post(':id/cancel')
  @BranchScoped()
  @RequirePermissions('purchase:create')
  async cancel(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.purchase.findFirst({ where: { id, branchId: currentBranchId() }, select: PURCHASE_SELECT });
    if (!before) throw new NotFoundException('Purchase not found');
    if (before.status !== 'DRAFT') throw new ConflictException('Only a draft purchase can be cancelled. Use a purchase return for received goods.');
    const after = await tx.purchase.update({ where: { id }, data: { status: 'CANCELLED' }, select: PURCHASE_SELECT });
    await this.audit.record({ action: 'purchase.cancelled', entityType: 'purchase', entityId: id, before, after });
    return after;
  }
}

// =============================================================================================
// Purchase returns (goods back to the supplier)
// =============================================================================================
@ApiTags('Purchasing')
@ApiCookieAuth()
@Controller('purchase-returns')
export class PurchaseReturnsController {
  constructor(private readonly db: TenantDb, private readonly purchasing: PurchasingService) {}

  @Get()
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async list(@Query() q: ListPurchaseReturnsQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.PurchaseReturnWhereInput = {
      branchId: currentBranchId(),
      ...(q.supplierId ? { supplierId: q.supplierId } : {}),
      ...(q.search ? { OR: [{ number: { contains: q.search, mode: 'insensitive' } }, { supplier: { name: { contains: q.search, mode: 'insensitive' } } }] } : {}),
    };
    const [rows, total] = await Promise.all([
      tx.purchaseReturn.findMany({ where, orderBy: { createdAt: 'desc' }, select: PURCHASE_RETURN_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.purchaseReturn.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get(':id')
  @BranchScoped()
  @RequirePermissions('purchase:read')
  async get(@Param('id', ParseUUIDPipe) id: string) {
    const r = await this.db.tx.purchaseReturn.findFirst({ where: { id, branchId: currentBranchId() }, select: PURCHASE_RETURN_SELECT });
    if (!r) throw new NotFoundException('Purchase return not found');
    return r;
  }

  @Post()
  @BranchScoped()
  @RequirePermissions('purchase:return')
  create(@Body() dto: CreatePurchaseReturnDto, @CurrentAuth() auth: AuthContext) {
    return this.purchasing.createReturn(auth, currentBranchId(), dto);
  }
}

@Module({
  imports: [InventoryCoreModule],
  controllers: [SuppliersController, PurchaseOrdersController, PurchasesController, PurchaseReturnsController],
  providers: [PurchasingService],
  exports: [PurchasingService],
})
export class PurchasingModule {}
