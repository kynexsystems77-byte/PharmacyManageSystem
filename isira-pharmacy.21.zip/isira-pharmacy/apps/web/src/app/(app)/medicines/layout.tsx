'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function MedicinesLayout({ children }: { children: ReactNode }) {
  const { can } = useAuth();
  if (!can('product:read')) return <Forbidden what="the catalogue" />;
  return (
    <div>
      <SubNav
        items={[
          { href: '/medicines', label: 'Products', exact: true },
          { href: '/medicines/categories', label: 'Categories' },
          { href: '/medicines/reference', label: 'Manufacturers & tax' },
        ]}
      />
      {children}
    </div>
  );
}
