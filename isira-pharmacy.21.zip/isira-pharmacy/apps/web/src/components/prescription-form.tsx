'use client';

import { Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { productName, todayIso } from '@/lib/format';
import { errorMessage, newKey } from '@/lib/hooks';
import type { Customer, Prescription } from '@/lib/types';
import { CustomerPicker } from './customer-picker';
import { Textarea } from './kit';
import { ProductPicker } from './pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from './ui';

export interface RxItemDraft { key: string; id?: string; medicineName: string; productId: string | null; dosage: string; frequency: string; durationDays: string; quantityPrescribed: string; instructions: string; dispensed?: number }
export interface RxDraft { customer: Customer | null; prescriptionNumber: string; doctorName: string; doctorRegistration: string; prescribedDate: string; validUntil: string; notes: string; items: RxItemDraft[] }

export function emptyRx(customer: Customer | null): RxDraft {
  const valid = new Date(); valid.setDate(valid.getDate() + 30);
  return { customer, prescriptionNumber: '', doctorName: '', doctorRegistration: '', prescribedDate: todayIso(), validUntil: valid.toISOString().slice(0, 10), notes: '', items: [] };
}

export function rxFromPrescription(p: Prescription): RxDraft {
  return {
    customer: { ...p.customer, email: null, address: null, dateOfBirth: null, creditLimit: '0', notes: null, isActive: true, createdAt: '' },
    prescriptionNumber: p.prescriptionNumber ?? '', doctorName: p.doctorName, doctorRegistration: p.doctorRegistration ?? '',
    prescribedDate: p.prescribedDate.slice(0, 10), validUntil: p.validUntil?.slice(0, 10) ?? '', notes: p.notes ?? '',
    items: p.prescriptionItems.map((i) => ({
      key: i.id, id: i.id, medicineName: i.medicineName, productId: i.product?.id ?? null, dosage: i.dosage ?? '', frequency: i.frequency ?? '',
      durationDays: i.durationDays === null ? '' : String(i.durationDays), quantityPrescribed: i.quantityPrescribed === null ? '' : String(Number(i.quantityPrescribed)),
      instructions: i.instructions ?? '', dispensed: Number(i.quantityDispensed),
    })),
  };
}

export function rxBody(d: RxDraft, mode: 'create' | 'update') {
  const t = (v: string) => (v.trim() === '' ? (mode === 'update' ? null : undefined) : v.trim());
  const items = d.items.map((i) => ({
    ...(i.id ? { id: i.id } : {}), medicineName: i.medicineName.trim(), productId: i.productId, dosage: i.dosage.trim() || undefined,
    frequency: i.frequency.trim() || undefined, durationDays: i.durationDays ? Number(i.durationDays) : undefined,
    quantityPrescribed: i.quantityPrescribed ? Number(i.quantityPrescribed) : undefined, instructions: i.instructions.trim() || undefined,
  }));
  return {
    ...(mode === 'create' ? { customerId: d.customer?.id } : {}),
    prescriptionNumber: t(d.prescriptionNumber), doctorName: d.doctorName.trim(), doctorRegistration: t(d.doctorRegistration),
    prescribedDate: d.prescribedDate, validUntil: d.validUntil || null, notes: t(d.notes), items,
  };
}

export function PrescriptionForm({ initial, mode, submitting, error, onSubmit, onCancel }: { initial: RxDraft; mode: 'create' | 'update'; submitting: boolean; error: unknown; onSubmit: (d: RxDraft) => void; onCancel: () => void }) {
  const [d, setD] = useState(initial);
  const set = <K extends keyof RxDraft>(k: K, v: RxDraft[K]) => setD((x) => ({ ...x, [k]: v }));
  const setItem = (key: string, patch: Partial<RxItemDraft>) => setD((x) => ({ ...x, items: x.items.map((i) => (i.key === key ? { ...i, ...patch } : i)) }));
  const blank = (): RxItemDraft => ({ key: newKey(), medicineName: '', productId: null, dosage: '', frequency: '', durationDays: '', quantityPrescribed: '', instructions: '' });
  const valid = d.customer && d.doctorName.trim().length >= 2 && d.prescribedDate && d.items.every((i) => i.medicineName.trim());
  return (
    <div className="space-y-4">
      {error ? <Alert>{errorMessage(error)}</Alert> : null}
      <Card className="grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3">
        <div className="sm:col-span-2 lg:col-span-3">
          <span className="mb-1 block text-sm font-medium">Patient *</span>
          {mode === 'create' ? <CustomerPicker value={d.customer} onChange={(c) => set('customer', c)} /> : <p className="text-sm">{d.customer?.fullName}</p>}
        </div>
        <Field label="Doctor *"><Input value={d.doctorName} onChange={(e) => set('doctorName', e.target.value)} placeholder="Dr. …" /></Field>
        <Field label="Doctor registration no."><Input value={d.doctorRegistration} onChange={(e) => set('doctorRegistration', e.target.value)} /></Field>
        <Field label="Prescription no."><Input value={d.prescriptionNumber} onChange={(e) => set('prescriptionNumber', e.target.value)} /></Field>
        <Field label="Prescribed on *"><Input type="date" value={d.prescribedDate} onChange={(e) => set('prescribedDate', e.target.value)} /></Field>
        <Field label="Valid until"><Input type="date" value={d.validUntil} onChange={(e) => set('validUntil', e.target.value)} /></Field>
      </Card>
      <Card>
        <CardHeader title="Medicines prescribed" action={<Button variant="outline" className="h-8 px-3" onClick={() => setD((x) => ({ ...x, items: [...x.items, blank()] }))}><Plus size={14} /> Free-text item</Button>} />
        <div className="space-y-3 p-4">
          <ProductPicker withStock={false} placeholder="Add from the catalogue (links the item to a product)" onPick={(p) => setD((x) => ({ ...x, items: [...x.items, { ...blank(), medicineName: productName(p.brandName, p.strength), productId: p.id }] }))} />
          {d.items.map((i) => (
            <div key={i.key} className="grid items-end gap-2 rounded-lg border border-line p-3 sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_90px_100px_auto]">
              <Field label={i.productId ? 'Medicine (catalogue)' : 'Medicine *'}><Input value={i.medicineName} onChange={(e) => setItem(i.key, { medicineName: e.target.value })} /></Field>
              <Field label="Dosage"><Input value={i.dosage} onChange={(e) => setItem(i.key, { dosage: e.target.value })} placeholder="500 mg" /></Field>
              <Field label="Frequency"><Input value={i.frequency} onChange={(e) => setItem(i.key, { frequency: e.target.value })} placeholder="1-0-1" /></Field>
              <Field label="Days"><Input type="number" min="0" value={i.durationDays} onChange={(e) => setItem(i.key, { durationDays: e.target.value })} /></Field>
              <Field label="Total qty"><Input type="number" min="0" step="0.001" value={i.quantityPrescribed} onChange={(e) => setItem(i.key, { quantityPrescribed: e.target.value })} /></Field>
              <button aria-label="Remove item" disabled={(i.dispensed ?? 0) > 0} title={(i.dispensed ?? 0) > 0 ? 'Already dispensed' : undefined} onClick={() => setD((x) => ({ ...x, items: x.items.filter((y) => y.key !== i.key) }))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger disabled:opacity-30"><Trash2 size={16} /></button>
              <div className="sm:col-span-2 lg:col-span-6"><Input value={i.instructions} onChange={(e) => setItem(i.key, { instructions: e.target.value })} placeholder="Instructions (after meals, avoid alcohol…)" /></div>
            </div>
          ))}
        </div>
      </Card>
      <Card className="p-4"><Field label="Notes"><Textarea value={d.notes} onChange={(e) => set('notes', e.target.value)} maxLength={1000} /></Field></Card>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button disabled={!valid} loading={submitting} onClick={() => onSubmit(d)}>{mode === 'create' ? 'Save prescription' : 'Save changes'}</Button>
      </div>
    </div>
  );
}
