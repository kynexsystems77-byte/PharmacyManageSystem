import { INestApplication } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { REPORTS } from '@kynex/contracts';
import { addStock, bootApp, createProduct, expectStatus, isoDay, login, uid, type Session } from './helpers';

const key = () => randomUUID().replace(/-/g, '');

/** supertest: collect binary bodies as Buffers. */
function binary(res: unknown, cb: (err: Error | null, body: unknown) => void) {
  const stream = res as NodeJS.ReadableStream;
  const chunks: Buffer[] = [];
  stream.on('data', (c: Buffer) => chunks.push(c));
  stream.on('end', () => cb(null, Buffer.concat(chunks)));
}

describe('Reports and exports (Phase 10)', () => {
  let app: INestApplication;
  let owner: Session;
  const today = isoDay(0);
  const from = isoDay(-30);
  beforeAll(async () => {
    app = await bootApp();
    owner = await login(app, 'owner@demo.local');
  });
  afterAll(async () => {
    await app.close();
  });

  it('runs every report in both scopes without errors', async () => {
    for (const r of REPORTS) {
      for (const scope of ['branch', 'all']) {
        const res = await owner.get(`/reports/${r.key}?from=${from}&to=${today}&scope=${scope}&days=90`);
        if (res.status !== 200) throw new Error(`${r.key} (${scope}) -> ${res.status} ${JSON.stringify(res.body)}`);
        expect(res.body.columns.length).toBeGreaterThan(0);
        expect(Array.isArray(res.body.rows)).toBe(true);
      }
    }
  });

  it('exports CSV, Excel and PDF files', async () => {
    const csv = await owner.agent.get(`/v1/reports/sales-daily?from=${from}&to=${today}&format=csv`).set('X-Branch-Id', owner.branchId).buffer(true).parse(binary);
    expect(csv.status).toBe(200);
    expect(csv.headers['content-disposition']).toMatch(/attachment; filename="sales-daily-/);
    expect((csv.body as Buffer).subarray(0, 3).toString('hex')).toBe('efbbbf'); // UTF-8 BOM
    expect((csv.body as Buffer).toString('utf8')).toContain('Date,Invoices');

    const xlsx = await owner.agent.get(`/v1/reports/stock-valuation?format=xlsx`).set('X-Branch-Id', owner.branchId).buffer(true).parse(binary);
    expect(xlsx.status).toBe(200);
    expect((xlsx.body as Buffer).subarray(0, 2).toString()).toBe('PK'); // zip container

    const pdf = await owner.agent.get(`/v1/reports/sales-by-product?from=${from}&to=${today}&format=pdf`).set('X-Branch-Id', owner.branchId).buffer(true).parse(binary);
    expect(pdf.status).toBe(200);
    expect((pdf.body as Buffer).subarray(0, 5).toString()).toBe('%PDF-');
  });

  it('hides cost columns without financial access and blocks exports without report:export', async () => {
    const pharmacist = await login(app, 'pharmacist@demo.local');
    const res = await pharmacist.get(`/reports/sales-by-product?from=${from}&to=${today}`);
    expectStatus(res, 200);
    expect(res.body.columns.map((c: { key: string }) => c.key)).not.toContain('cost');
    expect(res.body.rows.every((r: Record<string, unknown>) => !('profit' in r))).toBe(true);
    expect((await pharmacist.get(`/reports/profit-loss?from=${from}&to=${today}`)).status).toBe(403);
    expect((await pharmacist.get(`/reports/sales-daily?from=${from}&to=${today}&format=csv`)).status).toBe(403);
    const cat = await pharmacist.get('/reports');
    expect(cat.body.canExport).toBe(false);
    expect(cat.body.reports.map((r: { key: string }) => r.key)).toContain('expiry');
    const cashier = await login(app, 'cashier@demo.local');
    expect((await cashier.get('/reports')).body.reports).toHaveLength(0);
  });

  it('agrees with the finance P&L and ages receivables oldest-first', async () => {
    const code = `R${uid()}`.slice(0, 8);
    const b = await owner.agent.post('/v1/branches').set('X-Kynex-Csrf', '1').send({ name: `Zz Reports ${code}`, code });
    expectStatus(b, 201);
    const s = await login(app, 'owner@demo.local', b.body.id);
    const regs = await s.get('/registers');
    expectStatus(await s.post(`/registers/${regs.body[0].id}/open`, { openingBalance: 0 }), 201);
    const p = await createProduct(s, { sellingPrice: 10, purchasePrice: 3 });
    await addStock(s, p.id, { quantity: 100, unitCost: 3 });
    const cust = await s.post('/customers', { fullName: `Aging ${uid()}`, phone: `07${Date.now().toString().slice(-8)}`, creditLimit: 1000 });
    expectStatus(await s.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, items: [{ productId: p.id, quantity: 6 }], payments: [{ method: 'CUSTOMER_CREDIT', amount: 60 }] }), 201);
    expectStatus(await s.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, items: [{ productId: p.id, quantity: 4 }], payments: [{ method: 'CUSTOMER_CREDIT', amount: 40 }] }), 201);
    expectStatus(await s.post(`/customers/${cust.body.id}/payments`, { amount: 70, method: 'CARD' }), 201);

    const byProduct = await s.get(`/reports/sales-by-product?from=${today}&to=${today}`);
    expect(byProduct.body.totals.revenue).toBe(100);
    expect(byProduct.body.totals.profit).toBe(70);
    const pl = await s.get(`/reports/profit-loss?from=${today}&to=${today}`);
    const line = (label: string) => pl.body.rows.find((r: { label: string }) => r.label === label).amount;
    expect(line('Net sales')).toBe(100);
    expect(line('Gross profit')).toBe(70);
    const daily = await s.get(`/reports/sales-daily?from=${today}&to=${today}`);
    expect(daily.body.rows[0].profit).toBe(70);

    const aging = await s.get('/reports/receivables-aging');
    const row = aging.body.rows.find((r: { name: string }) => r.name === cust.body.fullName);
    expect(row.total).toBe(30);
    expect(row['0-30']).toBe(30);
  });

  it('renders an A4 invoice PDF', async () => {
    const sales = await owner.get(`/sales?from=${from}&to=${today}`);
    const id = sales.body.data[0].id;
    const res = await owner.agent.get(`/v1/sales/${id}/invoice.pdf`).set('X-Branch-Id', owner.branchId).buffer(true).parse(binary);
    expect(res.status).toBe(200);
    expect((res.body as Buffer).subarray(0, 5).toString()).toBe('%PDF-');
  });
});
