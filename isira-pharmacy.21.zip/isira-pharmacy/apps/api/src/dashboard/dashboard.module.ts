import { Controller, Get, Injectable, Module } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { BranchScoped, CurrentAuth } from '../common/decorators';
import { getStore, type AuthContext } from '../common/request-context';
import { NotificationsService } from '../notifications/notifications.module';
import { TenantDb } from '../prisma/prisma.service';

/** Statuses that count as revenue. */
const REVENUE = `('COMPLETED','PARTIALLY_RETURNED')`;

function safeTimezone(tz: string | null | undefined): string {
  try {
    new Intl.DateTimeFormat('en', { timeZone: tz ?? 'UTC' });
    return tz ?? 'UTC';
  } catch {
    return 'UTC';
  }
}

export interface DayPoint { day: string; total: number; count: number }

@Injectable()
export class DashboardService {
  constructor(private readonly db: TenantDb, private readonly notifications: NotificationsService) {}

  /**
   * One branch's dashboard. Sections the caller is not allowed to see are returned as null,
   * so the server (not the UI) decides what is visible. Runs inside the request's tenant transaction (RLS applies).
   */
  async summary(auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = getStore().branchId as string;
    const perms = auth.permissionsByBranch.get(branchId) ?? new Set<string>();
    const can = (p: string) => perms.has(p);

    const tenant = await tx.tenant.findFirstOrThrow({ select: { timezone: true, currencyCode: true } });
    const tz = safeTimezone(tenant.timezone);

    let sales: {
      today: { total: number; count: number; average: number };
      yesterday: { total: number; count: number };
      last7Days: DayPoint[];
      heldBills: number;
      profitToday: number | null;
      topProducts: { productId: string; name: string; quantity: number; revenue: number }[];
      recent: { id: string; invoiceNo: string | null; total: number; status: string; soldAt: Date | null; cashier: string; customer: string | null }[];
    } | null = null;

    if (can('sale:read')) {
      const series = await tx.$queryRawUnsafe<DayPoint[]>(
        `WITH d AS (SELECT date_trunc('day', now() AT TIME ZONE $1::text) AS d0)
         SELECT to_char(g.day, 'YYYY-MM-DD') AS day,
                COALESCE(SUM(s.grand_total), 0)::float8 AS total,
                COUNT(s.id)::int AS count
         FROM d, generate_series(d.d0 - interval '6 day', d.d0, interval '1 day') AS g(day)
         LEFT JOIN sales s
           ON (s.sold_at AT TIME ZONE $1::text)::date = g.day::date
          AND s.branch_id = $2::uuid
          AND s.status IN ${REVENUE}
         GROUP BY g.day ORDER BY g.day`,
        tz,
        branchId,
      );
      const today = series[series.length - 1] ?? { day: '', total: 0, count: 0 };
      const yesterday = series[series.length - 2] ?? { day: '', total: 0, count: 0 };

      const held = await tx.sale.count({ where: { branchId, status: 'HELD' } });

      let profitToday: number | null = null;
      if (can('report:financial:view')) {
        // same definition as the P&L: revenue ex tax - cost, net of today's returns (restocked cost comes back)
        const rows = await tx.$queryRawUnsafe<{ profit: number }[]>(
          `SELECT (
             COALESCE((SELECT SUM(si.line_total - si.tax_amount - si.cost_total) FROM sale_items si JOIN sales s ON s.id = si.sale_id
                       WHERE s.branch_id = $2::uuid AND s.status IN ${REVENUE}
                         AND (s.sold_at AT TIME ZONE $1::text)::date = (now() AT TIME ZONE $1::text)::date), 0)
           - COALESCE((SELECT SUM(ri.line_total * (1 - si.tax_amount / NULLIF(si.line_total, 0)) - CASE WHEN ri.restock THEN ri.cost_total ELSE 0 END)
                       FROM sales_returns sr JOIN sales_return_items ri ON ri.return_id = sr.id JOIN sale_items si ON si.id = ri.sale_item_id
                       WHERE sr.branch_id = $2::uuid AND sr.status = 'POSTED'
                         AND (sr.return_date AT TIME ZONE $1::text)::date = (now() AT TIME ZONE $1::text)::date), 0)
           )::float8 AS profit`,
          tz,
          branchId,
        );
        profitToday = rows[0]?.profit ?? 0;
      }

      const topProducts = await tx.$queryRawUnsafe<{ productId: string; name: string; quantity: number; revenue: number }[]>(
        `SELECT si.product_id AS "productId", MAX(si.product_name) AS name,
                SUM(si.base_quantity)::float8 AS quantity, SUM(si.line_total)::float8 AS revenue
         FROM sale_items si JOIN sales s ON s.id = si.sale_id
         WHERE s.branch_id = $1::uuid AND s.status IN ${REVENUE} AND s.sold_at >= now() - interval '7 days'
         GROUP BY si.product_id ORDER BY revenue DESC LIMIT 5`,
        branchId,
      );

      const recent = await tx.sale.findMany({
        where: { branchId, status: { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED', 'VOIDED'] } },
        orderBy: { createdAt: 'desc' },
        take: 8,
        select: {
          id: true, invoiceNo: true, grandTotal: true, status: true, soldAt: true,
          cashier: { select: { fullName: true } }, customer: { select: { fullName: true } },
        },
      });

      sales = {
        today: { total: today.total, count: today.count, average: today.count > 0 ? today.total / today.count : 0 },
        yesterday: { total: yesterday.total, count: yesterday.count },
        last7Days: series,
        heldBills: held,
        profitToday,
        topProducts,
        recent: recent.map((r) => ({
          id: r.id, invoiceNo: r.invoiceNo, total: Number(r.grandTotal), status: r.status, soldAt: r.soldAt,
          cashier: r.cashier.fullName, customer: r.customer?.fullName ?? null,
        })),
      };
    }

    let inventory: {
      lowStockCount: number;
      expiringSoonCount: number;
      expiredCount: number;
      stockValue: number | null;
      lowStock: { productId: string; name: string; sku: string; quantity: number; reorderLevel: number }[];
      expiring: { batchId: string; name: string; batchNumber: string; expiryDate: string; daysLeft: number; quantity: number }[];
    } | null = null;

    if (can('inventory:read')) {
      const today = `(now() AT TIME ZONE $1::text)::date`;
      const counts = await tx.$queryRawUnsafe<{ expired: number; expiring: number; value: number }[]>(
        `SELECT COUNT(DISTINCT sl.batch_id) FILTER (WHERE b.expiry_date < ${today})::int AS expired,
                COUNT(DISTINCT sl.batch_id) FILTER (WHERE b.expiry_date >= ${today} AND b.expiry_date <= ${today} + 30)::int AS expiring,
                COALESCE(SUM(sl.quantity * b.unit_cost), 0)::float8 AS value
         FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
         WHERE sl.branch_id = $2::uuid AND sl.quantity > 0`,
        tz,
        branchId,
      );

      // Available stock = sellable batches only (active, not expired).
      const low = await tx.$queryRawUnsafe<{ productId: string; name: string; sku: string; quantity: number; reorderLevel: number; total: number }[]>(
        `WITH stock AS (
           SELECT sl.product_id, SUM(sl.quantity) AS qty
           FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
           WHERE sl.branch_id = $2::uuid AND b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= ${today})
           GROUP BY sl.product_id)
         SELECT p.id AS "productId", p.brand_name AS name, p.sku,
                COALESCE(st.qty, 0)::float8 AS quantity,
                COALESCE(bps.reorder_level, p.reorder_level)::float8 AS "reorderLevel",
                COUNT(*) OVER ()::int AS total
         FROM products p
         LEFT JOIN stock st ON st.product_id = p.id
         LEFT JOIN branch_product_settings bps ON bps.product_id = p.id AND bps.branch_id = $2::uuid
         WHERE p.deleted_at IS NULL AND p.is_active
           AND COALESCE(bps.reorder_level, p.reorder_level) > 0
           AND COALESCE(st.qty, 0) <= COALESCE(bps.reorder_level, p.reorder_level)
         ORDER BY COALESCE(st.qty, 0) / COALESCE(bps.reorder_level, p.reorder_level) ASC, p.brand_name
         LIMIT 8`,
        tz,
        branchId,
      );

      const expiring = await tx.$queryRawUnsafe<{ batchId: string; name: string; batchNumber: string; expiryDate: string; daysLeft: number; quantity: number }[]>(
        `SELECT b.id AS "batchId", p.brand_name AS name, b.batch_number AS "batchNumber",
                to_char(b.expiry_date, 'YYYY-MM-DD') AS "expiryDate",
                (b.expiry_date - ${today})::int AS "daysLeft",
                SUM(sl.quantity)::float8 AS quantity
         FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id JOIN products p ON p.id = sl.product_id
         WHERE sl.branch_id = $2::uuid AND sl.quantity > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <= ${today} + 30
         GROUP BY b.id, p.brand_name, b.batch_number, b.expiry_date
         ORDER BY b.expiry_date, p.brand_name LIMIT 8`,
        tz,
        branchId,
      );

      inventory = {
        lowStockCount: low[0]?.total ?? 0,
        expiringSoonCount: counts[0]?.expiring ?? 0,
        expiredCount: counts[0]?.expired ?? 0,
        stockValue: can('report:financial:view') ? (counts[0]?.value ?? 0) : null,
        lowStock: low.map(({ total: _t, ...rest }) => rest),
        expiring,
      };
    }

    // per-user read receipts (Phase 11); scoped to what this user may see
    const unread = await tx.notification.count({
      where: { AND: [this.notifications.unreadWhere(auth), { OR: [{ branchId: null }, { branchId }] }] },
    });

    return {
      generatedAt: new Date().toISOString(),
      currencyCode: tenant.currencyCode,
      timezone: tz,
      unreadNotifications: unread,
      sales,
      inventory,
    };
  }
}

@ApiTags('Dashboard')
@ApiCookieAuth()
@Controller('dashboard')
export class DashboardController {
  constructor(private readonly dashboard: DashboardService) {}

  /** Requires X-Branch-Id. Any signed-in user may call it; sections are filtered by the caller's permissions in that branch. */
  @Get()
  @BranchScoped()
  summary(@CurrentAuth() auth: AuthContext) {
    return this.dashboard.summary(auth);
  }
}

@Module({ controllers: [DashboardController], providers: [DashboardService] })
export class DashboardModule {}
