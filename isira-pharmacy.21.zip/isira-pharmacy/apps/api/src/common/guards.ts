import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Inject,
  Injectable,
  BadRequestException,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';
import type { PermissionKey } from '@kynex/contracts';
import { ENV, type Env } from '../config/env';
import { SessionService } from '../auth/session.service';
import { BRANCH_SCOPED, IS_PUBLIC, PERMISSIONS_KEY } from './decorators';
import { getStore } from './request-context';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/** CSRF defence: cookie-authenticated writes must carry a custom header. Browsers cannot add it cross-site without CORS approval. */
@Injectable()
export class CsrfGuard implements CanActivate {
  constructor(@Inject(ENV) private readonly env: Env) {}
  canActivate(ctx: ExecutionContext): boolean {
    const req = ctx.switchToHttp().getRequest<Request>();
    if (SAFE_METHODS.has(req.method)) return true;
    const hasSession = Boolean(req.cookies?.[this.env.COOKIE_NAME]);
    if (hasSession && req.header('x-kynex-csrf') !== '1') {
      throw new ForbiddenException('Missing CSRF header');
    }
    return true;
  }
}

/** Authenticates the session cookie and loads the user's branch permissions. Never trusts the client. */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly sessions: SessionService,
    @Inject(ENV) private readonly env: Env,
  ) {}
  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, [ctx.getHandler(), ctx.getClass()])) return true;
    const req = ctx.switchToHttp().getRequest<Request>();
    getStore().auth = await this.sessions.authenticate(req.cookies?.[this.env.COOKIE_NAME]);
    return true;
  }
}

/** For @BranchScoped() routes: validates X-Branch-Id against the branches this user may access. */
@Injectable()
export class BranchGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}
  canActivate(ctx: ExecutionContext): boolean {
    if (!this.reflector.getAllAndOverride<boolean>(BRANCH_SCOPED, [ctx.getHandler(), ctx.getClass()])) return true;
    const store = getStore();
    if (!store.auth) throw new UnauthorizedException();
    const branchId = ctx.switchToHttp().getRequest<Request>().header('x-branch-id');
    if (!branchId || !UUID_RE.test(branchId)) {
      throw new BadRequestException('A valid X-Branch-Id header is required');
    }
    if (!store.auth.branchIds.has(branchId)) {
      throw new ForbiddenException('You do not have access to this branch');
    }
    store.branchId = branchId;
    return true;
  }
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}
  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<PermissionKey[] | undefined>(PERMISSIONS_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!required || required.length === 0) return true;
    const { auth, branchId } = getStore();
    if (!auth) throw new UnauthorizedException();
    const granted = branchId ? auth.permissionsByBranch.get(branchId) : auth.allPermissions;
    const missing = required.filter((p) => !granted?.has(p));
    if (missing.length > 0) {
      throw new ForbiddenException(`Missing permission: ${missing.join(', ')}`);
    }
    return true;
  }
}
