#!/bin/sh
# Runs once, when the Postgres volume is first created.
# Creates two roles:
#   kynex_owner : owns the schema, runs migrations (not a superuser)
#   kynex_app   : used by the API. NOSUPERUSER + NOBYPASSRLS so Row-Level Security always applies.
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<-EOSQL
CREATE ROLE kynex_owner LOGIN PASSWORD '${DB_OWNER_PASSWORD}' CREATEDB NOSUPERUSER NOBYPASSRLS;
CREATE ROLE kynex_app LOGIN PASSWORD '${DB_APP_PASSWORD}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
CREATE DATABASE kynex_pharmacy OWNER kynex_owner;
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname kynex_pharmacy <<-EOSQL
CREATE EXTENSION IF NOT EXISTS pg_trgm;
GRANT CONNECT ON DATABASE kynex_pharmacy TO kynex_app;
EOSQL
