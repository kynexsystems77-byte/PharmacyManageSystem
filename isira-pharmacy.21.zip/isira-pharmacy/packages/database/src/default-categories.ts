/** Starting product categories for a new pharmacy (top level -> sub-categories). Owners can rename or add more. */
export const DEFAULT_CATEGORIES: Record<string, string[]> = {
  Medicine: ['Antibiotics', 'Antacid', 'Antihistamines', 'Corticosteroid', 'Hypertension', 'Hyperglycemic'],
  Groceries: ['Beverages', 'Biscuits & snacks', 'Milk powder & baby food', 'Rice, flour & dry goods', 'Household', 'Personal hygiene'],
  Cosmetics: [],
};
