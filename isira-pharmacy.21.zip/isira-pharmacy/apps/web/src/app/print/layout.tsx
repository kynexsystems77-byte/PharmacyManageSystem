import type { ReactNode } from 'react';

/** Bare layout for printable documents (no app shell). */
export default function PrintLayout({ children }: { children: ReactNode }) {
  return <div className="min-h-screen bg-white text-black">{children}</div>;
}
