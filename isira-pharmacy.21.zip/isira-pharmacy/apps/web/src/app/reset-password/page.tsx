'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Suspense, useState, type FormEvent } from 'react';
import { Alert, Button, Card, Field, Input } from '@/components/ui';
import { api, ApiError } from '@/lib/api';

function ResetForm() {
  const token = useSearchParams().get('token') ?? '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirm) return setError('The two passwords do not match.');
    setBusy(true);
    try {
      await api('/auth/password/reset', { method: 'POST', body: { token, newPassword: password } });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  if (!token) return <Alert>This reset link is incomplete. Request a new one.</Alert>;
  if (done) {
    return (
      <div className="space-y-4">
        <Alert tone="success">Your password was changed. Sign in with the new password.</Alert>
        <Link href="/login" className="block text-center text-sm text-brand hover:underline">Go to sign in</Link>
      </div>
    );
  }
  return (
    <form onSubmit={submit} className="space-y-4">
      {error && <Alert>{error}</Alert>}
      <Field label="New password (at least 10 characters)">
        <Input type="password" autoComplete="new-password" minLength={10} required autoFocus value={password} onChange={(e) => setPassword(e.target.value)} />
      </Field>
      <Field label="Repeat new password">
        <Input type="password" autoComplete="new-password" minLength={10} required value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      </Field>
      <Button type="submit" className="w-full" loading={busy}>Change password</Button>
    </form>
  );
}

export default function ResetPasswordPage() {
  return (
    <main className="grid min-h-screen place-items-center p-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-6 text-center text-xl font-semibold">Choose a new password</h1>
        <Card className="p-5">
          <Suspense fallback={null}>
            <ResetForm />
          </Suspense>
        </Card>
      </div>
    </main>
  );
}
