/** Thin fetch wrapper for the same-origin API (/api/* is proxied to NestJS /v1/*). */

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  /** Sent as X-Branch-Id for branch-scoped routes. The server re-checks access; this is only a selector. */
  branchId?: string | null;
  signal?: AbortSignal;
}

export async function api<T>(path: string, opts: ApiOptions = {}): Promise<T> {
  const method = opts.method ?? 'GET';
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (method !== 'GET') {
    headers['Content-Type'] = 'application/json';
    headers['X-Kynex-Csrf'] = '1'; // CSRF defence required by the API for cookie-authenticated writes
  }
  if (opts.branchId) headers['X-Branch-Id'] = opts.branchId;

  let res: Response;
  try {
    res = await fetch(`/api${path}`, {
      method,
      headers,
      body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
      credentials: 'same-origin',
      cache: 'no-store',
      signal: opts.signal,
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') throw err;
    throw new ApiError(0, 'NETWORK', 'Cannot reach the server. Check your connection and that the API is running.');
  }

  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!res.ok) {
    const e = (data as { error?: { code?: string; message?: string; details?: unknown } } | null)?.error;
    throw new ApiError(res.status, e?.code ?? 'ERROR', e?.message ?? (res.statusText || 'Request failed'), e?.details);
  }
  return data as T;
}

/** multipart/form-data upload (same CSRF + branch headers as api()). */
export async function uploadFile<T>(path: string, file: File, opts: { branchId?: string | null; field?: string } = {}): Promise<T> {
  const form = new FormData();
  form.append(opts.field ?? 'file', file);
  const headers: Record<string, string> = { Accept: 'application/json', 'X-Kynex-Csrf': '1' };
  if (opts.branchId) headers['X-Branch-Id'] = opts.branchId;
  const res = await fetch(`/api${path}`, { method: 'POST', body: form, headers, credentials: 'same-origin' });
  const data = (await res.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null;
  if (!res.ok) throw new ApiError(res.status, data?.error?.code ?? 'ERROR', data?.error?.message ?? 'Upload failed');
  return data as T;
}

/** Downloads (or opens) a file from the API. Needed because a plain link cannot send the X-Branch-Id header. */
export async function downloadFile(path: string, opts: { branchId?: string | null; open?: boolean } = {}): Promise<void> {
  const headers: Record<string, string> = {};
  if (opts.branchId) headers['X-Branch-Id'] = opts.branchId;
  const res = await fetch(`/api${path}`, { headers, credentials: 'same-origin', cache: 'no-store' });
  if (!res.ok) {
    const data = (await res.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null;
    throw new ApiError(res.status, data?.error?.code ?? 'ERROR', data?.error?.message ?? 'Download failed');
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  if (opts.open) {
    window.open(url, '_blank', 'noopener');
  } else {
    const name = /filename="([^"]+)"/.exec(res.headers.get('content-disposition') ?? '')?.[1] ?? 'download';
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
