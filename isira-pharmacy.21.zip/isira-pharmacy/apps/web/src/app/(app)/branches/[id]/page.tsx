'use client';

import { Plus } from 'lucide-react';
import { useState } from 'react';
import { DataTable, KeyValue, Modal, PageHeader, Select, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { BranchRow, Location } from '@/lib/types';
import { BranchForm, branchBody, type BranchDraft } from '@/components/branch-form';

export default function BranchPage({ params }: { params: { id: string } }) {
  const { can } = useAuth();
  const toast = useToast();
  const { data: b, isLoading, error } = useBranchQuery<BranchRow & { locations: (Location & { isActive: boolean })[] }>(`/branches/${params.id}`);
  const [draft, setDraft] = useState<BranchDraft | null>(null);
  const [loc, setLoc] = useState<{ name: string; type: string; isDefault: boolean } | null>(null);
  const update = useApiMutation<object>('PATCH', `/branches/${params.id}`, { onSuccess: () => { toast.success('Branch saved'); setDraft(null); } });
  const toggle = useApiMutation<object>('PATCH', `/branches/${params.id}`, { onSuccess: () => toast.success('Branch status changed') });
  const addLoc = useApiMutation<object>('POST', `/branches/${params.id}/locations`, { onSuccess: () => { toast.success('Location added'); setLoc(null); } });
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !b) return <Alert>{errorMessage(error) || 'Branch not found'}</Alert>;
  const manage = can('branch:manage');
  return (
    <div className="space-y-4">
      <PageHeader
        back="/branches"
        title={b.name}
        subtitle={<span className="flex items-center gap-2"><span className="font-mono">{b.code}</span>{!b.isActive && <Badge>Inactive</Badge>}</span>}
        actions={manage && (
          <>
            <Button variant="outline" loading={toggle.isPending} onClick={() => toggle.mutate({ isActive: !b.isActive })}>{b.isActive ? 'Deactivate' : 'Activate'}</Button>
            <Button onClick={() => setDraft({ name: b.name, code: b.code, address: b.address ?? '', phone: b.phone ?? '', email: b.email ?? '', invoicePrefix: b.invoicePrefix, receiptHeader: b.receiptHeader ?? '', receiptFooter: b.receiptFooter ?? '', taxNumber: b.taxNumber ?? '' })}>Edit</Button>
          </>
        )}
      />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Address', value: b.address }, { label: 'Phone', value: b.phone }, { label: 'Email', value: b.email },
          { label: 'Tax number', value: b.taxNumber }, { label: 'Invoice prefix', value: b.invoicePrefix },
          { label: 'Receipt header', value: b.receiptHeader }, { label: 'Receipt footer', value: b.receiptFooter },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Stock locations" action={manage && <Button variant="outline" className="h-8 px-3" onClick={() => setLoc({ name: '', type: 'WAREHOUSE', isDefault: false })}><Plus size={14} /> Add location</Button>} />
        <DataTable
          rows={b.locations}
          rowKey={(l) => l.id}
          columns={[
            { key: 'n', header: 'Name', cell: (l) => <span className="font-medium">{l.name}</span> },
            { key: 't', header: 'Type', cell: (l) => titleCase(l.type) },
            { key: 'd', header: '', cell: (l) => l.isDefault && <Badge tone="success">Default for sales</Badge> },
          ]}
        />
      </Card>
      <Modal open={Boolean(draft)} onClose={() => setDraft(null)} title={`Edit ${b.name}`} size="lg"
        footer={<><Button variant="outline" onClick={() => setDraft(null)}>Cancel</Button><Button loading={update.isPending} onClick={() => draft && update.mutate(branchBody(draft, false))}>Save</Button></>}>
        {update.error && <div className="mb-3"><Alert>{errorMessage(update.error)}</Alert></div>}
        {draft && <BranchForm value={draft} onChange={setDraft} creating={false} />}
      </Modal>
      <Modal open={Boolean(loc)} onClose={() => setLoc(null)} title="Add location" size="sm"
        footer={<><Button variant="outline" onClick={() => setLoc(null)}>Cancel</Button><Button loading={addLoc.isPending} disabled={(loc?.name.trim().length ?? 0) < 2} onClick={() => loc && addLoc.mutate({ ...loc, name: loc.name.trim() })}>Add</Button></>}>
        {loc && (
          <div className="space-y-3">
            {addLoc.error && <Alert>{errorMessage(addLoc.error)}</Alert>}
            <Field label="Name"><Input value={loc.name} onChange={(e) => setLoc({ ...loc, name: e.target.value })} placeholder="Cold room, Back store…" /></Field>
            <Field label="Type">
              <Select value={loc.type} onChange={(e) => setLoc({ ...loc, type: e.target.value })}>
                {['SALES_FLOOR', 'WAREHOUSE', 'QUARANTINE'].map((t) => <option key={t} value={t}>{titleCase(t)}</option>)}
              </Select>
            </Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={loc.isDefault} onChange={(e) => setLoc({ ...loc, isDefault: e.target.checked })} /> Default location for sales</label>
          </div>
        )}
      </Modal>
    </div>
  );
}
