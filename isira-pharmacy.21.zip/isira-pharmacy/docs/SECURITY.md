# Kynex Pharmacy security model and go-live checklist

## How data is protected

### Tenant isolation is enforced by PostgreSQL

- Every tenant table has `FORCE ROW LEVEL SECURITY`, with a policy on `app.tenant_id`.
- The API connects as `kynex_app`, which is `NOSUPERUSER NOBYPASSRLS`. With no tenant context, a query returns zero rows.
- Each authenticated request runs in one transaction with the tenant set (`TenantTransactionInterceptor`).
- Generated triggers reject any foreign key that points at another tenant's row.
- Before a session exists, login, reset and session lookups go through narrow `SECURITY DEFINER` functions (`auth_find_*`).

### Ledgers are append-only

`inventory_movements`, `party_ledger_entries`, `cash_transactions` and `audit_logs` reject UPDATE, DELETE and TRUNCATE. This is enforced twice: by trigger and by grant.

### Integrity is enforced in the database

- CHECK constraints keep stock at zero or above and quantities positive, among other rules.
- Money is `NUMERIC` and handled with `Prisma.Decimal` end to end.
- Invoice and document numbers are gapless and come from a locked sequence table.

### Authentication

- Passwords are hashed with Argon2id.
- When an email is unknown, login still does the same password-check work, so response time doesn't reveal which accounts exist.
- After `LOGIN_MAX_ATTEMPTS` failures the account locks for `LOGIN_LOCK_MINUTES`.
- Error messages are generic.
- The session token is opaque and 256-bit, sent in an `httpOnly`, `SameSite=Lax` cookie. Only its SHA-256 hash is stored.
- Sessions have an idle timeout and an absolute lifetime. They are revoked on logout, on a password change or reset, and when a user is disabled.

### Two-factor authentication (TOTP, RFC 6238)

- The secret is AES-256-GCM encrypted with `MFA_ENCRYPTION_KEY`.
- The password step returns a signed challenge that expires after 5 minutes. The session cookie is only set once the second step succeeds.
- A used time step is recorded, so a code can't be replayed.
- Recovery codes are single-use, and only their SHA-256 hashes are stored.
- Wrong codes count toward the account lockout.
- An administrator with `user:manage` can reset a user's 2FA. This signs the user out everywhere and is audited.
- Turning 2FA on signs out the user's other sessions.

### CSRF

Every state-changing request needs the `X-Kynex-Csrf: 1` header. Combined with SameSite cookies and the same-origin `/api` proxy, a cross-site form can't forge a request.

### Authorization

- Permissions are per branch, and every route is checked server-side: guards, then a check inside the service for cost and profit data.
- Nobody can grant a permission they don't hold. System roles are read-only.
- Cost and profit are removed from API responses, not just hidden in the UI.

### Rate limits

- The default limit is 300 requests per minute per IP.
- Stricter limits apply to login (10/min), the 2FA step (5/min), password reset (5/min) and 2FA management.
- With `REDIS_URL` set, counters are shared across API replicas.

### Headers

| Where | Headers |
|---|---|
| API | Helmet. `x-powered-by` is removed. |
| Web | CSP (`default-src 'self'`, `frame-ancestors 'none'`, `object-src 'none'`), `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`, COOP. HSTS and `upgrade-insecure-requests` are added when `WEB_ORIGIN` is https. |

### Uploads

- The type is detected by magic bytes (PDF, PNG, JPEG, WebP) and the client's MIME type is ignored. Size is limited.
- Files are stored under random keys in S3 or on local disk.
- Downloads are served with `nosniff` and `Content-Disposition`, and need the `prescription:read` permission.

### Exports

CSV and Excel cells that start with `= + - @` are prefixed with `'`, which blocks formula injection.

### Audit

Every change writes an audit row inside the same transaction. The row records before and after values, the user, branch, IP and request id. Secrets are redacted.

## Go-live checklist

- [ ] Every password in `.env.production` is unique and random (`openssl rand -hex 24`). There are no demo values.
- [ ] `MFA_ENCRYPTION_KEY` is set (32+ characters) and stored in your password manager. Losing it disables everyone's 2FA.
- [ ] `WEB_ORIGIN` is the public `https://` URL. TLS terminates at Caddy or your load balancer, and `TRUST_PROXY` matches the number of proxies.
- [ ] `SWAGGER_ENABLED=false`. Leave `SEED_DEMO=false` on a real database.
- [ ] Postgres and Redis ports are **not** published to the internet. The production compose file publishes neither.
- [ ] Owners and managers have turned on two-factor authentication (Account page). Recovery codes are stored safely.
- [ ] SMTP is configured, and a password-reset email arrives.
- [ ] Nightly `pg_dump` backups go off the server, and a restore has been tested (see DEPLOYMENT.md). The storage volume or S3 bucket is backed up too.
- [ ] The worker is running: `docker compose ps` shows it as up, and low-stock and expiry alerts appear.
- [ ] Host OS updates are automatic. Docker images are rebuilt regularly for base-image security fixes.
- [ ] Every user account has its own login. Disable shared accounts and the accounts of staff who have left.
- [ ] Review the audit log (`Audit` page) for unexpected role or permission changes.

## Reporting a vulnerability

Email the maintainers privately. Do not open a public issue. Include steps to reproduce and the affected version.
