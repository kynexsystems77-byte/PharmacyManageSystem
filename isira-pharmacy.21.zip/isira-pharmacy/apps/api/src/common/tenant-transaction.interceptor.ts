import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { from, lastValueFrom, Observable } from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';
import { requestContext } from './request-context';

/**
 * Wraps every authenticated request in ONE transaction with the tenant set for Row-Level Security.
 * Business changes and their audit record commit (or roll back) together.
 * set_config(..., true) is transaction-local, so the tenant can never leak between requests.
 */
@Injectable()
export class TenantTransactionInterceptor implements NestInterceptor {
  constructor(private readonly prisma: PrismaService) {}

  intercept(_ctx: ExecutionContext, next: CallHandler): Observable<unknown> {
    const store = requestContext.getStore();
    const tenantId = store?.auth?.tenantId;
    if (!store || !tenantId) {
      return next.handle(); // public routes (login, health): no tenant data is touched here
    }
    return from(
      this.prisma.$transaction(
        async (tx) => {
          await tx.$queryRaw`SELECT set_config('app.tenant_id', ${tenantId}, true)`;
          store.tx = tx;
          try {
            return await lastValueFrom(next.handle(), { defaultValue: undefined });
          } finally {
            store.tx = undefined;
          }
        },
        { timeout: 30_000, maxWait: 5_000 },
      ),
    );
  }
}
