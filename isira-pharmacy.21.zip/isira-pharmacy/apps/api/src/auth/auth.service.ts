import { BadRequestException, ConflictException, ForbiddenException, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import { ENV, type Env } from '../config/env';
import { PrismaService, TenantDb } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { getStore, type AuthContext } from '../common/request-context';
import { AccessService } from './access.service';
import { MailService } from './mail.service';
import { MfaService } from './mfa.service';
import { PasswordService } from './password.service';
import { SessionService } from './session.service';

interface LoginUserRow {
  id: string;
  tenant_id: string;
  email: string;
  password_hash: string;
  status: string;
  failed_login_count: number;
  locked_until: Date | null;
}

const INVALID = 'Invalid email or password';
const sha256 = (v: string) => createHash('sha256').update(v).digest('hex');

@Injectable()
export class AuthService {
  constructor(
    @Inject(ENV) private readonly env: Env,
    private readonly prisma: PrismaService,
    private readonly db: TenantDb,
    private readonly passwords: PasswordService,
    private readonly sessions: SessionService,
    private readonly access: AccessService,
    private readonly audit: AuditService,
    private readonly mail: MailService,
    private readonly mfa: MfaService,
  ) {}

  async login(email: string, password: string) {
    const rows = await this.prisma.$queryRaw<LoginUserRow[]>`
      SELECT id, tenant_id, email, password_hash, status::text AS status, failed_login_count, locked_until
      FROM auth_find_user_by_email(${email})`;
    const user = rows[0];
    if (!user) {
      await this.passwords.verifyDummy(password);
      throw new UnauthorizedException(INVALID);
    }

    const locked = user.locked_until !== null && user.locked_until.getTime() > Date.now();
    const passwordOk = await this.passwords.verify(user.password_hash, password);
    if (locked) throw new UnauthorizedException(INVALID); // no signal to attackers that the account exists/is locked
    if (!passwordOk) {
      await this.registerFailure(user);
      throw new UnauthorizedException(INVALID);
    }

    const tenants = await this.prisma.$queryRaw<{ status: string }[]>`
      SELECT status::text AS status FROM auth_find_tenant(${user.tenant_id}::uuid)`;
    if (user.status !== 'ACTIVE' || tenants[0]?.status !== 'ACTIVE') {
      throw new ForbiddenException('This account is not active. Contact your pharmacy administrator.');
    }

    const mfaOn = await this.db.run(user.tenant_id, async (tx) => {
      const u = await tx.user.findUniqueOrThrow({ where: { id: user.id }, select: { mfaEnabledAt: true } });
      return u.mfaEnabledAt !== null;
    });
    if (mfaOn) {
      // Password step passed; the session is only created after the second factor.
      return { mfaRequired: true as const, challenge: this.mfa.signChallenge({ userId: user.id, tenantId: user.tenant_id }) };
    }
    return this.startSession(user.tenant_id, user.id);
  }

  /** Second login step for users with two-factor authentication. */
  async loginMfa(challenge: string, code: string) {
    const c = this.mfa.verifyChallenge(challenge);
    if (!c) throw new UnauthorizedException('Your sign-in attempt expired. Please enter your password again.');
    const tenants = await this.prisma.$queryRaw<{ status: string }[]>`
      SELECT status::text AS status FROM auth_find_tenant(${c.tenantId}::uuid)`;
    if (tenants[0]?.status !== 'ACTIVE') throw new ForbiddenException('This account is not active. Contact your pharmacy administrator.');

    const outcome = await this.db.run(c.tenantId, async (tx) => {
      const u = await tx.user.findFirst({
        where: { id: c.userId, deletedAt: null },
        select: { id: true, status: true, lockedUntil: true, failedLoginCount: true, mfaSecret: true, mfaEnabledAt: true, mfaRecoveryCodes: true, mfaLastStep: true },
      });
      if (!u || u.status !== 'ACTIVE' || !u.mfaEnabledAt || !u.mfaSecret) return { ok: false as const, user: null };
      if (u.lockedUntil && u.lockedUntil.getTime() > Date.now()) return { ok: false as const, user: null };
      const step = this.mfa.verifyTotp(u.mfaSecret, code, u.mfaLastStep);
      if (step !== null) {
        await tx.user.update({ where: { id: u.id }, data: { mfaLastStep: step } });
        return { ok: true as const, user: u, recovery: false };
      }
      const hash = this.mfa.hashRecovery(code);
      if (code.length >= 10 && u.mfaRecoveryCodes.includes(hash)) {
        await tx.user.update({ where: { id: u.id }, data: { mfaRecoveryCodes: u.mfaRecoveryCodes.filter((h) => h !== hash) } });
        await this.audit.record({ action: 'auth.mfa_recovery_code_used', entityType: 'user', entityId: u.id, tenantId: c.tenantId, userId: u.id }, tx);
        return { ok: true as const, user: u, recovery: true };
      }
      return { ok: false as const, user: u };
    });
    if (!outcome.ok) {
      if (outcome.user) {
        await this.registerFailure({ id: outcome.user.id, tenant_id: c.tenantId, email: '', password_hash: '', status: 'ACTIVE', failed_login_count: outcome.user.failedLoginCount, locked_until: null });
      }
      throw new UnauthorizedException('That code is not valid');
    }
    return this.startSession(c.tenantId, c.userId);
  }

  private startSession(tenantId: string, userId: string) {
    const store = getStore();
    const user = { id: userId, tenant_id: tenantId };
    return this.db.run(user.tenant_id, async (tx) => {
      await tx.user.update({ where: { id: user.id }, data: { failedLoginCount: 0, lockedUntil: null, lastLoginAt: new Date() } });
      const session = await this.sessions.create(tx, user.tenant_id, user.id, store.ip, store.userAgent);
      await this.audit.record(
        { action: 'auth.login', entityType: 'session', entityId: session.sessionId, tenantId: user.tenant_id, userId: user.id },
        tx,
      );
      return { mfaRequired: false as const, token: session.token, expiresAt: session.expiresAt, profile: await this.access.profile(tx, user.id) };
    });
  }

  private async registerFailure(user: LoginUserRow): Promise<void> {
    await this.db.run(user.tenant_id, async (tx) => {
      const attempts = user.failed_login_count + 1;
      const lock = attempts >= this.env.LOGIN_MAX_ATTEMPTS;
      await tx.user.update({
        where: { id: user.id },
        data: {
          failedLoginCount: lock ? 0 : attempts,
          lockedUntil: lock ? new Date(Date.now() + this.env.LOGIN_LOCK_MINUTES * 60_000) : null,
        },
      });
      await this.audit.record(
        { action: lock ? 'auth.account_locked' : 'auth.login_failed', entityType: 'user', entityId: user.id, tenantId: user.tenant_id, userId: user.id },
        tx,
      );
    });
  }

  async logout(auth: AuthContext): Promise<void> {
    const tx = this.db.tx;
    await tx.session.update({ where: { id: auth.sessionId }, data: { revokedAt: new Date() } });
    await this.audit.record({ action: 'auth.logout', entityType: 'session', entityId: auth.sessionId });
  }

  me(auth: AuthContext) {
    return this.access.profile(this.db.tx, auth.userId);
  }

  /** Always succeeds from the caller's point of view (no account enumeration). */
  async forgotPassword(email: string): Promise<void> {
    const rows = await this.prisma.$queryRaw<{ id: string; tenant_id: string; status: string }[]>`
      SELECT id, tenant_id, status::text AS status FROM auth_find_user_by_email(${email})`;
    const user = rows[0];
    if (!user || user.status !== 'ACTIVE') return;
    const token = randomBytes(32).toString('base64url');
    await this.db.run(user.tenant_id, async (tx) => {
      await tx.passwordResetToken.create({
        data: {
          tenantId: user.tenant_id,
          userId: user.id,
          tokenHash: sha256(token),
          expiresAt: new Date(Date.now() + this.env.PASSWORD_RESET_MINUTES * 60_000),
        },
      });
      await this.audit.record(
        { action: 'auth.password_reset_requested', entityType: 'user', entityId: user.id, tenantId: user.tenant_id, userId: user.id },
        tx,
      );
    });
    await this.mail.sendPasswordReset(email, token);
  }

  async resetPassword(token: string, newPassword: string): Promise<void> {
    const rows = await this.prisma.$queryRaw<{ id: string; tenant_id: string; user_id: string }[]>`
      SELECT id, tenant_id, user_id FROM auth_find_reset_token(${sha256(token)})`;
    const row = rows[0];
    if (!row) throw new BadRequestException('This reset link is invalid or has expired');
    const passwordHash = await this.passwords.hash(newPassword);
    await this.db.run(row.tenant_id, async (tx) => {
      await tx.user.update({ where: { id: row.user_id }, data: { passwordHash, failedLoginCount: 0, lockedUntil: null } });
      await tx.passwordResetToken.update({ where: { id: row.id }, data: { usedAt: new Date() } });
      await tx.session.updateMany({ where: { userId: row.user_id, revokedAt: null }, data: { revokedAt: new Date() } });
      await this.audit.record(
        { action: 'auth.password_reset', entityType: 'user', entityId: row.user_id, tenantId: row.tenant_id, userId: row.user_id },
        tx,
      );
    });
  }

  async changePassword(auth: AuthContext, currentPassword: string, newPassword: string): Promise<void> {
    const tx = this.db.tx;
    const user = await tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { passwordHash: true } });
    if (!(await this.passwords.verify(user.passwordHash, currentPassword))) {
      throw new BadRequestException('Current password is incorrect');
    }
    await tx.user.update({ where: { id: auth.userId }, data: { passwordHash: await this.passwords.hash(newPassword) } });
    await tx.session.updateMany({ where: { userId: auth.userId, revokedAt: null, id: { not: auth.sessionId } }, data: { revokedAt: new Date() } });
    await this.audit.record({ action: 'auth.password_changed', entityType: 'user', entityId: auth.userId });
  }

  // ---- two-factor management (signed-in user) ----

  async mfaStatus(auth: AuthContext) {
    const u = await this.db.tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { mfaEnabledAt: true, mfaRecoveryCodes: true } });
    return { enabled: u.mfaEnabledAt !== null, enabledAt: u.mfaEnabledAt, recoveryCodesLeft: u.mfaEnabledAt ? u.mfaRecoveryCodes.length : 0 };
  }

  /** Starts (or restarts) enrolment: a new secret is stored but not active until confirmed. */
  async mfaSetup(auth: AuthContext) {
    const tx = this.db.tx;
    const u = await tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { email: true, mfaEnabledAt: true, tenant: { select: { name: true } } } });
    if (u.mfaEnabledAt) throw new ConflictException('Two-factor authentication is already on. Turn it off first to re-enrol.');
    const secret = this.mfa.generateSecret();
    await tx.user.update({ where: { id: auth.userId }, data: { mfaSecret: this.mfa.encrypt(secret), mfaLastStep: null } });
    return { secret, otpauthUrl: this.mfa.otpauthUrl(secret, u.email, u.tenant.name.slice(0, 60)) };
  }

  async mfaEnable(auth: AuthContext, code: string) {
    const tx = this.db.tx;
    const u = await tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { mfaSecret: true, mfaEnabledAt: true } });
    if (u.mfaEnabledAt) throw new ConflictException('Two-factor authentication is already on');
    if (!u.mfaSecret) throw new BadRequestException('Start the set-up first');
    const step = this.mfa.verifyTotp(u.mfaSecret, code, null);
    if (step === null) throw new BadRequestException('That code is not valid. Check the time on your phone and try again.');
    const { codes, hashes } = this.mfa.generateRecoveryCodes();
    await tx.user.update({ where: { id: auth.userId }, data: { mfaEnabledAt: new Date(), mfaRecoveryCodes: hashes, mfaLastStep: step } });
    // other sessions were signed in with one factor only
    await tx.session.updateMany({ where: { userId: auth.userId, revokedAt: null, id: { not: auth.sessionId } }, data: { revokedAt: new Date() } });
    await this.audit.record({ action: 'auth.mfa_enabled', entityType: 'user', entityId: auth.userId });
    return { recoveryCodes: codes };
  }

  async mfaRegenerateCodes(auth: AuthContext, code: string) {
    const tx = this.db.tx;
    const u = await tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { mfaSecret: true, mfaEnabledAt: true, mfaLastStep: true } });
    if (!u.mfaEnabledAt || !u.mfaSecret) throw new BadRequestException('Two-factor authentication is off');
    const step = this.mfa.verifyTotp(u.mfaSecret, code, u.mfaLastStep);
    if (step === null) throw new BadRequestException('That code is not valid');
    const { codes, hashes } = this.mfa.generateRecoveryCodes();
    await tx.user.update({ where: { id: auth.userId }, data: { mfaRecoveryCodes: hashes, mfaLastStep: step } });
    await this.audit.record({ action: 'auth.mfa_recovery_codes_regenerated', entityType: 'user', entityId: auth.userId });
    return { recoveryCodes: codes };
  }

  async mfaDisable(auth: AuthContext, password: string, code: string) {
    const tx = this.db.tx;
    const u = await tx.user.findUniqueOrThrow({ where: { id: auth.userId }, select: { passwordHash: true, mfaSecret: true, mfaEnabledAt: true, mfaRecoveryCodes: true, mfaLastStep: true } });
    if (!u.mfaEnabledAt || !u.mfaSecret) throw new BadRequestException('Two-factor authentication is off');
    if (!(await this.passwords.verify(u.passwordHash, password))) throw new BadRequestException('Password is incorrect');
    const ok = this.mfa.verifyTotp(u.mfaSecret, code, u.mfaLastStep) !== null || u.mfaRecoveryCodes.includes(this.mfa.hashRecovery(code));
    if (!ok) throw new BadRequestException('That code is not valid');
    await tx.user.update({ where: { id: auth.userId }, data: { mfaSecret: null, mfaEnabledAt: null, mfaRecoveryCodes: [], mfaLastStep: null } });
    await this.audit.record({ action: 'auth.mfa_disabled', entityType: 'user', entityId: auth.userId });
  }
}
