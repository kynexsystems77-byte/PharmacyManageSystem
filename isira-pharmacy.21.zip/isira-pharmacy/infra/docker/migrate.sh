#!/bin/sh
# Applies committed Prisma migrations, then the security layer (RLS, triggers, grants), as the owner role.
# Optional: SEED_DEMO=true also loads the demo pharmacy (never do this on a real production database).
set -eu
cd /app/packages/database
echo "Applying migrations..."
./node_modules/.bin/prisma migrate deploy
echo "Applying database hardening..."
./node_modules/.bin/tsx scripts/harden.ts
if [ "${SEED_DEMO:-false}" = "true" ]; then
  echo "Seeding demo data..."
  ./node_modules/.bin/tsx prisma/seed.ts
fi
echo "Database ready."
