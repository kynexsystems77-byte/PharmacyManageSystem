import { randomBytes } from 'node:crypto';
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { ENV, loadEnv } from '../src/config/env';
import { configureApp } from '../src/setup';

/** Shared helpers for the Phase 5+ end-to-end tests (real database; run `pnpm db:seed` first). */

export const PASSWORD = process.env.SEED_PASSWORD ?? 'ChangeMe123!';
export const CSRF = { 'X-Kynex-Csrf': '1' };

export async function bootApp(): Promise<INestApplication> {
  process.env.NODE_ENV = 'test';
  const env = loadEnv();
  const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
  const app = moduleRef.createNestApplication();
  configureApp(app, moduleRef.get(ENV) ?? env);
  await app.init();
  return app;
}

export interface Session {
  agent: ReturnType<typeof request.agent>;
  branchId: string;
  profile: { user: { id: string }; branches: { id: string; name: string; permissions: string[] }[] };
  /** GET with X-Branch-Id */
  get: (path: string) => request.Test;
  /** POST with X-Branch-Id + CSRF */
  post: (path: string, body?: object) => request.Test;
  patch: (path: string, body?: object) => request.Test;
  put: (path: string, body?: object) => request.Test;
  del: (path: string) => request.Test;
}

export async function login(app: INestApplication, email: string, branchId?: string): Promise<Session> {
  const agent = request.agent(app.getHttpServer());
  const res = await agent.post('/v1/auth/login').send({ email, password: PASSWORD });
  if (res.status !== 200) throw new Error(`login ${email} failed: ${res.status} ${JSON.stringify(res.body)}`);
  const profile = res.body as Session['profile'];
  const branch = branchId ?? profile.branches[0]?.id;
  if (!branch) throw new Error(`${email} has no branch`);
  const h = { 'X-Branch-Id': branch };
  return {
    agent,
    branchId: branch,
    profile,
    get: (p) => agent.get(`/v1${p}`).set(h),
    post: (p, b) => agent.post(`/v1${p}`).set(h).set(CSRF).send(b ?? {}),
    patch: (p, b) => agent.patch(`/v1${p}`).set(h).set(CSRF).send(b ?? {}),
    put: (p, b) => agent.put(`/v1${p}`).set(h).set(CSRF).send(b ?? {}),
    del: (p) => agent.delete(`/v1${p}`).set(h).set(CSRF),
  };
}

export function uid(): string {
  return randomBytes(4).toString('hex').toUpperCase();
}

export function isoDay(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

export function expectStatus(res: request.Response, status: number): void {
  if (res.status !== status) {
    throw new Error(`Expected HTTP ${status}, got ${res.status}: ${JSON.stringify(res.body)}`);
  }
}

/** Creates a product in the first (sub-)category and returns it. */
export async function createProduct(s: Session, overrides: Record<string, unknown> = {}) {
  const cats = await s.get('/categories');
  expectStatus(cats, 200);
  const category = (cats.body as { id: string; name: string }[]).find((c) => c.name === 'Antibiotics') ?? cats.body[0];
  const res = await s.post('/products', {
    brandName: `Test Product ${uid()}`,
    genericName: 'Testamol',
    dosageForm: 'TABLET',
    baseUnit: 'tablet',
    purchasePrice: 2,
    sellingPrice: 5,
    reorderLevel: 10,
    categoryId: category.id,
    ...overrides,
  });
  expectStatus(res, 201);
  return res.body as { id: string; sku: string; brandName: string; productUnits: { id: string; name: string }[] };
}

export async function defaultLocationId(s: Session): Promise<string> {
  const res = await s.get('/branches/current');
  expectStatus(res, 200);
  const locs = res.body.locations as { id: string; isDefault: boolean }[];
  return (locs.find((l) => l.isDefault) ?? locs[0]).id;
}

/** Adds stock through the opening-stock endpoint; returns the batch id. */
export async function addStock(
  s: Session,
  productId: string,
  opts: { batchNumber?: string; quantity: number; expiryDate?: string | null; unitCost?: number; locationId?: string },
): Promise<string> {
  const res = await s.post('/inventory/opening-stock', {
    locationId: opts.locationId ?? (await defaultLocationId(s)),
    productId,
    batchNumber: opts.batchNumber ?? `B-${uid()}`,
    expiryDate: opts.expiryDate === undefined ? isoDay(365) : opts.expiryDate,
    unitCost: opts.unitCost ?? 2,
    quantity: opts.quantity,
  });
  expectStatus(res, 201);
  return res.body.batchId as string;
}
