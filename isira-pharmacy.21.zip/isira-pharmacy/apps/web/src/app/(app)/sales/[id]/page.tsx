'use client';

import { Ban, FileText, Printer, RotateCcw } from 'lucide-react';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { DataTable, KeyValue, Modal, PageHeader, Select, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { downloadFile } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, qty, titleCase } from '@/lib/format';
import { errorMessage, newKey, useApiMutation, useBranchQuery } from '@/lib/hooks';
import { receiptUrl, SALE_TONE } from '@/lib/status';
import type { Sale } from '@/lib/types';

export default function SalePage({ params }: { params: { id: string } }) {
  const { can, profile, branchId } = useAuth();
  const toast = useToast();
  const cur = profile.tenant.currencyCode;
  const fmt = (v: string | number) => money(num(v), cur);
  const { data: s, isLoading, error } = useBranchQuery<Sale>(`/sales/${params.id}`);
  const [voiding, setVoiding] = useState(false);
  const [returning, setReturning] = useState(false);
  const [reason, setReason] = useState('');
  const voidSale = useApiMutation<object>('POST', `/sales/${params.id}/void`, { onSuccess: () => { toast.success('Sale voided; stock and money reversed'); setVoiding(false); } });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !s) return <Alert>{errorMessage(error) || 'Sale not found'}</Alert>;
  const returnable = ['COMPLETED', 'PARTIALLY_RETURNED'].includes(s.status);
  const showCost = can('report:financial:view');
  // net of returns: returned revenue and its cost both come back out
  const profit = s.status === 'VOIDED' ? 0 : s.saleItems.reduce(
    (a, i) => a + num(i.lineTotal) - num(i.costTotal) - i.salesReturnItems.reduce((r, x) => r + num(x.lineTotal) - num(x.costTotal), 0),
    0,
  );

  return (
    <div className="space-y-4">
      <PageHeader
        back="/sales"
        title={s.invoiceNo ?? 'Held bill'}
        subtitle={<span className="flex items-center gap-2"><Badge tone={SALE_TONE[s.status]}>{titleCase(s.status)}</Badge>{dateTime(s.soldAt ?? s.heldAt)}</span>}
        actions={
          <>
            <Button variant="outline" onClick={() => window.open(receiptUrl(s.id, branchId), 'receipt', 'width=420,height=720')}><Printer size={16} /> Receipt</Button>
            {s.invoiceNo && <Button variant="outline" onClick={() => downloadFile(`/sales/${s.id}/invoice.pdf`, { branchId, open: true }).catch((e) => toast.error(errorMessage(e)))}><FileText size={16} /> A4 invoice</Button>}
            {returnable && can('sale:return') && <Button variant="outline" onClick={() => setReturning(true)}><RotateCcw size={16} /> Return items</Button>}
            {s.status === 'COMPLETED' && can('sale:void') && <Button variant="outline" onClick={() => setVoiding(true)} className="text-danger"><Ban size={16} /> Void</Button>}
          </>
        }
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-4 lg:col-span-2">
          <KeyValue items={[
            { label: 'Customer', value: s.customer ? <Link className="text-brand hover:underline" href={`/customers/${s.customer.id}`}>{s.customer.fullName}</Link> : 'Walk-in' },
            { label: 'Cashier', value: s.cashier.fullName },
            { label: 'Branch', value: `${s.branch.name} · ${s.location.name}` },
            { label: 'Prescription', value: s.prescription ? <Link className="text-brand hover:underline" href={`/prescriptions/${s.prescription.id}`}>{s.prescription.prescriptionNumber ?? 'Rx'} · Dr. {s.prescription.doctorName}</Link> : null },
            { label: 'Notes', value: s.notes },
            ...(s.status === 'VOIDED' ? [{ label: 'Voided', value: `${dateTime(s.voidedAt)} by ${s.voidedBy?.fullName ?? '-'}: ${s.voidReason}` }] : []),
          ]} />
        </Card>
        <Card className="space-y-1.5 p-4 text-sm">
          <R l="Subtotal" v={fmt(s.subtotal)} />
          {num(s.discountTotal) > 0 && <R l="Discounts" v={`- ${fmt(s.discountTotal)}`} />}
          {num(s.taxTotal) > 0 && <R l="Tax" v={fmt(s.taxTotal)} />}
          {num(s.roundingAdjustment) !== 0 && <R l="Rounding" v={fmt(s.roundingAdjustment)} />}
          <R l="Total" v={fmt(s.grandTotal)} strong />
          {s.payments.map((p) => <R key={p.id} l={`${p.kind === 'REFUND' ? 'Refund' : 'Paid'} · ${titleCase(p.method)}${p.reference ? ` (${p.reference})` : ''}`} v={`${p.kind === 'REFUND' ? '- ' : ''}${fmt(p.amount)}`} />)}
          {num(s.changeGiven) > 0 && <R l="Change given" v={fmt(s.changeGiven)} />}
          {num(s.balanceDue) > 0 && <R l="On credit" v={fmt(s.balanceDue)} />}
          {showCost && <R l={s.salesReturns.length ? 'Gross profit (after returns)' : 'Gross profit'} v={fmt(profit)} />}
        </Card>
      </div>
      <Card>
        <CardHeader title="Items" />
        <DataTable
          rows={s.saleItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => <div><p className="font-medium">{i.productName}</p><p className="text-xs text-fg-muted">{i.saleItemAllocations.map((a) => `${a.batch.batchNumber} ×${qty(num(a.baseQuantity))} (exp ${dateOnly(a.expiryDate)})`).join(' · ')}</p></div> },
            { key: 'q', header: 'Qty', align: 'right', cell: (i) => `${qty(num(i.quantity))} ${i.productUnit?.name ?? i.product.baseUnit}` },
            { key: 'u', header: 'Price', align: 'right', cell: (i) => fmt(i.unitPrice) },
            { key: 'd', header: 'Discount', align: 'right', cell: (i) => (num(i.discountAmount) > 0 ? fmt(i.discountAmount) : '-') },
            { key: 'x', header: 'Tax', align: 'right', cell: (i) => (num(i.taxAmount) > 0 ? `${fmt(i.taxAmount)}` : '-') },
            { key: 'r', header: 'Returned', align: 'right', cell: (i) => { const r = i.salesReturnItems.reduce((a, x) => a + num(x.quantity), 0); return r > 0 ? <span className="text-warning">{qty(r)}</span> : '-'; } },
            { key: 't', header: 'Total', align: 'right', cell: (i) => <span className="font-medium">{fmt(i.lineTotal)}</span> },
          ]}
        />
      </Card>
      {s.salesReturns.length > 0 && (
        <Card>
          <CardHeader title="Returns" />
          <ul className="divide-y divide-line text-sm">
            {s.salesReturns.map((r) => (
              <li key={r.id} className="flex justify-between gap-2 px-4 py-2.5">
                <Link href={`/sales/returns/${r.id}`} className="font-mono text-xs text-brand hover:underline">{r.number}</Link>
                <span className="text-fg-muted">{dateTime(r.returnDate)} · {titleCase(r.refundMethod ?? '')} · {r.reason}</span>
                <span className="tabular">{fmt(r.total)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <Modal open={voiding} onClose={() => setVoiding(false)} title={`Void ${s.invoiceNo}?`} size="sm"
        footer={<><Button variant="outline" onClick={() => setVoiding(false)}>Cancel</Button><Button className="!bg-danger !text-white" loading={voidSale.isPending} disabled={reason.trim().length < 3} onClick={() => voidSale.mutate({ reason: reason.trim() })}>Void sale</Button></>}>
        <div className="space-y-3 text-sm">
          {voidSale.error && <Alert>{errorMessage(voidSale.error)}</Alert>}
          <p>All items go back to their batches and every payment is refunded (cash from your open shift). This is recorded in the audit log.</p>
          <Field label="Reason"><Input value={reason} onChange={(e) => setReason(e.target.value)} autoFocus /></Field>
        </div>
      </Modal>
      {returning && <ReturnModal sale={s} onClose={() => setReturning(false)} />}
    </div>
  );
}

function R({ l, v, strong }: { l: string; v: string; strong?: boolean }) {
  return <div className={`flex justify-between gap-3 ${strong ? 'border-t border-line pt-1.5 text-base font-semibold' : 'text-fg-muted'}`}><span>{l}</span><span className="tabular text-fg">{v}</span></div>;
}

function ReturnModal({ sale, onClose }: { sale: Sale; onClose: () => void }) {
  const { profile } = useAuth();
  const toast = useToast();
  const fmt = (v: number) => money(v, profile.tenant.currencyCode);
  const [qtys, setQtys] = useState<Record<string, string>>({});
  const [damaged, setDamaged] = useState<Record<string, boolean>>({});
  const [method, setMethod] = useState('CASH');
  const [reason, setReason] = useState('');
  const [k] = useState(newKey);
  const rows = sale.saleItems.map((i) => {
    const returned = i.salesReturnItems.reduce((a, x) => a + num(x.quantity), 0);
    return { i, left: num(i.baseQuantity) - returned, perUnit: num(i.lineTotal) / num(i.baseQuantity) };
  });
  const estimate = useMemo(() => rows.reduce((a, r) => a + Math.min(num(qtys[r.i.id] ?? 0), r.left) * r.perUnit, 0), [rows, qtys]);
  const submit = useApiMutation<object>('POST', `/sales/${sale.id}/returns`, { onSuccess: () => { toast.success('Return processed'); onClose(); } });
  const items = rows.filter((r) => num(qtys[r.i.id] ?? 0) > 0).map((r) => ({ saleItemId: r.i.id, quantity: num(qtys[r.i.id]), restock: !damaged[r.i.id] }));
  return (
    <Modal open onClose={onClose} title={`Return items from ${sale.invoiceNo}`} size="lg"
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button loading={submit.isPending} disabled={!items.length || reason.trim().length < 3} onClick={() => submit.mutate({ idempotencyKey: k, items, refundMethod: method, reason: reason.trim() })}>Refund about {fmt(estimate)}</Button></>}>
      <div className="space-y-3 text-sm">
        {submit.error && <Alert>{errorMessage(submit.error)}</Alert>}
        <table className="w-full">
          <thead><tr className="text-left text-xs uppercase text-fg-muted"><th className="py-1">Item</th><th className="py-1 text-right">Can return</th><th className="py-1">Return qty (base units)</th><th className="py-1">Damaged</th></tr></thead>
          <tbody className="divide-y divide-line">
            {rows.map((r) => (
              <tr key={r.i.id}>
                <td className="py-2">{r.i.productName}</td>
                <td className="py-2 text-right tabular">{qty(r.left)} {r.i.product.baseUnit}</td>
                <td className="py-2 pl-3"><Input type="number" min="0" max={r.left} step="0.001" disabled={r.left <= 0} value={qtys[r.i.id] ?? ''} onChange={(e) => setQtys({ ...qtys, [r.i.id]: e.target.value })} className="w-28" /></td>
                <td className="py-2 pl-3"><input type="checkbox" aria-label="Damaged, do not restock" checked={Boolean(damaged[r.i.id])} onChange={(e) => setDamaged({ ...damaged, [r.i.id]: e.target.checked })} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Refund method">
            <Select value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="CASH">Cash (from your open shift)</option>
              <option value="CARD">Card</option>
              <option value="BANK_TRANSFER">Bank transfer</option>
              {sale.customer && <option value="CUSTOMER_CREDIT">Store credit to {sale.customer.fullName}</option>}
              <option value="OTHER">Other</option>
            </Select>
          </Field>
          <Field label="Reason"><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Wrong item, not needed, damaged…" /></Field>
        </div>
        <p className="text-xs text-fg-muted">Ticked items are refunded but not put back on the shelf. Large refunds need a manager&apos;s approval permission.</p>
      </div>
    </Modal>
  );
}
