'use client';

import { Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import { paymentState, PURCHASE_TONE } from '@/lib/status';
import type { PurchaseListRow } from '@/lib/types';

export default function PurchasesPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [unpaid, setUnpaid] = useState(false);
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status, unpaid]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<PurchaseListRow>>(
    `/purchases${qs({ page, pageSize: 25, search: s, status, unpaid: unpaid || undefined })}`,
    { keepPrevious: true },
  );
  return (
    <div>
      <PageHeader
        title="Purchases"
        subtitle="Supplier invoices and goods received. Receiving creates batches and adds stock."
        actions={can('purchase:create') && <Link href="/purchasing/new"><Button><Plus size={16} /> New purchase</Button></Link>}
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_180px_auto]">
          <SearchBox value={search} onChange={setSearch} placeholder="GRN, invoice number or supplier" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">Any status</option>
            <option value="DRAFT">Draft</option>
            <option value="RECEIVED">Received</option>
            <option value="CANCELLED">Cancelled</option>
          </Select>
          <label className="flex items-center gap-2 px-2 text-sm"><input type="checkbox" checked={unpaid} onChange={(e) => setUnpaid(e.target.checked)} /> Unpaid only</label>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(p) => p.id}
          onRowClick={(p) => router.push(`/purchasing/${p.id}`)}
          columns={[
            { key: 'n', header: 'GRN', cell: (p) => <span className="font-mono text-xs">{p.number}</span> },
            { key: 'd', header: 'Date', cell: (p) => dateOnly(p.purchaseDate) },
            { key: 's', header: 'Supplier', cell: (p) => <span className="font-medium">{p.supplier.name}</span> },
            { key: 'inv', header: 'Invoice no.', cell: (p) => p.supplierInvoiceNo ?? '-' },
            { key: 'st', header: 'Status', cell: (p) => <Badge tone={PURCHASE_TONE[p.status]}>{p.status.toLowerCase()}</Badge> },
            {
              key: 'pay', header: 'Payment',
              cell: (p) => {
                if (p.status !== 'RECEIVED') return '-';
                const st = paymentState(num(p.grandTotal), num(p.paidTotal));
                return <Badge tone={st.tone}>{st.label}</Badge>;
              },
            },
            { key: 'due', header: 'Due', cell: (p) => dateOnly(p.dueDate) },
            { key: 't', header: 'Total', align: 'right', cell: (p) => money(num(p.grandTotal), cur) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
