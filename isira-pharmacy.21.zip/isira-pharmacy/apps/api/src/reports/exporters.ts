import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import type { ReportColumn, ReportResult } from '@kynex/contracts';

type Cell = string | number | null | undefined;

function display(v: Cell, type: ReportColumn['type']): string {
  if (v === null || v === undefined || v === '') return '';
  if (typeof v === 'string' && Number.isNaN(Number(v))) return v;
  const n = Number(v);
  switch (type) {
    case 'money': return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    case 'quantity': return n.toLocaleString('en-US', { maximumFractionDigits: 3 });
    case 'number': return n.toLocaleString('en-US');
    case 'percent': return `${n.toLocaleString('en-US', { maximumFractionDigits: 2 })}%`;
    default: return String(v);
  }
}

/** Prevents CSV/Excel formula injection from user-entered text (=, +, -, @ at the start). */
function safeText(v: string): string {
  return /^[=+\-@\t\r]/.test(v) ? `'${v}` : v;
}

export function toCsv(r: ReportResult): Buffer {
  const esc = (s: string) => (/[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  const lines = [r.columns.map((c) => esc(c.label)).join(',')];
  const raw = (v: Cell, c: ReportColumn) => {
    if (v === null || v === undefined) return '';
    if (['money', 'quantity', 'number', 'percent'].includes(c.type) && typeof v === 'number') return String(v);
    return esc(safeText(String(v)));
  };
  for (const row of r.rows) lines.push(r.columns.map((c) => raw(row[c.key], c)).join(','));
  if (r.totals) lines.push(r.columns.map((c) => raw(r.totals![c.key], c)).join(','));
  // UTF-8 BOM so Excel opens non-ASCII text correctly
  return Buffer.from(`﻿${lines.join('\r\n')}\r\n`, 'utf8');
}

export async function toXlsx(r: ReportResult): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = process.env.APP_NAME || 'Isira Pharmacy';
  wb.created = new Date();
  const ws = wb.addWorksheet(r.title.slice(0, 31));
  ws.addRow([r.title]).font = { bold: true, size: 14 };
  ws.addRow([`${r.subtitle} · amounts in ${r.currencyCode} · generated ${new Date(r.generatedAt).toISOString().slice(0, 16).replace('T', ' ')} UTC`]).font = { color: { argb: 'FF666666' } };
  ws.addRow([]);
  const header = ws.addRow(r.columns.map((c) => c.label));
  header.font = { bold: true };
  header.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8F3F1' } };
    cell.border = { bottom: { style: 'thin', color: { argb: 'FF999999' } } };
  });
  const value = (v: Cell, c: ReportColumn) => {
    if (v === null || v === undefined || v === '') return null;
    if (['money', 'quantity', 'number', 'percent'].includes(c.type)) { const n = Number(v); return Number.isFinite(n) ? n : String(v); }
    return safeText(String(v));
  };
  for (const row of r.rows) ws.addRow(r.columns.map((c) => value(row[c.key], c)));
  if (r.totals) {
    const t = ws.addRow(r.columns.map((c) => value(r.totals![c.key], c)));
    t.font = { bold: true };
    t.eachCell((cell) => { cell.border = { top: { style: 'thin' } }; });
  }
  r.columns.forEach((c, i) => {
    const column = ws.getColumn(i + 1);
    column.numFmt = c.type === 'money' ? '#,##0.00' : c.type === 'quantity' ? '#,##0.###' : c.type === 'percent' ? '0.0"%"' : c.type === 'number' ? '#,##0' : '@';
    const longest = Math.max(c.label.length, ...r.rows.slice(0, 500).map((row) => String(row[c.key] ?? '').length));
    column.width = Math.min(Math.max(longest + 2, 10), 50);
  });
  ws.views = [{ state: 'frozen', ySplit: 4 }];
  if (r.notes?.length) {
    ws.addRow([]);
    for (const n of r.notes) ws.addRow([n]).font = { italic: true, color: { argb: 'FF666666' } };
  }
  return Buffer.from(await wb.xlsx.writeBuffer());
}

export function toPdf(r: ReportResult, meta: { tenantName: string }): Promise<Buffer> {
  const landscape = r.columns.length > 6;
  const doc = new PDFDocument({ size: 'A4', layout: landscape ? 'landscape' : 'portrait', margin: 36, bufferPages: true, info: { Title: r.title, Author: meta.tenantName } });
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve) => doc.on('end', () => resolve(Buffer.concat(chunks))));

  const left = doc.page.margins.left;
  const width = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const numeric = (c: ReportColumn) => ['money', 'quantity', 'number', 'percent'].includes(c.type);
  // column widths: weight text columns higher than numeric ones
  const weights = r.columns.map((c) => (numeric(c) ? 1 : c.type === 'date' ? 1 : 1.8));
  const totalW = weights.reduce((a, b) => a + b, 0);
  const widths = weights.map((w) => (w / totalW) * width);
  const fontSize = r.columns.length > 9 ? 7 : 8;

  const header = () => {
    doc.font('Helvetica-Bold').fontSize(14).fillColor('#111').text(r.title, left, doc.page.margins.top, { width });
    doc.font('Helvetica').fontSize(9).fillColor('#555').text(`${meta.tenantName} · ${r.subtitle} · amounts in ${r.currencyCode}`, { width });
    doc.moveDown(0.6);
    drawRow(r.columns.map((c) => c.label), true);
  };
  const drawRow = (cells: string[], bold = false, shade = false) => {
    doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(fontSize);
    const heights = cells.map((t, i) => doc.heightOfString(t, { width: widths[i] - 6 }));
    const h = Math.max(...heights, fontSize + 2) + 6;
    if (doc.y + h > doc.page.height - doc.page.margins.bottom - 14) {
      doc.addPage();
      header();
    }
    const y = doc.y;
    if (shade || bold) doc.rect(left, y, width, h).fill(bold ? '#e8f3f1' : '#f6f8f8').fillColor('#111');
    let x = left;
    cells.forEach((t, i) => {
      doc.fillColor('#111').text(t, x + 3, y + 3, { width: widths[i] - 6, align: numeric(r.columns[i]) && !bold ? 'right' : numeric(r.columns[i]) ? 'right' : 'left' });
      x += widths[i];
    });
    doc.moveTo(left, y + h).lineTo(left + width, y + h).strokeColor('#dddddd').lineWidth(0.5).stroke();
    doc.y = y + h;
    doc.x = left;
  };

  header();
  r.rows.forEach((row, i) => drawRow(r.columns.map((c) => display(row[c.key], c.type)), false, i % 2 === 1));
  if (r.totals) drawRow(r.columns.map((c) => display(r.totals![c.key], c.type)), true);
  if (r.rows.length === 0) doc.font('Helvetica-Oblique').fontSize(9).text('No data for this period.', left, doc.y + 8);
  if (r.notes?.length) {
    doc.moveDown(0.8);
    doc.font('Helvetica-Oblique').fontSize(8).fillColor('#555');
    for (const n of r.notes) doc.text(n, left, undefined, { width });
  }
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    // writing inside the bottom margin would otherwise make pdfkit start a new page
    const bottom = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    doc.font('Helvetica').fontSize(7).fillColor('#888').text(
      `Generated ${new Date(r.generatedAt).toISOString().slice(0, 16).replace('T', ' ')} UTC · page ${i + 1} of ${range.count}`,
      left, doc.page.height - bottom + 10, { width, align: 'right', lineBreak: false },
    );
    doc.page.margins.bottom = bottom;
  }
  doc.end();
  return done;
}
