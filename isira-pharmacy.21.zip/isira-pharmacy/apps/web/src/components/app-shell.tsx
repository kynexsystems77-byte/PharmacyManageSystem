'use client';

import clsx from 'clsx';
import { LogOut, Menu, Pill, UserRound, X } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState, type ReactNode } from 'react';
import { useAuth } from '@/lib/auth';
import { NAV } from '@/lib/nav';
import { NotificationBell } from './notification-bell';
import { ThemeToggle } from './theme-toggle';

const GROUPS = ['Main', 'Operations', 'Administration'] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { profile, branch, setBranchId, canAny, logout } = useAuth();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  const visible = NAV.filter((n) => n.anyOf.length === 0 || canAny(...n.anyOf));

  const sidebar = (
    <nav aria-label="Main navigation" className="flex h-full flex-col">
      <div className="flex h-16 items-center gap-2 border-b border-line px-5">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand text-brand-fg"><Pill size={18} /></span>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold leading-tight">{profile.tenant.name}</p>
          <p className="truncate text-xs text-fg-muted">{branch?.name ?? 'Pharmacy management'}</p>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-3 py-4">
        {GROUPS.map((g) => {
          const items = visible.filter((n) => n.group === g);
          if (items.length === 0) return null;
          return (
            <div key={g} className="mb-5">
              {g !== 'Main' && <p className="mb-1 px-2 text-[11px] font-semibold uppercase tracking-wider text-fg-muted">{g}</p>}
              <ul className="space-y-0.5">
                {items.map((n) => {
                  const href = n.slug ? `/${n.slug}` : '/';
                  const active = n.slug ? pathname === href || pathname.startsWith(`${href}/`) : pathname === '/';
                  const Icon = n.icon;
                  return (
                    <li key={n.slug || 'dashboard'}>
                      <Link
                        href={href}
                        aria-current={active ? 'page' : undefined}
                        className={clsx(
                          'flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium',
                          active ? 'bg-brand/10 text-brand' : 'text-fg-muted hover:bg-subtle hover:text-fg',
                        )}
                      >
                        <Icon size={18} />
                        <span className="truncate">{n.label}</span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-line bg-surface lg:block">{sidebar}</aside>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button aria-label="Close menu" className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-surface shadow-xl">
            <button aria-label="Close menu" className="absolute right-3 top-4 grid h-8 w-8 place-items-center rounded-lg hover:bg-subtle" onClick={() => setOpen(false)}>
              <X size={18} />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-line bg-surface/90 px-4 backdrop-blur">
          <button aria-label="Open menu" className="grid h-9 w-9 place-items-center rounded-lg hover:bg-subtle lg:hidden" onClick={() => setOpen(true)}>
            <Menu size={20} />
          </button>

          <label className="flex items-center gap-2 text-sm">
            <span className="sr-only">Branch</span>
            <select
              value={branch?.id ?? ''}
              onChange={(e) => setBranchId(e.target.value)}
              className="h-9 max-w-[12rem] rounded-lg border border-line bg-surface px-2 text-sm font-medium sm:max-w-xs"
            >
              {profile.branches.map((b) => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          </label>

          <div className="ml-auto flex items-center gap-1">
            <NotificationBell />
            <ThemeToggle />
            <Link href="/account" title="Your account" className="mx-1 hidden rounded-lg px-2 py-1 text-right leading-tight hover:bg-subtle sm:block">
              <p className="text-sm font-medium">{profile.user.fullName}</p>
              <p className="text-xs text-fg-muted">{profile.user.isOwner ? 'Owner' : profile.user.email}</p>
            </Link>
            <Link href="/account" aria-label="Your account" className="grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-fg sm:hidden">
              <UserRound size={18} />
            </Link>
            <button onClick={logout} aria-label="Sign out" className="grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-fg">
              <LogOut size={18} />
            </button>
          </div>
        </header>
        <main className="mx-auto max-w-7xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
