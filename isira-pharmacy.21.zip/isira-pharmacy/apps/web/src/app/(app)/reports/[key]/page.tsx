'use client';

import clsx from 'clsx';
import { FileDown, FileSpreadsheet, FileText } from 'lucide-react';
import { useMemo, useState } from 'react';
import { REPORTS, type ReportResult } from '@kynex/contracts';
import { Forbidden, PageHeader, Select, useToast } from '@/components/kit';
import { categoryOptions } from '@/components/product-form';
import { preset, RangePicker, ScopeToggle, type DateRange } from '@/components/range-picker';
import { SeriesChart } from '@/components/series-chart';
import { Alert, Button, Card, Input, Skeleton } from '@/components/ui';
import { downloadFile } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, qty } from '@/lib/format';
import { errorMessage, qs, useBranchQuery } from '@/lib/hooks';
import type { Category } from '@/lib/types';

export default function ReportPage({ params }: { params: { key: string } }) {
  const def = REPORTS.find((r) => r.key === params.key);
  const { can, branchId } = useAuth();
  const toast = useToast();
  const [range, setRange] = useState<DateRange>(() => preset(def?.group === 'Finance' ? 'month' : '30d'));
  const [scope, setScope] = useState<'branch' | 'all'>('branch');
  const [days, setDays] = useState(def?.key === 'dead-stock' ? '90' : '60');
  const [categoryId, setCategoryId] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const cats = useBranchQuery<Category[]>(def?.params.includes('category') ? '/categories' : null, { staleTime: 60_000 });
  const catOpts = useMemo(() => categoryOptions(cats.data), [cats.data]);
  const query = def
    ? qs({
        ...(def.params.includes('range') ? range : {}),
        scope: def.params.includes('scope') ? scope : undefined,
        days: def.params.includes('days') ? Number(days) || 60 : undefined,
        categoryId: def.params.includes('category') ? categoryId : undefined,
      })
    : '';
  const { data, isLoading, isFetching, error } = useBranchQuery<ReportResult>(def && can(def.permission) ? `/reports/${def.key}${query}` : null, { keepPrevious: true });
  if (!def) return <Alert>Unknown report.</Alert>;
  if (!can(def.permission)) return <Forbidden what={`the ${def.title} report`} />;

  const fmt = (v: unknown, type: string) => {
    if (v === null || v === undefined || v === '') return '';
    if (typeof v === 'string' && Number.isNaN(Number(v))) return v;
    if (type === 'money') return money(num(v as number), data?.currencyCode ?? 'USD');
    if (type === 'quantity') return qty(num(v as number));
    if (type === 'number') return num(v as number).toLocaleString();
    if (type === 'percent') return `${num(v as number).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;
    if (type === 'date') return dateOnly(String(v));
    return String(v);
  };
  const exportAs = async (format: 'csv' | 'xlsx' | 'pdf') => {
    setBusy(format);
    try { await downloadFile(`/reports/${def.key}${query}&format=${format}`.replace('?&', '?').replace(/^([^?]*)&/, '$1?'), { branchId }); }
    catch (e) { toast.error(errorMessage(e)); }
    finally { setBusy(null); }
  };
  const numericKeys = new Set(data?.columns.filter((c) => ['money', 'quantity', 'number', 'percent'].includes(c.type)).map((c) => c.key));
  const chart = data && def.key === 'sales-daily' && data.rows.length > 1;

  return (
    <div className="space-y-4">
      <PageHeader
        back="/reports"
        title={def.title}
        subtitle={data?.subtitle ?? def.description}
        actions={can('report:export') && (
          <>
            <Button variant="outline" loading={busy === 'csv'} onClick={() => exportAs('csv')}><FileDown size={16} /> CSV</Button>
            <Button variant="outline" loading={busy === 'xlsx'} onClick={() => exportAs('xlsx')}><FileSpreadsheet size={16} /> Excel</Button>
            <Button variant="outline" loading={busy === 'pdf'} onClick={() => exportAs('pdf')}><FileText size={16} /> PDF</Button>
          </>
        )}
      />
      {def.params.length > 0 && (
        <Card className="flex flex-wrap items-center gap-2 p-3">
          {def.params.includes('range') && <RangePicker value={range} onChange={setRange} />}
          {def.params.includes('days') && (
            <label className="flex items-center gap-2 text-sm">{def.key === 'expiry' ? 'Expiring within' : 'Not sold for'} <Input type="number" min="1" value={days} onChange={(e) => setDays(e.target.value)} className="w-24" /> days</label>
          )}
          {def.params.includes('category') && (
            <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className="w-56" aria-label="Category">
              <option value="">All categories</option>
              {catOpts.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </Select>
          )}
          {def.params.includes('scope') && <ScopeToggle value={scope} onChange={setScope} />}
        </Card>
      )}
      {error && <Alert>{errorMessage(error)}</Alert>}
      {isLoading && <Skeleton className="h-64" />}
      {chart && (
        <Card className="p-4">
          <SeriesChart data={data.rows.map((r) => ({ day: String(r.date), total: num(r.total as number), profit: num(r.profit as number) }))} bars={(d) => d.total} line={'profit' in (data.rows[0] ?? {}) ? (d) => d.profit : undefined} format={(v) => money(v, data.currencyCode)} barLabel="Sales" lineLabel="Gross profit" />
        </Card>
      )}
      {data && (
        <Card className={clsx(isFetching && 'opacity-70')}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-fg-muted">
                  {data.columns.map((c) => <th key={c.key} className={clsx('whitespace-nowrap px-3 py-2.5 font-medium', numericKeys.has(c.key) && 'text-right')}>{c.label}</th>)}
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {data.rows.map((r, i) => {
                  const kind = (r as { kind?: string }).kind;
                  return (
                    <tr key={i} className={clsx(kind === 'subtotal' && 'bg-subtle/50 font-semibold', kind === 'total' && 'bg-brand/10 font-bold')}>
                      {data.columns.map((c) => (
                        <td key={c.key} className={clsx('px-3 py-2', numericKeys.has(c.key) && 'tabular whitespace-nowrap text-right', c.key === 'days_left' && num(r[c.key] as number) < 0 && 'font-medium text-danger')}>{fmt(r[c.key], c.type)}</td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
              {data.totals && (
                <tfoot>
                  <tr className="border-t-2 border-line font-semibold">
                    {data.columns.map((c) => <td key={c.key} className={clsx('px-3 py-2.5', numericKeys.has(c.key) && 'tabular whitespace-nowrap text-right')}>{fmt(data.totals![c.key], c.type)}</td>)}
                  </tr>
                </tfoot>
              )}
            </table>
            {data.rows.length === 0 && <p className="px-4 py-10 text-center text-sm text-fg-muted">No data for these filters.</p>}
          </div>
          {data.notes?.length ? <div className="space-y-1 border-t border-line px-4 py-3 text-xs text-fg-muted">{data.notes.map((n) => <p key={n}>{n}</p>)}</div> : null}
        </Card>
      )}
    </div>
  );
}
