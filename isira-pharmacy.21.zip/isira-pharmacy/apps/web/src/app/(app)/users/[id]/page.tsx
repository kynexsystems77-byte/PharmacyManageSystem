'use client';

import { KeyRound, Pencil, ShieldOff } from 'lucide-react';
import { useEffect, useState } from 'react';
import { BranchRolesEditor, type BranchRole } from '@/components/branch-roles-editor';
import { ConfirmDialog, KeyValue, Modal, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { UserRow } from '@/lib/types';

export default function UserPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const toast = useToast();
  const { data: u, isLoading, error } = useBranchQuery<UserRow>(`/users/${params.id}`);
  const [roles, setRoles] = useState<BranchRole[] | null>(null);
  const [edit, setEdit] = useState<{ fullName: string; phone: string } | null>(null);
  const [pw, setPw] = useState<string | null>(null);
  const [mfaReset, setMfaReset] = useState(false);
  useEffect(() => { if (u) setRoles(u.userBranchRoles.map((r) => ({ branchId: r.branchId, roleId: r.roleId }))); }, [u]);
  const saveRoles = useApiMutation<object>('PUT', `/users/${params.id}/branch-roles`, { onSuccess: () => toast.success('Access saved. It applies at the user\'s next sign-in.') });
  const update = useApiMutation<object>('PATCH', `/users/${params.id}`, { onSuccess: () => { toast.success('User saved'); setEdit(null); } });
  const setPassword = useApiMutation<object>('POST', `/users/${params.id}/password`, { onSuccess: () => { toast.success('Password set; the user was signed out everywhere'); setPw(null); } });
  const resetMfa = useApiMutation<object>('POST', `/users/${params.id}/mfa/reset`, { onSuccess: () => { toast.success('Two-factor authentication turned off; the user was signed out'); setMfaReset(false); } });
  if (isLoading || !roles) return <Skeleton className="h-64" />;
  if (error || !u) return <Alert>{errorMessage(error) || 'User not found'}</Alert>;
  const manage = can('user:manage') && (!u.isOwner || profile.user.isOwner);
  const self = u.id === profile.user.id;
  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader
        back="/users"
        title={u.fullName}
        subtitle={<span className="flex items-center gap-2">{u.email}<Badge tone={u.status === 'ACTIVE' ? 'success' : 'danger'}>{titleCase(u.status)}</Badge>{u.isOwner && <Badge tone="success">Owner</Badge>}</span>}
        actions={manage && (
          <>
            {!self && <Button variant="outline" loading={update.isPending} onClick={() => update.mutate({ status: u.status === 'ACTIVE' ? 'DISABLED' : 'ACTIVE' })}>{u.status === 'ACTIVE' ? 'Disable' : 'Enable'}</Button>}
            <Button variant="outline" onClick={() => setPw('')}><KeyRound size={16} /> Set password</Button>
            {!self && u.mfaEnabledAt && <Button variant="outline" onClick={() => setMfaReset(true)}><ShieldOff size={16} /> Reset 2FA</Button>}
            <Button onClick={() => setEdit({ fullName: u.fullName, phone: u.phone ?? '' })}><Pencil size={16} /> Edit</Button>
          </>
        )}
      />
      {update.error && <Alert>{errorMessage(update.error)}</Alert>}
      <Card className="p-4">
        <KeyValue items={[{ label: 'Phone', value: u.phone }, { label: 'Last sign-in', value: dateTime(u.lastLoginAt) }, { label: 'Two-factor', value: u.mfaEnabledAt ? `On since ${dateTime(u.mfaEnabledAt)}` : 'Off' }, { label: 'Created', value: dateTime(u.createdAt) }]} />
      </Card>
      {!u.isOwner && (
        <Card>
          <CardHeader title="Branch access" />
          <div className="space-y-3 p-4">
            {manage ? (
              <>
                <BranchRolesEditor value={roles} onChange={setRoles} />
                {saveRoles.error && <Alert>{errorMessage(saveRoles.error)}</Alert>}
                <div className="flex justify-end"><Button loading={saveRoles.isPending} onClick={() => saveRoles.mutate({ branchRoles: roles.filter((r) => r.branchId && r.roleId) })}>Save access</Button></div>
              </>
            ) : (
              <ul className="text-sm">{u.userBranchRoles.map((r) => <li key={r.branchId + r.roleId}>{r.role.name} at {r.branch.name}</li>)}</ul>
            )}
          </div>
        </Card>
      )}
      <Modal open={Boolean(edit)} onClose={() => setEdit(null)} title="Edit user" size="sm"
        footer={<><Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button><Button loading={update.isPending} onClick={() => edit && update.mutate({ fullName: edit.fullName.trim(), phone: edit.phone.trim() || null })}>Save</Button></>}>
        {edit && <div className="space-y-3"><Field label="Full name"><Input value={edit.fullName} onChange={(e) => setEdit({ ...edit, fullName: e.target.value })} /></Field><Field label="Phone"><Input value={edit.phone} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} /></Field></div>}
      </Modal>
      <ConfirmDialog open={mfaReset} onClose={() => setMfaReset(false)} danger loading={resetMfa.isPending} confirmLabel="Reset two-factor"
        title={`Reset two-factor for ${u.fullName}?`}
        body={<>Use this only when the user has lost their authenticator and recovery codes. They will be signed out and can sign in with their password alone until they set it up again.{resetMfa.error && <Alert>{errorMessage(resetMfa.error)}</Alert>}</>}
        onConfirm={() => resetMfa.mutate({})} />
      <Modal open={pw !== null} onClose={() => setPw(null)} title={`New password for ${u.fullName}`} size="sm"
        footer={<><Button variant="outline" onClick={() => setPw(null)}>Cancel</Button><Button loading={setPassword.isPending} disabled={(pw?.length ?? 0) < 10} onClick={() => setPassword.mutate({ newPassword: pw })}>Set password</Button></>}>
        <div className="space-y-3">
          {setPassword.error && <Alert>{errorMessage(setPassword.error)}</Alert>}
          <Field label="Password (10+ characters)"><Input type="password" autoComplete="new-password" value={pw ?? ''} onChange={(e) => setPw(e.target.value)} autoFocus /></Field>
          <p className="text-xs text-fg-muted">The user is signed out on every device and must use the new password.</p>
        </div>
      </Modal>
    </div>
  );
}
