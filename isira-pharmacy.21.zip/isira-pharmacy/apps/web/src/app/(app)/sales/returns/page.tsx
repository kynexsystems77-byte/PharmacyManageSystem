'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox } from '@/components/kit';
import { Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { SalesReturn } from '@/lib/types';

export default function SalesReturnsPage() {
  const router = useRouter();
  const { profile } = useAuth();
  const [search, setSearch] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<SalesReturn>>(`/sales-returns${qs({ page, pageSize: 25, search: s })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader title="Customer returns" subtitle="Start a return from the invoice (Invoices → open the invoice → Return items)." />
      <Card>
        <div className="border-b border-line p-3"><SearchBox value={search} onChange={setSearch} placeholder="Return or invoice number" /></div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(r) => r.id}
          onRowClick={(r) => router.push(`/sales/returns/${r.id}`)}
          columns={[
            { key: 'n', header: 'Return', cell: (r) => <span className="font-mono text-xs">{r.number}</span> },
            { key: 'd', header: 'Date', cell: (r) => dateTime(r.returnDate) },
            { key: 'i', header: 'Invoice', cell: (r) => <span className="font-mono text-xs">{r.sale.invoiceNo}</span> },
            { key: 'c', header: 'Customer', cell: (r) => r.sale.customer?.fullName ?? '-' },
            { key: 'm', header: 'Refund', cell: (r) => titleCase(r.refundMethod ?? '') },
            { key: 'r', header: 'Reason', cell: (r) => <span className="text-fg-muted">{r.reason}</span> },
            { key: 't', header: 'Amount', align: 'right', cell: (r) => money(num(r.total), profile.tenant.currencyCode) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
