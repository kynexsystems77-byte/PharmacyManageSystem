'use client';

import { Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { CustomerFormModal } from '@/components/customer-form';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Customer } from '@/lib/types';

export default function CustomersPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('active');
  const [creating, setCreating] = useState(false);
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Customer>>(`/customers${qs({ page, pageSize: 25, search: s, status, withBalance: true })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader title="Customers" actions={can('customer:manage') && <Button onClick={() => setCreating(true)}><Plus size={16} /> New customer</Button>} />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_180px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Name, phone, code or email" autoFocus />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status"><option value="active">Active</option><option value="inactive">Inactive</option><option value="all">All</option></Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(c) => c.id}
          onRowClick={(c) => router.push(`/customers/${c.id}`)}
          columns={[
            { key: 'n', header: 'Customer', cell: (c) => <div><p className="font-medium">{c.fullName}</p><p className="text-xs text-fg-muted">{c.code}</p></div> },
            { key: 'p', header: 'Phone', cell: (c) => c.phone ?? '-' },
            { key: 'e', header: 'Email', cell: (c) => c.email ?? '-' },
            { key: 'l', header: 'Credit limit', align: 'right', cell: (c) => (num(c.creditLimit) > 0 ? money(num(c.creditLimit), profile.tenant.currencyCode) : <span className="text-fg-muted">Cash only</span>) },
            { key: 'b', header: 'Owes', align: 'right', cell: (c) => <span className={num(c.balance) > 0 ? 'font-medium text-warning' : 'text-fg-muted'}>{money(num(c.balance), profile.tenant.currencyCode)}</span> },
            { key: 's', header: '', cell: (c) => !c.isActive && <Badge>Inactive</Badge> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
      {creating && <CustomerFormModal onClose={() => setCreating(false)} onSaved={(c) => router.push(`/customers/${c.id}`)} />}
    </div>
  );
}
