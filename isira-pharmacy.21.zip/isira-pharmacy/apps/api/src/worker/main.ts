import 'reflect-metadata';
import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { Worker } from 'bullmq';
import { ENV, type Env } from '../config/env';
import { QUEUE_NAME, QueueService, redisConnection } from '../jobs/queue';
import { JobProcessor, WorkerModule, type JobName } from './worker.module';

/**
 * Background worker (same codebase as the API, separate process): `pnpm worker:dev` / `pnpm worker:start`.
 * With REDIS_URL: BullMQ worker + repeatable schedules (retries, backoff, one job per tenant).
 * Without it: simple in-process timers (fine for a single small installation).
 */
async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(WorkerModule, { bufferLogs: false });
  app.enableShutdownHooks();
  const env = app.get<Env>(ENV);
  const processor = app.get(JobProcessor);
  const queue = app.get(QueueService).queue;
  const log = new Logger('Worker');
  const scanEvery = env.ALERT_SCAN_MINUTES * 60_000;

  if (queue && env.REDIS_URL) {
    const enqueue = (name: JobName, data: Record<string, unknown>) => queue.add(name, data, { attempts: 3, backoff: { type: 'exponential', delay: 10_000 }, removeOnComplete: 1_000, removeOnFail: 5_000 });
    const worker = new Worker(QUEUE_NAME, (job) => processor.handle(job.name as JobName, job.data as Record<string, unknown>, enqueue), {
      connection: redisConnection(env.REDIS_URL),
      concurrency: 4,
    });
    worker.on('failed', (job, err) => { if (job) void processor.failed(job, err); });
    worker.on('error', (e) => log.error(`Worker error: ${e.message}`));
    // repeatable schedules (idempotent: re-running the worker updates them instead of duplicating)
    await queue.upsertJobScheduler('scan-alerts', { every: scanEvery }, { name: 'scan-alerts', data: {} });
    await queue.upsertJobScheduler('process-outbox', { every: 15_000 }, { name: 'process-outbox', data: {} });
    await queue.upsertJobScheduler('cleanup', { pattern: '30 2 * * *' }, { name: 'cleanup', data: {} });
    await enqueue('scan-alerts', {});
    log.log(`BullMQ worker running (alerts every ${env.ALERT_SCAN_MINUTES} min, outbox every 15 s, cleanup daily 02:30)`);
    const stop = async () => { await worker.close(); await app.close(); process.exit(0); };
    process.on('SIGTERM', () => void stop());
    process.on('SIGINT', () => void stop());
    return;
  }

  log.warn('REDIS_URL is not set: using in-process timers (no retries). Set REDIS_URL in production.');
  const run = (name: JobName) => processor.handle(name, {}).catch((e: Error) => {
    log.error(`${name} failed: ${e.message}`);
    void processor.failed({ name, data: {}, attemptsMade: 1, opts: { attempts: 1 } }, e);
  });
  void run('scan-alerts');
  setInterval(() => void run('scan-alerts'), scanEvery);
  setInterval(() => void run('process-outbox'), 15_000);
  setInterval(() => void run('cleanup'), 24 * 3_600_000);
}

bootstrap().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
