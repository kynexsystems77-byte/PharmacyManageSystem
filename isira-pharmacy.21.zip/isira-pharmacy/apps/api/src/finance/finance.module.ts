import {
  Body, ConflictException, Controller, Delete, Get, HttpCode, Module, NotFoundException, Param, ParseUUIDPipe, Patch, Post, Put, Query,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import {
  createExpenseCategorySchema, createExpenseSchema, dateRangeQuerySchema, listExpensesQuerySchema, tenantSettingsSchema, updateExpenseSchema,
} from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId } from '../common/branch';
import { openSessionFor, recordCash } from '../common/cash';
import { dec, money2, parseDateOnly, readTenantSettings, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';
import { FinanceService } from './finance.service';

class TenantSettingsDto extends createZodDto(tenantSettingsSchema) {}
class CreateExpenseCategoryDto extends createZodDto(createExpenseCategorySchema) {}
class CreateExpenseDto extends createZodDto(createExpenseSchema) {}
class UpdateExpenseDto extends createZodDto(updateExpenseSchema) {}
class ListExpensesQueryDto extends createZodDto(listExpensesQuerySchema) {}
class DateRangeQueryDto extends createZodDto(dateRangeQuerySchema) {}

@ApiTags('Settings')
@ApiCookieAuth()
@Controller('settings')
export class SettingsController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly tenantInfo: TenantInfoService) {}

  /** Operational settings (every signed-in user may read them; the POS needs some). */
  @Get()
  async get() {
    return this.tenantInfo.get(this.db.tx);
  }

  @Put()
  @RequirePermissions('tenant:settings:manage')
  async update(@Body() dto: TenantSettingsDto) {
    const tx = this.db.tx;
    const t = await tx.tenant.findFirstOrThrow({ select: { id: true, settings: true } });
    const before = readTenantSettings(t.settings);
    const after = { ...(t.settings as Record<string, unknown>), ...dto };
    await tx.tenant.update({ where: { id: t.id }, data: { settings: after as Prisma.InputJsonValue } });
    await this.audit.record({ action: 'tenant.settings_changed', entityType: 'tenant', entityId: t.id, before, after: readTenantSettings(after) });
    return this.tenantInfo.get(tx);
  }
}

const EXPENSE_SELECT = {
  id: true, amount: true, paymentMethod: true, description: true, expenseDate: true, reference: true, createdAt: true, registerSessionId: true,
  category: { select: { id: true, name: true } },
  createdBy: { select: { id: true, fullName: true } },
} satisfies Prisma.ExpenseSelect;

@ApiTags('Finance')
@ApiCookieAuth()
@Controller()
export class ExpensesController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly tenantInfo: TenantInfoService) {}

  @Get('expense-categories')
  @RequirePermissions('expense:read')
  categories() {
    return this.db.tx.expenseCategory.findMany({ where: { isActive: true }, orderBy: { name: 'asc' }, select: { id: true, name: true } });
  }

  @Post('expense-categories')
  @RequirePermissions('expense:manage')
  async createCategory(@Body() dto: CreateExpenseCategoryDto, @CurrentAuth() auth: AuthContext) {
    const c = await this.db.tx.expenseCategory.create({ data: { tenantId: auth.tenantId, name: dto.name }, select: { id: true, name: true } });
    await this.audit.record({ action: 'expense_category.created', entityType: 'expense_category', entityId: c.id, after: c });
    return c;
  }

  @Get('expenses')
  @BranchScoped()
  @RequirePermissions('expense:read')
  async list(@Query() q: ListExpensesQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.ExpenseWhereInput = {
      branchId: currentBranchId(),
      ...(q.categoryId ? { categoryId: q.categoryId } : {}),
      ...(q.from || q.to ? { expenseDate: { ...(q.from ? { gte: parseDateOnly(q.from) } : {}), ...(q.to ? { lte: parseDateOnly(q.to) } : {}) } } : {}),
      ...(q.search ? { OR: [{ description: { contains: q.search, mode: 'insensitive' } }, { reference: { contains: q.search, mode: 'insensitive' } }] } : {}),
    };
    const [rows, total, sum] = await Promise.all([
      tx.expense.findMany({ where, orderBy: [{ expenseDate: 'desc' }, { createdAt: 'desc' }], select: EXPENSE_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.expense.count({ where }),
      tx.expense.aggregate({ where, _sum: { amount: true } }),
    ]);
    return { ...paged(rows, total, q.page, q.pageSize), totalAmount: dec(sum._sum.amount).toFixed(2) };
  }

  @Post('expenses')
  @BranchScoped()
  @RequirePermissions('expense:manage')
  async create(@Body() dto: CreateExpenseDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    if (!(await tx.expenseCategory.count({ where: { id: dto.categoryId } }))) throw new NotFoundException('Expense category not found');
    let sessionId: string | null = null;
    if (dto.fromRegister) {
      if (dto.paymentMethod !== 'CASH') throw new UnprocessableEntityException('Only cash can be paid from the register');
      const s = await openSessionFor(tx, branchId, auth.userId);
      if (!s) throw new UnprocessableEntityException('Open a register shift to pay from the drawer');
      sessionId = s.id;
    }
    const { timezone } = await this.tenantInfo.get(tx);
    const e = await tx.expense.create({
      data: {
        tenantId: auth.tenantId, branchId, categoryId: dto.categoryId, amount: money2(dto.amount), paymentMethod: dto.paymentMethod,
        description: dto.description, expenseDate: parseDateOnly(dto.expenseDate ?? todayIn(timezone)), reference: dto.reference ?? null,
        createdById: auth.userId, registerSessionId: sessionId,
      },
      select: EXPENSE_SELECT,
    });
    if (sessionId) {
      await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: sessionId, userId: auth.userId, type: 'EXPENSE', amount: money2(dto.amount).negated(), referenceType: 'expense', referenceId: e.id, note: dto.description });
    }
    await this.audit.record({ action: 'expense.created', entityType: 'expense', entityId: e.id, after: e });
    return e;
  }

  @Patch('expenses/:id')
  @BranchScoped()
  @RequirePermissions('expense:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateExpenseDto) {
    const tx = this.db.tx;
    const before = await tx.expense.findFirst({ where: { id, branchId: currentBranchId() }, select: EXPENSE_SELECT });
    if (!before) throw new NotFoundException('Expense not found');
    if (dto.amount !== undefined && before.registerSessionId && !dec(dto.amount).equals(before.amount)) {
      throw new ConflictException('This expense was paid from a register. Delete it and enter it again to change the amount.');
    }
    const after = await tx.expense.update({
      where: { id },
      data: {
        categoryId: dto.categoryId, description: dto.description, reference: dto.reference,
        expenseDate: dto.expenseDate ? parseDateOnly(dto.expenseDate) : undefined, amount: dto.amount === undefined ? undefined : money2(dto.amount),
      },
      select: EXPENSE_SELECT,
    });
    await this.audit.record({ action: 'expense.updated', entityType: 'expense', entityId: id, before, after });
    return after;
  }

  /** Deleting a register-paid expense puts the cash back into that (still open) shift. */
  @Delete('expenses/:id')
  @HttpCode(204)
  @BranchScoped()
  @RequirePermissions('expense:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const before = await tx.expense.findFirst({ where: { id, branchId }, select: EXPENSE_SELECT });
    if (!before) throw new NotFoundException('Expense not found');
    if (before.registerSessionId) {
      const s = await tx.registerSession.findFirstOrThrow({ where: { id: before.registerSessionId }, select: { status: true } });
      if (s.status !== 'OPEN') throw new ConflictException('The shift this was paid from is closed; the expense can no longer be deleted');
      await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: before.registerSessionId, userId: auth.userId, type: 'EXPENSE', amount: dec(before.amount), referenceType: 'expense_reversal', referenceId: id, note: `Reversed: ${before.description}` });
    }
    await tx.expense.delete({ where: { id } });
    await this.audit.record({ action: 'expense.deleted', entityType: 'expense', entityId: id, before });
  }
}

@ApiTags('Finance')
@ApiCookieAuth()
@Controller('finance')
export class FinanceController {
  constructor(private readonly db: TenantDb, private readonly finance: FinanceService, private readonly tenantInfo: TenantInfoService) {}

  /** Profit and loss for a date range, with a daily series and outstanding balances. */
  @Get('summary')
  @BranchScoped()
  @RequirePermissions('finance:read')
  async summary(@Query() q: DateRangeQueryDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const { timezone, currencyCode } = await this.tenantInfo.get(tx);
    const branchIds = this.finance.branchesFor(auth, 'finance:read', currentBranchId(), q.scope);
    const range = { from: q.from, to: q.to, timezone, branchIds };
    const [pl, daily, recv, pay] = await Promise.all([
      this.finance.profitAndLoss(tx, range),
      this.finance.daily(tx, range),
      tx.partyLedgerEntry.aggregate({ where: { customerId: { not: null } }, _sum: { amount: true } }),
      tx.partyLedgerEntry.aggregate({ where: { supplierId: { not: null } }, _sum: { amount: true } }),
    ]);
    return { currencyCode, timezone, ...pl, daily, receivables: dec(recv._sum.amount).toFixed(2), payables: dec(pay._sum.amount).toFixed(2) };
  }

  /** Register shifts in the range with expected vs counted cash. */
  @Get('reconciliation')
  @BranchScoped()
  @RequirePermissions('register:read')
  async reconciliation(@Query() q: DateRangeQueryDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const branchIds = this.finance.branchesFor(auth, 'register:read', currentBranchId(), q.scope);
    const shifts = await this.finance.shifts(tx, { from: q.from, to: q.to, timezone, branchIds });
    const closed = shifts.filter((s) => s.status === 'CLOSED');
    return {
      shifts: shifts.map((s) => ({
        id: s.id, register: s.register, branch: s.branch, openedBy: s.opened_by, closedBy: s.closed_by, openedAt: s.opened_at, closedAt: s.closed_at,
        status: s.status, opening: s.opening, expected: s.expected, counted: s.counted, variance: s.variance,
      })),
      totals: {
        shifts: shifts.length,
        open: shifts.length - closed.length,
        shortages: closed.filter((s) => dec(s.variance).lt(0)).length,
        netVariance: closed.reduce((a, s) => a.plus(s.variance ?? 0), dec(0)).toFixed(2),
      },
    };
  }
}

@Module({ controllers: [SettingsController, ExpensesController, FinanceController], providers: [FinanceService], exports: [FinanceService] })
export class FinanceModule {}
