import { Global, Module } from '@nestjs/common';
import { AccessService } from './access.service';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { MailService } from './mail.service';
import { MfaService } from './mfa.service';
import { PasswordService } from './password.service';
import { SessionService } from './session.service';

/** Global: the guards in AppModule depend on SessionService / AccessService. */
@Global()
@Module({
  controllers: [AuthController],
  providers: [AuthService, SessionService, AccessService, PasswordService, MailService, MfaService],
  exports: [SessionService, AccessService, PasswordService],
})
export class AuthModule {}
