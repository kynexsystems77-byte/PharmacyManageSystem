'use client';

import clsx from 'clsx';
import { AlertOctagon, AlertTriangle, Bell, CheckCheck, Info } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { dateTime } from '@/lib/format';
import { useApiMutation, useBranchQuery, type Paged } from '@/lib/hooks';
import type { AppNotification } from '@/lib/types';

export const SEVERITY_ICON = { INFO: Info, WARNING: AlertTriangle, CRITICAL: AlertOctagon } as const;
export const SEVERITY_TONE = { INFO: 'text-brand', WARNING: 'text-warning', CRITICAL: 'text-danger' } as const;

/** Header bell: unread count (polled every 30 s) and the latest alerts. */
export function NotificationBell() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const count = useBranchQuery<{ unread: number }>('/notifications/unread-count', { refetchInterval: 30_000 });
  const list = useBranchQuery<Paged<AppNotification> & { unread: number }>(open ? '/notifications?pageSize=8' : null);
  const read = useApiMutation<string>('POST', (id) => `/notifications/${id}/read`);
  const readAll = useApiMutation<object>('POST', '/notifications/read-all');
  useEffect(() => {
    const onDoc = (e: MouseEvent) => box.current && !box.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);
  const unread = count.data?.unread ?? 0;
  const go = (n: AppNotification) => {
    if (!n.readAt) read.mutate(n.id);
    setOpen(false);
    if (n.data?.link) router.push(n.data.link);
  };
  return (
    <div ref={box} className="relative">
      <button aria-label={`Notifications${unread ? ` (${unread} unread)` : ''}`} onClick={() => setOpen((o) => !o)} className="relative grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-fg">
        <Bell size={18} />
        {unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">{unread > 99 ? '99+' : unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-40 mt-2 w-[min(92vw,380px)] overflow-hidden rounded-xl border border-line bg-surface shadow-xl">
          <div className="flex items-center justify-between border-b border-line px-3 py-2">
            <p className="text-sm font-semibold">Notifications</p>
            {unread > 0 && <button onClick={() => readAll.mutate({})} className="flex items-center gap-1 text-xs font-medium text-brand hover:underline"><CheckCheck size={14} /> Mark all read</button>}
          </div>
          <ul className="max-h-96 divide-y divide-line overflow-y-auto">
            {list.data?.data.length === 0 && <li className="px-3 py-6 text-center text-sm text-fg-muted">You are all caught up.</li>}
            {list.data?.data.map((n) => {
              const Icon = SEVERITY_ICON[n.severity];
              return (
                <li key={n.id}>
                  <button onClick={() => go(n)} className={clsx('flex w-full gap-3 px-3 py-2.5 text-left hover:bg-subtle', !n.readAt && 'bg-brand/5')}>
                    <Icon size={18} className={clsx('mt-0.5 shrink-0', SEVERITY_TONE[n.severity])} />
                    <span className="min-w-0 flex-1">
                      <span className={clsx('block text-sm', !n.readAt && 'font-semibold')}>{n.title}</span>
                      {n.body && <span className="block truncate text-xs text-fg-muted">{n.body}</span>}
                      <span className="block text-[11px] text-fg-muted">{dateTime(n.createdAt)}{n.branch ? ` · ${n.branch.name}` : ''}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
          <Link href="/notifications" onClick={() => setOpen(false)} className="block border-t border-line px-3 py-2 text-center text-xs font-medium text-brand hover:bg-subtle">See all</Link>
        </div>
      )}
    </div>
  );
}
