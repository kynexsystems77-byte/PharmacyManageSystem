import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { ENV, loadEnv } from '../src/config/env';
import { configureApp } from '../src/setup';

const PASSWORD = process.env.SEED_PASSWORD ?? 'ChangeMe123!';

describe('Dashboard API (Phase 4)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    process.env.NODE_ENV = 'test';
    const env = loadEnv();
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    configureApp(app, moduleRef.get(ENV) ?? env);
    await app.init();
  });
  afterAll(async () => {
    await app.close();
  });

  async function login(email: string) {
    const agent = request.agent(app.getHttpServer());
    const res = await agent.post('/v1/auth/login').send({ email, password: PASSWORD });
    expect(res.status).toBe(200);
    return { agent, branchId: (res.body as { branches: { id: string }[] }).branches[0].id };
  }

  it('requires authentication', async () => {
    const res = await request(app.getHttpServer()).get('/v1/dashboard');
    expect(res.status).toBe(401);
  });

  it('requires the X-Branch-Id header', async () => {
    const { agent } = await login('owner@demo.local');
    const res = await agent.get('/v1/dashboard');
    expect(res.status).toBe(400);
  });

  it('returns sales and inventory sections for the owner', async () => {
    const { agent, branchId } = await login('owner@demo.local');
    const res = await agent.get('/v1/dashboard').set('X-Branch-Id', branchId);
    expect(res.status).toBe(200);
    expect(res.body.sales.last7Days).toHaveLength(7);
    expect(res.body.sales.profitToday).not.toBeNull();
    expect(res.body.inventory.expiredCount).toBeGreaterThanOrEqual(1); // seeded expired Omeprazole batch
    expect(res.body.inventory.stockValue).not.toBeNull();
  });

  it('hides financial figures from a cashier', async () => {
    const { agent, branchId } = await login('cashier@demo.local');
    const res = await agent.get('/v1/dashboard').set('X-Branch-Id', branchId);
    expect(res.status).toBe(200);
    expect(res.body.sales.profitToday).toBeNull();
    expect(res.body.inventory.stockValue).toBeNull();
  });
});
