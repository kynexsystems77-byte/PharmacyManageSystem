'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, Select } from '@/components/kit';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, titleCase } from '@/lib/format';
import { qs, useBranchQuery, usePaging, type Paged } from '@/lib/hooks';
import { TRANSFER_TONE } from '@/lib/status';
import type { Transfer } from '@/lib/types';

export default function TransfersPage() {
  const router = useRouter();
  const { can, branchId } = useAuth();
  const [direction, setDirection] = useState('all');
  const [status, setStatus] = useState('');
  const { page, setPage } = usePaging([direction, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Transfer>>(`/inventory/transfers${qs({ page, pageSize: 25, direction, status })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader
        title="Stock transfers"
        subtitle="Stock leaves the source when dispatched and arrives when the destination branch receives it."
        actions={can('inventory:transfer') && <Link href="/inventory/transfers/new"><Button>New transfer</Button></Link>}
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[200px_200px]">
          <Select value={direction} onChange={(e) => setDirection(e.target.value)} aria-label="Direction">
            <option value="all">Incoming and outgoing</option>
            <option value="incoming">Incoming</option>
            <option value="outgoing">Outgoing</option>
          </Select>
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">Any status</option>
            <option value="DISPATCHED">In transit</option>
            <option value="RECEIVED">Received</option>
            <option value="CANCELLED">Cancelled</option>
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(t) => t.id}
          onRowClick={(t) => router.push(`/inventory/transfers/${t.id}`)}
          columns={[
            { key: 'n', header: 'Number', cell: (t) => <span className="font-mono text-xs">{t.number}</span> },
            { key: 'd', header: 'Direction', cell: (t) => (t.toBranch.id === branchId && t.fromBranch.id !== branchId ? <Badge tone="success">Incoming</Badge> : <Badge>Outgoing</Badge>) },
            { key: 'f', header: 'From', cell: (t) => `${t.fromBranch.name} · ${t.fromLocation.name}` },
            { key: 't', header: 'To', cell: (t) => `${t.toBranch.name} · ${t.toLocation.name}` },
            { key: 'i', header: 'Lines', align: 'right', cell: (t) => t.stockTransferItems.length },
            { key: 's', header: 'Status', cell: (t) => <Badge tone={TRANSFER_TONE[t.status]}>{t.status === 'DISPATCHED' ? 'In transit' : titleCase(t.status)}</Badge> },
            { key: 'w', header: 'Dispatched', cell: (t) => dateTime(t.dispatchedAt) },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
