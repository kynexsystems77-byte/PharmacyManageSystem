import { BadRequestException, Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import type { MovementType, Prisma } from '@kynex/database';
import { Decimal, dec, formatDateOnly, todayIn, uuidv7, type Dec } from '../common/core';

export interface MovementInput {
  tenantId: string;
  branchId: string;
  locationId: string;
  productId: string;
  batchId: string;
  /** Positive = stock in, negative = stock out (base units). */
  delta: Prisma.Decimal.Value;
  type: MovementType;
  unitCost: Prisma.Decimal.Value;
  referenceType?: string | null;
  referenceId?: string | null;
  reason?: string | null;
  userId?: string | null;
  occurredAt?: Date;
}

export interface Allocation {
  batchId: string;
  batchNumber: string;
  expiryDate: string | null;
  unitCost: Dec;
  sellingPrice: Dec | null;
  quantity: Dec;
}

interface FefoRow {
  batch_id: string;
  batch_number: string;
  expiry_date: Date | null;
  unit_cost: string;
  selling_price: string | null;
  quantity: string;
}

/**
 * The ONLY code that changes stock. Every change:
 *   1. updates the stock_levels projection with a guarded statement (never below zero), and
 *   2. appends an immutable inventory_movements row (the source of truth).
 * Both happen in the caller's transaction, so they commit or roll back together.
 */
@Injectable()
export class StockService {
  async assertLocation(tx: Prisma.TransactionClient, branchId: string, locationId: string) {
    const loc = await tx.location.findFirst({ where: { id: locationId, branchId }, select: { id: true, name: true, type: true, isActive: true } });
    if (!loc) throw new BadRequestException('The location does not belong to this branch');
    if (!loc.isActive) throw new BadRequestException(`Location "${loc.name}" is inactive`);
    return loc;
  }

  async defaultLocation(tx: Prisma.TransactionClient, branchId: string) {
    const loc =
      (await tx.location.findFirst({ where: { branchId, isDefault: true, isActive: true }, select: { id: true, name: true } })) ??
      (await tx.location.findFirst({ where: { branchId, isActive: true, type: 'SALES_FLOOR' }, orderBy: { createdAt: 'asc' }, select: { id: true, name: true } }));
    if (!loc) throw new UnprocessableEntityException('This branch has no active sales location');
    return loc;
  }

  async applyMovement(tx: Prisma.TransactionClient, m: MovementInput): Promise<{ movementId: string; balance: Dec }> {
    const delta = dec(m.delta).toDecimalPlaces(3);
    if (delta.isZero()) throw new BadRequestException('Quantity cannot be zero');
    let balance: Dec;

    if (delta.isPositive()) {
      const rows = await tx.$queryRaw<{ quantity: string }[]>`
        INSERT INTO stock_levels (id, tenant_id, quantity, branch_id, location_id, product_id, batch_id, updated_at)
        VALUES (${uuidv7()}::uuid, ${m.tenantId}::uuid, ${delta.toString()}::numeric, ${m.branchId}::uuid,
                ${m.locationId}::uuid, ${m.productId}::uuid, ${m.batchId}::uuid, now())
        ON CONFLICT (location_id, batch_id)
        DO UPDATE SET quantity = stock_levels.quantity + EXCLUDED.quantity, updated_at = now()
        RETURNING quantity::text AS quantity`;
      balance = dec(rows[0]?.quantity);
    } else {
      // guarded decrement: succeeds only if enough stock exists (checked under the row lock)
      const rows = await tx.$queryRaw<{ quantity: string }[]>`
        UPDATE stock_levels SET quantity = quantity + ${delta.toString()}::numeric, updated_at = now()
        WHERE location_id = ${m.locationId}::uuid AND batch_id = ${m.batchId}::uuid
          AND quantity + ${delta.toString()}::numeric >= 0
        RETURNING quantity::text AS quantity`;
      if (rows.length === 0) {
        const batch = await tx.batch.findFirst({ where: { id: m.batchId }, select: { batchNumber: true, product: { select: { brandName: true } } } });
        const have = await tx.stockLevel.findFirst({ where: { locationId: m.locationId, batchId: m.batchId }, select: { quantity: true } });
        throw new UnprocessableEntityException(
          `Not enough stock of ${batch?.product.brandName ?? 'product'} batch ${batch?.batchNumber ?? m.batchId}: ` +
            `available ${dec(have?.quantity).toString()}, needed ${delta.abs().toString()}`,
        );
      }
      balance = dec(rows[0]?.quantity);
    }

    const movement = await tx.inventoryMovement.create({
      data: {
        tenantId: m.tenantId,
        branchId: m.branchId,
        locationId: m.locationId,
        productId: m.productId,
        batchId: m.batchId,
        movementType: m.type,
        quantityDelta: delta,
        unitCost: dec(m.unitCost),
        referenceType: m.referenceType ?? null,
        referenceId: m.referenceId ?? null,
        reason: m.reason ?? null,
        createdById: m.userId ?? null,
        occurredAt: m.occurredAt ?? new Date(),
      },
      select: { id: true },
    });
    return { movementId: movement.id, balance };
  }

  /**
   * First-Expiry-First-Out allocation of `quantity` base units of a product at one location.
   * With `lock`, the candidate stock rows are locked (FOR UPDATE, in a fixed order) until the transaction ends.
   * Expired, quarantined and recalled batches are never returned.
   */
  async allocateFefo(
    tx: Prisma.TransactionClient,
    opts: {
      locationId: string;
      productId: string;
      quantity: Prisma.Decimal.Value;
      timezone: string;
      minDaysToExpiry?: number;
      lock?: boolean;
      /** Exclude these batches (already allocated earlier in the same request). */
      reserved?: Map<string, Dec>;
    },
  ): Promise<{ allocations: Allocation[]; shortfall: Dec }> {
    const rows = await this.sellableRows(tx, opts.locationId, opts.productId, opts.timezone, opts.minDaysToExpiry ?? 0, opts.lock ?? false);
    let remaining = dec(opts.quantity);
    const allocations: Allocation[] = [];
    for (const r of rows) {
      if (remaining.lte(0)) break;
      const reserved = opts.reserved?.get(r.batch_id) ?? new Decimal(0);
      const free = dec(r.quantity).minus(reserved);
      if (free.lte(0)) continue;
      const take = Decimal.min(free, remaining);
      allocations.push({
        batchId: r.batch_id,
        batchNumber: r.batch_number,
        expiryDate: formatDateOnly(r.expiry_date),
        unitCost: dec(r.unit_cost),
        sellingPrice: r.selling_price === null ? null : dec(r.selling_price),
        quantity: take,
      });
      remaining = remaining.minus(take);
    }
    return { allocations, shortfall: Decimal.max(remaining, 0) };
  }

  /** Validates a manually chosen batch (FEFO override) and locks its stock row. */
  async allocateBatch(
    tx: Prisma.TransactionClient,
    opts: { locationId: string; productId: string; batchId: string; quantity: Prisma.Decimal.Value; timezone: string; minDaysToExpiry?: number; reserved?: Map<string, Dec> },
  ): Promise<Allocation> {
    const rows = await this.sellableRows(tx, opts.locationId, opts.productId, opts.timezone, opts.minDaysToExpiry ?? 0, true, opts.batchId);
    const r = rows[0];
    if (!r) {
      const batch = await tx.batch.findFirst({ where: { id: opts.batchId, productId: opts.productId }, select: { batchNumber: true, status: true, expiryDate: true } });
      if (!batch) throw new NotFoundException('Batch not found for this product');
      throw new UnprocessableEntityException(
        `Batch ${batch.batchNumber} cannot be sold (status ${batch.status}${batch.expiryDate ? `, expires ${formatDateOnly(batch.expiryDate)}` : ''}, or no stock at this location)`,
      );
    }
    const free = dec(r.quantity).minus(opts.reserved?.get(r.batch_id) ?? 0);
    if (free.lt(opts.quantity)) {
      throw new UnprocessableEntityException(`Batch ${r.batch_number} has only ${free.toString()} available`);
    }
    return {
      batchId: r.batch_id,
      batchNumber: r.batch_number,
      expiryDate: formatDateOnly(r.expiry_date),
      unitCost: dec(r.unit_cost),
      sellingPrice: r.selling_price === null ? null : dec(r.selling_price),
      quantity: dec(opts.quantity),
    };
  }

  private async sellableRows(
    tx: Prisma.TransactionClient,
    locationId: string,
    productId: string,
    timezone: string,
    minDays: number,
    lock: boolean,
    batchId?: string,
  ): Promise<FefoRow[]> {
    const today = todayIn(timezone);
    // ORDER BY gives FEFO and a stable lock order (prevents deadlocks between concurrent sales).
    if (lock) {
      return tx.$queryRaw<FefoRow[]>`
        SELECT s.batch_id, b.batch_number, b.expiry_date, b.unit_cost::text AS unit_cost,
               b.selling_price::text AS selling_price, s.quantity::text AS quantity
        FROM stock_levels s JOIN batches b ON b.id = s.batch_id
        WHERE s.location_id = ${locationId}::uuid AND s.product_id = ${productId}::uuid AND s.quantity > 0
          AND b.status = 'ACTIVE'
          AND (b.expiry_date IS NULL OR b.expiry_date >= ${today}::date + ${minDays}::int)
          AND (${batchId ?? null}::uuid IS NULL OR s.batch_id = ${batchId ?? null}::uuid)
        ORDER BY b.expiry_date ASC NULLS LAST, b.received_at ASC, b.id ASC
        FOR UPDATE OF s`;
    }
    return tx.$queryRaw<FefoRow[]>`
      SELECT s.batch_id, b.batch_number, b.expiry_date, b.unit_cost::text AS unit_cost,
             b.selling_price::text AS selling_price, s.quantity::text AS quantity
      FROM stock_levels s JOIN batches b ON b.id = s.batch_id
      WHERE s.location_id = ${locationId}::uuid AND s.product_id = ${productId}::uuid AND s.quantity > 0
        AND b.status = 'ACTIVE'
        AND (b.expiry_date IS NULL OR b.expiry_date >= ${today}::date + ${minDays}::int)
        AND (${batchId ?? null}::uuid IS NULL OR s.batch_id = ${batchId ?? null}::uuid)
      ORDER BY b.expiry_date ASC NULLS LAST, b.received_at ASC, b.id ASC`;
  }

  /** Sellable quantity of each product at a branch (optionally one location). */
  async sellableByProduct(
    tx: Prisma.TransactionClient,
    branchId: string,
    productIds: string[],
    timezone: string,
    locationId?: string,
  ): Promise<Map<string, Dec>> {
    if (productIds.length === 0) return new Map();
    const today = todayIn(timezone);
    const rows = await tx.$queryRaw<{ product_id: string; qty: string }[]>`
      SELECT s.product_id, SUM(s.quantity)::text AS qty
      FROM stock_levels s JOIN batches b ON b.id = s.batch_id
      WHERE s.branch_id = ${branchId}::uuid AND s.product_id = ANY(${productIds}::uuid[]) AND s.quantity > 0
        AND b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= ${today}::date)
        AND (${locationId ?? null}::uuid IS NULL OR s.location_id = ${locationId ?? null}::uuid)
      GROUP BY s.product_id`;
    return new Map(rows.map((r) => [r.product_id, dec(r.qty)]));
  }
}
