'use client';

import { FolderTree, Pencil, Plus, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { ConfirmDialog, Modal, PageHeader, Select, useToast } from '@/components/kit';
import { categoryOptions } from '@/components/product-form';
import { Alert, Badge, Button, Card, Field, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Category } from '@/lib/types';

interface Draft { id?: string; name: string; parentId: string; sortOrder: string; isActive: boolean }

export default function CategoriesPage() {
  const { can } = useAuth();
  const toast = useToast();
  const manage = can('category:manage');
  const { data, isLoading } = useBranchQuery<Category[]>('/categories?includeInactive=true');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [toDelete, setToDelete] = useState<Category | null>(null);
  const options = useMemo(() => categoryOptions(data), [data]);
  const byId = useMemo(() => new Map((data ?? []).map((c) => [c.id, c])), [data]);

  const save = useApiMutation<Draft>('POST', '/categories', { onSuccess: () => { toast.success('Category saved'); setDraft(null); } });
  const update = useApiMutation<Draft>('PATCH', (d) => `/categories/${d.id}`, { onSuccess: () => { toast.success('Category saved'); setDraft(null); } });
  const remove = useApiMutation<Category>('DELETE', (c) => `/categories/${c.id}`, {
    onSuccess: () => { toast.success('Category deleted'); setToDelete(null); },
  });

  const submit = () => {
    if (!draft) return;
    const body = { name: draft.name.trim(), parentId: draft.parentId || null, sortOrder: Number(draft.sortOrder || 0), ...(draft.id ? { isActive: draft.isActive } : {}) };
    if (draft.id) update.mutate({ ...draft, ...body } as never);
    else save.mutate(body as never);
  };
  const pending = save.isPending || update.isPending;
  const err = save.error ?? update.error;

  return (
    <div>
      <PageHeader
        title="Categories"
        subtitle="Medicine sub-categories (Antibiotics, Antacid, Vitamins…) and Groceries sub-categories (Beverages, Biscuits & snacks, Household…) and other departments such as Cosmetics."
        actions={manage && <Button onClick={() => setDraft({ name: '', parentId: '', sortOrder: '0', isActive: true })}><Plus size={16} /> New category</Button>}
      />
      <Card>
        {isLoading && <div className="p-4"><Skeleton className="h-40" /></div>}
        <ul className="divide-y divide-line">
          {options.map((o) => {
            const c = byId.get(o.id)!;
            return (
              <li key={o.id} className="flex items-center gap-3 px-4 py-2.5 text-sm" style={{ paddingLeft: `${16 + o.depth * 24}px` }}>
                <FolderTree size={16} className={o.depth === 0 ? 'text-brand' : 'text-fg-muted'} />
                <span className={`min-w-0 flex-1 truncate ${o.depth === 0 ? 'font-semibold' : ''}`}>{c.name}</span>
                {!c.isActive && <Badge>Inactive</Badge>}
                <span className="tabular w-24 text-right text-xs text-fg-muted">{c.productCount} products</span>
                {manage && (
                  <span className="flex gap-1">
                    <button aria-label={`Edit ${c.name}`} onClick={() => setDraft({ id: c.id, name: c.name, parentId: c.parentId ?? '', sortOrder: String(c.sortOrder), isActive: c.isActive })} className="grid h-8 w-8 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-fg"><Pencil size={15} /></button>
                    <button aria-label={`Delete ${c.name}`} onClick={() => setToDelete(c)} className="grid h-8 w-8 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={15} /></button>
                  </span>
                )}
              </li>
            );
          })}
        </ul>
      </Card>

      <Modal
        open={Boolean(draft)}
        onClose={() => setDraft(null)}
        title={draft?.id ? 'Edit category' : 'New category'}
        size="sm"
        footer={<><Button variant="outline" onClick={() => setDraft(null)}>Cancel</Button><Button loading={pending} onClick={submit} disabled={!draft?.name.trim()}>Save</Button></>}
      >
        {draft && (
          <div className="space-y-3">
            {err && <Alert>{errorMessage(err)}</Alert>}
            <Field label="Name"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} maxLength={80} /></Field>
            <Field label="Parent">
              <Select value={draft.parentId} onChange={(e) => setDraft({ ...draft, parentId: e.target.value })}>
                <option value="">None (top level)</option>
                {options.filter((o) => o.id !== draft.id).map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
              </Select>
            </Field>
            <Field label="Sort order"><Input type="number" min="0" value={draft.sortOrder} onChange={(e) => setDraft({ ...draft, sortOrder: e.target.value })} /></Field>
            {draft.id && (
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={draft.isActive} onChange={(e) => setDraft({ ...draft, isActive: e.target.checked })} /> Active</label>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={Boolean(toDelete)}
        title="Delete category?"
        danger
        confirmLabel="Delete"
        loading={remove.isPending}
        onClose={() => setToDelete(null)}
        onConfirm={() => toDelete && remove.mutate(toDelete, { onError: (e) => { toast.error(errorMessage(e)); setToDelete(null); } })}
        body={<p>Delete <b>{toDelete?.name}</b>? Categories that still contain products or sub-categories cannot be deleted.</p>}
      />
    </div>
  );
}
