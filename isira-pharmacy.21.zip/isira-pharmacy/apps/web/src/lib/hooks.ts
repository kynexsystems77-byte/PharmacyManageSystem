'use client';

import { keepPreviousData, useMutation, useQuery, useQueryClient, type UseQueryOptions } from '@tanstack/react-query';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from './api';
import { useAuth } from './auth';

export interface Paged<T> {
  data: T[];
  meta: { page: number; pageSize: number; total: number; totalPages: number };
}

export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

/** Builds a query string, skipping empty values. */
export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue;
    u.set(k, String(v));
  }
  const s = u.toString();
  return s ? `?${s}` : '';
}

/**
 * GET against the API with the selected branch sent as X-Branch-Id.
 * The branch id is part of the cache key, so switching branches refetches everything.
 */
export function useBranchQuery<T>(
  path: string | null,
  opts: Omit<UseQueryOptions<T, Error, T, (string | null)[]>, 'queryKey' | 'queryFn'> & { keepPrevious?: boolean } = {},
) {
  const { branchId } = useAuth();
  const { keepPrevious, ...rest } = opts;
  return useQuery({
    queryKey: [branchId, path],
    queryFn: ({ signal }) => api<T>(path as string, { branchId, signal }),
    enabled: Boolean(path && branchId) && (rest.enabled ?? true),
    placeholderData: keepPrevious ? keepPreviousData : undefined,
    ...rest,
  });
}

type Method = 'POST' | 'PUT' | 'PATCH' | 'DELETE';

/** Write against the API (branch header + CSRF). Invalidates every cached query on success unless told otherwise. */
export function useApiMutation<TBody = unknown, TResult = unknown>(
  method: Method,
  path: string | ((body: TBody) => string),
  opts: { onSuccess?: (data: TResult, body: TBody) => void; invalidate?: boolean } = {},
) {
  const { branchId } = useAuth();
  const qc = useQueryClient();
  return useMutation<TResult, Error, TBody>({
    mutationFn: (body: TBody) =>
      api<TResult>(typeof path === 'function' ? path(body) : path, { method, body: method === 'DELETE' ? undefined : body, branchId }),
    onSuccess: async (data, body) => {
      if (opts.invalidate !== false) await qc.invalidateQueries();
      opts.onSuccess?.(data, body);
    },
  });
}

export function errorMessage(err: unknown): string {
  if (err instanceof ApiError) {
    if (Array.isArray(err.details) && err.details.length > 0) {
      const first = err.details[0] as { path?: (string | number)[]; message?: string };
      if (first?.message) return `${first.path?.length ? `${first.path.join('.')}: ` : ''}${first.message}`;
    }
    return err.message;
  }
  return err instanceof Error ? err.message : 'Something went wrong';
}

/** Page state with reset-to-1 when filters change. */
export function usePaging(deps: unknown[]) {
  const [page, setPage] = useState(1);
  const key = JSON.stringify(deps);
  useEffect(() => setPage(1), [key]);
  return { page, setPage };
}

/** Keyboard shortcut (ignored while typing in inputs unless `allowInInputs`). */
export function useHotkey(key: string, handler: (e: KeyboardEvent) => void, allowInInputs = false) {
  const cb = useCallback(handler, [handler]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
      if (typing && !allowInInputs) return;
      if (e.key === key) cb(e);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [key, cb, allowInInputs]);
}

/** Stable client-side id for idempotency keys and list keys. */
export function newKey(): string {
  try {
    return crypto.randomUUID().replace(/-/g, '');
  } catch {
    return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;
  }
}

export function useStableKey(): [string, () => void] {
  const [k, setK] = useState(newKey);
  const reset = useCallback(() => setK(newKey()), []);
  return useMemo(() => [k, reset], [k, reset]);
}
