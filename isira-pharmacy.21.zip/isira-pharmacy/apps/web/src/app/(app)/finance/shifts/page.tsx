'use client';

import { Plus } from 'lucide-react';
import { useState } from 'react';
import { DataTable, Modal, PageHeader, useToast } from '@/components/kit';
import { preset, RangePicker, ScopeToggle, type DateRange } from '@/components/range-picker';
import { ShiftModal } from '@/components/shift-panel';
import { Alert, Badge, Button, Card, CardHeader, Field, Input, StatTile } from '@/components/ui';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Reconciliation, Register, ShiftSummary } from '@/lib/types';
import { AlertTriangle, Scale, Timer } from 'lucide-react';

export default function ShiftsPage() {
  const { can, profile, branchId } = useAuth();
  const toast = useToast();
  const fmt = (v: string | number | null) => money(num(v), profile.tenant.currencyCode);
  const [range, setRange] = useState<DateRange>(() => preset('7d'));
  const [scope, setScope] = useState<'branch' | 'all'>('branch');
  const [shown, setShown] = useState<ShiftSummary | null>(null);
  const [newReg, setNewReg] = useState<string | null>(null);
  const rec = useBranchQuery<Reconciliation>(`/finance/reconciliation${qs({ ...range, scope })}`, { keepPrevious: true });
  const regs = useBranchQuery<Register[]>('/registers');
  const create = useApiMutation<object>('POST', '/registers', { onSuccess: () => { toast.success('Register added'); setNewReg(null); } });
  const open = async (id: string) => {
    try { setShown(await api<ShiftSummary>(`/shifts/${id}`, { branchId })); } catch (e) { toast.error(errorMessage(e)); }
  };
  return (
    <div className="space-y-4">
      <PageHeader title="Shifts & cash" subtitle="Every register shift with its expected and counted cash." actions={<><RangePicker value={range} onChange={setRange} /><ScopeToggle value={scope} onChange={setScope} /></>} />
      {rec.data && (
        <div className="grid gap-3 sm:grid-cols-3">
          <StatTile label="Shifts" value={String(rec.data.totals.shifts)} icon={<Timer size={18} />} hint={`${rec.data.totals.open} still open`} />
          <StatTile label="Shifts short" value={String(rec.data.totals.shortages)} icon={<AlertTriangle size={18} />} tone={rec.data.totals.shortages ? 'danger' : 'neutral'} />
          <StatTile label="Net cash variance" value={fmt(rec.data.totals.netVariance)} icon={<Scale size={18} />} tone={num(rec.data.totals.netVariance) < 0 ? 'danger' : 'success'} />
        </div>
      )}
      <Card>
        <DataTable
          rows={rec.data?.shifts}
          loading={rec.isLoading}
          rowKey={(s) => s.id}
          onRowClick={(s) => open(s.id)}
          empty={<p className="px-4 py-8 text-center text-sm text-fg-muted">No shifts in this period.</p>}
          columns={[
            { key: 'r', header: 'Register', cell: (s) => <div><p className="font-medium">{s.register}</p>{scope === 'all' && <p className="text-xs text-fg-muted">{s.branch}</p>}</div> },
            { key: 'o', header: 'Opened', cell: (s) => <div><p>{dateTime(s.openedAt)}</p><p className="text-xs text-fg-muted">{s.openedBy}</p></div> },
            { key: 'c', header: 'Closed', cell: (s) => (s.closedAt ? <div><p>{dateTime(s.closedAt)}</p><p className="text-xs text-fg-muted">{s.closedBy}</p></div> : <Badge tone="warning">Open</Badge>) },
            { key: 'f', header: 'Float', align: 'right', cell: (s) => fmt(s.opening) },
            { key: 'e', header: 'Expected', align: 'right', cell: (s) => (s.expected ? fmt(s.expected) : '-') },
            { key: 'n', header: 'Counted', align: 'right', cell: (s) => (s.counted ? fmt(s.counted) : '-') },
            { key: 'v', header: 'Variance', align: 'right', cell: (s) => (s.variance === null ? '-' : <span className={num(s.variance) < 0 ? 'font-medium text-danger' : num(s.variance) > 0 ? 'text-warning' : 'text-success'}>{fmt(s.variance)}</span>) },
          ]}
        />
      </Card>
      <Card>
        <CardHeader title="Registers in this branch" action={can('branch:manage') && <Button variant="outline" className="h-8 px-3" onClick={() => setNewReg('')}><Plus size={14} /> Add register</Button>} />
        <ul className="divide-y divide-line text-sm">
          {regs.data?.map((r) => (
            <li key={r.id} className="flex items-center justify-between px-4 py-2.5">
              <span className="font-medium">{r.name}</span>
              {r.registerSessions[0] ? (
                <button className="text-brand hover:underline" onClick={() => open(r.registerSessions[0].id)}>Open since {dateTime(r.registerSessions[0].openedAt)} · {r.registerSessions[0].openedBy.fullName}</button>
              ) : <span className="text-fg-muted">Closed</span>}
            </li>
          ))}
        </ul>
      </Card>
      {shown && <ShiftModal summary={shown} onClose={() => { setShown(null); void rec.refetch(); }} />}
      <Modal open={newReg !== null} onClose={() => setNewReg(null)} size="sm" title="Add register"
        footer={<><Button variant="outline" onClick={() => setNewReg(null)}>Cancel</Button><Button loading={create.isPending} disabled={!newReg?.trim()} onClick={() => create.mutate({ name: newReg!.trim() })}>Add</Button></>}>
        {create.error && <Alert>{errorMessage(create.error)}</Alert>}
        <Field label="Name"><Input value={newReg ?? ''} onChange={(e) => setNewReg(e.target.value)} placeholder="Counter 2" autoFocus /></Field>
      </Modal>
    </div>
  );
}
