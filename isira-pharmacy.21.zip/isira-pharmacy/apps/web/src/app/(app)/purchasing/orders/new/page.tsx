'use client';

import { Trash2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { Forbidden, PageHeader, Select, Textarea, useToast } from '@/components/kit';
import { ProductPicker } from '@/components/pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num, productName, qty, todayIso } from '@/lib/format';
import { errorMessage, newKey, useApiMutation, useBranchQuery, type Paged } from '@/lib/hooks';
import type { Product, PurchaseOrder, Supplier } from '@/lib/types';

interface Line { key: string; product: Product; orderedQuantity: string; unitCost: string; taxPercent: string }

export default function NewOrderPage() {
  const router = useRouter();
  const toast = useToast();
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const suppliers = useBranchQuery<Paged<Supplier>>('/suppliers?pageSize=100');
  const [supplierId, setSupplierId] = useState('');
  const [orderDate, setOrderDate] = useState(todayIso());
  const [expectedDate, setExpectedDate] = useState('');
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const create = useApiMutation<object, PurchaseOrder>('POST', '/purchase-orders', { onSuccess: (po) => { toast.success(`${po.number} created`); router.push(`/purchasing/orders/${po.id}`); } });
  const total = useMemo(() => lines.reduce((a, l) => a + Number(l.orderedQuantity || 0) * Number(l.unitCost || 0) * (1 + Number(l.taxPercent || 0) / 100), 0), [lines]);
  if (!can('purchase_order:manage')) return <Forbidden what="purchase orders" />;
  const setLine = (key: string, patch: Partial<Line>) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const valid = supplierId && lines.length > 0 && lines.every((l) => Number(l.orderedQuantity) > 0);
  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader back="/purchasing/orders" title="New purchase order" />
      <Card className="grid gap-4 p-4 sm:grid-cols-3">
        <Field label="Supplier *">
          <Select value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            <option value="">Choose…</option>
            {suppliers.data?.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </Field>
        <Field label="Order date"><Input type="date" value={orderDate} onChange={(e) => setOrderDate(e.target.value)} /></Field>
        <Field label="Expected delivery"><Input type="date" value={expectedDate} onChange={(e) => setExpectedDate(e.target.value)} /></Field>
      </Card>
      <Card>
        <CardHeader title="Items" action={<span className="tabular text-sm font-semibold">{money(total, cur)}</span>} />
        <div className="space-y-3 p-4">
          <ProductPicker onPick={(p) => setLines((ls) => [...ls, { key: newKey(), product: p, orderedQuantity: String(Math.max(num(p.reorderLevel) * 2 - num(p.stock), num(p.reorderLevel), 1)), unitCost: String(num(p.purchasePrice)), taxPercent: p.taxRate ? String(num(p.taxRate.ratePercent)) : '0' }])} placeholder="Add a product (search or scan)" />
          {lines.map((l) => (
            <div key={l.key} className="grid items-end gap-2 rounded-lg border border-line p-3 sm:grid-cols-[1.5fr_120px_120px_100px_auto]">
              <div className="pb-2 text-sm"><p className="font-medium">{productName(l.product.brandName, l.product.strength)}</p><p className="text-xs text-fg-muted">In stock {qty(num(l.product.stock))} · reorder at {qty(num(l.product.reorderLevel))} {l.product.baseUnit}</p></div>
              <Field label={`Qty (${l.product.baseUnit})`}><Input type="number" min="0.001" step="0.001" value={l.orderedQuantity} onChange={(e) => setLine(l.key, { orderedQuantity: e.target.value })} /></Field>
              <Field label="Unit cost"><Input type="number" min="0" step="0.0001" value={l.unitCost} onChange={(e) => setLine(l.key, { unitCost: e.target.value })} /></Field>
              <Field label="Tax %"><Input type="number" min="0" max="100" step="0.01" value={l.taxPercent} onChange={(e) => setLine(l.key, { taxPercent: e.target.value })} /></Field>
              <button aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      </Card>
      <Card className="p-4"><Field label="Notes for the supplier"><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={1000} /></Field></Card>
      {create.error && <Alert>{errorMessage(create.error)}</Alert>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
        <Button disabled={!valid} loading={create.isPending} onClick={() => create.mutate({
          supplierId, orderDate, expectedDate: expectedDate || null, notes: notes.trim() || undefined,
          items: lines.map((l) => ({ productId: l.product.id, orderedQuantity: Number(l.orderedQuantity), unitCost: Number(l.unitCost || 0), taxPercent: Number(l.taxPercent || 0) })),
        })}>Create order</Button>
      </div>
    </div>
  );
}
