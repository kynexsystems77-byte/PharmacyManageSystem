import { Global, Inject, Injectable, Logger, Module, OnModuleDestroy } from '@nestjs/common';
import { Queue, type JobsOptions } from 'bullmq';
import { ENV, type Env } from '../config/env';

export const QUEUE_NAME = 'kynex';

/** BullMQ connection options from a redis:// URL (password, db and TLS included). */
export function redisConnection(url: string) {
  const u = new URL(url);
  return {
    host: u.hostname,
    port: Number(u.port || 6379),
    username: u.username || undefined,
    password: u.password ? decodeURIComponent(u.password) : undefined,
    db: u.pathname && u.pathname !== '/' ? Number(u.pathname.slice(1)) : undefined,
    tls: u.protocol === 'rediss:' ? {} : undefined,
    maxRetriesPerRequest: null as null,
  };
}

/**
 * Enqueues background jobs. Without REDIS_URL (or when Redis is unreachable) `add` returns false
 * and the caller does the work inline, so a Redis outage never breaks a user-facing request.
 */
@Injectable()
export class QueueService implements OnModuleDestroy {
  private readonly logger = new Logger('Queue');
  readonly queue: Queue | null;

  constructor(@Inject(ENV) env: Env) {
    this.queue = env.REDIS_URL ? new Queue(QUEUE_NAME, { connection: redisConnection(env.REDIS_URL) }) : null;
    this.queue?.on('error', (e) => this.logger.warn(`Redis queue error: ${e.message}`));
  }

  async add(name: string, data: Record<string, unknown>, opts: JobsOptions = {}): Promise<boolean> {
    if (!this.queue) return false;
    try {
      // do not queue into a disconnected client: the job could be delivered later AND run inline now
      const client = await this.queue.client;
      if (client.status !== 'ready') throw new Error(`redis ${client.status}`);
      await Promise.race([
        this.queue.add(name, data, { attempts: 3, backoff: { type: 'exponential', delay: 5_000 }, removeOnComplete: 1_000, removeOnFail: 5_000, ...opts }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 2_000)),
      ]);
      return true;
    } catch (e) {
      this.logger.warn(`Could not enqueue ${name} (${(e as Error).message}); running inline instead`);
      return false;
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.queue?.close();
  }
}

@Global()
@Module({ providers: [QueueService], exports: [QueueService] })
export class JobsModule {}
