import { z } from 'zod';
import { PERMISSION_KEYS, type PermissionKey } from './permissions';

/** Request schemas shared by the API (validation + OpenAPI) and the web app (forms). */

export const uuidSchema = z.string().uuid();
export const emailSchema = z.string().trim().toLowerCase().email().max(254);
export const passwordSchema = z.string().min(10, 'Use at least 10 characters').max(128);

export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  search: z.string().trim().max(100).optional(),
});

// ---- auth ----
export const loginSchema = z.object({ email: emailSchema, password: z.string().min(1).max(128) });
export const forgotPasswordSchema = z.object({ email: emailSchema });
export const resetPasswordSchema = z.object({ token: z.string().min(20).max(200), newPassword: passwordSchema });
export const changePasswordSchema = z.object({ currentPassword: z.string().min(1).max(128), newPassword: passwordSchema });

// ---- two-factor authentication (TOTP) ----
/** A 6-digit authenticator code, or a recovery code (xxxxx-xxxxx). */
export const mfaCodeSchema = z.string().trim().min(6).max(20).transform((v) => v.replace(/\s+/g, ''));
export const mfaLoginSchema = z.object({ challenge: z.string().min(20).max(500), code: mfaCodeSchema });
export const mfaEnableSchema = z.object({ code: z.string().trim().regex(/^\d{6}$/, 'Enter the 6-digit code from your app') });
export const mfaDisableSchema = z.object({ password: z.string().min(1).max(128), code: mfaCodeSchema });

// ---- tenant ----
export const updateTenantSchema = z
  .object({
    name: z.string().trim().min(2).max(120).optional(),
    currencyCode: z.string().trim().length(3).toUpperCase().optional(),
    timezone: z.string().trim().min(1).max(64).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

// ---- branches ----
export const createBranchSchema = z.object({
  name: z.string().trim().min(2).max(120),
  code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_-]{2,20}$/, 'Use 2-20 letters, digits, - or _'),
  address: z.string().trim().max(300).optional(),
  phone: z.string().trim().max(40).optional(),
  email: z.string().trim().email().max(254).optional(),
  invoicePrefix: z.string().trim().toUpperCase().regex(/^[A-Z0-9-]{1,10}$/).default('INV'),
  receiptHeader: z.string().trim().max(500).optional(),
  receiptFooter: z.string().trim().max(500).optional(),
  taxNumber: z.string().trim().max(60).optional(),
});
export const updateBranchSchema = createBranchSchema.partial().extend({ isActive: z.boolean().optional() })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const createLocationSchema = z.object({
  name: z.string().trim().min(2).max(80),
  type: z.enum(['SALES_FLOOR', 'WAREHOUSE', 'IN_TRANSIT', 'QUARANTINE']).default('SALES_FLOOR'),
  isDefault: z.boolean().default(false),
});

// ---- users ----
export const branchRoleSchema = z.object({ branchId: uuidSchema, roleId: uuidSchema });
export const createUserSchema = z.object({
  email: emailSchema,
  fullName: z.string().trim().min(2).max(120),
  phone: z.string().trim().max(40).optional(),
  password: passwordSchema,
  isOwner: z.boolean().default(false),
  branchRoles: z.array(branchRoleSchema).max(100).default([]),
});
export const updateUserSchema = z
  .object({
    fullName: z.string().trim().min(2).max(120).optional(),
    phone: z.string().trim().max(40).nullable().optional(),
    status: z.enum(['ACTIVE', 'DISABLED']).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const setUserBranchRolesSchema = z.object({ branchRoles: z.array(branchRoleSchema).max(100) });
export const adminSetPasswordSchema = z.object({ newPassword: passwordSchema });
export const listUsersQuerySchema = paginationSchema.extend({ status: z.enum(['ACTIVE', 'INVITED', 'DISABLED']).optional() });

// ---- roles ----
const permissionKeySchema = z.enum(PERMISSION_KEYS as unknown as [PermissionKey, ...PermissionKey[]]);
export const createRoleSchema = z.object({
  name: z.string().trim().min(2).max(60),
  description: z.string().trim().max(200).optional(),
  maxDiscountPercent: z.number().min(0).max(100).default(0),
  permissions: z.array(permissionKeySchema).max(200).default([]),
});
export const updateRoleSchema = z
  .object({
    name: z.string().trim().min(2).max(60).optional(),
    description: z.string().trim().max(200).nullable().optional(),
    maxDiscountPercent: z.number().min(0).max(100).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const setRolePermissionsSchema = z.object({ permissions: z.array(permissionKeySchema).max(200) });

// ---- audit ----
export const listAuditQuerySchema = paginationSchema.extend({
  entityType: z.string().trim().max(60).optional(),
  entityId: z.string().trim().max(60).optional(),
  userId: uuidSchema.optional(),
  action: z.string().trim().max(80).optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});
