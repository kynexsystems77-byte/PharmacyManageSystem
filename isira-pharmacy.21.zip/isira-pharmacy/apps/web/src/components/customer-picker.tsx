'use client';

import clsx from 'clsx';
import { UserPlus, UserRound, X } from 'lucide-react';
import { forwardRef, useEffect, useRef, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { money, num } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery, useDebounced, type Paged } from '@/lib/hooks';
import type { Customer } from '@/lib/types';
import { Modal, Spinner } from './kit';
import { Alert, Button, Field, Input } from './ui';

export const CustomerPicker = forwardRef<HTMLInputElement, { value: Customer | null; onChange: (c: Customer | null) => void }>(function CustomerPicker({ value, onChange }, ref) {
  const { can, profile } = useAuth();
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const s = useDebounced(text.trim(), 200);
  const { data, isFetching } = useBranchQuery<Paged<Customer>>(s.length >= 2 ? `/customers${qs({ search: s, pageSize: 8, withBalance: true })}` : null);
  useEffect(() => {
    const onDoc = (e: MouseEvent) => box.current && !box.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  if (value) {
    return (
      <div className="flex items-center gap-3 rounded-lg border border-line bg-subtle/50 px-3 py-2">
        <span className="grid h-8 w-8 place-items-center rounded-full bg-brand/10 text-brand"><UserRound size={16} /></span>
        <div className="min-w-0 flex-1 text-sm">
          <p className="truncate font-medium">{value.fullName}</p>
          <p className="truncate text-xs text-fg-muted">
            {[value.code, value.phone].filter(Boolean).join(' · ')}
            {value.balance !== undefined && num(value.balance) !== 0 && <> · owes {money(num(value.balance), profile.tenant.currencyCode)}</>}
          </p>
        </div>
        <button aria-label="Remove customer" onClick={() => onChange(null)} className="grid h-8 w-8 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-fg"><X size={16} /></button>
      </div>
    );
  }

  const items = s.length >= 2 ? (data?.data ?? []) : [];
  return (
    <div ref={box} className="relative">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <UserRound size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-fg-muted" />
          <input
            ref={ref}
            value={text}
            onChange={(e) => { setText(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
            onKeyDown={(e) => { if (e.key === 'Enter' && items[0]) { e.preventDefault(); onChange(items[0]); setText(''); setOpen(false); } }}
            placeholder="Customer name, phone or code (F4)"
            aria-label="Customer"
            className="h-10 w-full rounded-lg border border-line bg-surface pl-9 pr-8 text-sm placeholder:text-fg-muted/70"
          />
          {isFetching && <Spinner className="absolute right-3 top-3 text-fg-muted" />}
        </div>
        {can('customer:manage') && (
          <Button variant="outline" className="px-3" onClick={() => setCreating(true)} aria-label="New customer"><UserPlus size={16} /></Button>
        )}
      </div>
      {open && s.length >= 2 && (
        <ul className="absolute z-40 mt-1 max-h-72 w-full overflow-y-auto rounded-lg border border-line bg-surface py-1 shadow-lg">
          {items.length === 0 && !isFetching && <li className="px-3 py-2 text-sm text-fg-muted">No customer found</li>}
          {items.map((c, i) => (
            <li key={c.id}>
              <button
                onMouseDown={(e) => { e.preventDefault(); onChange(c); setText(''); setOpen(false); }}
                className={clsx('flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm hover:bg-subtle', i === 0 && 'bg-subtle/60')}
              >
                <span className="min-w-0"><span className="block truncate font-medium">{c.fullName}</span><span className="block truncate text-xs text-fg-muted">{[c.code, c.phone].filter(Boolean).join(' · ')}</span></span>
                {c.balance !== undefined && num(c.balance) > 0 && <span className="text-xs text-warning">owes {money(num(c.balance), profile.tenant.currencyCode)}</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
      {creating && <QuickCustomer initialName={/\d/.test(text) ? '' : text} initialPhone={/\d/.test(text) ? text : ''} onClose={() => setCreating(false)} onCreated={(c) => { onChange(c); setText(''); }} />}
    </div>
  );
});

function QuickCustomer({ initialName, initialPhone, onClose, onCreated }: { initialName: string; initialPhone: string; onClose: () => void; onCreated: (c: Customer) => void }) {
  const [name, setName] = useState(initialName);
  const [phone, setPhone] = useState(initialPhone);
  const create = useApiMutation<object, Customer>('POST', '/customers', { onSuccess: (c) => { onCreated({ ...c, balance: '0' }); onClose(); }, invalidate: false });
  return (
    <Modal open onClose={onClose} title="New customer" size="sm"
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button loading={create.isPending} disabled={name.trim().length < 2} onClick={() => create.mutate({ fullName: name.trim(), phone: phone.trim() || undefined })}>Add customer</Button></>}>
      <div className="space-y-3">
        {create.error && <Alert>{errorMessage(create.error)}</Alert>}
        <Field label="Full name"><Input value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
        <Field label="Phone"><Input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" /></Field>
      </div>
    </Modal>
  );
}
