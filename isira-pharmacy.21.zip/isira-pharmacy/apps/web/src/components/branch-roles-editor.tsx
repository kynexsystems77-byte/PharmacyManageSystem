'use client';

import { Plus, Trash2 } from 'lucide-react';
import { useBranchQuery } from '@/lib/hooks';
import type { BranchRow, RoleRow } from '@/lib/types';
import { Select } from './kit';
import { Button } from './ui';

export interface BranchRole { branchId: string; roleId: string }

/** Rows of (branch, role): one person can be Manager in one branch and Cashier in another. */
export function BranchRolesEditor({ value, onChange }: { value: BranchRole[]; onChange: (v: BranchRole[]) => void }) {
  const branches = useBranchQuery<BranchRow[]>('/branches');
  const roles = useBranchQuery<RoleRow[]>('/roles');
  const set = (i: number, patch: Partial<BranchRole>) => onChange(value.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  return (
    <div className="space-y-2">
      {value.length === 0 && <p className="text-sm text-fg-muted">No branch access yet.</p>}
      {value.map((r, i) => (
        <div key={i} className="flex gap-2">
          <Select value={r.branchId} onChange={(e) => set(i, { branchId: e.target.value })} aria-label="Branch">
            <option value="">Branch…</option>
            {branches.data?.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </Select>
          <Select value={r.roleId} onChange={(e) => set(i, { roleId: e.target.value })} aria-label="Role">
            <option value="">Role…</option>
            {roles.data?.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </Select>
          <button aria-label="Remove" onClick={() => onChange(value.filter((_, j) => j !== i))} className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
        </div>
      ))}
      <Button variant="outline" className="h-8 px-3" onClick={() => onChange([...value, { branchId: branches.data?.[0]?.id ?? '', roleId: '' }])}><Plus size={14} /> Add branch role</Button>
    </div>
  );
}
