import { Inject, Injectable, InternalServerErrorException, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Global, Module } from '@nestjs/common';
import { Prisma, PrismaClient, withTenant } from '@kynex/database';
import { ENV, type Env } from '../config/env';
import { requestContext } from '../common/request-context';

/** Connects as the APPLICATION role (kynex_app): it cannot bypass Row-Level Security. */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  constructor(@Inject(ENV) env: Env) {
    super({ datasourceUrl: env.DATABASE_URL, log: env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'] });
  }
  async onModuleInit(): Promise<void> {
    await this.$connect();
  }
  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }
}

/** Access to tenant data. Every tenant query goes through a transaction that has app.tenant_id set. */
@Injectable()
export class TenantDb {
  constructor(private readonly prisma: PrismaService) {}

  /** The current request's tenant transaction (opened by TenantTransactionInterceptor). */
  get tx(): Prisma.TransactionClient {
    const tx = requestContext.getStore()?.tx;
    if (!tx) {
      throw new InternalServerErrorException('No tenant transaction is active for this request');
    }
    return tx;
  }

  /** Own short transaction for a given tenant: used by guards, login and background work. */
  run<T>(tenantId: string, fn: (tx: Prisma.TransactionClient) => Promise<T>, options?: { timeout?: number }): Promise<T> {
    return withTenant(this.prisma, tenantId, fn, options);
  }
}

@Global()
@Module({ providers: [PrismaService, TenantDb], exports: [PrismaService, TenantDb] })
export class PrismaModule {}
