'use client';

import { Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { categoryOptions } from '@/components/product-form';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num, qty, productName } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Category, Product } from '@/lib/types';

export default function ProductsPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [status, setStatus] = useState('active');
  const [rx, setRx] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, categoryId, status, rx]);
  const cats = useBranchQuery<Category[]>('/categories', { staleTime: 60_000 });
  const catOpts = useMemo(() => categoryOptions(cats.data), [cats.data]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Product>>(
    `/products${qs({ page, pageSize: 25, search: s, categoryId, includeSubcategories: categoryId ? true : undefined, status, requiresPrescription: rx || undefined, withStock: true })}`,
    { keepPrevious: true },
  );
  const cur = profile.tenant.currencyCode;

  return (
    <div>
      <PageHeader
        title="Medicines & products"
        subtitle={data ? `${data.meta.total.toLocaleString()} products` : undefined}
        actions={can('product:create') && <Link href="/medicines/new"><Button><Plus size={16} /> New product</Button></Link>}
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_220px_150px_150px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Name, generic, SKU or barcode" autoFocus />
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="Category">
            <option value="">All categories</option>
            {catOpts.map((c) => <option key={c.id} value={c.id}>{'  '.repeat(c.depth)}{c.label.split(' › ').pop()}</option>)}
          </Select>
          <Select value={rx} onChange={(e) => setRx(e.target.value)} aria-label="Prescription">
            <option value="">Rx and OTC</option>
            <option value="true">Prescription only</option>
            <option value="false">Over the counter</option>
          </Select>
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="all">All</option>
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(p) => p.id}
          onRowClick={(p) => router.push(`/medicines/${p.id}`)}
          empty={<p className="px-4 py-10 text-center text-sm text-fg-muted">No products match these filters.</p>}
          columns={[
            {
              key: 'name', header: 'Product',
              cell: (p) => (
                <div className="min-w-0">
                  <p className="flex items-center gap-2 font-medium">
                    <span className="truncate">{productName(p.brandName, p.strength)}</span>
                    {p.requiresPrescription && <Badge tone="warning">Rx</Badge>}
                    {!p.isActive && <Badge>Inactive</Badge>}
                  </p>
                  <p className="truncate text-xs text-fg-muted">{[p.genericName, p.dosageForm.toLowerCase()].filter(Boolean).join(' · ')}</p>
                </div>
              ),
            },
            { key: 'sku', header: 'SKU', cell: (p) => <span className="font-mono text-xs">{p.sku}</span> },
            { key: 'cat', header: 'Category', cell: (p) => p.category.name },
            { key: 'price', header: 'Price', align: 'right', cell: (p) => money(num(p.branchSellingPrice ?? p.sellingPrice), cur) },
            {
              key: 'stock', header: 'Sellable stock', align: 'right',
              cell: (p) => {
                const s = num(p.stock);
                const low = num(p.reorderLevel) > 0 && s <= num(p.branchReorderLevel ?? p.reorderLevel);
                return <span className={s === 0 ? 'text-danger' : low ? 'text-warning' : ''}>{qty(s)} <span className="text-xs text-fg-muted">{p.baseUnit}</span></span>;
              },
            },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
