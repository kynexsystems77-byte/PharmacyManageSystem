import { randomUUID } from 'node:crypto';
import { afterAll, describe, expect, it } from 'vitest';
import { PrismaClient } from '@prisma/client';
import { withTenant } from '../src/tenant-context';

/**
 * These tests connect as the APPLICATION role (DATABASE_URL), exactly like the API will.
 * They prove tenant isolation and the ledger/stock invariants are enforced by PostgreSQL itself.
 */
const prisma = new PrismaClient({ datasourceUrl: process.env.DATABASE_URL });
afterAll(async () => {
  await prisma.$disconnect();
});

async function createFixture(label: string) {
  const tenantId = randomUUID();
  const ids = await withTenant(prisma, tenantId, async (tx) => {
    await tx.tenant.create({ data: { id: tenantId, name: `Test ${label}`, slug: `test-${label}-${tenantId.slice(0, 8)}` } });
    const branch = await tx.branch.create({ data: { tenantId, name: 'Branch', code: 'B1' } });
    const location = await tx.location.create({ data: { tenantId, branchId: branch.id, name: 'Floor' } });
    const category = await tx.category.create({ data: { tenantId, name: 'Medicine' } });
    const product = await tx.product.create({ data: { tenantId, sku: 'SKU-1', brandName: 'Test Drug', categoryId: category.id } });
    const batch = await tx.batch.create({ data: { tenantId, productId: product.id, batchNumber: 'BATCH-1' } });
    const stock = await tx.stockLevel.create({
      data: { tenantId, branchId: branch.id, locationId: location.id, productId: product.id, batchId: batch.id, quantity: 10 },
    });
    const movement = await tx.inventoryMovement.create({
      data: {
        tenantId, branchId: branch.id, locationId: location.id, productId: product.id, batchId: batch.id,
        movementType: 'OPENING_BALANCE', quantityDelta: 10,
      },
    });
    return {
      branchId: branch.id, categoryId: category.id, productId: product.id, batchId: batch.id,
      stockId: stock.id, movementId: movement.id,
    };
  });
  return { tenantId, ...ids };
}

describe('tenant isolation (Row-Level Security)', () => {
  it('returns no tenant rows when no tenant context is set', async () => {
    await createFixture('nocontext');
    expect(await prisma.product.count()).toBe(0);
    expect(await prisma.batch.count()).toBe(0);
  });

  it('lets a tenant see only its own rows', async () => {
    const a = await createFixture('a');
    const b = await createFixture('b');
    const seenByA = await withTenant(prisma, a.tenantId, (tx) => tx.product.findMany());
    const seenByB = await withTenant(prisma, b.tenantId, (tx) => tx.product.findMany());
    expect(seenByA.map((p) => p.id)).toEqual([a.productId]);
    expect(seenByB.map((p) => p.id)).toEqual([b.productId]);
    const bReadsA = await withTenant(prisma, b.tenantId, (tx) => tx.product.findUnique({ where: { id: a.productId } }));
    expect(bReadsA).toBeNull();
  });

  it('rejects writing a row that belongs to another tenant', async () => {
    const a = await createFixture('w1');
    const b = await createFixture('w2');
    await expect(
      withTenant(prisma, a.tenantId, (tx) =>
        tx.product.create({ data: { tenantId: b.tenantId, sku: 'EVIL', brandName: 'Evil', categoryId: b.categoryId } }),
      ),
    ).rejects.toThrow();
  });

  it('rejects referencing another tenant\'s row (cross-tenant foreign key)', async () => {
    const a = await createFixture('r1');
    const b = await createFixture('r2');
    await expect(
      withTenant(prisma, b.tenantId, (tx) =>
        tx.product.create({ data: { tenantId: b.tenantId, sku: 'X-REF', brandName: 'Cross', categoryId: a.categoryId } }),
      ),
    ).rejects.toThrow();
  });
});

describe('inventory invariants', () => {
  it('never allows a stock movement to be updated or deleted', async () => {
    const f = await createFixture('ledger');
    await expect(
      withTenant(prisma, f.tenantId, (tx) => tx.inventoryMovement.update({ where: { id: f.movementId }, data: { reason: 'tamper' } })),
    ).rejects.toThrow();
    await expect(
      withTenant(prisma, f.tenantId, (tx) => tx.inventoryMovement.delete({ where: { id: f.movementId } })),
    ).rejects.toThrow();
  });

  it('never allows stock to go negative', async () => {
    const f = await createFixture('negative');
    await expect(
      withTenant(prisma, f.tenantId, (tx) => tx.stockLevel.update({ where: { id: f.stockId }, data: { quantity: -1 } })),
    ).rejects.toThrow();
  });
});

describe('login lookup before a tenant is known', () => {
  it('finds a user by email through the SECURITY DEFINER function only', async () => {
    const f = await createFixture('login');
    const email = `login-${f.tenantId.slice(0, 8)}@example.test`;
    await withTenant(prisma, f.tenantId, (tx) =>
      tx.user.create({ data: { tenantId: f.tenantId, email, fullName: 'Login Test', passwordHash: 'x' } }),
    );
    expect(await prisma.user.count()).toBe(0); // direct table access without context: nothing visible
    const rows = await prisma.$queryRaw<{ id: string; tenant_id: string }[]>`SELECT id, tenant_id FROM auth_find_user_by_email(${email})`;
    expect(rows).toHaveLength(1);
    expect(rows[0]?.tenant_id).toBe(f.tenantId);
  });
});
