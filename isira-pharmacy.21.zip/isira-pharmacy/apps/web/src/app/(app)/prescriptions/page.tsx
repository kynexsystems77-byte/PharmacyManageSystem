'use client';

import { Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, Forbidden, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import { RX_TONE } from '@/lib/status';
import type { Prescription } from '@/lib/types';

export default function PrescriptionsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Prescription>>(`/prescriptions${qs({ page, pageSize: 25, search: s, status })}`, { keepPrevious: true });
  if (!can('prescription:read')) return <Forbidden what="prescriptions" />;
  return (
    <div>
      <PageHeader title="Prescriptions" actions={can('prescription:manage') && <Link href="/prescriptions/new"><Button><Plus size={16} /> Record prescription</Button></Link>} />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_200px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Patient, phone, doctor or Rx number" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">Any status</option>
            {['ACTIVE', 'PARTIALLY_DISPENSED', 'DISPENSED', 'CANCELLED'].map((x) => <option key={x} value={x}>{titleCase(x)}</option>)}
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(p) => p.id}
          onRowClick={(p) => router.push(`/prescriptions/${p.id}`)}
          columns={[
            { key: 'd', header: 'Date', cell: (p) => dateOnly(p.prescribedDate) },
            { key: 'c', header: 'Patient', cell: (p) => <div><p className="font-medium">{p.customer.fullName}</p><p className="text-xs text-fg-muted">{p.customer.phone ?? ''}</p></div> },
            { key: 'doc', header: 'Doctor', cell: (p) => p.doctorName },
            { key: 'n', header: 'Rx no.', cell: (p) => p.prescriptionNumber ?? '-' },
            { key: 'i', header: 'Items', cell: (p) => <span className="line-clamp-1 text-fg-muted">{p.prescriptionItems.map((i) => i.medicineName).join(', ')}</span> },
            { key: 'v', header: 'Valid until', cell: (p) => dateOnly(p.validUntil) },
            { key: 's', header: 'Status', cell: (p) => <Badge tone={RX_TONE[p.status]}>{titleCase(p.status)}</Badge> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
