'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function SalesLayout({ children }: { children: ReactNode }) {
  const { can } = useAuth();
  if (!can('sale:read')) return <Forbidden what="sales" />;
  return (
    <div>
      <SubNav items={[{ href: '/sales', label: 'Invoices', exact: true }, { href: '/sales/returns', label: 'Returns' }]} />
      {children}
    </div>
  );
}
