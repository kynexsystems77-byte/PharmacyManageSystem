import { Body, Controller, Get, Module, Patch } from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { updateTenantSchema } from '@kynex/contracts';
import { AuditService } from '../audit/audit.service';
import { RequirePermissions } from '../common/decorators';
import { TenantDb } from '../prisma/prisma.service';

class UpdateTenantDto extends createZodDto(updateTenantSchema) {}

const TENANT_SELECT = { id: true, name: true, slug: true, status: true, currencyCode: true, timezone: true } as const;

@ApiTags('Tenant')
@ApiCookieAuth()
@Controller('tenant')
export class TenantsController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService) {}

  @Get()
  get() {
    return this.db.tx.tenant.findFirstOrThrow({ select: TENANT_SELECT });
  }

  @Patch()
  @RequirePermissions('tenant:settings:manage')
  async update(@Body() dto: UpdateTenantDto) {
    const tx = this.db.tx;
    const before = await tx.tenant.findFirstOrThrow({ select: TENANT_SELECT });
    const after = await tx.tenant.update({ where: { id: before.id }, data: dto, select: TENANT_SELECT });
    await this.audit.record({ action: 'tenant.updated', entityType: 'tenant', entityId: after.id, before, after });
    return after;
  }
}

@Module({ controllers: [TenantsController] })
export class TenantsModule {}
