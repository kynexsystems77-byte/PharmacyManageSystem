'use client';

import type { ReactNode } from 'react';
import { Forbidden, SubNav } from '@/components/kit';
import { useAuth } from '@/lib/auth';

export default function PurchasingLayout({ children }: { children: ReactNode }) {
  const { can, canAny } = useAuth();
  if (!canAny('purchase:read', 'supplier:read')) return <Forbidden what="purchasing" />;
  const items = [
    can('purchase:read') && { href: '/purchasing', label: 'Purchases', exact: true },
    can('purchase:read') && { href: '/purchasing/orders', label: 'Purchase orders' },
    can('supplier:read') && { href: '/purchasing/suppliers', label: 'Suppliers' },
    can('purchase:read') && { href: '/purchasing/returns', label: 'Returns' },
    can('supplier:read') && { href: '/purchasing/payables', label: 'Payables' },
  ].filter(Boolean) as { href: string; label: string; exact?: boolean }[];
  return (
    <div>
      <SubNav items={items} />
      {children}
    </div>
  );
}
