'use client';

import { PackageCheck, Printer, Send } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { ConfirmDialog, DataTable, KeyValue, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, productName, qty, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import { PO_TONE } from '@/lib/status';
import type { PurchaseOrder } from '@/lib/types';

export default function OrderPage({ params }: { params: { id: string } }) {
  const toast = useToast();
  const { can, profile, branch } = useAuth();
  const cur = profile.tenant.currencyCode;
  const { data: o, isLoading, error } = useBranchQuery<PurchaseOrder>(`/purchase-orders/${params.id}`);
  const [confirm, setConfirm] = useState<'cancel' | 'close' | null>(null);
  const act = useApiMutation<'order' | 'cancel' | 'close'>('POST', (a) => `/purchase-orders/${params.id}/${a}`, {
    onSuccess: (_r, a) => { toast.success(a === 'order' ? 'Marked as ordered' : a === 'cancel' ? 'Order cancelled' : 'Order closed'); setConfirm(null); },
  });
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !o) return <Alert>{errorMessage(error) || 'Order not found'}</Alert>;
  const manage = can('purchase_order:manage');
  const receivable = ['ORDERED', 'PARTIALLY_RECEIVED'].includes(o.status) && can('purchase:create');

  return (
    <div className="space-y-4">
      <PageHeader
        back="/purchasing/orders"
        title={o.number}
        subtitle={<span className="flex items-center gap-2"><Badge tone={PO_TONE[o.status]}>{titleCase(o.status)}</Badge>{o.supplier.name}</span>}
        actions={
          <>
            <Button variant="outline" onClick={() => window.print()}><Printer size={16} /> Print</Button>
            {manage && o.status === 'DRAFT' && <Button variant="outline" onClick={() => setConfirm('cancel')}>Cancel</Button>}
            {manage && o.status === 'ORDERED' && <Button variant="outline" onClick={() => setConfirm('cancel')}>Cancel</Button>}
            {manage && o.status === 'PARTIALLY_RECEIVED' && <Button variant="outline" onClick={() => setConfirm('close')}>Close (rest not coming)</Button>}
            {manage && o.status === 'DRAFT' && <Button loading={act.isPending} onClick={() => act.mutate('order')}><Send size={16} /> Mark as sent</Button>}
            {receivable && <Link href={`/purchasing/new?orderId=${o.id}`}><Button><PackageCheck size={16} /> Receive delivery</Button></Link>}
          </>
        }
      />
      {act.error && <Alert>{errorMessage(act.error)}</Alert>}
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Supplier', value: <Link className="text-brand hover:underline" href={`/purchasing/suppliers/${o.supplier.id}`}>{o.supplier.name}</Link> },
          { label: 'Supplier contact', value: [o.supplier.phone, o.supplier.email].filter(Boolean).join(' · ') || null },
          { label: 'Deliver to', value: branch?.name },
          { label: 'Order date', value: dateOnly(o.orderDate) },
          { label: 'Expected', value: dateOnly(o.expectedDate) },
          { label: 'Created by', value: `${o.createdBy.fullName}, ${dateTime(o.createdAt)}` },
          { label: 'Notes', value: o.notes },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Lines" action={<span className="tabular font-semibold">{money(num(o.grandTotal), cur)}</span>} />
        <DataTable
          rows={o.purchaseOrderItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => <span className="font-medium">{productName(i.product.brandName, i.product.strength)}</span> },
            { key: 's', header: 'SKU', cell: (i) => <span className="font-mono text-xs">{i.product.sku}</span> },
            { key: 'o', header: 'Ordered', align: 'right', cell: (i) => `${qty(num(i.orderedQuantity))} ${i.product.baseUnit}` },
            { key: 'r', header: 'Received', align: 'right', cell: (i) => <span className={num(i.receivedQuantity) >= num(i.orderedQuantity) ? 'text-success' : num(i.receivedQuantity) > 0 ? 'text-warning' : ''}>{qty(num(i.receivedQuantity))}</span> },
            { key: 'c', header: 'Unit cost', align: 'right', cell: (i) => money(num(i.unitCost), cur) },
            { key: 't', header: 'Line total', align: 'right', cell: (i) => money(num(i.lineTotal), cur) },
          ]}
        />
      </Card>
      {o.purchases.length > 0 && (
        <Card>
          <CardHeader title="Deliveries" />
          <ul className="divide-y divide-line text-sm">
            {o.purchases.map((p) => (
              <li key={p.id} className="flex justify-between px-4 py-2.5">
                <Link className="font-mono text-xs text-brand hover:underline" href={`/purchasing/${p.id}`}>{p.number}</Link>
                <span className="text-fg-muted">{p.status.toLowerCase()} · {dateTime(p.receivedAt)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <ConfirmDialog
        open={Boolean(confirm)}
        title={confirm === 'cancel' ? 'Cancel this order?' : 'Close this order?'}
        danger={confirm === 'cancel'}
        loading={act.isPending}
        confirmLabel={confirm === 'cancel' ? 'Cancel order' : 'Close order'}
        onClose={() => setConfirm(null)}
        onConfirm={() => confirm && act.mutate(confirm)}
        body={<p>{confirm === 'cancel' ? 'Nothing more can be received against it.' : 'Undelivered quantities are dropped and the order is marked received.'}</p>}
      />
    </div>
  );
}
