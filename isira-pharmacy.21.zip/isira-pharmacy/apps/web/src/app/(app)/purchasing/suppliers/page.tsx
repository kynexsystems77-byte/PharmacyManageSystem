'use client';

import { Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { SupplierFormModal } from '@/components/supplier-form';
import { Badge, Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { money, num } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Supplier } from '@/lib/types';

export default function SuppliersPage() {
  const router = useRouter();
  const { can, profile } = useAuth();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('active');
  const [creating, setCreating] = useState(false);
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Supplier>>(`/suppliers${qs({ page, pageSize: 25, search: s, status, withBalance: true })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader title="Suppliers" actions={can('supplier:manage') && <Button onClick={() => setCreating(true)}><Plus size={16} /> New supplier</Button>} />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_180px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Name, contact or phone" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="active">Active</option><option value="inactive">Inactive</option><option value="all">All</option>
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(x) => x.id}
          onRowClick={(x) => router.push(`/purchasing/suppliers/${x.id}`)}
          columns={[
            { key: 'n', header: 'Supplier', cell: (x) => <div><p className="font-medium">{x.name}</p><p className="text-xs text-fg-muted">{x.contactName ?? ''}</p></div> },
            { key: 'p', header: 'Phone', cell: (x) => x.phone ?? '-' },
            { key: 't', header: 'Terms', cell: (x) => (x.paymentTermsDays ? `${x.paymentTermsDays} days` : 'On delivery') },
            { key: 's', header: '', cell: (x) => !x.isActive && <Badge>Inactive</Badge> },
            { key: 'b', header: 'We owe', align: 'right', cell: (x) => <span className={num(x.balance) > 0 ? 'font-medium' : 'text-fg-muted'}>{money(num(x.balance), profile.tenant.currencyCode)}</span> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
      {creating && <SupplierFormModal open onClose={() => setCreating(false)} onSaved={(x) => router.push(`/purchasing/suppliers/${x.id}`)} />}
    </div>
  );
}
