'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Forbidden, PageHeader, useToast } from '@/components/kit';
import { draftBody, draftFromOrder, PurchaseForm, type PurchaseDraft } from '@/components/purchase-form';
import { Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { todayIso } from '@/lib/format';
import { useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Purchase, PurchaseOrder } from '@/lib/types';

export default function NewPurchasePage() {
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const orderId = useSearchParams().get('orderId');
  const po = useBranchQuery<PurchaseOrder>(orderId ? `/purchase-orders/${orderId}` : null);
  const create = useApiMutation<object, Purchase>('POST', '/purchases', {
    onSuccess: (p) => {
      toast.success(p.status === 'RECEIVED' ? `${p.number} received into stock` : `${p.number} saved as draft`);
      router.push(`/purchasing/${p.id}`);
    },
  });
  if (!can('purchase:create')) return <Forbidden what="creating purchases" />;
  if (orderId && !po.data) return <Skeleton className="h-64" />;
  const initial: PurchaseDraft = po.data
    ? draftFromOrder(po.data)
    : { supplierId: '', locationId: '', supplierInvoiceNo: '', purchaseDate: todayIso(), dueDate: '', notes: '', lines: [] };
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader back="/purchasing" title={po.data ? `Receive against ${po.data.number}` : 'New purchase'} subtitle={po.data ? `${po.data.supplier.name} · enter batch numbers and expiry dates from the delivery` : 'Enter the supplier invoice. Save as a draft, or receive the goods into stock now.'} />
      <PurchaseForm
        mode="create"
        initial={initial}
        submitting={create.isPending}
        error={create.error}
        onSave={(d, action, payment) => create.mutate({ ...draftBody(d), receive: action === 'receive', payment })}
        onCancel={() => router.back()}
      />
    </div>
  );
}
