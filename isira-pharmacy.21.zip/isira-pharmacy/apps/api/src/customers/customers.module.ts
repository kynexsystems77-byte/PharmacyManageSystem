import {
  Body, ConflictException, Controller, Delete, Get, HttpCode, Module, NotFoundException, Param, ParseUUIDPipe, Patch, Post, Query,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import { createCustomerSchema, customerPaymentSchema, listCustomersQuerySchema, paginationSchema, updateCustomerSchema } from '@kynex/contracts';
import { Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId, requirePermission } from '../common/branch';
import { openSessionFor, partyBalance, recordCash } from '../common/cash';
import { dec, money2, optionalDate, SequenceService, sumDec } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';

class CreateCustomerDto extends createZodDto(createCustomerSchema) {}
class UpdateCustomerDto extends createZodDto(updateCustomerSchema) {}
class ListCustomersQueryDto extends createZodDto(listCustomersQuerySchema) {}
class CustomerPaymentDto extends createZodDto(customerPaymentSchema) {}
class PageQueryDto extends createZodDto(paginationSchema) {}

export const CUSTOMER_SELECT = {
  id: true, code: true, fullName: true, phone: true, email: true, address: true, dateOfBirth: true, creditLimit: true,
  notes: true, isActive: true, createdAt: true,
} satisfies Prisma.CustomerSelect;

@ApiTags('Customers')
@ApiCookieAuth()
@Controller('customers')
export class CustomersController {
  constructor(private readonly db: TenantDb, private readonly audit: AuditService, private readonly sequences: SequenceService) {}

  @Get()
  @RequirePermissions('customer:read')
  async list(@Query() q: ListCustomersQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.CustomerWhereInput = {
      deletedAt: null,
      ...(q.status === 'active' ? { isActive: true } : q.status === 'inactive' ? { isActive: false } : {}),
      ...(q.search
        ? { OR: [{ fullName: { contains: q.search, mode: 'insensitive' } }, { phone: { contains: q.search } }, { code: { contains: q.search, mode: 'insensitive' } }, { email: { contains: q.search, mode: 'insensitive' } }] }
        : {}),
    };
    if (q.owing === 'true') {
      const owing = await tx.$queryRaw<{ customer_id: string }[]>`
        SELECT customer_id FROM party_ledger_entries WHERE customer_id IS NOT NULL GROUP BY customer_id HAVING SUM(amount) > 0`;
      where.id = { in: owing.map((o) => o.customer_id) };
    }
    const [rows, total] = await Promise.all([
      tx.customer.findMany({ where, orderBy: { fullName: 'asc' }, select: CUSTOMER_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.customer.count({ where }),
    ]);
    if (q.withBalance !== 'true' && q.owing !== 'true') return paged(rows, total, q.page, q.pageSize);
    const sums = await tx.partyLedgerEntry.groupBy({ by: ['customerId'], where: { customerId: { in: rows.map((r) => r.id) } }, _sum: { amount: true } });
    const bal = new Map(sums.map((s) => [s.customerId, dec(s._sum.amount).toFixed(2)]));
    return paged(rows.map((r) => ({ ...r, balance: bal.get(r.id) ?? '0.00' })), total, q.page, q.pageSize);
  }

  /** Customers who owe the pharmacy money (credit sales not yet paid). */
  @Get('receivables')
  @RequirePermissions('customer:read')
  async receivables() {
    const rows = await this.db.tx.$queryRaw<{ id: string; full_name: string; phone: string | null; code: string | null; credit_limit: string; balance: string; last_entry: Date }[]>`
      SELECT c.id, c.full_name, c.phone, c.code, c.credit_limit::text, ROUND(SUM(l.amount), 2)::text AS balance, MAX(l.created_at) AS last_entry
      FROM customers c JOIN party_ledger_entries l ON l.customer_id = c.id
      WHERE c.deleted_at IS NULL
      GROUP BY c.id HAVING SUM(l.amount) <> 0
      ORDER BY SUM(l.amount) DESC`;
    return {
      total: sumDec(rows.map((r) => r.balance)).toFixed(2),
      customers: rows.map((r) => ({ id: r.id, fullName: r.full_name, phone: r.phone, code: r.code, creditLimit: r.credit_limit, balance: r.balance, lastActivity: r.last_entry })),
    };
  }

  @Get(':id')
  @RequirePermissions('customer:read')
  async get(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const c = await tx.customer.findFirst({ where: { id, deletedAt: null }, select: CUSTOMER_SELECT });
    if (!c) throw new NotFoundException('Customer not found');
    const branches = [...auth.branchIds];
    const [balance, stats, recent, prescriptions] = await Promise.all([
      partyBalance(tx, { customerId: id }),
      tx.sale.aggregate({ where: { customerId: id, status: { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED'] } }, _sum: { grandTotal: true }, _count: true, _max: { soldAt: true } }),
      tx.sale.findMany({
        where: { customerId: id, branchId: { in: branches }, status: { in: ['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED', 'VOIDED'] } },
        orderBy: { soldAt: 'desc' }, take: 10,
        select: { id: true, invoiceNo: true, status: true, grandTotal: true, balanceDue: true, soldAt: true, branch: { select: { id: true, name: true } }, _count: { select: { saleItems: true } } },
      }),
      tx.prescription.findMany({
        where: { customerId: id, deletedAt: null }, orderBy: { prescribedDate: 'desc' }, take: 10,
        select: { id: true, prescriptionNumber: true, doctorName: true, prescribedDate: true, validUntil: true, status: true, _count: { select: { prescriptionItems: true } } },
      }),
    ]);
    return {
      ...c,
      balance: balance.toFixed(2),
      availableCredit: dec(c.creditLimit).gt(0) ? Prisma.Decimal.max(dec(c.creditLimit).minus(balance), 0).toFixed(2) : '0.00',
      stats: { visits: stats._count, totalSpent: dec(stats._sum.grandTotal).toFixed(2), lastVisit: stats._max.soldAt },
      recentSales: recent.map(({ _count, ...s }) => ({ ...s, itemCount: _count.saleItems })),
      prescriptions: prescriptions.map(({ _count, ...p }) => ({ ...p, itemCount: _count.prescriptionItems })),
    };
  }

  @Get(':id/ledger')
  @RequirePermissions('customer:read')
  async ledger(@Param('id', ParseUUIDPipe) id: string, @Query() q: PageQueryDto) {
    const { skip, take } = skipTake(q.page, q.pageSize);
    const rows = await this.db.tx.$queryRaw<{ id: string; entry_type: string; amount: string; description: string | null; reference_type: string | null; reference_id: string | null; created_at: Date; balance: string; total: number }[]>`
      SELECT id, entry_type::text, amount::text, description, reference_type, reference_id, created_at,
             SUM(amount) OVER (ORDER BY created_at, id ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)::text AS balance,
             COUNT(*) OVER ()::int AS total
      FROM party_ledger_entries WHERE customer_id = ${id}::uuid
      ORDER BY created_at DESC, id DESC LIMIT ${take} OFFSET ${skip}`;
    return paged(
      rows.map((r) => ({ id: r.id, entryType: r.entry_type, amount: r.amount, description: r.description, referenceType: r.reference_type, referenceId: r.reference_id, createdAt: r.created_at, balance: r.balance })),
      rows[0]?.total ?? 0, q.page, q.pageSize,
    );
  }

  @Post()
  @RequirePermissions('customer:manage')
  async create(@Body() dto: CreateCustomerDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    if (dto.creditLimit > 0) requirePermission(auth, 'customer:credit:manage');
    if (dto.phone && (await tx.customer.count({ where: { phone: dto.phone, deletedAt: null } }))) {
      throw new ConflictException('A customer with this phone number already exists');
    }
    const code = dto.code ?? (await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'CUSTOMER', scopeKey: 'tenant', prefix: 'C', yearless: true }));
    const c = await tx.customer.create({
      data: {
        tenantId: auth.tenantId, code, fullName: dto.fullName, phone: dto.phone ?? null, email: dto.email ?? null, address: dto.address ?? null,
        dateOfBirth: optionalDate(dto.dateOfBirth) ?? null, creditLimit: money2(dto.creditLimit), notes: dto.notes ?? null,
      },
      select: CUSTOMER_SELECT,
    });
    await this.audit.record({ action: 'customer.created', entityType: 'customer', entityId: c.id, after: c });
    return c;
  }

  @Patch(':id')
  @RequirePermissions('customer:manage')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateCustomerDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await tx.customer.findFirst({ where: { id, deletedAt: null }, select: CUSTOMER_SELECT });
    if (!before) throw new NotFoundException('Customer not found');
    if (dto.creditLimit !== undefined && !dec(dto.creditLimit).equals(before.creditLimit)) requirePermission(auth, 'customer:credit:manage');
    if (dto.phone && dto.phone !== before.phone && (await tx.customer.count({ where: { phone: dto.phone, deletedAt: null, id: { not: id } } }))) {
      throw new ConflictException('Another customer has this phone number');
    }
    const { dateOfBirth, creditLimit, ...rest } = dto;
    const after = await tx.customer.update({
      where: { id },
      data: { ...rest, dateOfBirth: optionalDate(dateOfBirth), creditLimit: creditLimit === undefined ? undefined : money2(creditLimit) },
      select: CUSTOMER_SELECT,
    });
    await this.audit.record({ action: 'customer.updated', entityType: 'customer', entityId: id, before, after });
    return after;
  }

  @Delete(':id')
  @HttpCode(204)
  @RequirePermissions('customer:manage')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const before = await tx.customer.findFirst({ where: { id, deletedAt: null }, select: CUSTOMER_SELECT });
    if (!before) throw new NotFoundException('Customer not found');
    if (!(await partyBalance(tx, { customerId: id })).isZero()) throw new ConflictException('Settle the customer balance before deleting');
    await tx.customer.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
    await this.audit.record({ action: 'customer.deleted', entityType: 'customer', entityId: id, before });
  }

  /** Money received against a customer's credit balance. Cash goes into the receiver's open register shift. */
  @Post(':id/payments')
  @BranchScoped()
  @RequirePermissions('customer:credit:manage')
  async pay(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CustomerPaymentDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const c = await tx.customer.findFirst({ where: { id, deletedAt: null }, select: { id: true, fullName: true } });
    if (!c) throw new NotFoundException('Customer not found');
    const amount = money2(dto.amount);
    const session = dto.method === 'CASH' ? await openSessionFor(tx, branchId, auth.userId) : null;
    if (dto.method === 'CASH' && !session) throw new UnprocessableEntityException('Open a register shift to take cash');
    const payment = await tx.payment.create({
      data: {
        tenantId: auth.tenantId, kind: 'CUSTOMER_PAYMENT', method: dto.method, amount, reference: dto.reference ?? null, note: dto.note ?? null,
        branchId, receivedById: auth.userId, registerSessionId: session?.id ?? null, customerId: id,
      },
    });
    await tx.partyLedgerEntry.create({
      data: {
        tenantId: auth.tenantId, entryType: 'PAYMENT', amount: amount.negated(), referenceType: 'customer_payment', referenceId: payment.id,
        description: `Payment (${dto.method.toLowerCase().replace('_', ' ')})${dto.reference ? ` ref ${dto.reference}` : ''}`, branchId, customerId: id, createdById: auth.userId,
      },
    });
    if (session) {
      await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: session.id, userId: auth.userId, type: 'CUSTOMER_PAYMENT', amount, referenceType: 'customer_payment', referenceId: payment.id, note: c.fullName });
    }
    const balance = await partyBalance(tx, { customerId: id });
    const result = { paymentId: payment.id, amount: amount.toFixed(2), balance: balance.toFixed(2) };
    await this.audit.record({ action: 'customer.payment', entityType: 'customer', entityId: id, after: result });
    return result;
  }
}

@Module({ controllers: [CustomersController] })
export class CustomersModule {}
