import { shortDay } from '@/lib/format';
import type { DayPoint } from '@/lib/types';

/** Dependency-free responsive SVG bar chart (last 7 days of sales). */
export function SalesBars({ data, format }: { data: DayPoint[]; format: (v: number) => string }) {
  const W = 560, H = 190, padX = 12, padTop = 12, padBottom = 28;
  const max = Math.max(1, ...data.map((d) => d.total));
  const slot = (W - padX * 2) / Math.max(1, data.length);
  const barW = Math.min(46, slot * 0.6);
  const plotH = H - padTop - padBottom;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Sales for the last 7 days" className="h-auto w-full">
      <line x1={padX} x2={W - padX} y1={H - padBottom} y2={H - padBottom} className="stroke-line" />
      {data.map((d, i) => {
        const h = (d.total / max) * plotH;
        const x = padX + i * slot + (slot - barW) / 2;
        const isToday = i === data.length - 1;
        return (
          <g key={d.day}>
            <title>{`${d.day}: ${format(d.total)} (${d.count} invoices)`}</title>
            <rect
              x={x}
              y={H - padBottom - Math.max(h, d.total > 0 ? 2 : 0)}
              width={barW}
              height={Math.max(h, d.total > 0 ? 2 : 0)}
              rx={4}
              className={isToday ? 'fill-brand' : 'fill-brand/35'}
            />
            <text x={x + barW / 2} y={H - 10} textAnchor="middle" className="fill-fg-muted text-[11px]">
              {shortDay(d.day)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
