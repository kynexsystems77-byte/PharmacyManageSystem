'use client';

import { AlertTriangle, CalendarClock, PackageX, Plus, Wallet } from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useMemo, useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { LocationSelect } from '@/components/pickers';
import { categoryOptions } from '@/components/product-form';
import { Badge, Button, Card, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, qty, productName } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Category, Dashboard, StockRow } from '@/lib/types';

const FILTERS = [
  { v: 'all', l: 'All products' },
  { v: 'in_stock', l: 'In stock' },
  { v: 'low', l: 'Low stock' },
  { v: 'out', l: 'Out of stock' },
  { v: 'expiring', l: 'Expiring soon' },
  { v: 'expired', l: 'Has expired stock' },
];

export default function StockPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState(params.get('filter') ?? 'all');
  const [categoryId, setCategoryId] = useState('');
  const [locationId, setLocationId] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, filter, categoryId, locationId]);
  const cats = useBranchQuery<Category[]>('/categories', { staleTime: 60_000 });
  const catOpts = useMemo(() => categoryOptions(cats.data), [cats.data]);
  const dash = useBranchQuery<Dashboard>('/dashboard', { staleTime: 30_000 });
  const { data, isLoading, isFetching } = useBranchQuery<Paged<StockRow> & { today: string; totals: { onHandValue: string | null; products: number } }>(
    `/inventory/stock${qs({ page, pageSize: 25, search: s, filter, categoryId, locationId, days: 90 })}`,
    { keepPrevious: true },
  );
  const inv = dash.data?.inventory;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Stock"
        subtitle="Quantities are in base units. Sellable excludes expired, quarantined and recalled batches."
        actions={
          <>
            {can('inventory:adjust') && <Link href="/inventory/opening-stock"><Button variant="outline"><Plus size={16} /> Opening stock</Button></Link>}
            {can('inventory:adjust') && <Link href="/inventory/adjustments/new"><Button>New adjustment</Button></Link>}
          </>
        }
      />

      {inv && (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <button className="h-full text-left" onClick={() => setFilter('low')}><StatTile label="Low stock" value={String(inv.lowStockCount)} icon={<AlertTriangle size={18} />} tone={inv.lowStockCount ? 'warning' : 'neutral'} hint="products at or below reorder level" /></button>
          <button className="h-full text-left" onClick={() => setFilter('expiring')}><StatTile label="Expiring in 30 days" value={String(inv.expiringSoonCount)} icon={<CalendarClock size={18} />} tone={inv.expiringSoonCount ? 'warning' : 'neutral'} hint="batches" /></button>
          <button className="h-full text-left" onClick={() => setFilter('expired')}><StatTile label="Expired batches" value={String(inv.expiredCount)} icon={<PackageX size={18} />} tone={inv.expiredCount ? 'danger' : 'neutral'} hint="still on hand" /></button>
          {data?.totals.onHandValue != null && <StatTile label="Stock value (cost)" value={money(num(data.totals.onHandValue), cur)} icon={<Wallet size={18} />} tone="success" hint="all batches on hand" />}
        </div>
      )}

      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-[1fr_180px_200px_180px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Search products" />
          <Select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter">
            {FILTERS.map((f) => <option key={f.v} value={f.v}>{f.l}</option>)}
          </Select>
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="Category">
            <option value="">All categories</option>
            {catOpts.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </Select>
          <LocationSelect value={locationId} onChange={setLocationId} allowAll />
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(r) => r.productId}
          onRowClick={(r) => router.push(`/medicines/${r.productId}`)}
          columns={[
            {
              key: 'p', header: 'Product',
              cell: (r) => (
                <div className="min-w-0">
                  <p className="truncate font-medium">{productName(r.brandName, r.strength)}</p>
                  <p className="truncate text-xs text-fg-muted">{r.sku} · {r.categoryName}</p>
                </div>
              ),
            },
            { key: 'status', header: 'Status', cell: (r) => <Badge tone={r.status === 'OUT' ? 'danger' : r.status === 'LOW' ? 'warning' : 'success'}>{r.status === 'OK' ? 'In stock' : r.status === 'LOW' ? 'Low' : 'Out'}</Badge> },
            { key: 'sell', header: 'Sellable', align: 'right', cell: (r) => <span className="font-medium">{qty(num(r.sellable))} <span className="text-xs font-normal text-fg-muted">{r.baseUnit}</span></span> },
            { key: 'reorder', header: 'Reorder at', align: 'right', cell: (r) => (num(r.reorderLevel) > 0 ? qty(num(r.reorderLevel)) : '-') },
            { key: 'exp', header: 'Expired', align: 'right', cell: (r) => (num(r.expired) > 0 ? <span className="text-danger">{qty(num(r.expired))}</span> : '-') },
            { key: 'soon', header: 'Expiring (90d)', align: 'right', cell: (r) => (num(r.expiring) > 0 ? <span className="text-warning">{qty(num(r.expiring))}</span> : '-') },
            { key: 'next', header: 'Next expiry', cell: (r) => dateOnly(r.nextExpiry) },
            { key: 'b', header: 'Batches', align: 'right', cell: (r) => r.batches },
            ...(data?.totals.onHandValue != null ? [{ key: 'v', header: 'Value', align: 'right' as const, cell: (r: StockRow) => money(num(r.value), cur) }] : []),
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
