import {
  BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException, UnprocessableEntityException,
} from '@nestjs/common';
import type { z } from 'zod';
import type { createSaleSchema, createSalesReturnSchema, holdSaleSchema, quoteSaleSchema } from '@kynex/contracts';
import type { PaymentMethod, Prisma } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { hasPermission } from '../common/branch';
import { openSessionFor, partyBalance, recordCash } from '../common/cash';
import { dec, Decimal, money2, price4, SequenceService, sumDec, TenantInfoService, type Dec } from '../common/core';
import { claimIdempotency, storeIdempotentResponse } from '../common/idempotency';
import type { AuthContext } from '../common/request-context';
import { StockService } from '../inventory/stock.service';
import { TenantDb } from '../prisma/prisma.service';
import { PricingService, quoteView, type Priced } from './pricing';

type CreateSale = z.infer<typeof createSaleSchema>;
type QuoteSale = z.infer<typeof quoteSaleSchema>;
type HoldSale = z.infer<typeof holdSaleSchema>;
type CreateReturn = z.infer<typeof createSalesReturnSchema>;

export const SALE_SELECT = {
  id: true, invoiceNo: true, status: true, subtotal: true, discountTotal: true, taxTotal: true, roundingAdjustment: true,
  grandTotal: true, paidTotal: true, changeGiven: true, balanceDue: true, notes: true, soldAt: true, heldAt: true,
  voidedAt: true, voidReason: true, createdAt: true, registerSessionId: true,
  branch: { select: { id: true, name: true, code: true, address: true, phone: true, taxNumber: true, receiptHeader: true, receiptFooter: true } },
  location: { select: { id: true, name: true } },
  cashier: { select: { id: true, fullName: true } },
  voidedBy: { select: { id: true, fullName: true } },
  customer: { select: { id: true, fullName: true, phone: true, code: true } },
  prescription: { select: { id: true, prescriptionNumber: true, doctorName: true } },
  saleItems: {
    orderBy: { createdAt: 'asc' },
    select: {
      id: true, productName: true, sku: true, quantity: true, unitFactor: true, baseQuantity: true, unitPrice: true,
      discountAmount: true, taxPercent: true, taxAmount: true, lineTotal: true, costTotal: true, prescriptionItemId: true,
      product: { select: { id: true, baseUnit: true, requiresPrescription: true } },
      productUnit: { select: { id: true, name: true } },
      saleItemAllocations: { select: { id: true, baseQuantity: true, unitCost: true, expiryDate: true, batch: { select: { id: true, batchNumber: true } }, location: { select: { id: true } } } },
      salesReturnItems: { where: { return: { status: 'POSTED' } }, select: { quantity: true, lineTotal: true, costTotal: true } },
    },
  },
  payments: { orderBy: { paidAt: 'asc' }, select: { id: true, kind: true, method: true, amount: true, reference: true, paidAt: true } },
  salesReturns: { orderBy: { createdAt: 'asc' }, select: { id: true, number: true, total: true, refundMethod: true, returnDate: true, reason: true } },
} satisfies Prisma.SaleSelect;

@Injectable()
export class SalesService {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly stock: StockService,
    private readonly pricing: PricingService,
    private readonly sequences: SequenceService,
    private readonly tenantInfo: TenantInfoService,
  ) {}

  private async assertCustomer(tx: Prisma.TransactionClient, customerId: string | undefined) {
    if (!customerId) return null;
    const c = await tx.customer.findFirst({ where: { id: customerId, deletedAt: null }, select: { id: true, fullName: true, isActive: true, creditLimit: true } });
    if (!c) throw new BadRequestException('Customer not found');
    if (!c.isActive) throw new UnprocessableEntityException(`${c.fullName} is inactive`);
    return c;
  }

  async quote(auth: AuthContext, branchId: string, input: QuoteSale) {
    const tx = this.db.tx;
    await this.assertCustomer(tx, input.customerId);
    const tenant = await this.tenantInfo.get(tx);
    const priced = await this.pricing.price(tx, { auth, branchId, tenant, mode: 'quote' }, input);
    return quoteView(priced);
  }

  // =============================================================================================
  // Complete a sale (one transaction; see docs in the README "POS transaction")
  // =============================================================================================
  async create(auth: AuthContext, branchId: string, input: CreateSale) {
    const tx = this.db.tx;
    const { idempotencyKey, ...body } = input;
    const claim = await claimIdempotency(tx, { tenantId: auth.tenantId, userId: auth.userId, key: idempotencyKey, endpoint: 'POST /sales', body });
    if ('replay' in claim) return claim.replay;

    const tenant = await this.tenantInfo.get(tx);
    const customer = await this.assertCustomer(tx, input.customerId);
    const session = await openSessionFor(tx, branchId, auth.userId);
    if (!session && tenant.settings.requireOpenShiftForSale) throw new UnprocessableEntityException('Open a register shift before selling');
    if (session) await tx.$queryRaw`SELECT id FROM register_sessions WHERE id = ${session.id}::uuid AND status = 'OPEN' FOR SHARE`;

    if (input.heldSaleId) await this.discardHeld(tx, branchId, input.heldSaleId);

    const priced = await this.pricing.price(tx, { auth, branchId, tenant, mode: 'commit' }, input);
    if (priced.prescription && customer && priced.prescription.customerId !== customer.id) throw new BadRequestException('The prescription belongs to another customer');
    const customerId = customer?.id ?? priced.prescription?.customerId ?? null;
    const pay = await this.settle(tx, priced.grandTotal, input.payments, customerId, Boolean(session));

    const branch = await tx.branch.findFirstOrThrow({ where: { id: branchId }, select: { invoicePrefix: true } });
    const invoiceNo = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'SALE', scopeKey: branchId, prefix: branch.invoicePrefix });
    const now = new Date();
    const notes = [input.notes, priced.rxOverride ? 'Prescription confirmed by pharmacist (not recorded)' : null].filter(Boolean).join('\n') || null;

    const sale = await tx.sale.create({
      data: {
        tenantId: auth.tenantId, invoiceNo, status: 'COMPLETED', subtotal: priced.subtotal, discountTotal: priced.discountTotal,
        taxTotal: priced.taxTotal, roundingAdjustment: priced.roundingAdjustment, grandTotal: priced.grandTotal,
        paidTotal: pay.paidTotal, changeGiven: pay.change, balanceDue: pay.credit, notes, soldAt: now,
        branchId, locationId: priced.locationId, cashierId: auth.userId, customerId, prescriptionId: priced.prescription?.id ?? null,
        registerSessionId: session?.id ?? null,
        saleItems: {
          create: priced.lines.map((l) => ({
            tenantId: auth.tenantId,
            productName: [l.product.brandName, l.product.strength].filter(Boolean).join(' '),
            sku: l.product.sku, quantity: l.quantity, unitFactor: l.unit?.factor ?? dec(1), baseQuantity: l.baseQuantity,
            unitPrice: l.unitPrice, discountAmount: l.discount, taxPercent: l.taxPercent, taxAmount: l.tax, lineTotal: l.lineTotal,
            costTotal: l.cost, productId: l.product.id, productUnitId: l.unit?.id ?? null, prescriptionItemId: l.input.prescriptionItemId ?? null,
            saleItemAllocations: {
              create: l.allocations.map((a) => ({
                tenantId: auth.tenantId, baseQuantity: a.quantity, unitCost: a.unitCost,
                expiryDate: a.expiryDate ? new Date(`${a.expiryDate}T00:00:00.000Z`) : null, batchId: a.batchId, locationId: a.locationId,
              })),
            },
          })),
        },
      },
      select: { id: true },
    });

    for (const l of priced.lines) {
      for (const a of l.allocations) {
        await this.stock.applyMovement(tx, {
          tenantId: auth.tenantId, branchId, locationId: a.locationId, productId: l.product.id, batchId: a.batchId, delta: a.quantity.negated(),
          type: 'SALE', unitCost: a.unitCost, referenceType: 'sale', referenceId: sale.id, reason: invoiceNo, userId: auth.userId, occurredAt: now,
        });
      }
      if (l.input.prescriptionItemId) {
        await tx.prescriptionItem.update({ where: { id: l.input.prescriptionItemId }, data: { quantityDispensed: { increment: l.baseQuantity } } });
      }
    }
    if (priced.prescription) await this.refreshPrescriptionStatus(tx, priced.prescription.id);

    const paymentBase = { tenantId: auth.tenantId, kind: 'SALE_PAYMENT' as const, branchId, receivedById: auth.userId, registerSessionId: session?.id ?? null, saleId: sale.id, customerId, paidAt: now };
    for (const p of pay.rows) {
      await tx.payment.create({ data: { ...paymentBase, method: p.method, amount: p.amount, reference: p.reference ?? null } });
    }
    if (pay.cashApplied.gt(0) && session) {
      await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: session.id, userId: auth.userId, type: 'SALE_CASH', amount: pay.cashApplied, referenceType: 'sale', referenceId: sale.id });
    }
    if (pay.credit.gt(0) && customerId) {
      await tx.partyLedgerEntry.create({
        data: { tenantId: auth.tenantId, entryType: 'SALE_ON_CREDIT', amount: pay.credit, referenceType: 'sale', referenceId: sale.id, description: invoiceNo, branchId, customerId, createdById: auth.userId },
      });
    }
    await tx.outboxEvent.create({ data: { tenantId: auth.tenantId, topic: 'sale.completed', payload: { saleId: sale.id, branchId, productIds: priced.lines.map((l) => l.product.id) } } });

    const result = await tx.sale.findFirstOrThrow({ where: { id: sale.id }, select: SALE_SELECT });
    await this.audit.record({
      action: 'sale.completed', entityType: 'sale', entityId: sale.id,
      after: { invoiceNo, grandTotal: priced.grandTotal, discountTotal: priced.discountTotal, payments: pay.rows, rxOverride: priced.rxOverride, warnings: priced.warnings },
    });
    const response = { ...result, warnings: priced.warnings };
    await storeIdempotentResponse(tx, claim.claimed, 201, response);
    return response;
  }

  /** Validates split payments against the total. Cash may be over-tendered (change); other methods may not. */
  private async settle(
    tx: Prisma.TransactionClient,
    total: Dec,
    payments: CreateSale['payments'],
    customerId: string | null,
    hasSession: boolean,
  ) {
    const by = (m: string) => sumDec(payments.filter((p) => p.method === m).map((p) => money2(p.amount)));
    const cashTendered = by('CASH');
    const credit = by('CUSTOMER_CREDIT');
    const nonCash = sumDec(payments.filter((p) => p.method !== 'CASH').map((p) => money2(p.amount)));
    if (nonCash.gt(total)) throw new UnprocessableEntityException('Card, transfer and credit payments add up to more than the bill');
    const cashNeeded = total.minus(nonCash);
    const cashApplied = Decimal.min(cashTendered, cashNeeded);
    const change = cashTendered.minus(cashApplied);
    const short = total.minus(nonCash).minus(cashApplied);
    if (short.gt(0)) throw new UnprocessableEntityException(`Payment is short by ${short.toFixed(2)}`);
    if (cashTendered.gt(0) && !hasSession) throw new UnprocessableEntityException('Cash needs an open register shift');
    if (credit.gt(0)) {
      if (!customerId) throw new UnprocessableEntityException('Choose the customer to sell on credit');
      const c = await tx.customer.findFirstOrThrow({ where: { id: customerId }, select: { fullName: true, creditLimit: true } });
      const limit = dec(c.creditLimit);
      const balance = await partyBalance(tx, { customerId });
      if (limit.lte(0)) throw new UnprocessableEntityException(`${c.fullName} has no credit limit`);
      if (balance.plus(credit).gt(limit)) throw new UnprocessableEntityException(`${c.fullName}'s credit limit is ${limit.toFixed(2)}; balance would be ${balance.plus(credit).toFixed(2)}`);
    }
    const rows: { method: PaymentMethod; amount: Dec; reference?: string }[] = [];
    if (cashApplied.gt(0)) rows.push({ method: 'CASH', amount: cashApplied });
    for (const p of payments.filter((x) => x.method !== 'CASH')) rows.push({ method: p.method, amount: money2(p.amount), reference: p.reference });
    return { rows, cashApplied, change, credit, paidTotal: total.minus(credit) };
  }

  private async refreshPrescriptionStatus(tx: Prisma.TransactionClient, prescriptionId: string) {
    const items = await tx.prescriptionItem.findMany({ where: { prescriptionId }, select: { quantityPrescribed: true, quantityDispensed: true } });
    const anyDispensed = items.some((i) => dec(i.quantityDispensed).gt(0));
    const allDone = items.length > 0 && items.every((i) => i.quantityPrescribed !== null && dec(i.quantityDispensed).gte(i.quantityPrescribed));
    const status = allDone ? 'DISPENSED' : anyDispensed ? 'PARTIALLY_DISPENSED' : 'ACTIVE';
    await tx.prescription.update({ where: { id: prescriptionId }, data: { status } });
  }

  // =============================================================================================
  // Held bills (server-side drafts, no stock effect)
  // =============================================================================================
  private async discardHeld(tx: Prisma.TransactionClient, branchId: string, heldSaleId: string) {
    const rows = await tx.$queryRaw<{ status: string; branch_id: string }[]>`SELECT status::text AS status, branch_id FROM sales WHERE id = ${heldSaleId}::uuid FOR UPDATE`;
    if (!rows[0] || rows[0].branch_id !== branchId) throw new NotFoundException('Held bill not found in this branch');
    if (rows[0].status !== 'HELD') throw new ConflictException('That bill is no longer on hold');
    await tx.sale.delete({ where: { id: heldSaleId } });
  }

  async hold(auth: AuthContext, branchId: string, input: HoldSale) {
    const tx = this.db.tx;
    const tenant = await this.tenantInfo.get(tx);
    await this.assertCustomer(tx, input.customerId);
    if (input.heldSaleId) await this.discardHeld(tx, branchId, input.heldSaleId);
    const priced: Priced = await this.pricing.price(tx, { auth, branchId, tenant, mode: 'hold' }, input);
    const sale = await tx.sale.create({
      data: {
        tenantId: auth.tenantId, status: 'HELD', heldAt: new Date(), subtotal: priced.subtotal, discountTotal: priced.discountTotal,
        taxTotal: priced.taxTotal, roundingAdjustment: priced.roundingAdjustment, grandTotal: priced.grandTotal, notes: input.notes ?? null,
        branchId, locationId: priced.locationId, cashierId: auth.userId, customerId: input.customerId ?? null,
        saleItems: {
          create: priced.lines.map((l) => ({
            tenantId: auth.tenantId, productName: [l.product.brandName, l.product.strength].filter(Boolean).join(' '), sku: l.product.sku,
            quantity: l.quantity, unitFactor: l.unit?.factor ?? dec(1), baseQuantity: l.baseQuantity, unitPrice: l.unitPrice,
            discountAmount: l.discount, taxPercent: l.taxPercent, taxAmount: l.tax, lineTotal: l.lineTotal, productId: l.product.id,
            productUnitId: l.unit?.id ?? null,
          })),
        },
      },
      select: SALE_SELECT,
    });
    await this.audit.record({ action: 'sale.held', entityType: 'sale', entityId: sale.id, after: { grandTotal: sale.grandTotal, items: priced.lines.length } });
    return sale;
  }

  async cancelHeld(auth: AuthContext, branchId: string, id: string) {
    const tx = this.db.tx;
    const held = await tx.sale.findFirst({ where: { id, branchId, status: 'HELD' }, select: { id: true, cashierId: true, grandTotal: true } });
    if (!held) throw new NotFoundException('Held bill not found');
    await this.discardHeld(tx, branchId, id);
    await this.audit.record({ action: 'sale.held_cancelled', entityType: 'sale', entityId: id, before: held });
  }

  // =============================================================================================
  // Void: reverses a completed sale completely (stock, money, credit)
  // =============================================================================================
  async void(auth: AuthContext, branchId: string, id: string, reason: string) {
    const tx = this.db.tx;
    const locked = await tx.$queryRaw<{ status: string; branch_id: string }[]>`SELECT status::text AS status, branch_id FROM sales WHERE id = ${id}::uuid FOR UPDATE`;
    if (!locked[0] || locked[0].branch_id !== branchId) throw new NotFoundException('Sale not found in this branch');
    if (locked[0].status !== 'COMPLETED') {
      throw new ConflictException(locked[0].status === 'PARTIALLY_RETURNED' ? 'This sale has returns; process a return for the rest instead' : `A ${locked[0].status.toLowerCase()} sale cannot be voided`);
    }
    const sale = await tx.sale.findFirstOrThrow({ where: { id }, select: SALE_SELECT });
    const cashPaid = sumDec(sale.payments.filter((p) => p.kind === 'SALE_PAYMENT' && p.method === 'CASH').map((p) => dec(p.amount)));
    const session = await openSessionFor(tx, branchId, auth.userId);
    if (cashPaid.gt(0) && !session) throw new UnprocessableEntityException('Open a register shift to refund the cash');

    for (const item of sale.saleItems) {
      for (const a of item.saleItemAllocations) {
        await this.stock.applyMovement(tx, {
          tenantId: auth.tenantId, branchId, locationId: a.location.id, productId: item.product.id, batchId: a.batch.id, delta: a.baseQuantity,
          type: 'SALE_RETURN', unitCost: a.unitCost, referenceType: 'sale_void', referenceId: id, reason: `Void ${sale.invoiceNo}: ${reason}`, userId: auth.userId,
        });
      }
      if (item.prescriptionItemId) await tx.prescriptionItem.update({ where: { id: item.prescriptionItemId }, data: { quantityDispensed: { decrement: item.baseQuantity } } });
    }
    if (sale.prescription) await this.refreshPrescriptionStatus(tx, sale.prescription.id);

    for (const p of sale.payments.filter((x) => x.kind === 'SALE_PAYMENT')) {
      await tx.payment.create({
        data: {
          tenantId: auth.tenantId, kind: 'REFUND', method: p.method, amount: p.amount, reference: p.reference, note: `Void ${sale.invoiceNo}`,
          branchId, receivedById: auth.userId, registerSessionId: p.method === 'CASH' ? (session?.id ?? null) : null, saleId: id, customerId: sale.customer?.id ?? null,
        },
      });
    }
    if (cashPaid.gt(0) && session) {
      await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: session.id, userId: auth.userId, type: 'REFUND_CASH', amount: cashPaid.negated(), referenceType: 'sale_void', referenceId: id, note: sale.invoiceNo });
    }
    if (dec(sale.balanceDue).gt(0) && sale.customer) {
      await tx.partyLedgerEntry.create({
        data: { tenantId: auth.tenantId, entryType: 'RETURN_CREDIT', amount: dec(sale.balanceDue).negated(), referenceType: 'sale_void', referenceId: id, description: `Void ${sale.invoiceNo}`, branchId, customerId: sale.customer.id, createdById: auth.userId },
      });
    }
    await tx.sale.update({ where: { id }, data: { status: 'VOIDED', voidedAt: new Date(), voidedById: auth.userId, voidReason: reason } });
    const after = await tx.sale.findFirstOrThrow({ where: { id }, select: SALE_SELECT });
    await this.audit.record({ action: 'sale.voided', entityType: 'sale', entityId: id, before: { status: sale.status, grandTotal: sale.grandTotal }, after: { status: 'VOIDED', reason } });
    return after;
  }

  // =============================================================================================
  // Customer return / refund (partial or full)
  // =============================================================================================
  async createReturn(auth: AuthContext, branchId: string, saleId: string, input: CreateReturn) {
    const tx = this.db.tx;
    const { idempotencyKey, ...body } = input;
    const claim = await claimIdempotency(tx, { tenantId: auth.tenantId, userId: auth.userId, key: idempotencyKey, endpoint: `POST /sales/${saleId}/returns`, body });
    if ('replay' in claim) return claim.replay;

    const locked = await tx.$queryRaw<{ status: string; branch_id: string }[]>`SELECT status::text AS status, branch_id FROM sales WHERE id = ${saleId}::uuid FOR UPDATE`;
    if (!locked[0] || locked[0].branch_id !== branchId) throw new NotFoundException('Sale not found in this branch');
    if (!['COMPLETED', 'PARTIALLY_RETURNED'].includes(locked[0].status)) throw new ConflictException(`A ${locked[0].status.toLowerCase()} sale cannot be returned`);
    const sale = await tx.sale.findFirstOrThrow({ where: { id: saleId }, select: SALE_SELECT });
    const tenant = await this.tenantInfo.get(tx);

    if (new Set(input.items.map((i) => i.saleItemId)).size !== input.items.length) throw new BadRequestException('Each line may appear only once');
    const pieces: { saleItem: (typeof sale.saleItems)[number]; batchId: string; locationId: string; quantity: Dec; refund: Dec; cost: Dec; unitCost: Dec; restock: boolean }[] = [];
    for (const r of input.items) {
      const item = sale.saleItems.find((s) => s.id === r.saleItemId);
      if (!item) throw new BadRequestException('That line is not on this sale');
      const qty = dec(r.quantity);
      const returnedQty = sumDec(item.salesReturnItems.map((x) => dec(x.quantity)));
      const returnedAmount = sumDec(item.salesReturnItems.map((x) => dec(x.lineTotal)));
      const left = dec(item.baseQuantity).minus(returnedQty);
      if (qty.gt(left)) throw new UnprocessableEntityException(`Only ${left.toString()} ${item.product.baseUnit} of ${item.productName} can still be returned`);
      // the last units of a line refund exactly what is left of it (no rounding drift)
      const lineRefund = qty.equals(left) ? dec(item.lineTotal).minus(returnedAmount) : money2(dec(item.lineTotal).times(qty).div(item.baseQuantity));
      let refundLeft = lineRefund;

      // spread the returned quantity over the original batches (what each batch still has un-returned)
      const prior = await tx.salesReturnItem.groupBy({ by: ['batchId'], where: { saleItemId: item.id, return: { status: 'POSTED' } }, _sum: { quantity: true } });
      const priorBy = new Map(prior.map((p) => [p.batchId, dec(p._sum.quantity)]));
      let remaining = qty;
      const allocs = item.saleItemAllocations;
      for (let i = 0; i < allocs.length && remaining.gt(0); i++) {
        const a = allocs[i];
        const free = dec(a.baseQuantity).minus(priorBy.get(a.batch.id) ?? 0);
        if (free.lte(0)) continue;
        const take = Decimal.min(free, remaining);
        remaining = remaining.minus(take);
        const isLast = remaining.lte(0);
        const share = isLast ? refundLeft : money2(lineRefund.times(take).div(qty));
        refundLeft = refundLeft.minus(share);
        pieces.push({ saleItem: item, batchId: a.batch.id, locationId: a.location.id, quantity: take, refund: share, cost: money2(take.times(a.unitCost)), unitCost: dec(a.unitCost), restock: r.restock });
      }
      if (remaining.gt(0)) throw new UnprocessableEntityException(`Could not match the returned ${item.productName} to its batches`);
    }
    const total = sumDec(pieces.map((p) => p.refund));

    if (total.gte(tenant.settings.refundApprovalThreshold) && !hasPermission(auth, 'refund:approve', branchId)) {
      throw new ForbiddenException(`Refunds of ${tenant.settings.refundApprovalThreshold.toFixed(2)} or more need a manager (refund:approve)`);
    }
    const session = await openSessionFor(tx, branchId, auth.userId);
    if (input.refundMethod === 'CASH' && !session) throw new UnprocessableEntityException('Open a register shift to refund cash');
    if (input.refundMethod === 'CUSTOMER_CREDIT' && !sale.customer) throw new UnprocessableEntityException('Store credit needs a customer on the sale');

    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'SALES_RETURN', scopeKey: branchId, prefix: 'SRN' });
    const ret = await tx.salesReturn.create({
      data: {
        tenantId: auth.tenantId, number, status: 'POSTED', total, refundMethod: input.refundMethod, reason: input.reason, saleId, branchId,
        createdById: auth.userId, approvedById: hasPermission(auth, 'refund:approve', branchId) ? auth.userId : null, registerSessionId: session?.id ?? null,
        salesReturnItems: {
          create: pieces.map((p) => ({
            tenantId: auth.tenantId, quantity: p.quantity, unitPrice: price4(p.quantity.isZero() ? 0 : p.refund.div(p.quantity)), lineTotal: p.refund,
            costTotal: p.cost, restock: p.restock, saleItemId: p.saleItem.id, productId: p.saleItem.product.id, batchId: p.batchId, locationId: p.locationId,
          })),
        },
      },
      select: { id: true },
    });
    for (const p of pieces.filter((x) => x.restock)) {
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId, locationId: p.locationId, productId: p.saleItem.product.id, batchId: p.batchId, delta: p.quantity,
        type: 'SALE_RETURN', unitCost: p.unitCost, referenceType: 'sales_return', referenceId: ret.id, reason: `${number} (${sale.invoiceNo})`, userId: auth.userId,
      });
    }
    if (total.gt(0)) {
      await tx.payment.create({
        data: {
          tenantId: auth.tenantId, kind: 'REFUND', method: input.refundMethod, amount: total, note: `${number} for ${sale.invoiceNo}`, branchId,
          receivedById: auth.userId, registerSessionId: input.refundMethod === 'CASH' ? (session?.id ?? null) : null, saleId, customerId: sale.customer?.id ?? null, salesReturnId: ret.id,
        },
      });
      if (input.refundMethod === 'CASH' && session) {
        await recordCash(tx, { tenantId: auth.tenantId, branchId, registerSessionId: session.id, userId: auth.userId, type: 'REFUND_CASH', amount: total.negated(), referenceType: 'sales_return', referenceId: ret.id, note: number });
      }
      if (input.refundMethod === 'CUSTOMER_CREDIT' && sale.customer) {
        await tx.partyLedgerEntry.create({
          data: { tenantId: auth.tenantId, entryType: 'RETURN_CREDIT', amount: total.negated(), referenceType: 'sales_return', referenceId: ret.id, description: `${number} for ${sale.invoiceNo}`, branchId, customerId: sale.customer.id, createdById: auth.userId },
        });
      }
    }
    // sale status: fully returned when every base unit has come back
    const after = await tx.sale.findFirstOrThrow({ where: { id: saleId }, select: SALE_SELECT });
    const fully = after.saleItems.every((i) => sumDec(i.salesReturnItems.map((x) => dec(x.quantity))).gte(i.baseQuantity));
    await tx.sale.update({ where: { id: saleId }, data: { status: fully ? 'RETURNED' : 'PARTIALLY_RETURNED' } });

    const result = await tx.salesReturn.findFirstOrThrow({ where: { id: ret.id }, select: SALES_RETURN_SELECT });
    await this.audit.record({ action: 'sale.returned', entityType: 'sales_return', entityId: ret.id, after: { number, invoiceNo: sale.invoiceNo, total, refundMethod: input.refundMethod } });
    await storeIdempotentResponse(tx, claim.claimed, 201, result);
    return result;
  }
}

export const SALES_RETURN_SELECT = {
  id: true, number: true, status: true, returnDate: true, total: true, refundMethod: true, reason: true, createdAt: true,
  sale: { select: { id: true, invoiceNo: true, customer: { select: { id: true, fullName: true } } } },
  createdBy: { select: { id: true, fullName: true } },
  approvedBy: { select: { id: true, fullName: true } },
  salesReturnItems: {
    select: {
      id: true, quantity: true, unitPrice: true, lineTotal: true, costTotal: true, restock: true,
      saleItem: { select: { id: true, productName: true } },
      product: { select: { id: true, baseUnit: true } },
      batch: { select: { id: true, batchNumber: true } },
    },
  },
} satisfies Prisma.SalesReturnSelect;
