import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import type { CookieOptions } from 'express';
import type { Prisma } from '@kynex/database';
import { ENV, type Env } from '../config/env';
import { PrismaService, TenantDb } from '../prisma/prisma.service';
import type { AuthContext } from '../common/request-context';
import { AccessService } from './access.service';

interface SessionRow {
  id: string;
  tenant_id: string;
  user_id: string;
  last_seen_at: Date;
}

const EXPIRED = 'Your session has expired. Please log in again.';

@Injectable()
export class SessionService {
  constructor(
    @Inject(ENV) private readonly env: Env,
    private readonly prisma: PrismaService,
    private readonly db: TenantDb,
    private readonly access: AccessService,
  ) {}

  static hash(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  /** Opaque 256-bit token. Only its SHA-256 hash is stored, so a database leak cannot be replayed. */
  async create(tx: Prisma.TransactionClient, tenantId: string, userId: string, ip: string | null, userAgent: string | null) {
    const token = randomBytes(32).toString('base64url');
    const expiresAt = new Date(Date.now() + this.env.SESSION_MAX_HOURS * 3_600_000);
    const session = await tx.session.create({
      data: { tenantId, userId, tokenHash: SessionService.hash(token), ipAddress: ip, userAgent, expiresAt },
    });
    return { token, expiresAt, sessionId: session.id };
  }

  cookieOptions(): CookieOptions {
    return {
      httpOnly: true,
      secure: this.env.COOKIE_SECURE === 'auto' ? this.env.NODE_ENV === 'production' && this.env.WEB_ORIGIN.startsWith('https://') : this.env.COOKIE_SECURE === 'true',
      sameSite: 'lax',
      path: '/',
      maxAge: this.env.SESSION_MAX_HOURS * 3_600_000,
    };
  }

  /** Validates the cookie and builds the per-request AuthContext. Throws 401 on any problem. */
  async authenticate(token: string | undefined): Promise<AuthContext> {
    if (!token) throw new UnauthorizedException('Not authenticated');

    // Before the tenant is known we use SECURITY DEFINER lookups (see security.sql).
    const rows = await this.prisma.$queryRaw<SessionRow[]>`
      SELECT id, tenant_id, user_id, last_seen_at FROM auth_find_session(${SessionService.hash(token)})`;
    const session = rows[0];
    if (!session) throw new UnauthorizedException(EXPIRED);
    if (Date.now() - session.last_seen_at.getTime() > this.env.SESSION_IDLE_MINUTES * 60_000) {
      throw new UnauthorizedException(EXPIRED);
    }

    const tenants = await this.prisma.$queryRaw<{ status: string }[]>`
      SELECT status::text AS status FROM auth_find_tenant(${session.tenant_id}::uuid)`;
    if (tenants[0]?.status !== 'ACTIVE') throw new UnauthorizedException('This pharmacy account is not active');

    const auth = await this.db.run(session.tenant_id, async (tx): Promise<AuthContext | null> => {
      const user = await tx.user.findFirst({ where: { id: session.user_id, deletedAt: null } });
      if (!user || user.status !== 'ACTIVE') return null;
      const access = await this.access.load(tx, user);
      if (Date.now() - session.last_seen_at.getTime() > 60_000) {
        await tx.session.update({ where: { id: session.id }, data: { lastSeenAt: new Date() } });
      }
      return {
        userId: user.id,
        tenantId: session.tenant_id,
        sessionId: session.id,
        email: user.email,
        fullName: user.fullName,
        isOwner: user.isOwner,
        ...access,
      };
    });
    if (!auth) throw new UnauthorizedException(EXPIRED);
    return auth;
  }
}
