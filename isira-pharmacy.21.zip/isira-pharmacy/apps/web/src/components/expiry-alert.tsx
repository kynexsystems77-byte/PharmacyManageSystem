'use client';

import clsx from 'clsx';
import { AlertTriangle, CalendarClock, OctagonAlert } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { dateOnly, num, productName, qty } from '@/lib/format';
import type { ExpiryCheck, ExpiryCheckBatch } from '@/lib/types';
import { Modal } from './kit';
import { Badge, Button } from './ui';

const STATE: Record<ExpiryCheckBatch['state'], { label: string; tone: 'danger' | 'warning' | 'success' | 'neutral' }> = {
  EXPIRED: { label: 'Expired, blocked', tone: 'danger' },
  BLOCKED: { label: 'Blocked', tone: 'danger' },
  TOO_CLOSE: { label: 'Too close to sell', tone: 'danger' },
  EXPIRING: { label: 'Expiring soon', tone: 'warning' },
  OK: { label: 'OK', tone: 'success' },
};

function daysText(d: number | null): string {
  if (d === null) return 'No expiry date';
  if (d < 0) return `Expired ${-d} day${d === -1 ? '' : 's'} ago`;
  if (d === 0) return 'Expires today';
  return `${d} day${d === 1 ? '' : 's'} left`;
}

/** Short alert sound so the cashier notices the popup while scanning (ignored if the browser blocks audio). */
export function playExpiryAlert(level: 'warning' | 'danger') {
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const tones = level === 'danger' ? [880, 660, 880] : [740];
    tones.forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = f;
      o.type = 'square';
      g.gain.value = 0.05;
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + i * 0.16);
      o.stop(ctx.currentTime + i * 0.16 + 0.12);
    });
    setTimeout(() => void ctx.close(), 1000);
  } catch {
    /* audio not available */
  }
}

/** Popup shown at the POS when a scanned product's next batch is close to expiry or expired stock is on the shelf. */
export function ExpiryAlertModal({ check, onAdd, onCancel }: { check: ExpiryCheck; onAdd: () => void; onCancel: () => void }) {
  const danger = check.level === 'danger';
  const canSell = check.next !== null;
  const openedAt = useRef(Date.now());
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // ignore the Enter a barcode scanner sends right after the code
      if (e.key === 'Enter' && canSell && Date.now() - openedAt.current > 400) { e.preventDefault(); onAdd(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [canSell, onAdd]);
  const p = check.product;
  const Icon = !canSell ? OctagonAlert : danger ? AlertTriangle : CalendarClock;
  return (
    <Modal open onClose={onCancel} size="md" title={!canSell ? 'Cannot be sold' : 'Check the expiry date'}
      footer={canSell ? (
        <>
          <Button variant="outline" onClick={onCancel}>Don&apos;t add</Button>
          <Button onClick={onAdd}>Add to bill (Enter)</Button>
        </>
      ) : <Button onClick={onCancel}>OK</Button>}>
      <div className="space-y-4">
        <div className={clsx('flex items-start gap-3 rounded-xl p-4', danger || !canSell ? 'bg-danger/10 text-danger' : 'bg-warning/10 text-warning')} role="alert">
          <Icon size={28} className="mt-0.5 shrink-0" />
          <div className="min-w-0">
            <p className="text-base font-semibold">{productName(p.brandName, p.strength)}</p>
            <p className="text-sm text-fg">{check.message}</p>
          </div>
        </div>
        {check.next && (
          <div className="grid grid-cols-3 gap-3 rounded-xl border border-line p-3 text-center">
            <div><p className="text-xs text-fg-muted">Batch sold now</p><p className="font-mono text-sm font-semibold">{check.next.batchNumber}</p></div>
            <div><p className="text-xs text-fg-muted">Expiry date</p><p className="text-sm font-semibold">{dateOnly(check.next.expiryDate)}</p></div>
            <div><p className="text-xs text-fg-muted">Time left</p><p className={clsx('text-sm font-semibold', danger ? 'text-danger' : 'text-warning')}>{daysText(check.next.daysLeft)}</p></div>
          </div>
        )}
        <div className="overflow-x-auto rounded-lg border border-line">
          <table className="w-full text-sm">
            <thead className="bg-subtle text-left text-xs uppercase text-fg-muted">
              <tr><th className="px-3 py-2">Batch</th><th className="px-3 py-2">Expiry</th><th className="px-3 py-2 text-right">Qty</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody>
              {check.batches.map((b) => (
                <tr key={b.id} className={clsx('border-t border-line', b.id === check.next?.id && 'bg-brand/5')}>
                  <td className="px-3 py-2 font-mono text-xs">{b.batchNumber}{b.id === check.next?.id && <span className="ml-1 font-sans text-brand">(next)</span>}</td>
                  <td className="px-3 py-2">{dateOnly(b.expiryDate)}<span className="block text-xs text-fg-muted">{daysText(b.daysLeft)}</span></td>
                  <td className="tabular px-3 py-2 text-right">{qty(num(b.quantity))}</td>
                  <td className="px-3 py-2"><Badge tone={STATE[b.state].tone}>{STATE[b.state].label}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-fg-muted">
          Batches expiring within {check.warningDays} days are flagged. {num(check.unsellableQuantity) > 0 ? `${qty(num(check.unsellableQuantity))} ${p.baseUnit} on the shelf cannot be sold; write them off in Inventory.` : ''}
        </p>
      </div>
    </Modal>
  );
}
