import {
  BadRequestException, Body, ConflictException, Controller, ForbiddenException, Get, Module, NotFoundException, Param,
  ParseUUIDPipe, Patch, Post, Query, UnprocessableEntityException,
} from '@nestjs/common';
import { ApiCookieAuth, ApiTags } from '@nestjs/swagger';
import { createZodDto } from 'nestjs-zod';
import {
  createAdjustmentSchema, createTransferSchema, fefoPreviewQuerySchema, listAdjustmentsQuerySchema, listBatchesQuerySchema,
  listMovementsQuerySchema, listStockQuerySchema, listTransfersQuerySchema, openingStockSchema, receiveTransferSchema,
  updateBatchSchema, writeOffSchema,
} from '@kynex/contracts';
import { Prisma, type AdjustmentReason, type MovementType } from '@kynex/database';
import { AuditService } from '../audit/audit.service';
import { currentBranchId, hasPermission } from '../common/branch';
import { dec, formatDateOnly, optionalDate, parseDateOnly, SequenceService, TenantInfoService, todayIn } from '../common/core';
import { BranchScoped, CurrentAuth, RequirePermissions } from '../common/decorators';
import { paged, skipTake } from '../common/pagination';
import type { AuthContext } from '../common/request-context';
import { TenantDb } from '../prisma/prisma.service';
import { InventoryCoreModule } from './inventory-core.module';
import { StockService } from './stock.service';

class ListStockQueryDto extends createZodDto(listStockQuerySchema) {}
class ListBatchesQueryDto extends createZodDto(listBatchesQuerySchema) {}
class UpdateBatchDto extends createZodDto(updateBatchSchema) {}
class ListMovementsQueryDto extends createZodDto(listMovementsQuerySchema) {}
class OpeningStockDto extends createZodDto(openingStockSchema) {}
class CreateAdjustmentDto extends createZodDto(createAdjustmentSchema) {}
class WriteOffDto extends createZodDto(writeOffSchema) {}
class ListAdjustmentsQueryDto extends createZodDto(listAdjustmentsQuerySchema) {}
class CreateTransferDto extends createZodDto(createTransferSchema) {}
class ReceiveTransferDto extends createZodDto(receiveTransferSchema) {}
class ListTransfersQueryDto extends createZodDto(listTransfersQuerySchema) {}
class FefoPreviewQueryDto extends createZodDto(fefoPreviewQuerySchema) {}

interface StockRow {
  productId: string; sku: string; brandName: string; genericName: string | null; strength: string | null;
  dosageForm: string; baseUnit: string; categoryName: string; onHand: string; sellable: string; expired: string;
  expiring: string; nextExpiry: Date | null; batches: number; value: string; reorderLevel: string; total: number;
}

interface BatchRow {
  id: string; batchNumber: string; expiryDate: Date | null; manufactureDate: Date | null; unitCost: string;
  sellingPrice: string | null; status: string; receivedAt: Date; productId: string; brandName: string; sku: string;
  baseUnit: string; supplierName: string | null; quantity: string; daysLeft: number | null; total: number;
}

const ADJUSTMENT_SELECT = {
  id: true, number: true, reason: true, note: true, status: true, postedAt: true, createdAt: true,
  location: { select: { id: true, name: true } },
  createdBy: { select: { id: true, fullName: true } },
  stockAdjustmentItems: {
    select: {
      id: true, quantityDelta: true, unitCost: true, note: true,
      product: { select: { id: true, brandName: true, sku: true, baseUnit: true } },
      batch: { select: { id: true, batchNumber: true, expiryDate: true } },
    },
  },
} satisfies Prisma.StockAdjustmentSelect;

const TRANSFER_SELECT = {
  id: true, number: true, status: true, note: true, dispatchedAt: true, receivedAt: true, createdAt: true,
  fromBranch: { select: { id: true, name: true } }, toBranch: { select: { id: true, name: true } },
  fromLocation: { select: { id: true, name: true } }, toLocation: { select: { id: true, name: true } },
  createdBy: { select: { id: true, fullName: true } }, receivedBy: { select: { id: true, fullName: true } },
  stockTransferItems: {
    select: {
      id: true, quantity: true, receivedQuantity: true,
      product: { select: { id: true, brandName: true, sku: true, baseUnit: true } },
      batch: { select: { id: true, batchNumber: true, expiryDate: true, unitCost: true } },
    },
  },
} satisfies Prisma.StockTransferSelect;

@ApiTags('Inventory')
@ApiCookieAuth()
@Controller('inventory')
export class InventoryController {
  constructor(
    private readonly db: TenantDb,
    private readonly audit: AuditService,
    private readonly stock: StockService,
    private readonly sequences: SequenceService,
    private readonly tenantInfo: TenantInfoService,
  ) {}

  // ------------------------------------------------------------------------------------------
  // Stock overview (one row per product, this branch)
  // ------------------------------------------------------------------------------------------
  @Get('stock')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async stockOverview(@Query() q: ListStockQueryDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const { timezone } = await this.tenantInfo.get(tx);
    const today = todayIn(timezone);
    const showValue = hasPermission(auth, 'report:financial:view', branchId);
    const { skip, take } = skipTake(q.page, q.pageSize);

    const loc = q.locationId ? Prisma.sql`AND sl.location_id = ${q.locationId}::uuid` : Prisma.empty;
    const conds: Prisma.Sql[] = [Prisma.sql`p.deleted_at IS NULL AND p.is_active`];
    if (q.categoryId) conds.push(Prisma.sql`p.category_id = ${q.categoryId}::uuid`);
    if (q.search) {
      const like = `%${q.search}%`;
      conds.push(Prisma.sql`(p.brand_name ILIKE ${like} OR p.generic_name ILIKE ${like} OR p.sku ILIKE ${like} OR p.barcode = ${q.search})`);
    }
    const reorder = Prisma.sql`COALESCE(bps.reorder_level, p.reorder_level)`;
    if (q.filter === 'in_stock') conds.push(Prisma.sql`COALESCE(s.on_hand, 0) > 0`);
    if (q.filter === 'low') conds.push(Prisma.sql`${reorder} > 0 AND COALESCE(s.sellable, 0) <= ${reorder}`);
    if (q.filter === 'out') conds.push(Prisma.sql`COALESCE(s.sellable, 0) = 0`);
    if (q.filter === 'expiring') conds.push(Prisma.sql`COALESCE(s.expiring, 0) > 0`);
    if (q.filter === 'expired') conds.push(Prisma.sql`COALESCE(s.expired, 0) > 0`);

    const rows = await tx.$queryRaw<StockRow[]>`
      WITH s AS (
        SELECT sl.product_id,
               SUM(sl.quantity) AS on_hand,
               SUM(sl.quantity) FILTER (WHERE b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= ${today}::date)) AS sellable,
               SUM(sl.quantity) FILTER (WHERE b.expiry_date < ${today}::date) AS expired,
               SUM(sl.quantity) FILTER (WHERE b.expiry_date >= ${today}::date AND b.expiry_date <= ${today}::date + ${q.days}::int) AS expiring,
               MIN(b.expiry_date) FILTER (WHERE b.expiry_date >= ${today}::date) AS next_expiry,
               COUNT(DISTINCT sl.batch_id)::int AS batches,
               SUM(sl.quantity * b.unit_cost) AS value
        FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
        WHERE sl.branch_id = ${branchId}::uuid AND sl.quantity > 0 ${loc}
        GROUP BY sl.product_id)
      SELECT p.id AS "productId", p.sku, p.brand_name AS "brandName", p.generic_name AS "genericName", p.strength,
             p.dosage_form::text AS "dosageForm", p.base_unit AS "baseUnit", c.name AS "categoryName",
             COALESCE(s.on_hand, 0)::text AS "onHand", COALESCE(s.sellable, 0)::text AS sellable,
             COALESCE(s.expired, 0)::text AS expired, COALESCE(s.expiring, 0)::text AS expiring,
             s.next_expiry AS "nextExpiry", COALESCE(s.batches, 0)::int AS batches,
             ROUND(COALESCE(s.value, 0), 2)::text AS value, ${reorder}::text AS "reorderLevel",
             COUNT(*) OVER ()::int AS total
      FROM products p
      JOIN categories c ON c.id = p.category_id
      LEFT JOIN s ON s.product_id = p.id
      LEFT JOIN branch_product_settings bps ON bps.product_id = p.id AND bps.branch_id = ${branchId}::uuid
      WHERE ${Prisma.join(conds, ' AND ')}
      ORDER BY p.brand_name ASC, p.id ASC
      LIMIT ${take} OFFSET ${skip}`;

    let totals: { onHandValue: string | null; products: number } = { onHandValue: null, products: 0 };
    if (showValue) {
      const v = await tx.$queryRaw<{ value: string }[]>`
        SELECT ROUND(COALESCE(SUM(sl.quantity * b.unit_cost), 0), 2)::text AS value
        FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
        WHERE sl.branch_id = ${branchId}::uuid AND sl.quantity > 0 ${loc}`;
      totals = { onHandValue: v[0]?.value ?? '0', products: 0 };
    }
    const total = rows[0]?.total ?? 0;
    totals.products = total;
    return {
      ...paged(
        rows.map(({ total: _t, value, nextExpiry, ...r }) => {
          const reorderLevel = dec(r.reorderLevel);
          const sellable = dec(r.sellable);
          return {
            ...r,
            nextExpiry: formatDateOnly(nextExpiry),
            value: showValue ? value : null,
            status: sellable.isZero() ? 'OUT' : reorderLevel.gt(0) && sellable.lte(reorderLevel) ? 'LOW' : 'OK',
          };
        }),
        total,
        q.page,
        q.pageSize,
      ),
      today,
      totals,
    };
  }

  // ------------------------------------------------------------------------------------------
  // Batches
  // ------------------------------------------------------------------------------------------
  @Get('batches')
  @BranchScoped()
  @RequirePermissions('batch:read')
  async batches(@Query() q: ListBatchesQueryDto) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const { timezone } = await this.tenantInfo.get(tx);
    const today = todayIn(timezone);
    const { skip, take } = skipTake(q.page, q.pageSize);
    const loc = q.locationId ? Prisma.sql`AND sl.location_id = ${q.locationId}::uuid` : Prisma.empty;

    const conds: Prisma.Sql[] = [Prisma.sql`p.deleted_at IS NULL`];
    if (q.productId) conds.push(Prisma.sql`b.product_id = ${q.productId}::uuid`);
    if (q.status) conds.push(Prisma.sql`b.status = ${q.status}::batch_status`);
    if (q.inStock) conds.push(Prisma.sql`COALESCE(s.qty, 0) > 0`);
    if (q.expired) conds.push(Prisma.sql`b.expiry_date < ${today}::date`);
    if (q.expiringWithinDays !== undefined) conds.push(Prisma.sql`b.expiry_date <= ${today}::date + ${q.expiringWithinDays}::int`);
    if (q.search) {
      const like = `%${q.search}%`;
      conds.push(Prisma.sql`(b.batch_number ILIKE ${like} OR p.brand_name ILIKE ${like} OR p.sku ILIKE ${like})`);
    }
    const order =
      q.sort === 'received' ? Prisma.sql`b.received_at DESC` : q.sort === 'product' ? Prisma.sql`p.brand_name ASC, b.expiry_date ASC NULLS LAST` : Prisma.sql`b.expiry_date ASC NULLS LAST, p.brand_name ASC`;

    const rows = await tx.$queryRaw<BatchRow[]>`
      WITH s AS (
        SELECT sl.batch_id, SUM(sl.quantity) AS qty
        FROM stock_levels sl WHERE sl.branch_id = ${branchId}::uuid ${loc}
        GROUP BY sl.batch_id)
      SELECT b.id, b.batch_number AS "batchNumber", b.expiry_date AS "expiryDate", b.manufacture_date AS "manufactureDate",
             b.unit_cost::text AS "unitCost", b.selling_price::text AS "sellingPrice", b.status::text AS status,
             b.received_at AS "receivedAt", p.id AS "productId", p.brand_name AS "brandName", p.sku, p.base_unit AS "baseUnit",
             sup.name AS "supplierName", COALESCE(s.qty, 0)::text AS quantity,
             CASE WHEN b.expiry_date IS NULL THEN NULL ELSE (b.expiry_date - ${today}::date)::int END AS "daysLeft",
             COUNT(*) OVER ()::int AS total
      FROM batches b
      JOIN products p ON p.id = b.product_id
      LEFT JOIN suppliers sup ON sup.id = b.supplier_id
      LEFT JOIN s ON s.batch_id = b.id
      WHERE ${Prisma.join(conds, ' AND ')}
      ORDER BY ${order}, b.id
      LIMIT ${take} OFFSET ${skip}`;

    return {
      ...paged(
        rows.map(({ total: _t, expiryDate, manufactureDate, ...r }) => ({
          ...r,
          expiryDate: formatDateOnly(expiryDate),
          manufactureDate: formatDateOnly(manufactureDate),
          sellable: r.status === 'ACTIVE' && (r.daysLeft === null || r.daysLeft >= 0),
        })),
        rows[0]?.total ?? 0,
        q.page,
        q.pageSize,
      ),
      today,
    };
  }

  @Get('batches/:id')
  @BranchScoped()
  @RequirePermissions('batch:read')
  async batch(@Param('id', ParseUUIDPipe) id: string) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const batch = await tx.batch.findFirst({
      where: { id },
      include: {
        product: { select: { id: true, brandName: true, sku: true, baseUnit: true, genericName: true, strength: true } },
        supplier: { select: { id: true, name: true } },
      },
    });
    if (!batch) throw new NotFoundException('Batch not found');
    const levels = await tx.stockLevel.findMany({
      where: { batchId: id, branchId },
      select: { quantity: true, location: { select: { id: true, name: true, type: true } } },
    });
    const movements = await tx.inventoryMovement.findMany({
      where: { batchId: id, branchId },
      orderBy: { occurredAt: 'desc' },
      take: 50,
      select: {
        id: true, movementType: true, quantityDelta: true, unitCost: true, referenceType: true, referenceId: true, reason: true, occurredAt: true,
        location: { select: { name: true } }, createdBy: { select: { fullName: true } },
      },
    });
    return {
      ...batch,
      expiryDate: formatDateOnly(batch.expiryDate),
      manufactureDate: formatDateOnly(batch.manufactureDate),
      levels,
      movements,
    };
  }

  @Patch('batches/:id')
  @BranchScoped()
  @RequirePermissions('inventory:adjust')
  async updateBatch(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateBatchDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const before = await tx.batch.findFirst({ where: { id } });
    if (!before) throw new NotFoundException('Batch not found');
    if (dto.sellingPrice !== undefined && !hasPermission(auth, 'product:price:update', currentBranchId())) {
      throw new ForbiddenException('Missing permission: product:price:update');
    }
    const expiryDate = optionalDate(dto.expiryDate);
    const manufactureDate = optionalDate(dto.manufactureDate);
    const exp = expiryDate === undefined ? before.expiryDate : expiryDate;
    const mfg = manufactureDate === undefined ? before.manufactureDate : manufactureDate;
    if (exp && mfg && mfg > exp) throw new BadRequestException('Manufacture date must be before the expiry date');
    const after = await tx.batch.update({
      where: { id },
      data: {
        status: dto.status,
        sellingPrice: dto.sellingPrice === undefined ? undefined : dto.sellingPrice === null ? null : dec(dto.sellingPrice),
        expiryDate,
        manufactureDate,
        notes: dto.notes,
      },
    });
    const action = dto.status && dto.status !== before.status ? `batch.${dto.status.toLowerCase()}` : 'batch.updated';
    await this.audit.record({ action, entityType: 'batch', entityId: id, before, after });
    return { ...after, expiryDate: formatDateOnly(after.expiryDate), manufactureDate: formatDateOnly(after.manufactureDate) };
  }

  // ------------------------------------------------------------------------------------------
  // Stock ledger (append-only)
  // ------------------------------------------------------------------------------------------
  @Get('movements')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async movements(@Query() q: ListMovementsQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.InventoryMovementWhereInput = {
      branchId: currentBranchId(),
      ...(q.productId ? { productId: q.productId } : {}),
      ...(q.batchId ? { batchId: q.batchId } : {}),
      ...(q.locationId ? { locationId: q.locationId } : {}),
      ...(q.type ? { movementType: q.type } : {}),
      ...(q.from || q.to ? { occurredAt: { ...(q.from ? { gte: q.from } : {}), ...(q.to ? { lte: q.to } : {}) } } : {}),
      ...(q.search
        ? { OR: [{ product: { brandName: { contains: q.search, mode: 'insensitive' } } }, { batch: { batchNumber: { contains: q.search, mode: 'insensitive' } } }] }
        : {}),
    };
    const [rows, total] = await Promise.all([
      tx.inventoryMovement.findMany({
        where,
        orderBy: [{ occurredAt: 'desc' }, { id: 'desc' }],
        ...skipTake(q.page, q.pageSize),
        select: {
          id: true, movementType: true, quantityDelta: true, unitCost: true, referenceType: true, referenceId: true,
          reason: true, occurredAt: true,
          product: { select: { id: true, brandName: true, sku: true, baseUnit: true } },
          batch: { select: { id: true, batchNumber: true, expiryDate: true } },
          location: { select: { id: true, name: true } },
          createdBy: { select: { id: true, fullName: true } },
        },
      }),
      tx.inventoryMovement.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  // ------------------------------------------------------------------------------------------
  // FEFO preview: which batches a sale of N units would use right now
  // ------------------------------------------------------------------------------------------
  @Get('fefo')
  @BranchScoped()
  @RequirePermissions('batch:read')
  async fefo(@Query() q: FefoPreviewQueryDto) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const { timezone, settings } = await this.tenantInfo.get(tx);
    const location = q.locationId ? await this.stock.assertLocation(tx, branchId, q.locationId) : await this.stock.defaultLocation(tx, branchId);
    const product = await tx.product.findFirst({ where: { id: q.productId, deletedAt: null }, select: { id: true, brandName: true, baseUnit: true } });
    if (!product) throw new NotFoundException('Product not found');
    const { allocations, shortfall } = await this.stock.allocateFefo(tx, {
      locationId: location.id, productId: product.id, quantity: q.quantity, timezone, minDaysToExpiry: settings.minDaysToExpiryForSale,
    });
    return {
      product,
      location,
      requested: String(q.quantity),
      minDaysToExpiryForSale: settings.minDaysToExpiryForSale,
      allocations: allocations.map((a) => ({ ...a, unitCost: a.unitCost.toString(), sellingPrice: a.sellingPrice?.toString() ?? null, quantity: a.quantity.toString() })),
      shortfall: shortfall.toString(),
      fulfilled: shortfall.isZero(),
    };
  }

  // ------------------------------------------------------------------------------------------
  // Opening stock (stock that did not come through a purchase)
  // ------------------------------------------------------------------------------------------
  @Post('opening-stock')
  @BranchScoped()
  @RequirePermissions('inventory:adjust')
  async openingStock(@Body() dto: OpeningStockDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    await this.stock.assertLocation(tx, branchId, dto.locationId);
    const product = await tx.product.findFirst({ where: { id: dto.productId, deletedAt: null }, select: { id: true, trackExpiry: true, brandName: true } });
    if (!product) throw new NotFoundException('Product not found');
    if (product.trackExpiry && !dto.expiryDate) throw new BadRequestException(`${product.brandName} tracks expiry: an expiry date is required`);
    const expiryDate = optionalDate(dto.expiryDate) ?? null;
    const manufactureDate = optionalDate(dto.manufactureDate) ?? null;
    if (expiryDate && manufactureDate && manufactureDate > expiryDate) throw new BadRequestException('Manufacture date must be before the expiry date');

    let batch = await tx.batch.findFirst({ where: { productId: product.id, batchNumber: dto.batchNumber } });
    if (batch) {
      if (formatDateOnly(batch.expiryDate) !== formatDateOnly(expiryDate)) {
        throw new ConflictException(`Batch ${dto.batchNumber} already exists with expiry ${formatDateOnly(batch.expiryDate) ?? 'none'}`);
      }
    } else {
      batch = await tx.batch.create({
        data: {
          tenantId: auth.tenantId, productId: product.id, batchNumber: dto.batchNumber, expiryDate, manufactureDate,
          unitCost: dec(dto.unitCost), sellingPrice: dto.sellingPrice == null ? null : dec(dto.sellingPrice),
        },
      });
    }
    const { movementId, balance } = await this.stock.applyMovement(tx, {
      tenantId: auth.tenantId, branchId, locationId: dto.locationId, productId: product.id, batchId: batch.id,
      delta: dto.quantity, type: 'OPENING_BALANCE', unitCost: dto.unitCost, referenceType: 'opening_stock', reason: dto.note ?? null, userId: auth.userId,
    });
    await this.audit.record({ action: 'stock.opening_balance', entityType: 'batch', entityId: batch.id, after: { movementId, quantity: dto.quantity, locationId: dto.locationId } });
    return { batchId: batch.id, movementId, balance: balance.toString() };
  }

  // ------------------------------------------------------------------------------------------
  // Adjustments and write-offs
  // ------------------------------------------------------------------------------------------
  private async postAdjustment(
    auth: AuthContext,
    input: { locationId: string; reason: AdjustmentReason; note?: string; items: { batchId: string; delta: number; note?: string }[]; movementTypeOut?: MovementType },
  ) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    await this.stock.assertLocation(tx, branchId, input.locationId);
    const batchIds = [...new Set(input.items.map((i) => i.batchId))];
    if (batchIds.length !== input.items.length) throw new BadRequestException('Each batch may appear only once');
    const batches = await tx.batch.findMany({ where: { id: { in: batchIds } }, select: { id: true, productId: true, unitCost: true, batchNumber: true, expiryDate: true } });
    if (batches.length !== batchIds.length) throw new BadRequestException('Unknown batch');
    const byId = new Map(batches.map((b) => [b.id, b]));

    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'ADJUSTMENT', scopeKey: branchId, prefix: 'ADJ' });
    const doc = await tx.stockAdjustment.create({
      data: {
        tenantId: auth.tenantId, number, reason: input.reason, note: input.note ?? null, status: 'POSTED', postedAt: new Date(),
        branchId, locationId: input.locationId, createdById: auth.userId, approvedById: auth.userId,
        stockAdjustmentItems: {
          create: input.items.map((i) => {
            const b = byId.get(i.batchId)!;
            return { tenantId: auth.tenantId, quantityDelta: dec(i.delta), unitCost: b.unitCost, note: i.note ?? null, productId: b.productId, batchId: b.id };
          }),
        },
      },
      select: { id: true },
    });
    for (const i of input.items) {
      const b = byId.get(i.batchId)!;
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId, locationId: input.locationId, productId: b.productId, batchId: b.id, delta: i.delta,
        type: i.delta > 0 ? 'ADJUSTMENT_IN' : (input.movementTypeOut ?? 'ADJUSTMENT_OUT'),
        unitCost: b.unitCost, referenceType: 'stock_adjustment', referenceId: doc.id, reason: i.note ?? input.note ?? input.reason, userId: auth.userId,
      });
    }
    return tx.stockAdjustment.findFirstOrThrow({ where: { id: doc.id }, select: ADJUSTMENT_SELECT });
  }

  @Post('adjustments')
  @BranchScoped()
  @RequirePermissions('inventory:adjust')
  async createAdjustment(@Body() dto: CreateAdjustmentDto, @CurrentAuth() auth: AuthContext) {
    const doc = await this.postAdjustment(auth, {
      locationId: dto.locationId, reason: dto.reason, note: dto.note,
      items: dto.items.map((i) => ({ batchId: i.batchId, delta: i.quantityDelta, note: i.note })),
    });
    await this.audit.record({ action: 'stock.adjusted', entityType: 'stock_adjustment', entityId: doc.id, after: doc });
    return doc;
  }

  @Post('write-offs')
  @BranchScoped()
  @RequirePermissions('inventory:writeoff')
  async writeOff(@Body() dto: WriteOffDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const { timezone } = await this.tenantInfo.get(tx);
    const today = parseDateOnly(todayIn(timezone));
    if (dto.reason === 'EXPIRED') {
      const notExpired = await tx.batch.findFirst({
        where: { id: { in: dto.items.map((i) => i.batchId) }, OR: [{ expiryDate: null }, { expiryDate: { gte: today } }] },
        select: { batchNumber: true },
      });
      if (notExpired) throw new UnprocessableEntityException(`Batch ${notExpired.batchNumber} has not expired yet. Use reason DAMAGED or a stock adjustment.`);
    }
    const doc = await this.postAdjustment(auth, {
      locationId: dto.locationId, reason: dto.reason, note: dto.note,
      items: dto.items.map((i) => ({ batchId: i.batchId, delta: -i.quantity })),
      movementTypeOut: dto.reason === 'EXPIRED' ? 'EXPIRED_WRITE_OFF' : 'DAMAGE',
    });
    // An expired batch with no stock left anywhere is closed.
    if (dto.reason === 'EXPIRED') {
      for (const i of dto.items) {
        const left = await tx.stockLevel.aggregate({ where: { batchId: i.batchId }, _sum: { quantity: true } });
        if (dec(left._sum.quantity).isZero()) await tx.batch.update({ where: { id: i.batchId }, data: { status: 'EXPIRED' } });
      }
    }
    await this.audit.record({ action: 'stock.written_off', entityType: 'stock_adjustment', entityId: doc.id, after: doc });
    return doc;
  }

  @Get('adjustments')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async adjustments(@Query() q: ListAdjustmentsQueryDto) {
    const tx = this.db.tx;
    const where: Prisma.StockAdjustmentWhereInput = {
      branchId: currentBranchId(),
      ...(q.reason ? { reason: q.reason } : {}),
      ...(q.from || q.to ? { createdAt: { ...(q.from ? { gte: q.from } : {}), ...(q.to ? { lte: q.to } : {}) } } : {}),
      ...(q.search ? { number: { contains: q.search, mode: 'insensitive' } } : {}),
    };
    const [rows, total] = await Promise.all([
      tx.stockAdjustment.findMany({ where, orderBy: { createdAt: 'desc' }, select: ADJUSTMENT_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.stockAdjustment.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get('adjustments/:id')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async adjustment(@Param('id', ParseUUIDPipe) id: string) {
    const doc = await this.db.tx.stockAdjustment.findFirst({ where: { id, branchId: currentBranchId() }, select: ADJUSTMENT_SELECT });
    if (!doc) throw new NotFoundException('Adjustment not found');
    return doc;
  }

  // ------------------------------------------------------------------------------------------
  // Transfers between branches / locations: dispatch (stock leaves) -> receive (stock arrives)
  // ------------------------------------------------------------------------------------------
  @Post('transfers')
  @BranchScoped()
  @RequirePermissions('inventory:transfer')
  async createTransfer(@Body() dto: CreateTransferDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const fromBranchId = currentBranchId();
    await this.stock.assertLocation(tx, fromBranchId, dto.fromLocationId);
    const toBranch = await tx.branch.findFirst({ where: { id: dto.toBranchId, deletedAt: null, isActive: true }, select: { id: true } });
    if (!toBranch) throw new BadRequestException('Destination branch not found');
    const toLocationId = dto.toLocationId
      ? (await this.stock.assertLocation(tx, dto.toBranchId, dto.toLocationId)).id
      : (await this.stock.defaultLocation(tx, dto.toBranchId)).id;
    if (dto.fromLocationId === toLocationId) throw new BadRequestException('Source and destination are the same location');
    const batchIds = [...new Set(dto.items.map((i) => i.batchId))];
    if (batchIds.length !== dto.items.length) throw new BadRequestException('Each batch may appear only once');
    const batches = await tx.batch.findMany({ where: { id: { in: batchIds } }, select: { id: true, productId: true, unitCost: true } });
    if (batches.length !== batchIds.length) throw new BadRequestException('Unknown batch');
    const byId = new Map(batches.map((b) => [b.id, b]));

    const number = await this.sequences.next(tx, { tenantId: auth.tenantId, docType: 'TRANSFER', scopeKey: 'tenant', prefix: 'TRF' });
    const transfer = await tx.stockTransfer.create({
      data: {
        tenantId: auth.tenantId, number, status: 'DISPATCHED', note: dto.note ?? null, dispatchedAt: new Date(),
        fromBranchId, toBranchId: dto.toBranchId, fromLocationId: dto.fromLocationId, toLocationId, createdById: auth.userId,
        stockTransferItems: {
          create: dto.items.map((i) => ({ tenantId: auth.tenantId, quantity: dec(i.quantity), productId: byId.get(i.batchId)!.productId, batchId: i.batchId })),
        },
      },
      select: { id: true },
    });
    for (const i of dto.items) {
      const b = byId.get(i.batchId)!;
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId: fromBranchId, locationId: dto.fromLocationId, productId: b.productId, batchId: b.id,
        delta: -i.quantity, type: 'TRANSFER_OUT', unitCost: b.unitCost, referenceType: 'stock_transfer', referenceId: transfer.id, reason: number, userId: auth.userId,
      });
    }
    const doc = await tx.stockTransfer.findFirstOrThrow({ where: { id: transfer.id }, select: TRANSFER_SELECT });
    await this.audit.record({ action: 'transfer.dispatched', entityType: 'stock_transfer', entityId: transfer.id, after: doc });
    return doc;
  }

  /** Every active branch (and its locations) that stock can be sent to; branch:read is not required for this. */
  @Get('transfer-destinations')
  @BranchScoped()
  @RequirePermissions('inventory:transfer')
  transferDestinations() {
    return this.db.tx.branch.findMany({
      where: { deletedAt: null, isActive: true },
      orderBy: { name: 'asc' },
      select: { id: true, name: true, code: true, locations: { where: { isActive: true }, select: { id: true, name: true, type: true, isDefault: true } } },
    });
  }

  @Get('transfers')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async transfers(@Query() q: ListTransfersQueryDto) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const dir: Prisma.StockTransferWhereInput =
      q.direction === 'outgoing' ? { fromBranchId: branchId } : q.direction === 'incoming' ? { toBranchId: branchId } : { OR: [{ fromBranchId: branchId }, { toBranchId: branchId }] };
    const where: Prisma.StockTransferWhereInput = {
      AND: [dir, q.status ? { status: q.status } : {}, q.search ? { number: { contains: q.search, mode: 'insensitive' } } : {}],
    };
    const [rows, total] = await Promise.all([
      tx.stockTransfer.findMany({ where, orderBy: { createdAt: 'desc' }, select: TRANSFER_SELECT, ...skipTake(q.page, q.pageSize) }),
      tx.stockTransfer.count({ where }),
    ]);
    return paged(rows, total, q.page, q.pageSize);
  }

  @Get('transfers/:id')
  @BranchScoped()
  @RequirePermissions('inventory:read')
  async transfer(@Param('id', ParseUUIDPipe) id: string) {
    const branchId = currentBranchId();
    const doc = await this.db.tx.stockTransfer.findFirst({ where: { id, OR: [{ fromBranchId: branchId }, { toBranchId: branchId }] }, select: TRANSFER_SELECT });
    if (!doc) throw new NotFoundException('Transfer not found');
    return doc;
  }

  /** Called from the DESTINATION branch (X-Branch-Id = toBranch). */
  @Post('transfers/:id/receive')
  @BranchScoped()
  @RequirePermissions('inventory:transfer')
  async receiveTransfer(@Param('id', ParseUUIDPipe) id: string, @Body() dto: ReceiveTransferDto, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    // lock the transfer row so it cannot be received or cancelled twice concurrently
    const locked = await tx.$queryRaw<{ id: string; status: string; to_branch_id: string }[]>`
      SELECT id, status::text AS status, to_branch_id FROM stock_transfers WHERE id = ${id}::uuid FOR UPDATE`;
    const t = locked[0];
    if (!t || t.to_branch_id !== branchId) throw new NotFoundException('Incoming transfer not found for this branch');
    if (t.status !== 'DISPATCHED') throw new ConflictException(`Transfer is ${t.status.toLowerCase()}, not awaiting receipt`);
    const doc = await tx.stockTransfer.findFirstOrThrow({ where: { id }, select: TRANSFER_SELECT });
    const overrides = new Map(dto.items.map((i) => [i.itemId, i.receivedQuantity]));
    for (const itemId of overrides.keys()) {
      if (!doc.stockTransferItems.some((i) => i.id === itemId)) throw new BadRequestException('Unknown transfer item');
    }
    for (const item of doc.stockTransferItems) {
      const received = overrides.has(item.id) ? dec(overrides.get(item.id)!) : dec(item.quantity);
      if (received.gt(item.quantity)) throw new BadRequestException(`Cannot receive more than was sent (${item.product.brandName})`);
      await tx.stockTransferItem.update({ where: { id: item.id }, data: { receivedQuantity: received } });
      if (received.gt(0)) {
        await this.stock.applyMovement(tx, {
          tenantId: auth.tenantId, branchId, locationId: doc.toLocation.id, productId: item.product.id, batchId: item.batch.id,
          delta: received, type: 'TRANSFER_IN', unitCost: item.batch.unitCost, referenceType: 'stock_transfer', referenceId: id,
          reason: dto.note ?? doc.number, userId: auth.userId,
        });
      }
    }
    await tx.stockTransfer.update({ where: { id }, data: { status: 'RECEIVED', receivedAt: new Date(), receivedById: auth.userId } });
    const after = await tx.stockTransfer.findFirstOrThrow({ where: { id }, select: TRANSFER_SELECT });
    await this.audit.record({ action: 'transfer.received', entityType: 'stock_transfer', entityId: id, before: doc, after });
    return after;
  }

  /** Called from the SOURCE branch while the goods are still in transit: stock goes back to the source location. */
  @Post('transfers/:id/cancel')
  @BranchScoped()
  @RequirePermissions('inventory:transfer')
  async cancelTransfer(@Param('id', ParseUUIDPipe) id: string, @CurrentAuth() auth: AuthContext) {
    const tx = this.db.tx;
    const branchId = currentBranchId();
    const locked = await tx.$queryRaw<{ id: string; status: string; from_branch_id: string }[]>`
      SELECT id, status::text AS status, from_branch_id FROM stock_transfers WHERE id = ${id}::uuid FOR UPDATE`;
    const t = locked[0];
    if (!t || t.from_branch_id !== branchId) throw new NotFoundException('Outgoing transfer not found for this branch');
    if (t.status !== 'DISPATCHED') throw new ConflictException(`Only a dispatched transfer can be cancelled (it is ${t.status.toLowerCase()})`);
    const doc = await tx.stockTransfer.findFirstOrThrow({ where: { id }, select: TRANSFER_SELECT });
    for (const item of doc.stockTransferItems) {
      await this.stock.applyMovement(tx, {
        tenantId: auth.tenantId, branchId, locationId: doc.fromLocation.id, productId: item.product.id, batchId: item.batch.id,
        delta: item.quantity, type: 'TRANSFER_IN', unitCost: item.batch.unitCost, referenceType: 'stock_transfer', referenceId: id,
        reason: `${doc.number} cancelled`, userId: auth.userId,
      });
    }
    await tx.stockTransfer.update({ where: { id }, data: { status: 'CANCELLED' } });
    const after = await tx.stockTransfer.findFirstOrThrow({ where: { id }, select: TRANSFER_SELECT });
    await this.audit.record({ action: 'transfer.cancelled', entityType: 'stock_transfer', entityId: id, before: doc, after });
    return after;
  }
}

@Module({ imports: [InventoryCoreModule], controllers: [InventoryController] })
export class InventoryModule {}
