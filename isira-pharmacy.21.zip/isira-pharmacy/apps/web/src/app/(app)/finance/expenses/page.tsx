'use client';

import { Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { EXPENSE_METHODS } from '@kynex/contracts';
import { ConfirmDialog, DataTable, Modal, PageHeader, Pagination, SearchBox, Select, useToast } from '@/components/kit';
import { preset, RangePicker, type DateRange } from '@/components/range-picker';
import { Alert, Badge, Button, Card, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, titleCase, todayIso } from '@/lib/format';
import { errorMessage, qs, useApiMutation, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Expense } from '@/lib/types';

export default function ExpensesPage() {
  const { can, profile } = useAuth();
  const toast = useToast();
  const fmt = (v: string | number) => money(num(v), profile.tenant.currencyCode);
  const [range, setRange] = useState<DateRange>(() => preset('month'));
  const [categoryId, setCategoryId] = useState('');
  const [search, setSearch] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([range, categoryId, s]);
  const cats = useBranchQuery<{ id: string; name: string }[]>('/expense-categories');
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Expense> & { totalAmount: string }>(`/expenses${qs({ page, pageSize: 25, ...range, categoryId, search: s })}`, { keepPrevious: true });
  const [form, setForm] = useState<{ categoryId: string; amount: string; paymentMethod: string; description: string; expenseDate: string; reference: string; fromRegister: boolean } | null>(null);
  const [toDelete, setToDelete] = useState<Expense | null>(null);
  const [newCat, setNewCat] = useState('');
  const create = useApiMutation<object>('POST', '/expenses', { onSuccess: () => { toast.success('Expense recorded'); setForm(null); } });
  const createCat = useApiMutation<object, { id: string }>('POST', '/expense-categories', { onSuccess: (c) => { setNewCat(''); setForm((f) => (f ? { ...f, categoryId: c.id } : f)); } });
  const remove = useApiMutation<string>('DELETE', (id) => `/expenses/${id}`, { onSuccess: () => { toast.success('Expense deleted'); setToDelete(null); } });
  return (
    <div className="space-y-4">
      <PageHeader
        title="Expenses"
        subtitle={data ? `${fmt(data.totalAmount)} in this period` : undefined}
        actions={<><RangePicker value={range} onChange={setRange} />{can('expense:manage') && <Button onClick={() => setForm({ categoryId: cats.data?.[0]?.id ?? '', amount: '', paymentMethod: 'CASH', description: '', expenseDate: todayIso(), reference: '', fromRegister: false })}><Plus size={16} /> Add expense</Button>}</>}
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_220px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Description or reference" />
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="Category"><option value="">All categories</option>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(e) => e.id}
          columns={[
            { key: 'd', header: 'Date', cell: (e) => dateOnly(e.expenseDate) },
            { key: 'c', header: 'Category', cell: (e) => e.category.name },
            { key: 'x', header: 'Description', cell: (e) => <div><p>{e.description}</p>{e.reference && <p className="text-xs text-fg-muted">Ref {e.reference}</p>}</div> },
            { key: 'm', header: 'Paid by', cell: (e) => <span className="flex items-center gap-2">{titleCase(e.paymentMethod)}{e.registerSessionId && <Badge>Drawer</Badge>}</span> },
            { key: 'u', header: 'By', cell: (e) => e.createdBy.fullName },
            { key: 'a', header: 'Amount', align: 'right', cell: (e) => <span className="font-medium">{fmt(e.amount)}</span> },
            ...(can('expense:manage') ? [{ key: 'del', header: '', cell: (e: Expense) => <button aria-label="Delete" onClick={() => setToDelete(e)} className="grid h-8 w-8 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={15} /></button> }] : []),
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
      <Modal open={Boolean(form)} onClose={() => setForm(null)} title="Add expense"
        footer={<><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button loading={create.isPending} disabled={!form?.categoryId || !(num(form?.amount) > 0) || (form?.description.trim().length ?? 0) < 2} onClick={() => form && create.mutate({ ...form, amount: num(form.amount), description: form.description.trim(), reference: form.reference.trim() || undefined })}>Save</Button></>}>
        {form && (
          <div className="grid gap-3 sm:grid-cols-2">
            {create.error && <div className="sm:col-span-2"><Alert>{errorMessage(create.error)}</Alert></div>}
            <Field label="Category">
              <Select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
            </Field>
            <Field label="Or add a category">
              <div className="flex gap-1"><Input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="New category" /><Button variant="outline" disabled={newCat.trim().length < 2} loading={createCat.isPending} onClick={() => createCat.mutate({ name: newCat.trim() })}>Add</Button></div>
            </Field>
            <Field label="Amount"><Input type="number" min="0.01" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} autoFocus /></Field>
            <Field label="Date"><Input type="date" value={form.expenseDate} onChange={(e) => setForm({ ...form, expenseDate: e.target.value })} /></Field>
            <div className="sm:col-span-2"><Field label="Description"><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Electricity bill, cleaning, courier…" /></Field></div>
            <Field label="Paid by"><Select value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value, fromRegister: e.target.value === 'CASH' && form.fromRegister })}>{EXPENSE_METHODS.map((m) => <option key={m} value={m}>{titleCase(m)}</option>)}</Select></Field>
            <Field label="Reference"><Input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} /></Field>
            {form.paymentMethod === 'CASH' && <label className="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" checked={form.fromRegister} onChange={(e) => setForm({ ...form, fromRegister: e.target.checked })} /> Paid from my register drawer (lowers the shift&apos;s expected cash)</label>}
          </div>
        )}
      </Modal>
      <ConfirmDialog open={Boolean(toDelete)} title="Delete expense?" danger confirmLabel="Delete" loading={remove.isPending} onClose={() => setToDelete(null)} onConfirm={() => toDelete && remove.mutate(toDelete.id, { onError: (e) => { toast.error(errorMessage(e)); setToDelete(null); } })} body={<p>{toDelete?.registerSessionId ? 'The cash goes back into the shift it was paid from (only while that shift is open).' : 'This removes the expense from the reports.'}</p>} />
    </div>
  );
}
