import { Suspense, type ReactNode } from 'react';
import { AppShell } from '@/components/app-shell';
import { ToastProvider } from '@/components/kit';
import { AuthGate } from '@/lib/auth';

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <AuthGate>
      <ToastProvider>
        <AppShell>
          {/* Pages may read URL search params (useSearchParams), which needs a Suspense boundary. */}
          <Suspense fallback={null}>{children}</Suspense>
        </AppShell>
      </ToastProvider>
    </AuthGate>
  );
}
