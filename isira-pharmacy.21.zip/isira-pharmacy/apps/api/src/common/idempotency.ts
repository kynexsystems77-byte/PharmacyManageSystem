import { createHash } from 'node:crypto';
import { UnprocessableEntityException } from '@nestjs/common';
import type { Prisma } from '@kynex/database';
import { uuidv7 } from './core';

/**
 * Idempotent writes (POS sale, returns). The key row is inserted INSIDE the business transaction:
 *  - first request: the insert succeeds, the work runs, the response is stored, everything commits together;
 *  - a retry after commit: the insert finds the row and the stored response is returned (no second invoice);
 *  - a concurrent duplicate: its insert waits on the unique index until the first commits, then replays;
 *  - if the first request fails, its key row rolls back too, so the client can simply retry.
 */
export async function claimIdempotency(
  tx: Prisma.TransactionClient,
  opts: { tenantId: string; userId: string; key: string; endpoint: string; body: unknown },
): Promise<{ replay: unknown } | { claimed: string }> {
  const hash = createHash('sha256').update(JSON.stringify(opts.body ?? null)).digest('hex');
  const inserted = await tx.$queryRaw<{ id: string }[]>`
    INSERT INTO idempotency_keys (id, tenant_id, key, endpoint, request_hash, expires_at, user_id, created_at)
    VALUES (${uuidv7()}::uuid, ${opts.tenantId}::uuid, ${opts.key}, ${opts.endpoint}, ${hash}, now() + interval '7 days', ${opts.userId}::uuid, now())
    ON CONFLICT (tenant_id, key, endpoint) DO NOTHING
    RETURNING id`;
  if (inserted[0]) return { claimed: inserted[0].id };
  const existing = await tx.idempotencyKey.findFirst({ where: { key: opts.key, endpoint: opts.endpoint }, select: { requestHash: true, responseBody: true } });
  if (!existing || existing.responseBody === null) {
    throw new UnprocessableEntityException('This request is still being processed. Try again in a moment.');
  }
  if (existing.requestHash !== hash) {
    throw new UnprocessableEntityException('This idempotency key was already used for a different request');
  }
  return { replay: existing.responseBody };
}

export async function storeIdempotentResponse(tx: Prisma.TransactionClient, id: string, status: number, body: unknown): Promise<void> {
  await tx.idempotencyKey.update({
    where: { id },
    data: { responseStatus: status, responseBody: JSON.parse(JSON.stringify(body)) as Prisma.InputJsonValue },
  });
}
