'use client';

import { useQueryClient } from '@tanstack/react-query';
import { Pill, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState, type FormEvent } from 'react';
import { Alert, Button, Card, Field, Input } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import type { MfaChallenge, Profile } from '@/lib/types';
import { APP_NAME } from '@/lib/brand';

function safeNext(value: string | null): string {
  return value && value.startsWith('/') && !value.startsWith('//') ? value : '/';
}

function LoginForm() {
  const router = useRouter();
  const qc = useQueryClient();
  const params = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [challenge, setChallenge] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [useRecovery, setUseRecovery] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function finish(profile: Profile) {
    qc.clear();
    qc.setQueryData(['me'], profile);
    router.replace(safeNext(params.get('next')));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (challenge) {
        finish(await api<Profile>('/auth/login/mfa', { method: 'POST', body: { challenge, code } }));
        return;
      }
      const res = await api<Profile | MfaChallenge>('/auth/login', { method: 'POST', body: { email, password } });
      if ('mfaRequired' in res && res.mfaRequired) {
        setChallenge(res.challenge);
        setPassword('');
        setBusy(false);
        return;
      }
      finish(res as Profile);
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Something went wrong. Please try again.';
      if (challenge && err instanceof ApiError && /expired/i.test(err.message)) {
        setChallenge(null);
        setCode('');
      }
      setError(msg);
      setBusy(false);
    }
  }

  if (challenge) {
    return (
      <form onSubmit={submit} className="space-y-4">
        {error && <Alert>{error}</Alert>}
        <div className="flex items-start gap-3 rounded-lg bg-subtle p-3 text-sm">
          <ShieldCheck size={20} className="mt-0.5 shrink-0 text-brand" />
          <p>{useRecovery ? 'Enter one of the recovery codes you saved when you turned on two-factor authentication.' : `Open your authenticator app and enter the 6-digit code for ${APP_NAME}.`}</p>
        </div>
        <Field label={useRecovery ? 'Recovery code' : 'Authentication code'}>
          {useRecovery ? (
            <Input key="recovery" autoComplete="one-time-code" required autoFocus value={code} onChange={(e) => setCode(e.target.value)} placeholder="xxxxx-xxxxx" />
          ) : (
            <Input key="totp" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required autoFocus value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} placeholder="123456" className="text-center font-mono text-lg tracking-[0.4em]" />
          )}
        </Field>
        <Button type="submit" className="w-full" loading={busy}>Verify</Button>
        <div className="flex justify-between text-sm">
          <button type="button" className="text-brand hover:underline" onClick={() => { setUseRecovery(!useRecovery); setCode(''); setError(null); }}>
            {useRecovery ? 'Use authenticator code' : 'Use a recovery code'}
          </button>
          <button type="button" className="text-fg-muted hover:underline" onClick={() => { setChallenge(null); setCode(''); setError(null); }}>Back</button>
        </div>
      </form>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {error && <Alert>{error}</Alert>}
      <Field label="Email">
        <Input type="email" autoComplete="username" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@pharmacy.com" />
      </Field>
      <Field label="Password">
        <Input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      </Field>
      <Button type="submit" className="w-full" loading={busy}>Sign in</Button>
      <p className="text-center text-sm">
        <Link href="/forgot-password" className="text-brand hover:underline">Forgot your password?</Link>
      </p>
    </form>
  );
}

export default function LoginPage() {
  return (
    <main className="grid min-h-screen place-items-center p-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-brand text-brand-fg"><Pill size={24} /></span>
          <h1 className="mt-3 text-xl font-semibold">{APP_NAME}</h1>
          <p className="text-sm text-fg-muted">Sign in to your pharmacy</p>
        </div>
        <Card className="p-5">
          <Suspense fallback={null}>
            <LoginForm />
          </Suspense>
        </Card>
      </div>
    </main>
  );
}
