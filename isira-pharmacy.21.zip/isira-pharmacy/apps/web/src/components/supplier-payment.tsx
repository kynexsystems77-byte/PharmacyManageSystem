'use client';

import { useState } from 'react';
import { SUPPLIER_PAYMENT_METHODS } from '@kynex/contracts';
import { money, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation } from '@/lib/hooks';
import { useAuth } from '@/lib/auth';
import { Modal, Select, useToast } from './kit';
import { Alert, Button, Field, Input } from './ui';

interface PaymentResult { amount: string; applied: { purchaseId: string | null; number: string | null; amount: string }[]; cashFromRegister: boolean; balance: string }

/** Pay a supplier: one invoice (purchaseId) or oldest-first across open invoices. */
export function SupplierPaymentModal({
  open, onClose, supplierId, supplierName, purchaseId, purchaseNumber, suggested,
}: { open: boolean; onClose: () => void; supplierId: string; supplierName: string; purchaseId?: string; purchaseNumber?: string; suggested: number }) {
  const toast = useToast();
  const { profile } = useAuth();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('BANK_TRANSFER');
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const pay = useApiMutation<object, PaymentResult>('POST', `/suppliers/${supplierId}/payments`, {
    onSuccess: (r) => {
      toast.success(`Paid ${money(Number(r.amount), profile.tenant.currencyCode)}${r.cashFromRegister ? ' from your register' : ''}. Balance now ${money(Number(r.balance), profile.tenant.currencyCode)}.`);
      setAmount(''); setReference(''); setNote('');
      onClose();
    },
  });
  const value = amount === '' ? String(Math.max(0, suggested)) : amount;
  return (
    <Modal
      open={open}
      onClose={onClose}
      size="sm"
      title={`Pay ${supplierName}`}
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button loading={pay.isPending} disabled={!(Number(value) > 0)} onClick={() => pay.mutate({ amount: Number(value), method, reference: reference.trim() || undefined, note: note.trim() || undefined, purchaseId })}>Record payment</Button></>}
    >
      <div className="space-y-3">
        {pay.error && <Alert>{errorMessage(pay.error)}</Alert>}
        <p className="text-sm text-fg-muted">{purchaseId ? `Applied to ${purchaseNumber}.` : 'Applied to the oldest unpaid invoices first; any excess is kept as an advance.'}</p>
        <Field label="Amount"><Input type="number" min="0.01" step="0.01" value={value} onChange={(e) => setAmount(e.target.value)} /></Field>
        <Field label="Method">
          <Select value={method} onChange={(e) => setMethod(e.target.value)}>
            {SUPPLIER_PAYMENT_METHODS.map((m) => <option key={m} value={m}>{titleCase(m)}</option>)}
          </Select>
        </Field>
        {method === 'CASH' && <p className="text-xs text-fg-muted">Cash comes out of your open register shift, if you have one.</p>}
        <Field label="Reference"><Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Cheque or transfer number" maxLength={120} /></Field>
        <Field label="Note"><Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} /></Field>
      </div>
    </Modal>
  );
}
