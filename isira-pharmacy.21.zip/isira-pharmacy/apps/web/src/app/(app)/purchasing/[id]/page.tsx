'use client';

import { RotateCcw, Wallet } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ConfirmDialog, DataTable, KeyValue, PageHeader, useToast } from '@/components/kit';
import { draftBody, draftFromPurchase, PurchaseForm, type PurchaseDraft } from '@/components/purchase-form';
import { SupplierPaymentModal } from '@/components/supplier-payment';
import { Alert, Badge, Button, Card, CardHeader, Skeleton } from '@/components/ui';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, productName, qty, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import { paymentState, PURCHASE_TONE } from '@/lib/status';
import type { Purchase } from '@/lib/types';
import { useMutation, useQueryClient } from '@tanstack/react-query';

export default function PurchasePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const { can, profile, branchId } = useAuth();
  const cur = profile.tenant.currencyCode;
  const { data: p, isLoading, error } = useBranchQuery<Purchase>(`/purchases/${params.id}`);
  const [paying, setPaying] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const cancel = useApiMutation<object>('POST', `/purchases/${params.id}/cancel`, { onSuccess: () => { toast.success('Purchase cancelled'); setConfirmCancel(false); } });

  // Draft editing: save (PATCH) then optionally receive.
  const save = useMutation({
    mutationFn: async ({ d, action, payment }: { d: PurchaseDraft; action: 'draft' | 'receive'; payment?: object }) => {
      const { orderId: _o, ...body } = draftBody(d);
      await api(`/purchases/${params.id}`, { method: 'PATCH', body, branchId });
      if (action === 'receive') return api<Purchase>(`/purchases/${params.id}/receive`, { method: 'POST', body: { payment }, branchId });
      return null;
    },
    onSuccess: async (r) => {
      await qc.invalidateQueries();
      toast.success(r ? `${r.number} received into stock` : 'Draft saved');
    },
  });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !p) return <Alert>{errorMessage(error) || 'Purchase not found'}</Alert>;

  if (p.status === 'DRAFT' && can('purchase:create')) {
    return (
      <div className="mx-auto max-w-6xl">
        <PageHeader
          back="/purchasing"
          title={`${p.number} (draft)`}
          subtitle="Drafts do not change stock until they are received."
          actions={<Button variant="outline" onClick={() => setConfirmCancel(true)}>Cancel draft</Button>}
        />
        <PurchaseForm
          key={p.id}
          mode="edit"
          initial={draftFromPurchase(p)}
          submitting={save.isPending}
          error={save.error}
          onSave={(d, action, payment) => save.mutate({ d, action, payment })}
          onCancel={() => router.push('/purchasing')}
        />
        <ConfirmDialog open={confirmCancel} title="Cancel this draft?" danger confirmLabel="Cancel draft" loading={cancel.isPending} onClose={() => setConfirmCancel(false)} onConfirm={() => cancel.mutate({})} body={<p>The draft is kept for the record but can no longer be received.</p>} />
      </div>
    );
  }

  const outstanding = num(p.grandTotal) - num(p.paidTotal);
  const ps = paymentState(num(p.grandTotal), num(p.paidTotal));
  return (
    <div className="space-y-4">
      <PageHeader
        back="/purchasing"
        title={p.number}
        subtitle={<span className="flex flex-wrap items-center gap-2"><Badge tone={PURCHASE_TONE[p.status]}>{p.status.toLowerCase()}</Badge>{p.status === 'RECEIVED' && <Badge tone={ps.tone}>{ps.label}</Badge>}<span>{p.supplier.name}</span></span>}
        actions={p.status === 'RECEIVED' && (
          <>
            {can('purchase:return') && <Link href={`/purchasing/returns/new?purchaseId=${p.id}`}><Button variant="outline"><RotateCcw size={16} /> Return goods</Button></Link>}
            {can('supplier:payment') && outstanding > 0 && <Button onClick={() => setPaying(true)}><Wallet size={16} /> Record payment</Button>}
          </>
        )}
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-4 lg:col-span-2">
          <KeyValue items={[
            { label: 'Supplier', value: <Link className="text-brand hover:underline" href={`/purchasing/suppliers/${p.supplier.id}`}>{p.supplier.name}</Link> },
            { label: 'Supplier invoice', value: p.supplierInvoiceNo },
            { label: 'Invoice date', value: dateOnly(p.purchaseDate) },
            { label: 'Due date', value: dateOnly(p.dueDate) },
            { label: 'Received into', value: p.location.name },
            { label: 'Received', value: p.receivedAt ? dateTime(p.receivedAt) : '-' },
            { label: 'Purchase order', value: p.order ? <Link className="text-brand hover:underline" href={`/purchasing/orders/${p.order.id}`}>{p.order.number}</Link> : null },
            { label: 'Entered by', value: p.createdBy.fullName },
            { label: 'Notes', value: p.notes },
          ]} />
        </Card>
        <Card className="space-y-2 p-4 text-sm">
          <Row label="Subtotal" value={money(num(p.subtotal), cur)} />
          {num(p.discountTotal) > 0 && <Row label="Discount" value={`- ${money(num(p.discountTotal), cur)}`} />}
          <Row label="Tax" value={money(num(p.taxTotal), cur)} />
          <Row label="Total" value={money(num(p.grandTotal), cur)} strong />
          <Row label="Paid" value={money(num(p.paidTotal), cur)} />
          <Row label="Outstanding" value={money(outstanding, cur)} strong />
        </Card>
      </div>
      <Card>
        <CardHeader title="Items" />
        <DataTable
          rows={p.purchaseItems}
          rowKey={(i) => i.id}
          onRowClick={(i) => i.batchId && router.push(`/inventory/batches/${i.batchId}`)}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => <span className="font-medium">{productName(i.product.brandName, i.product.strength)}</span> },
            { key: 'b', header: 'Batch', cell: (i) => <span className="font-mono text-xs">{i.batchNumber}</span> },
            { key: 'e', header: 'Expiry', cell: (i) => dateOnly(i.expiryDate) },
            { key: 'q', header: 'Qty', align: 'right', cell: (i) => `${qty(num(i.quantity))}${num(i.bonusQuantity) > 0 ? ` + ${qty(num(i.bonusQuantity))} free` : ''}` },
            { key: 'c', header: 'Supplier price', align: 'right', cell: (i) => money(num(i.unitCost), cur) },
            { key: 'd', header: 'Discount', align: 'right', cell: (i) => { const g = num(i.quantity) * num(i.unitCost); return num(i.discountAmount) > 0 ? <span>{money(num(i.discountAmount), cur)}<span className="block text-xs text-fg-muted">{g > 0 ? `${((num(i.discountAmount) / g) * 100).toFixed(1)}% off` : ''}</span></span> : '-'; } },
            { key: 'n', header: 'Net cost / unit', align: 'right', cell: (i) => { const recv = num(i.quantity) + num(i.bonusQuantity); return recv > 0 ? money((num(i.quantity) * num(i.unitCost) - num(i.discountAmount)) / recv, cur) : '-'; } },
            { key: 'pr', header: 'Profit / unit', align: 'right', cell: (i) => {
              const recv = num(i.quantity) + num(i.bonusQuantity);
              const sell = i.sellingPrice !== null ? num(i.sellingPrice) : i.product.sellingPrice !== undefined ? num(i.product.sellingPrice) : null;
              if (sell === null || recv <= 0) return '-';
              const profit = sell - (num(i.quantity) * num(i.unitCost) - num(i.discountAmount)) / recv;
              return <span className={profit < 0 ? 'text-danger' : 'text-success'}>{money(profit, cur)}<span className="block text-xs text-fg-muted">sells {money(sell, cur)}</span></span>;
            } },
            { key: 't', header: 'Tax', align: 'right', cell: (i) => (num(i.taxAmount) > 0 ? `${money(num(i.taxAmount), cur)} (${num(i.taxPercent)}%)` : '-') },
            { key: 'l', header: 'Line total', align: 'right', cell: (i) => <span className="font-medium">{money(num(i.lineTotal), cur)}</span> },
          ]}
        />
      </Card>
      {p.payments.length > 0 && (
        <Card>
          <CardHeader title="Payments" />
          <DataTable
            rows={p.payments}
            rowKey={(x) => x.id}
            columns={[
              { key: 'd', header: 'Date', cell: (x) => dateTime(x.paidAt) },
              { key: 'm', header: 'Method', cell: (x) => titleCase(x.method) },
              { key: 'r', header: 'Reference', cell: (x) => x.reference ?? '-' },
              { key: 'a', header: 'Amount', align: 'right', cell: (x) => money(num(x.amount), cur) },
            ]}
          />
        </Card>
      )}
      <SupplierPaymentModal open={paying} onClose={() => setPaying(false)} supplierId={p.supplier.id} supplierName={p.supplier.name} purchaseId={p.id} purchaseNumber={p.number} suggested={outstanding} />
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return <div className={`flex justify-between ${strong ? 'font-semibold' : 'text-fg-muted'}`}><span>{label}</span><span className="tabular text-fg">{value}</span></div>;
}
