import { z } from 'zod';
import { dateOnlySchema, moneySchema, nullableText, optionalText, percentSchema, priceSchema, quantitySchema } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 6: suppliers, purchase orders, purchases (goods receipt), supplier payments and purchase returns. */

export const PAYMENT_METHODS = ['CASH', 'CARD', 'BANK_TRANSFER', 'CUSTOMER_CREDIT', 'OTHER'] as const;
/** Methods that move real money (customer credit is only a ledger entry). */
export const SUPPLIER_PAYMENT_METHODS = ['CASH', 'CARD', 'BANK_TRANSFER', 'OTHER'] as const;

// ---- suppliers ----
export const createSupplierSchema = z.object({
  name: z.string().trim().min(2).max(160),
  contactName: optionalText(120),
  phone: optionalText(40),
  email: z.string().trim().email().max(254).optional().or(z.literal('').transform(() => undefined)),
  address: optionalText(300),
  taxNumber: optionalText(60),
  paymentTermsDays: z.coerce.number().int().min(0).max(365).default(0),
  notes: optionalText(1000),
});
export const updateSupplierSchema = z
  .object({
    name: z.string().trim().min(2).max(160).optional(),
    contactName: nullableText(120),
    phone: nullableText(40),
    email: z.string().trim().email().max(254).nullable().optional().or(z.literal('').transform(() => null)),
    address: nullableText(300),
    taxNumber: nullableText(60),
    paymentTermsDays: z.coerce.number().int().min(0).max(365).optional(),
    notes: nullableText(1000),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const listSuppliersQuerySchema = paginationSchema.extend({
  status: z.enum(['active', 'inactive', 'all']).default('active'),
  withBalance: z.enum(['true', 'false']).optional(),
});

// ---- purchase orders ----
const poItemSchema = z.object({
  productId: uuidSchema,
  orderedQuantity: quantitySchema,
  unitCost: priceSchema,
  taxPercent: percentSchema.default(0),
});
export const createPurchaseOrderSchema = z.object({
  supplierId: uuidSchema,
  orderDate: dateOnlySchema.optional(),
  expectedDate: dateOnlySchema.nullable().optional(),
  notes: optionalText(1000),
  items: z.array(poItemSchema).min(1).max(300),
});
export const updatePurchaseOrderSchema = createPurchaseOrderSchema.partial().refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const listPurchaseOrdersQuerySchema = paginationSchema.extend({
  status: z.enum(['DRAFT', 'ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED']).optional(),
  supplierId: uuidSchema.optional(),
});

// ---- purchases (supplier invoice + goods receipt) ----
export const purchaseItemSchema = z.object({
  productId: uuidSchema,
  batchNumber: z.string().trim().min(1).max(60),
  expiryDate: dateOnlySchema.nullable().optional(),
  manufactureDate: dateOnlySchema.nullable().optional(),
  /** Paid quantity, in base units. */
  quantity: quantitySchema,
  /** Free goods, in base units (lowers the landed cost per unit). */
  bonusQuantity: z.coerce.number().min(0).max(99_999_999).default(0),
  /** Cost per base unit before discount and tax. */
  unitCost: priceSchema,
  discountAmount: moneySchema.default(0),
  taxPercent: percentSchema.default(0),
  /** Optional batch-specific selling price. */
  sellingPrice: priceSchema.nullable().optional(),
});

export const supplierPaymentInputSchema = z.object({
  amount: moneySchema.refine((v) => v > 0, 'Amount must be positive'),
  method: z.enum(SUPPLIER_PAYMENT_METHODS),
  reference: optionalText(120),
  note: optionalText(500),
});

export const createPurchaseSchema = z.object({
  supplierId: uuidSchema,
  locationId: uuidSchema.optional(),
  orderId: uuidSchema.optional(),
  supplierInvoiceNo: optionalText(60),
  purchaseDate: dateOnlySchema.optional(),
  dueDate: dateOnlySchema.nullable().optional(),
  notes: optionalText(1000),
  items: z.array(purchaseItemSchema).min(1).max(300),
  /** Receive immediately (creates batches + stock). Otherwise the purchase stays a DRAFT. */
  receive: z.boolean().default(false),
  /** Payment made at receipt (only with receive=true). */
  payment: supplierPaymentInputSchema.optional(),
});
export const updatePurchaseSchema = z
  .object({
    supplierId: uuidSchema.optional(),
    locationId: uuidSchema.optional(),
    supplierInvoiceNo: nullableText(60),
    purchaseDate: dateOnlySchema.optional(),
    dueDate: dateOnlySchema.nullable().optional(),
    notes: nullableText(1000),
    items: z.array(purchaseItemSchema).min(1).max(300).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');
export const receivePurchaseSchema = z.object({ payment: supplierPaymentInputSchema.optional() });
export const listPurchasesQuerySchema = paginationSchema.extend({
  status: z.enum(['DRAFT', 'RECEIVED', 'CANCELLED']).optional(),
  supplierId: uuidSchema.optional(),
  unpaid: z.enum(['true', 'false']).optional(),
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
});

// ---- supplier payments ----
export const createSupplierPaymentSchema = supplierPaymentInputSchema.extend({
  /** Apply to one invoice; without it the payment is applied to the oldest unpaid invoices first. */
  purchaseId: uuidSchema.optional(),
});

// ---- purchase returns ----
export const createPurchaseReturnSchema = z.object({
  supplierId: uuidSchema,
  purchaseId: uuidSchema.optional(),
  reason: optionalText(500),
  items: z
    .array(z.object({ batchId: uuidSchema, locationId: uuidSchema, quantity: quantitySchema, unitCost: priceSchema.optional() }))
    .min(1)
    .max(200),
});
export const listPurchaseReturnsQuerySchema = paginationSchema.extend({ supplierId: uuidSchema.optional() });
