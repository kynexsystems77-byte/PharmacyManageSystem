'use client';

import { Trash2 } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Forbidden, PageHeader, Select, useToast } from '@/components/kit';
import { BatchSelect, LocationSelect, ProductPicker } from '@/components/pickers';
import { Alert, Button, Card, CardHeader, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num, productName, qty } from '@/lib/format';
import { errorMessage, newKey, useApiMutation, useBranchQuery, type Paged } from '@/lib/hooks';
import type { BatchRow, Purchase, PurchaseReturn, Supplier } from '@/lib/types';

interface Line { key: string; productId: string; label: string; baseUnit: string; batchId: string; batchLabel?: string; locationId: string; quantity: string; max?: number; unitCost: string }

export default function NewReturnPage() {
  const router = useRouter();
  const toast = useToast();
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const purchaseId = useSearchParams().get('purchaseId');
  const purchase = useBranchQuery<Purchase>(purchaseId ? `/purchases/${purchaseId}` : null);
  const suppliers = useBranchQuery<Paged<Supplier>>('/suppliers?pageSize=100');
  const [supplierId, setSupplierId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [reason, setReason] = useState('');
  const [lines, setLines] = useState<Line[]>([]);

  useEffect(() => {
    const p = purchase.data;
    if (!p) return;
    setSupplierId(p.supplier.id);
    setLines(p.purchaseItems.filter((i) => i.batchId).map((i) => ({
      key: i.id, productId: i.product.id, label: productName(i.product.brandName, i.product.strength), baseUnit: i.product.baseUnit,
      batchId: i.batchId as string, batchLabel: `${i.batchNumber} · exp ${dateOnly(i.expiryDate)}`, locationId: p.location.id, quantity: '',
      max: num(i.quantity) + num(i.bonusQuantity), unitCost: String(num(i.unitCost)),
    })));
  }, [purchase.data]);

  const create = useApiMutation<object, PurchaseReturn>('POST', '/purchase-returns', { onSuccess: (r) => { toast.success(`${r.number} posted`); router.push(`/purchasing/returns/${r.id}`); } });
  if (!can('purchase:return')) return <Forbidden what="purchase returns" />;
  const setLine = (key: string, patch: Partial<Line>) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const active = lines.filter((l) => Number(l.quantity) > 0);
  const total = active.reduce((a, l) => a + Number(l.quantity) * Number(l.unitCost || 0), 0);
  const valid = supplierId && active.length > 0 && active.every((l) => l.batchId && l.locationId);

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader back="/purchasing/returns" title="Return goods to a supplier" subtitle={purchase.data ? `From ${purchase.data.number} (${purchase.data.supplier.name}). Enter the quantity for each line you send back.` : 'Choose the batches to send back.'} />
      <Card className="grid gap-4 p-4 sm:grid-cols-3">
        <Field label="Supplier *">
          <Select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} disabled={Boolean(purchaseId)}>
            <option value="">Choose…</option>
            {suppliers.data?.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </Field>
        {!purchaseId && <Field label="Take stock from"><LocationSelect value={locationId} onChange={setLocationId} /></Field>}
        <Field label="Reason"><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Damaged, near expiry, wrong item…" maxLength={500} /></Field>
      </Card>
      <Card>
        <CardHeader title="Lines" action={<span className="tabular font-semibold">{money(total, cur)}</span>} />
        <div className="space-y-3 p-4">
          {!purchaseId && (
            <ProductPicker onPick={(p) => setLines((ls) => [...ls, { key: newKey(), productId: p.id, label: productName(p.brandName, p.strength), baseUnit: p.baseUnit, batchId: '', locationId, quantity: '', unitCost: '' }])} placeholder="Add a product" />
          )}
          {lines.map((l) => (
            <div key={l.key} className="grid items-end gap-2 rounded-lg border border-line p-3 md:grid-cols-[1.3fr_1.7fr_120px_120px_auto]">
              <div className="pb-2 text-sm"><p className="font-medium">{l.label}</p>{l.max !== undefined && <p className="text-xs text-fg-muted">Received {qty(l.max)} {l.baseUnit}</p>}</div>
              {l.batchLabel ? <div className="pb-2 text-sm font-mono">{l.batchLabel}</div> : (
                <Field label="Batch"><BatchSelect productId={l.productId} locationId={locationId} value={l.batchId} onChange={(id, b?: BatchRow) => setLine(l.key, { batchId: id, locationId, unitCost: b ? String(num(b.unitCost)) : '' })} /></Field>
              )}
              <Field label={`Return qty`}><Input type="number" min="0" step="0.001" max={l.max} value={l.quantity} onChange={(e) => setLine(l.key, { quantity: e.target.value })} /></Field>
              <Field label="Credit / unit"><Input type="number" min="0" step="0.0001" value={l.unitCost} onChange={(e) => setLine(l.key, { unitCost: e.target.value })} /></Field>
              <button aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((x) => x.key !== l.key))} className="mb-1 grid h-9 w-9 place-items-center rounded-lg text-fg-muted hover:bg-subtle hover:text-danger"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      </Card>
      {create.error && <Alert>{errorMessage(create.error)}</Alert>}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
        <Button disabled={!valid} loading={create.isPending} onClick={() => create.mutate({
          supplierId, purchaseId: purchaseId ?? undefined, reason: reason.trim() || undefined,
          items: active.map((l) => ({ batchId: l.batchId, locationId: l.locationId || locationId, quantity: Number(l.quantity), unitCost: l.unitCost === '' ? undefined : Number(l.unitCost) })),
        })}>Post return</Button>
      </div>
    </div>
  );
}
