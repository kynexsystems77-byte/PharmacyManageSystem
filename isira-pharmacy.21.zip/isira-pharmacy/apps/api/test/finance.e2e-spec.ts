import { INestApplication } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { addStock, bootApp, createProduct, defaultLocationId, expectStatus, isoDay, login, uid, type Session } from './helpers';

const key = () => randomUUID().replace(/-/g, '');

describe('Finance (Phase 9)', () => {
  let app: INestApplication;
  beforeAll(async () => {
    app = await bootApp();
  });
  afterAll(async () => {
    await app.close();
  });

  /** A brand-new branch so the P&L numbers are exact. Owners get access to new branches at their next login. */
  async function freshBranch(): Promise<Session> {
    const owner = await login(app, 'owner@demo.local');
    const code = `F${uid()}`.slice(0, 8);
    const b = await owner.agent.post('/v1/branches').set('X-Kynex-Csrf', '1').send({ name: `Zz Finance ${code}`, code });
    expectStatus(b, 201);
    const s = await login(app, 'owner@demo.local', b.body.id);
    const regs = await s.get('/registers');
    expectStatus(await s.post(`/registers/${regs.body[0].id}/open`, { openingBalance: 100 }), 201);
    return s;
  }

  it('produces an exact profit and loss: returns, restocked vs damaged cost, stock losses, expenses, tax', async () => {
    const s = await freshBranch();
    const today = isoDay(0);
    const tax = await s.post('/tax-rates', { name: `VAT10 ${uid()}`, ratePercent: 10 });
    const plain = await createProduct(s, { sellingPrice: 10, purchasePrice: 4 });
    const taxed = await createProduct(s, { sellingPrice: 20, purchasePrice: 8, taxRateId: tax.body.id });
    await addStock(s, plain.id, { quantity: 100, unitCost: 4 });
    await addStock(s, taxed.id, { quantity: 100, unitCost: 8 });

    const sale1 = await s.post('/sales', { idempotencyKey: key(), items: [{ productId: plain.id, quantity: 10 }], payments: [{ method: 'CASH', amount: 100 }] });
    expectStatus(sale1, 201);
    const sale2 = await s.post('/sales', { idempotencyKey: key(), items: [{ productId: taxed.id, quantity: 5 }], payments: [{ method: 'CARD', amount: 110 }] });
    expectStatus(sale2, 201);
    expectStatus(await s.post(`/sales/${sale1.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: sale1.body.saleItems[0].id, quantity: 2 }], refundMethod: 'CASH', reason: 'Not needed' }), 201);
    expectStatus(await s.post(`/sales/${sale2.body.id}/returns`, { idempotencyKey: key(), items: [{ saleItemId: sale2.body.saleItems[0].id, quantity: 1, restock: false }], refundMethod: 'CARD', reason: 'Broken seal' }), 201);

    const locationId = await defaultLocationId(s);
    const batch = (await s.get(`/inventory/batches?productId=${plain.id}`)).body.data[0].id;
    expectStatus(await s.post('/inventory/write-offs', { locationId, reason: 'DAMAGED', items: [{ batchId: batch, quantity: 3 }] }), 201);

    const cats = await s.get('/expense-categories');
    expectStatus(await s.post('/expenses', { categoryId: cats.body[0].id, amount: 30, description: 'Courier', fromRegister: true }), 201);

    const pl = await s.get(`/finance/summary?from=${today}&to=${today}`);
    expectStatus(pl, 200);
    expect(pl.body.sales.invoices).toBe(2);
    expect(pl.body.sales.total).toBe('210.00');
    expect(pl.body.sales.revenueExTax).toBe('200.00');
    expect(pl.body.returns.exTax).toBe('40.00');
    expect(pl.body.netSales).toBe('160.00');
    expect(pl.body.cogs).toBe('72.00'); // 80 sold - 8 restocked (the damaged return's cost is not recovered)
    expect(pl.body.grossProfit).toBe('88.00');
    expect(pl.body.stockLoss.total).toBe('12.00');
    expect(pl.body.expenses.total).toBe('30.00');
    expect(pl.body.netProfit).toBe('46.00');
    expect(pl.body.taxCollected).toBe('8.00');
    expect(pl.body.daily).toHaveLength(1);
    expect(pl.body.daily[0].profit).toBe(88);

    const rec = await s.get(`/finance/reconciliation?from=${today}&to=${today}`);
    expect(rec.body.totals.open).toBe(1);
    const shift = (await s.get('/registers/my-shift')).body.current;
    expect(shift.expectedCash).toBe('150.00'); // 100 float + 100 cash sale - 20 cash refund - 30 expense
  });

  it('reverses a register-paid expense into the open shift when deleted', async () => {
    const s = await freshBranch();
    const cats = await s.get('/expense-categories');
    const e = await s.post('/expenses', { categoryId: cats.body[0].id, amount: 25, description: 'Tea and snacks', fromRegister: true });
    expectStatus(e, 201);
    expect((await s.get('/registers/my-shift')).body.current.expectedCash).toBe('75.00');
    expect((await s.patch(`/expenses/${e.body.id}`, { amount: 20 })).status).toBe(409);
    expect((await s.del(`/expenses/${e.body.id}`)).status).toBe(204);
    expect((await s.get('/registers/my-shift')).body.current.expectedCash).toBe('100.00');
    const card = await s.post('/expenses', { categoryId: cats.body[0].id, amount: 10, paymentMethod: 'CARD', description: 'Domain renewal', fromRegister: true });
    expect(card.status).toBe(422);
  });

  it('lets an owner change operational settings (cash rounding) and restores them', async () => {
    const s = await freshBranch();
    const before = (await s.get('/settings')).body.settings;
    try {
      const upd = await s.put('/settings', { cashRoundingStep: 0.5 });
      expectStatus(upd, 200);
      expect(upd.body.settings.cashRoundingStep).toBe(0.5);
      const p = await createProduct(s, { sellingPrice: 10.2 });
      await addStock(s, p.id, { quantity: 5 });
      const q = await s.post('/sales/quote', { items: [{ productId: p.id, quantity: 1 }] });
      expect(q.body.grandTotal).toBe('10.00');
      expect(q.body.roundingAdjustment).toBe('-0.20');
      const cashier = await login(app, 'cashier@demo.local');
      expect((await cashier.put('/settings', { cashRoundingStep: 1 })).status).toBe(403);
    } finally {
      expectStatus(await s.put('/settings', { cashRoundingStep: before.cashRoundingStep }), 200);
    }
  });
});
