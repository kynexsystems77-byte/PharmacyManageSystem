import { INestApplication, INestApplicationContext } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { QueueEvents, Worker } from 'bullmq';
import { randomUUID } from 'node:crypto';
import { QUEUE_NAME, QueueService, redisConnection } from '../src/jobs/queue';
import { AlertsService } from '../src/worker/alerts.service';
import { JobProcessor, WorkerModule, type JobName } from '../src/worker/worker.module';
import { addStock, bootApp, createProduct, expectStatus, login, uid } from './helpers';

const key = () => randomUUID().replace(/-/g, '');

describe('Notifications and background jobs (Phase 11)', () => {
  let app: INestApplication;
  let worker: INestApplicationContext;
  let alerts: AlertsService;
  let tenantId: string;

  beforeAll(async () => {
    app = await bootApp();
    const ref = await Test.createTestingModule({ imports: [WorkerModule] }).compile();
    worker = await ref.init();
    alerts = worker.get(AlertsService);
    const owner = await login(app, 'owner@demo.local');
    tenantId = (await owner.agent.get('/v1/tenant')).body.id;
  });
  afterAll(async () => {
    await worker.close();
    await app.close();
  });

  it('turns a sale into a low-stock alert through the outbox, visible only to users of that branch', async () => {
    const owner = await login(app, 'owner@demo.local');
    const code = `N${uid()}`.slice(0, 8);
    const b = await owner.agent.post('/v1/branches').set('X-Kynex-Csrf', '1').send({ name: `Zz Alerts ${code}`, code });
    expectStatus(b, 201);
    const s = await login(app, 'owner@demo.local', b.body.id);
    const regs = await s.get('/registers');
    expectStatus(await s.post(`/registers/${regs.body[0].id}/open`, { openingBalance: 0 }), 201);
    const p = await createProduct(s, { reorderLevel: 10, sellingPrice: 5 });
    await addStock(s, p.id, { quantity: 12 });
    expectStatus(await s.post('/sales', { idempotencyKey: key(), items: [{ productId: p.id, quantity: 5 }], payments: [{ method: 'CARD', amount: 25 }] }), 201);

    const res = await alerts.processOutbox(tenantId);
    expect(res.failed).toBe(0);
    expect(res.processed).toBeGreaterThanOrEqual(1);

    const list = await s.get('/notifications?unread=true');
    const mine = list.body.data.find((n: { title: string }) => n.title.includes(p.brandName));
    expect(mine).toBeTruthy();
    expect(mine.type).toBe('LOW_STOCK');
    expect(mine.data.link).toBe(`/medicines/${p.id}`);

    // the cashier is not assigned to this branch, so the alert is not theirs
    const cashier = await login(app, 'cashier@demo.local');
    expect((await cashier.get('/notifications')).body.data.some((n: { title: string }) => n.title.includes(p.brandName))).toBe(false);

    // processing again is a no-op (event already processed)
    expect((await alerts.processOutbox(tenantId)).processed).toBe(0);
  });

  it('creates daily expiry alerts once, with read status per user', async () => {
    await alerts.scanTenant(tenantId); // first scan of the day creates the alerts (0 if an earlier run already did)
    expect(await alerts.scanTenant(tenantId)).toBe(0); // deduplicated

    const owner = await login(app, 'owner@demo.local');
    const pharmacist = await login(app, 'pharmacist@demo.local');
    const expired = (await owner.get('/notifications?pageSize=100')).body.data.find((n: { type: string; branch: { id: string } | null }) => n.type === 'EXPIRED' && n.branch?.id === owner.branchId);
    expect(expired).toBeTruthy(); // the seeded expired Omeprazole batch
    const before = (await pharmacist.get('/notifications/unread-count')).body.unread;

    expect((await owner.post(`/notifications/${expired.id}/read`)).status).toBe(204);
    expect((await owner.get('/notifications?unread=true')).body.data.some((n: { id: string }) => n.id === expired.id)).toBe(false);
    expect((await pharmacist.get('/notifications/unread-count')).body.unread).toBe(before); // still unread for them

    expect((await pharmacist.post('/notifications/read-all')).status).toBe(204);
    expect((await pharmacist.get('/notifications/unread-count')).body.unread).toBe(0);
    const dash = await pharmacist.get('/dashboard');
    expect(dash.body.unreadNotifications).toBe(0);
  });

  it('runs housekeeping without touching live data', async () => {
    const r = await alerts.cleanupTenant(tenantId);
    expect(r).toEqual(expect.objectContaining({ idempotencyKeys: expect.any(Number), sessions: expect.any(Number) }));
    const owner = await login(app, 'owner@demo.local');
    expectStatus(await owner.get('/auth/me'), 200);
  });

  it('processes jobs through BullMQ (Redis) including the queued password-reset email', async () => {
    const queue = worker.get(QueueService).queue;
    if (!queue || !process.env.REDIS_URL) return; // REDIS_URL not configured: inline mode is covered above
    const processor = worker.get(JobProcessor);
    const w = new Worker(QUEUE_NAME, (job) => processor.handle(job.name as JobName, job.data as Record<string, unknown>, (n, d) => queue.add(n, d)), { connection: redisConnection(process.env.REDIS_URL) });
    const events = new QueueEvents(QUEUE_NAME, { connection: redisConnection(process.env.REDIS_URL) });
    try {
      await events.waitUntilReady();
      const job = await queue.add('scan-alerts', {});
      const result = await job.waitUntilFinished(events, 20_000);
      expect(result.tenants).toBeGreaterThanOrEqual(1);

      // the API enqueues the reset email instead of sending it during the request
      const res = await (await import('supertest')).default(app.getHttpServer()).post('/v1/auth/password/forgot').send({ email: 'owner@demo.local' });
      expect(res.status).toBeLessThan(300);
      const deadline = Date.now() + 10_000;
      let mailDone = false;
      while (!mailDone && Date.now() < deadline) {
        const done = await queue.getJobs(['completed'], 0, 50);
        mailDone = done.some((j) => j.name === 'mail' && (j.data as { to: string }).to === 'owner@demo.local');
        if (!mailDone) await new Promise((r) => setTimeout(r, 200));
      }
      expect(mailDone).toBe(true);
    } finally {
      await w.close();
      await events.close();
    }
  });
});
