'use client';

import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'next/navigation';
import { Suspense, useEffect } from 'react';
import { api } from '@/lib/api';
import { num, qty, titleCase } from '@/lib/format';
import type { Sale } from '@/lib/types';

interface ReceiptData { sale: Sale; tenant: { name: string; currencyCode: string; timezone: string } }

function branchFromStorage(): string | null {
  try {
    return localStorage.getItem('kx_branch');
  } catch {
    return null;
  }
}

/** 80 mm thermal receipt. Opens the print dialog automatically with ?auto=1. */
function Receipt({ id }: { id: string }) {
  const params = useSearchParams();
  const auto = params.get('auto') === '1';
  const branchId = params.get('branch') ?? branchFromStorage();
  const { data, error } = useQuery({ queryKey: ['receipt', id, branchId], queryFn: () => api<ReceiptData>(`/sales/${id}/receipt`, { branchId }) });
  useEffect(() => {
    if (data && auto) setTimeout(() => window.print(), 300);
  }, [data, auto]);
  if (error) return <p className="p-4 text-sm">Could not load the receipt: {(error as Error).message}</p>;
  if (!data) return <p className="p-4 text-sm">Loading…</p>;
  const { sale: s, tenant } = data;
  const m = (v: string | number) => num(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const when = s.soldAt ? new Intl.DateTimeFormat(undefined, { dateStyle: 'short', timeStyle: 'short', timeZone: tenant.timezone }).format(new Date(s.soldAt)) : '';
  const salePays = s.payments.filter((p) => p.kind === 'SALE_PAYMENT');
  return (
    <div className="receipt mx-auto w-[80mm] px-[3mm] py-[4mm] font-mono text-[11px] leading-snug">
      <style>{`@page { size: 80mm auto; margin: 0 } @media print { .no-print { display: none } body { background: #fff } }`}</style>
      <div className="text-center">
        <p className="text-[14px] font-bold">{tenant.name}</p>
        <p>{s.branch.name}</p>
        {s.branch.address && <p>{s.branch.address}</p>}
        {s.branch.phone && <p>Tel {s.branch.phone}</p>}
        {s.branch.taxNumber && <p>Tax no {s.branch.taxNumber}</p>}
        {s.branch.receiptHeader && <p className="mt-1 whitespace-pre-line">{s.branch.receiptHeader}</p>}
      </div>
      <Hr />
      <div className="flex justify-between"><span>{s.invoiceNo}</span><span>{when}</span></div>
      <p>Cashier: {s.cashier.fullName}</p>
      {s.customer && <p>Customer: {s.customer.fullName}{s.customer.code ? ` (${s.customer.code})` : ''}</p>}
      {s.prescription && <p>Rx: {s.prescription.prescriptionNumber ?? ''} Dr. {s.prescription.doctorName}</p>}
      {s.status === 'VOIDED' && <p className="text-center font-bold">*** VOIDED ***</p>}
      <Hr />
      {s.saleItems.map((i) => (
        <div key={i.id} className="mb-1">
          <p className="font-semibold">{i.productName}</p>
          <div className="flex justify-between">
            <span>{qty(num(i.quantity))} {i.productUnit?.name ?? i.product.baseUnit} x {m(i.unitPrice)}</span>
            <span>{m(i.lineTotal)}</span>
          </div>
          {num(i.discountAmount) > 0 && <p className="text-right">disc -{m(i.discountAmount)}</p>}
          <p className="text-[10px]">Batch {i.saleItemAllocations.map((a) => a.batch.batchNumber).join(', ')}</p>
        </div>
      ))}
      <Hr />
      <Line l="Subtotal" v={m(s.subtotal)} />
      {num(s.discountTotal) > 0 && <Line l="Discount" v={`-${m(s.discountTotal)}`} />}
      {num(s.taxTotal) > 0 && <Line l="Tax" v={m(s.taxTotal)} />}
      {num(s.roundingAdjustment) !== 0 && <Line l="Rounding" v={m(s.roundingAdjustment)} />}
      <div className="my-1 flex justify-between text-[14px] font-bold"><span>TOTAL {tenant.currencyCode}</span><span>{m(s.grandTotal)}</span></div>
      {salePays.map((p) => <Line key={p.id} l={titleCase(p.method)} v={m(p.amount)} />)}
      {num(s.changeGiven) > 0 && <Line l="Change" v={m(s.changeGiven)} />}
      {num(s.balanceDue) > 0 && <Line l="On account" v={m(s.balanceDue)} />}
      <Hr />
      <p className="text-center">Items: {s.saleItems.length}</p>
      {s.branch.receiptFooter ? <p className="mt-1 whitespace-pre-line text-center">{s.branch.receiptFooter}</p> : <p className="mt-1 text-center">Thank you. Get well soon!</p>}
      <p className="mt-2 text-center text-[9px]">Keep this receipt for returns.</p>
      <div className="no-print mt-4 flex justify-center gap-2 font-sans">
        <button onClick={() => window.print()} className="rounded border px-3 py-1 text-sm">Print</button>
        <button onClick={() => window.close()} className="rounded border px-3 py-1 text-sm">Close</button>
      </div>
    </div>
  );
}

function Hr() {
  return <div className="my-1.5 border-t border-dashed border-black" />;
}
function Line({ l, v }: { l: string; v: string }) {
  return <div className="flex justify-between"><span>{l}</span><span>{v}</span></div>;
}

export default function ReceiptPage({ params }: { params: { id: string } }) {
  return (
    <Suspense fallback={null}>
      <Receipt id={params.id} />
    </Suspense>
  );
}
