import { z } from 'zod';
import { dateOnlySchema, idempotencyKeySchema, moneySchema, optionalText, percentSchema, quantitySchema } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 7: register shifts, POS sales, held bills, voids and customer returns. */

export const SALE_PAYMENT_METHODS = ['CASH', 'CARD', 'BANK_TRANSFER', 'CUSTOMER_CREDIT', 'OTHER'] as const;
export const SALE_STATUSES = ['DRAFT', 'HELD', 'COMPLETED', 'VOIDED', 'PARTIALLY_RETURNED', 'RETURNED'] as const;

// ---- registers and shifts ----
export const createRegisterSchema = z.object({ name: z.string().trim().min(1).max(60) });
export const openShiftSchema = z.object({ openingBalance: moneySchema, notes: optionalText(500) });
export const closeShiftSchema = z.object({ countedClosingBalance: moneySchema, notes: optionalText(500) });
export const cashMovementSchema = z.object({
  type: z.enum(['DEPOSIT', 'WITHDRAWAL']),
  amount: moneySchema.refine((v) => v > 0, 'Amount must be positive'),
  note: z.string().trim().min(2, 'Say why the cash moved').max(300),
});
export const listShiftsQuerySchema = paginationSchema.extend({
  registerId: uuidSchema.optional(),
  status: z.enum(['OPEN', 'CLOSED']).optional(),
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
});

// ---- sale lines ----
export const saleLineSchema = z
  .object({
    productId: uuidSchema,
    /** Sell in a pack unit (strip, box). Omit to sell base units. */
    productUnitId: uuidSchema.optional(),
    /** Quantity in the chosen unit. */
    quantity: quantitySchema,
    /** Choose a batch instead of the FEFO suggestion (needs sale:batch:override). */
    batchId: uuidSchema.optional(),
    discountPercent: percentSchema.optional(),
    discountAmount: moneySchema.optional(),
    prescriptionItemId: uuidSchema.optional(),
  })
  .refine((l) => !(l.discountPercent !== undefined && l.discountAmount !== undefined), 'Use a discount percent OR an amount, not both');

export const billDiscountSchema = z.object({ type: z.enum(['PERCENT', 'AMOUNT']), value: z.coerce.number().min(0) });

const saleBase = {
  customerId: uuidSchema.optional(),
  prescriptionId: uuidSchema.optional(),
  locationId: uuidSchema.optional(),
  items: z.array(saleLineSchema).min(1).max(200),
  billDiscount: billDiscountSchema.optional(),
  notes: optionalText(500),
  /** Pharmacist confirms a prescription was checked without recording it (needs prescription:manage). */
  rxOverride: z.boolean().optional(),
};

export const quoteSaleSchema = z.object(saleBase);

export const salePaymentSchema = z.object({
  method: z.enum(SALE_PAYMENT_METHODS),
  /** For CASH this is the amount tendered; change is calculated. */
  amount: moneySchema.refine((v) => v > 0, 'Amount must be positive'),
  reference: optionalText(120),
});

export const createSaleSchema = z.object({
  ...saleBase,
  idempotencyKey: idempotencyKeySchema,
  payments: z.array(salePaymentSchema).max(6).default([]),
  /** Completing a held bill removes it from the held list. */
  heldSaleId: uuidSchema.optional(),
});

export const holdSaleSchema = z.object({
  customerId: uuidSchema.optional(),
  items: z.array(saleLineSchema).min(1).max(200),
  billDiscount: billDiscountSchema.optional(),
  notes: optionalText(500),
  /** Re-holding an already held bill replaces it. */
  heldSaleId: uuidSchema.optional(),
});

/** POS scan check: what the till will sell next for this product, and how close it is to expiry. */
export const expiryCheckQuerySchema = z.object({ productId: uuidSchema });
export const EXPIRY_ALERT_LEVELS = ['none', 'warning', 'danger'] as const;

export const voidSaleSchema = z.object({ reason: z.string().trim().min(3, 'Give a reason').max(300) });

export const createSalesReturnSchema = z.object({
  idempotencyKey: idempotencyKeySchema,
  items: z
    .array(z.object({
      saleItemId: uuidSchema,
      /** In base units. */
      quantity: quantitySchema,
      /** false = damaged/unsellable: refunded but not put back into stock. */
      restock: z.boolean().default(true),
    }))
    .min(1)
    .max(200),
  refundMethod: z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'CUSTOMER_CREDIT', 'OTHER']),
  reason: z.string().trim().min(3, 'Give a reason').max(500),
});

export const listSalesQuerySchema = paginationSchema.extend({
  status: z.enum(SALE_STATUSES).optional(),
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
  cashierId: uuidSchema.optional(),
  customerId: uuidSchema.optional(),
  registerSessionId: uuidSchema.optional(),
});

export const listSalesReturnsQuerySchema = paginationSchema.extend({
  from: dateOnlySchema.optional(),
  to: dateOnlySchema.optional(),
});
