'use client';

import { Plus } from 'lucide-react';
import { useState } from 'react';
import { DataTable, Modal, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { num } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery, type Paged } from '@/lib/hooks';
import type { Manufacturer, TaxRate } from '@/lib/types';

export default function ReferenceDataPage() {
  const { can } = useAuth();
  const toast = useToast();
  const mfrs = useBranchQuery<Paged<Manufacturer>>('/manufacturers?pageSize=100&includeInactive=true');
  const taxes = useBranchQuery<TaxRate[]>('/tax-rates?includeInactive=true');
  const [mfr, setMfr] = useState<{ id?: string; name: string; country: string; isActive: boolean } | null>(null);
  const [tax, setTax] = useState<{ id?: string; name: string; ratePercent: string; isInclusive: boolean; isActive: boolean } | null>(null);

  const createMfr = useApiMutation<object>('POST', '/manufacturers', { onSuccess: () => { toast.success('Manufacturer saved'); setMfr(null); } });
  const updateMfr = useApiMutation<object>('PATCH', () => `/manufacturers/${mfr?.id}`, { onSuccess: () => { toast.success('Manufacturer saved'); setMfr(null); } });
  const createTax = useApiMutation<object>('POST', '/tax-rates', { onSuccess: () => { toast.success('Tax rate saved'); setTax(null); } });
  const updateTax = useApiMutation<object>('PATCH', () => `/tax-rates/${tax?.id}`, { onSuccess: () => { toast.success('Tax rate saved'); setTax(null); } });
  const mfrErr = createMfr.error ?? updateMfr.error;
  const taxErr = createTax.error ?? updateTax.error;

  const submitMfr = () => {
    if (!mfr) return;
    if (mfr.id) updateMfr.mutate({ name: mfr.name.trim(), country: mfr.country.trim() || null, isActive: mfr.isActive });
    else createMfr.mutate({ name: mfr.name.trim(), country: mfr.country.trim() || undefined });
  };
  const submitTax = () => {
    if (!tax) return;
    const body = { name: tax.name.trim(), ratePercent: Number(tax.ratePercent || 0), isInclusive: tax.isInclusive };
    if (tax.id) updateTax.mutate({ ...body, isActive: tax.isActive });
    else createTax.mutate(body);
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Manufacturers & tax rates" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Manufacturers" action={can('product:create') && <Button variant="outline" className="h-8 px-3" onClick={() => setMfr({ name: '', country: '', isActive: true })}><Plus size={14} /> Add</Button>} />
          <DataTable
            rows={mfrs.data?.data}
            loading={mfrs.isLoading}
            rowKey={(m) => m.id}
            onRowClick={can('product:update') ? (m) => setMfr({ id: m.id, name: m.name, country: m.country ?? '', isActive: m.isActive }) : undefined}
            columns={[
              { key: 'n', header: 'Name', cell: (m) => <span className="font-medium">{m.name}</span> },
              { key: 'c', header: 'Country', cell: (m) => m.country ?? '-' },
              { key: 's', header: '', cell: (m) => !m.isActive && <Badge>Inactive</Badge> },
            ]}
          />
        </Card>
        <Card>
          <CardHeader title="Tax rates" action={can('tenant:settings:manage') && <Button variant="outline" className="h-8 px-3" onClick={() => setTax({ name: '', ratePercent: '0', isInclusive: false, isActive: true })}><Plus size={14} /> Add</Button>} />
          <DataTable
            rows={taxes.data}
            loading={taxes.isLoading}
            rowKey={(t) => t.id}
            onRowClick={can('tenant:settings:manage') ? (t) => setTax({ id: t.id, name: t.name, ratePercent: String(num(t.ratePercent)), isInclusive: t.isInclusive, isActive: t.isActive }) : undefined}
            columns={[
              { key: 'n', header: 'Name', cell: (t) => <span className="font-medium">{t.name}</span> },
              { key: 'r', header: 'Rate', align: 'right', cell: (t) => `${num(t.ratePercent)}%` },
              { key: 'i', header: 'Prices', cell: (t) => (t.isInclusive ? 'Include tax' : 'Exclude tax') },
              { key: 's', header: '', cell: (t) => !t.isActive && <Badge>Inactive</Badge> },
            ]}
          />
        </Card>
      </div>

      <Modal open={Boolean(mfr)} onClose={() => setMfr(null)} title={mfr?.id ? 'Edit manufacturer' : 'New manufacturer'} size="sm"
        footer={<><Button variant="outline" onClick={() => setMfr(null)}>Cancel</Button><Button loading={createMfr.isPending || updateMfr.isPending} disabled={!mfr?.name.trim()} onClick={submitMfr}>Save</Button></>}>
        {mfr && (
          <div className="space-y-3">
            {mfrErr && <Alert>{errorMessage(mfrErr)}</Alert>}
            <Field label="Name"><Input value={mfr.name} onChange={(e) => setMfr({ ...mfr, name: e.target.value })} /></Field>
            <Field label="Country"><Input value={mfr.country} onChange={(e) => setMfr({ ...mfr, country: e.target.value })} /></Field>
            {mfr.id && <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={mfr.isActive} onChange={(e) => setMfr({ ...mfr, isActive: e.target.checked })} /> Active</label>}
          </div>
        )}
      </Modal>

      <Modal open={Boolean(tax)} onClose={() => setTax(null)} title={tax?.id ? 'Edit tax rate' : 'New tax rate'} size="sm"
        footer={<><Button variant="outline" onClick={() => setTax(null)}>Cancel</Button><Button loading={createTax.isPending || updateTax.isPending} disabled={!tax?.name.trim()} onClick={submitTax}>Save</Button></>}>
        {tax && (
          <div className="space-y-3">
            {taxErr && <Alert>{errorMessage(taxErr)}</Alert>}
            <Field label="Name"><Input value={tax.name} onChange={(e) => setTax({ ...tax, name: e.target.value })} placeholder="VAT 18%" /></Field>
            <Field label="Rate (%)"><Input type="number" min="0" max="100" step="0.0001" value={tax.ratePercent} onChange={(e) => setTax({ ...tax, ratePercent: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={tax.isInclusive} onChange={(e) => setTax({ ...tax, isInclusive: e.target.checked })} /> Selling prices already include this tax</label>
            {tax.id && <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={tax.isActive} onChange={(e) => setTax({ ...tax, isActive: e.target.checked })} /> Active</label>}
          </div>
        )}
      </Modal>
    </div>
  );
}
