export function money(value: number, currency: string): string {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(value);
  } catch {
    return `${currency} ${value.toFixed(2)}`;
  }
}

export function qty(value: number): string {
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 3 }).format(value);
}

export function dateTime(iso: string | null, timeZone?: string): string {
  if (!iso) return '-';
  try {
    return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short', timeZone }).format(new Date(iso));
  } catch {
    return new Date(iso).toLocaleString();
  }
}

export function shortDay(yyyyMmDd: string): string {
  const [y, m, d] = yyyyMmDd.split('-').map(Number);
  return new Intl.DateTimeFormat(undefined, { weekday: 'short' }).format(new Date(Date.UTC(y, m - 1, d, 12)));
}

/** Percentage change, or null when there is no baseline. */
export function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return ((current - previous) / previous) * 100;
}

/** API decimals arrive as strings (exact); convert only for display. */
export function num(v: string | number | null | undefined): number {
  if (v === null || v === undefined || v === '') return 0;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

/** 'YYYY-MM-DD' (or ISO) -> localized calendar date, without time-zone shifting. */
export function dateOnly(v: string | null | undefined): string {
  if (!v) return '-';
  const [y, m, d] = v.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return v;
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeZone: 'UTC' }).format(new Date(Date.UTC(y, m - 1, d)));
}

/** Whole days from today (local calendar) to a 'YYYY-MM-DD' date. */
export function daysUntil(v: string | null | undefined): number | null {
  if (!v) return null;
  const [y, m, d] = v.slice(0, 10).split('-').map(Number);
  const now = new Date();
  const today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((Date.UTC(y, m - 1, d) - today) / 86_400_000);
}

export function expiryTone(daysLeft: number | null, warnDays = 30): 'danger' | 'warning' | 'success' | 'neutral' {
  if (daysLeft === null) return 'neutral';
  if (daysLeft < 0) return 'danger';
  if (daysLeft <= warnDays) return 'warning';
  return 'success';
}

export function titleCase(v: string): string {
  return v.toLowerCase().replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

export function todayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Brand name plus strength, unless the brand name already contains it ("Amoxicillin 500mg" + "500 mg"). */
export function productName(brandName: string, strength?: string | null): string {
  if (!strength) return brandName;
  const squash = (s: string) => s.toLowerCase().replace(/\s+/g, '');
  return squash(brandName).includes(squash(strength)) ? brandName : `${brandName} ${strength}`;
}
