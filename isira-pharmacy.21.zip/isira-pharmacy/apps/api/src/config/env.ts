import { Global, Module } from '@nestjs/common';
import { z } from 'zod';

const bool = (def: 'true' | 'false') => z.enum(['true', 'false']).default(def).transform((v) => v === 'true');

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(4000),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  WEB_ORIGIN: z.string().url().default('http://localhost:3000'),
  /** Product name used in emails, API docs and exports. Each pharmacy's own name comes from Settings. */
  APP_NAME: z.string().min(1).default('Isira Pharmacy'),
  COOKIE_NAME: z.string().min(1).default('kx_session'),
  /** auto = Secure cookie in production when WEB_ORIGIN is https (a plain-http LAN install still works). */
  COOKIE_SECURE: z.enum(['auto', 'true', 'false']).default('auto'),
  SESSION_IDLE_MINUTES: z.coerce.number().int().min(5).default(480),
  SESSION_MAX_HOURS: z.coerce.number().int().min(1).default(24),
  PASSWORD_RESET_MINUTES: z.coerce.number().int().min(5).default(30),
  LOGIN_MAX_ATTEMPTS: z.coerce.number().int().min(3).default(5),
  LOGIN_LOCK_MINUTES: z.coerce.number().int().min(1).default(15),
  /** Reverse proxies in front of the API: false/0, true (=1), or a hop count (web app + Caddy = 2). Used for client IPs in rate limits and audit logs. */
  TRUST_PROXY: z.string().default('false').transform((v) => (v === 'true' ? 1 : v === 'false' || v === '' ? 0 : Number(v))).pipe(z.number().int().min(0).max(5)),
  SWAGGER_ENABLED: bool('true'),
  // ---- file storage (Phase 8): S3-compatible (MinIO in development) when S3_ENDPOINT + S3_BUCKET are set, else local disk ----
  S3_ENDPOINT: z.string().url().optional().or(z.literal('').transform(() => undefined)),
  S3_REGION: z.string().default('us-east-1'),
  S3_BUCKET: z.string().optional(),
  S3_ACCESS_KEY: z.string().optional(),
  S3_SECRET_KEY: z.string().optional(),
  S3_FORCE_PATH_STYLE: bool('true'),
  STORAGE_DIR: z.string().default('./storage'),
  // ---- background jobs and email (Phase 11) ----
  /** BullMQ queue. Without it the worker falls back to an in-process timer and emails are sent inline. */
  REDIS_URL: z.string().optional().or(z.literal('').transform(() => undefined)),
  SMTP_HOST: z.string().optional().or(z.literal('').transform(() => undefined)),
  SMTP_PORT: z.coerce.number().int().default(587),
  SMTP_SECURE: bool('false'),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  MAIL_FROM: z.string().default('Kynex Pharmacy <no-reply@kynex.local>'),
  /** How often the worker scans for low stock and expiry (minutes). */
  ALERT_SCAN_MINUTES: z.coerce.number().int().min(5).max(1440).default(60),
  // ---- hardening (Phase 12) ----
  /** Encrypts TOTP secrets and signs login challenges. Required in production (32+ random characters). */
  MFA_ENCRYPTION_KEY: z.string().min(32).optional().or(z.literal('').transform(() => undefined)),
}).superRefine((v, ctx) => {
  if (v.NODE_ENV === 'production' && !v.MFA_ENCRYPTION_KEY) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['MFA_ENCRYPTION_KEY'], message: 'is required in production (use 32+ random characters)' });
  }
});

export type Env = z.infer<typeof envSchema>;
export const ENV = Symbol('ENV');

export function loadEnv(raw: NodeJS.ProcessEnv = process.env): Env {
  const parsed = envSchema.safeParse(raw);
  if (!parsed.success) {
    const problems = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
    throw new Error(`Invalid environment configuration: ${problems}`);
  }
  return parsed.data;
}

@Global()
@Module({ providers: [{ provide: ENV, useFactory: () => loadEnv() }], exports: [ENV] })
export class ConfigModule {}
