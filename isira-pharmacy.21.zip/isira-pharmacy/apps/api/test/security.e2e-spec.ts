import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { base32Decode, currentStep, totp } from '../src/auth/mfa.service';
import { RedisThrottlerStorage } from '../src/common/throttler-storage';
import { bootApp, expectStatus, login, uid } from './helpers';

const PASSWORD = 'Str0ng-Passw0rd!';
const code = (secret: string, offset = 0) => totp(base32Decode(secret), currentStep() + offset);

describe('Two-factor authentication and hardening (Phase 12)', () => {
  let app: INestApplication;
  beforeAll(async () => {
    app = await bootApp();
  });
  afterAll(async () => {
    await app.close();
  });

  async function newUser() {
    const owner = await login(app, 'owner@demo.local');
    const roles = await owner.get('/roles');
    const role = roles.body.find((r: { name: string }) => r.name.toLowerCase().includes('pharmacist')) ?? roles.body[0];
    const email = `mfa-${uid().toLowerCase()}@demo.local`;
    const u = await owner.post('/users', { email, fullName: 'Mfa Tester', password: PASSWORD, branchRoles: [{ branchId: owner.branchId, roleId: role.id }] });
    expectStatus(u, 201);
    return { owner, email, id: u.body.id as string };
  }

  const csrf = { 'X-Kynex-Csrf': '1' };

  it('enrols, then requires a second factor at login, rejects replays and accepts a recovery code once', async () => {
    const { email } = await newUser();
    const agent = request.agent(app.getHttpServer());
    expectStatus(await agent.post('/v1/auth/login').send({ email, password: PASSWORD }), 200);

    const setup = await agent.post('/v1/auth/mfa/setup').set(csrf);
    expectStatus(setup, 200);
    expect(setup.body.otpauthUrl).toMatch(/^otpauth:\/\/totp\//);
    const secret: string = setup.body.secret;

    expect((await agent.post('/v1/auth/mfa/enable').set(csrf).send({ code: '000000' })).status).toBe(400);
    const enabled = await agent.post('/v1/auth/mfa/enable').set(csrf).send({ code: code(secret) });
    expectStatus(enabled, 200);
    expect(enabled.body.recoveryCodes).toHaveLength(10);
    expect((await agent.get('/v1/auth/me')).body.user.mfaEnabled).toBe(true);
    expect((await agent.get('/v1/auth/mfa')).body).toEqual(expect.objectContaining({ enabled: true, recoveryCodesLeft: 10 }));

    // password alone no longer signs in
    const fresh = request.agent(app.getHttpServer());
    const step1 = await fresh.post('/v1/auth/login').send({ email, password: PASSWORD });
    expectStatus(step1, 200);
    expect(step1.body.mfaRequired).toBe(true);
    expect(step1.headers['set-cookie']).toBeUndefined();
    expect((await fresh.get('/v1/auth/me')).status).toBe(401);

    // the enrolment code was already used for this step, so use the next window's code
    const next = code(secret, 1);
    expect((await fresh.post('/v1/auth/login/mfa').send({ challenge: step1.body.challenge, code: '123456' })).status).toBe(401);
    expect((await fresh.post('/v1/auth/login/mfa').send({ challenge: 'bogus.challenge-token-value', code: next })).status).toBe(401);
    const ok = await fresh.post('/v1/auth/login/mfa').send({ challenge: step1.body.challenge, code: next });
    expectStatus(ok, 200);
    expect(ok.body.user.email).toBe(email);
    expectStatus(await fresh.get('/v1/auth/me'), 200);

    // the same code cannot be replayed
    const again = request.agent(app.getHttpServer());
    const s2 = await again.post('/v1/auth/login').send({ email, password: PASSWORD });
    expect((await again.post('/v1/auth/login/mfa').send({ challenge: s2.body.challenge, code: next })).status).toBe(401);

    // recovery code works once
    const recovery: string = enabled.body.recoveryCodes[0];
    expectStatus(await again.post('/v1/auth/login/mfa').send({ challenge: s2.body.challenge, code: recovery.toUpperCase() }), 200);
    const third = request.agent(app.getHttpServer());
    const s3 = await third.post('/v1/auth/login').send({ email, password: PASSWORD });
    expect((await third.post('/v1/auth/login/mfa').send({ challenge: s3.body.challenge, code: recovery })).status).toBe(401);
    expect((await again.get('/v1/auth/mfa')).body.recoveryCodesLeft).toBe(9);

    // disabling needs the password and a valid code
    expect((await again.post('/v1/auth/mfa/disable').set(csrf).send({ password: 'wrong-password', code: enabled.body.recoveryCodes[1] })).status).toBe(400);
    expect((await again.post('/v1/auth/mfa/disable').set(csrf).send({ password: PASSWORD, code: enabled.body.recoveryCodes[1] })).status).toBe(204);
    const plain = await request(app.getHttpServer()).post('/v1/auth/login').send({ email, password: PASSWORD });
    expect(plain.body.mfaRequired).toBeUndefined();
    expect(plain.body.user.mfaEnabled).toBe(false);
  });

  it('lets an administrator reset a locked-out user and signs them out', async () => {
    const { owner, email, id } = await newUser();
    const agent = request.agent(app.getHttpServer());
    await agent.post('/v1/auth/login').send({ email, password: PASSWORD });
    const setup = await agent.post('/v1/auth/mfa/setup').set(csrf);
    expectStatus(await agent.post('/v1/auth/mfa/enable').set(csrf).send({ code: code(setup.body.secret) }), 200);

    const cashier = await login(app, 'cashier@demo.local');
    expect((await cashier.post(`/users/${id}/mfa/reset`)).status).toBe(403);
    expect((await owner.post(`/users/${id}/mfa/reset`)).status).toBe(204);
    expect((await agent.get('/v1/auth/me')).status).toBe(401);
    const res = await request(app.getHttpServer()).post('/v1/auth/login').send({ email, password: PASSWORD });
    expect(res.body.user.mfaEnabled).toBe(false);
  });

  it('never returns MFA secrets in user listings', async () => {
    const owner = await login(app, 'owner@demo.local');
    const list = await owner.get('/users?pageSize=100');
    expectStatus(list, 200);
    const json = JSON.stringify(list.body);
    expect(json).not.toContain('mfaSecret');
    expect(json).not.toContain('mfaRecoveryCodes');
  });

  it('sends security headers on API responses', async () => {
    const res = await request(app.getHttpServer()).get('/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  it('shares rate-limit counters through Redis and blocks after the limit', async () => {
    if (!process.env.REDIS_URL) return; // in-memory throttling is the default without Redis
    const store = new RedisThrottlerStorage(process.env.REDIS_URL);
    try {
      expect(await store.waitUntilReady()).toBe(true);
      const key = `test-${uid()}`;
      const hits = [];
      for (let i = 0; i < 4; i++) hits.push(await store.increment(key, 5_000, 3, 2_000, 'default'));
      expect(hits.map((h) => h.totalHits)).toEqual([1, 2, 3, 4]);
      expect(hits[2].isBlocked).toBe(false);
      expect(hits[3].isBlocked).toBe(true);
      expect(hits[3].timeToBlockExpire).toBeGreaterThan(0);
      // a second instance sees the same counters
      const other = new RedisThrottlerStorage(process.env.REDIS_URL);
      expect(await other.waitUntilReady()).toBe(true);
      expect((await other.increment(key, 5_000, 3, 2_000, 'default')).isBlocked).toBe(true);
      await other.onModuleDestroy();
    } finally {
      await store.onModuleDestroy();
    }
  });
});
