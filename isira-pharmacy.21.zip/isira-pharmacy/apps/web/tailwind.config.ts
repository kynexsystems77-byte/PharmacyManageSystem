import type { Config } from 'tailwindcss';

const v = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: v('bg'),
        surface: v('surface'),
        subtle: v('subtle'),
        line: v('line'),
        fg: v('fg'),
        'fg-muted': v('fg-muted'),
        brand: v('brand'),
        'brand-fg': v('brand-fg'),
        success: v('success'),
        warning: v('warning'),
        danger: v('danger'),
      },
      borderRadius: { xl: '0.875rem' },
      boxShadow: { card: '0 1px 2px rgb(0 0 0 / 0.04), 0 1px 3px rgb(0 0 0 / 0.06)' },
    },
  },
  plugins: [],
} satisfies Config;
