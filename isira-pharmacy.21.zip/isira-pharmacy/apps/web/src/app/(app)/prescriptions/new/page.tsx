'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Forbidden, PageHeader, useToast } from '@/components/kit';
import { emptyRx, PrescriptionForm, rxBody } from '@/components/prescription-form';
import { Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Customer, Prescription } from '@/lib/types';

export default function NewPrescriptionPage() {
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const customerId = useSearchParams().get('customerId');
  const customer = useBranchQuery<Customer>(customerId ? `/customers/${customerId}` : null);
  const create = useApiMutation<object, Prescription>('POST', '/prescriptions', { onSuccess: (p) => { toast.success('Prescription saved'); router.push(`/prescriptions/${p.id}`); } });
  if (!can('prescription:manage')) return <Forbidden what="recording prescriptions" />;
  if (customerId && !customer.data) return <Skeleton className="h-64" />;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader back="/prescriptions" title="Record a prescription" subtitle="Attach the scan after saving." />
      <PrescriptionForm mode="create" initial={emptyRx(customer.data ?? null)} submitting={create.isPending} error={create.error} onSubmit={(d) => create.mutate(rxBody(d, 'create'))} onCancel={() => router.back()} />
    </div>
  );
}
