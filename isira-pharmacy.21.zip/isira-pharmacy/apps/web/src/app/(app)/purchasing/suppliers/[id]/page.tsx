'use client';

import { Pencil, Wallet } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { DataTable, KeyValue, PageHeader, Pagination } from '@/components/kit';
import { SupplierFormModal } from '@/components/supplier-form';
import { SupplierPaymentModal } from '@/components/supplier-payment';
import { Alert, Badge, Button, Card, CardHeader, Skeleton, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, money, num, titleCase } from '@/lib/format';
import { errorMessage, qs, useBranchQuery, usePaging, type Paged } from '@/lib/hooks';
import type { LedgerEntry, SupplierDetail } from '@/lib/types';
import { AlertTriangle, Receipt } from 'lucide-react';

export default function SupplierPage({ params }: { params: { id: string } }) {
  const { can, profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const { data: s, isLoading, error } = useBranchQuery<SupplierDetail>(`/suppliers/${params.id}`);
  const { page, setPage } = usePaging([params.id]);
  const ledger = useBranchQuery<Paged<LedgerEntry>>(`/suppliers/${params.id}/ledger${qs({ page, pageSize: 20 })}`, { keepPrevious: true });
  const [editing, setEditing] = useState(false);
  const [paying, setPaying] = useState(false);
  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !s) return <Alert>{errorMessage(error) || 'Supplier not found'}</Alert>;
  return (
    <div className="space-y-4">
      <PageHeader
        back="/purchasing/suppliers"
        title={s.name}
        subtitle={!s.isActive ? <Badge>Inactive</Badge> : s.paymentTermsDays ? `${s.paymentTermsDays}-day terms` : 'Pays on delivery'}
        actions={
          <>
            {can('supplier:manage') && <Button variant="outline" onClick={() => setEditing(true)}><Pencil size={16} /> Edit</Button>}
            {can('supplier:payment') && num(s.balance) > 0 && <Button onClick={() => setPaying(true)}><Wallet size={16} /> Pay supplier</Button>}
          </>
        }
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <StatTile label="We owe" value={money(num(s.balance), cur)} icon={<Wallet size={18} />} tone={num(s.balance) > 0 ? 'warning' : 'success'} hint={num(s.balance) < 0 ? 'Advance paid to the supplier' : 'Current balance'} />
        <StatTile label="Overdue" value={money(num(s.overdue), cur)} icon={<AlertTriangle size={18} />} tone={num(s.overdue) > 0 ? 'danger' : 'neutral'} hint="Past the due date" />
        <StatTile label="Open invoices" value={String(s.openInvoices.length)} icon={<Receipt size={18} />} hint="Received, not fully paid" />
      </div>
      <Card className="p-4">
        <KeyValue items={[
          { label: 'Contact', value: s.contactName }, { label: 'Phone', value: s.phone }, { label: 'Email', value: s.email },
          { label: 'Tax number', value: s.taxNumber }, { label: 'Address', value: s.address }, { label: 'Notes', value: s.notes },
        ]} />
      </Card>
      {s.openInvoices.length > 0 && (
        <Card>
          <CardHeader title="Open invoices (oldest first)" />
          <DataTable
            rows={s.openInvoices}
            rowKey={(i) => i.id}
            columns={[
              { key: 'n', header: 'GRN', cell: (i) => <Link className="font-mono text-xs text-brand hover:underline" href={`/purchasing/${i.id}`}>{i.number}</Link> },
              { key: 'inv', header: 'Invoice', cell: (i) => i.supplierInvoiceNo ?? '-' },
              { key: 'd', header: 'Date', cell: (i) => dateOnly(i.purchaseDate) },
              { key: 'due', header: 'Due', cell: (i) => <span className={i.overdue ? 'font-medium text-danger' : ''}>{dateOnly(i.dueDate)}{i.overdue ? ' · overdue' : ''}</span> },
              { key: 't', header: 'Total', align: 'right', cell: (i) => money(num(i.grandTotal), cur) },
              { key: 'o', header: 'Outstanding', align: 'right', cell: (i) => <span className="font-medium">{money(num(i.outstanding), cur)}</span> },
            ]}
          />
        </Card>
      )}
      <Card>
        <CardHeader title="Statement" action={<span className="text-xs text-fg-muted">Positive = we owe more</span>} />
        <DataTable
          rows={ledger.data?.data}
          loading={ledger.isLoading}
          rowKey={(e) => e.id}
          columns={[
            { key: 'd', header: 'Date', cell: (e) => dateTime(e.createdAt) },
            { key: 't', header: 'Entry', cell: (e) => titleCase(e.entryType) },
            { key: 'x', header: 'Details', cell: (e) => (e.referenceType === 'purchase' && e.referenceId ? <Link className="text-brand hover:underline" href={`/purchasing/${e.referenceId}`}>{e.description}</Link> : e.description ?? '-') },
            { key: 'a', header: 'Amount', align: 'right', cell: (e) => <span className={num(e.amount) < 0 ? 'text-success' : ''}>{money(num(e.amount), cur)}</span> },
            { key: 'b', header: 'Balance', align: 'right', cell: (e) => <span className="font-medium">{money(num(e.balance), cur)}</span> },
          ]}
        />
        {ledger.data && <Pagination page={ledger.data.meta.page} totalPages={ledger.data.meta.totalPages} total={ledger.data.meta.total} onPage={setPage} />}
      </Card>
      {editing && <SupplierFormModal open supplier={s} onClose={() => setEditing(false)} />}
      <SupplierPaymentModal open={paying} onClose={() => setPaying(false)} supplierId={s.id} supplierName={s.name} suggested={num(s.balance)} />
    </div>
  );
}
