/** Product name shown before sign-in and in the browser tab. After sign-in the pharmacy's own name (Settings) is used. */
export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME?.trim() || 'Isira Pharmacy';
