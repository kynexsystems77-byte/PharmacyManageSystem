import { Injectable, Logger } from '@nestjs/common';
import type { Prisma } from '@kynex/database';
import { TenantInfoService, todayIn } from '../common/core';
import { NotificationsService, type NewNotification } from '../notifications/notifications.module';
import { PrismaService, TenantDb } from '../prisma/prisma.service';

interface LowRow { productId: string; name: string; qty: number; reorder: number }

/** ISO week key (e.g. 2026-W41): a product's low-stock alert repeats at most weekly. */
function isoWeek(dateIso: string): string {
  const d = new Date(`${dateIso}T00:00:00Z`);
  const day = (d.getUTCDay() + 6) % 7;
  d.setUTCDate(d.getUTCDate() - day + 3);
  const firstThursday = new Date(Date.UTC(d.getUTCFullYear(), 0, 4));
  const week = 1 + Math.round(((d.getTime() - firstThursday.getTime()) / 86_400_000 - 3 + ((firstThursday.getUTCDay() + 6) % 7)) / 7);
  return `${d.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}

/**
 * Background work, always per tenant inside withTenant (Row-Level Security applies to the worker too).
 */
@Injectable()
export class AlertsService {
  private readonly logger = new Logger('Alerts');
  constructor(
    private readonly prisma: PrismaService,
    private readonly db: TenantDb,
    private readonly tenantInfo: TenantInfoService,
    private readonly notifications: NotificationsService,
  ) {}

  async activeTenants(): Promise<string[]> {
    const rows = await this.prisma.$queryRaw<{ id: string }[]>`SELECT id FROM system_list_active_tenants()`;
    return rows.map((r) => r.id);
  }

  async tenantsWithOutbox(): Promise<string[]> {
    const rows = await this.prisma.$queryRaw<{ tenant_id: string }[]>`SELECT tenant_id FROM system_tenants_with_pending_outbox()`;
    return rows.map((r) => r.tenant_id);
  }

  private async lowStock(tx: Prisma.TransactionClient, branchId: string, today: string, productIds?: string[]): Promise<LowRow[]> {
    return tx.$queryRaw<LowRow[]>`
      WITH st AS (
        SELECT sl.product_id, SUM(sl.quantity) AS qty
        FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
        WHERE sl.branch_id = ${branchId}::uuid AND b.status = 'ACTIVE' AND (b.expiry_date IS NULL OR b.expiry_date >= ${today}::date)
        GROUP BY sl.product_id)
      SELECT p.id AS "productId", p.brand_name AS name, COALESCE(st.qty, 0)::float8 AS qty, COALESCE(bps.reorder_level, p.reorder_level)::float8 AS reorder
      FROM products p
      LEFT JOIN st ON st.product_id = p.id
      LEFT JOIN branch_product_settings bps ON bps.product_id = p.id AND bps.branch_id = ${branchId}::uuid
      WHERE p.deleted_at IS NULL AND p.is_active AND COALESCE(bps.is_available, true)
        AND COALESCE(bps.reorder_level, p.reorder_level) > 0 AND COALESCE(st.qty, 0) <= COALESCE(bps.reorder_level, p.reorder_level)
        AND (${productIds ?? null}::uuid[] IS NULL OR p.id = ANY(${productIds ?? null}::uuid[]))
      ORDER BY COALESCE(st.qty, 0) / COALESCE(bps.reorder_level, p.reorder_level), p.brand_name`;
  }

  /** Daily summary alerts per branch: products to reorder, batches expiring soon, expired stock still on hand. */
  async scanTenant(tenantId: string): Promise<number> {
    return this.db.run(tenantId, async (tx) => {
      const t = await this.tenantInfo.get(tx);
      const today = todayIn(t.timezone);
      const branches = await tx.branch.findMany({ where: { deletedAt: null, isActive: true }, select: { id: true, name: true } });
      const out: NewNotification[] = [];
      for (const b of branches) {
        if (t.settings.lowStockAlerts) {
          const low = await this.lowStock(tx, b.id, today);
          if (low.length) {
            const out0 = low.filter((l) => l.qty <= 0).length;
            out.push({
              tenantId, branchId: b.id, type: 'LOW_STOCK', severity: out0 ? 'CRITICAL' : 'WARNING',
              title: `${low.length} product${low.length === 1 ? '' : 's'} to reorder at ${b.name}`,
              body: `${out0 ? `${out0} out of stock. ` : ''}Lowest: ${low.slice(0, 5).map((l) => `${l.name} (${l.qty})`).join(', ')}`,
              data: { link: '/inventory?filter=low', count: low.length }, dedupeKey: `low-summary:${b.id}:${today}`,
            });
          }
        }
        if (t.settings.expiryAlerts) {
          const exp = await tx.$queryRaw<{ soon: number; expired: number }[]>`
            SELECT COUNT(DISTINCT b.id) FILTER (WHERE b.expiry_date >= ${today}::date AND b.expiry_date <= ${today}::date + ${t.settings.expiryWarningDays}::int)::int AS soon,
                   COUNT(DISTINCT b.id) FILTER (WHERE b.expiry_date < ${today}::date)::int AS expired
            FROM stock_levels sl JOIN batches b ON b.id = sl.batch_id
            WHERE sl.branch_id = ${b.id}::uuid AND sl.quantity > 0 AND b.expiry_date IS NOT NULL`;
          const { soon, expired } = exp[0] ?? { soon: 0, expired: 0 };
          if (soon) out.push({
            tenantId, branchId: b.id, type: 'EXPIRING_SOON', severity: 'WARNING',
            title: `${soon} batch${soon === 1 ? '' : 'es'} expire within ${t.settings.expiryWarningDays} days at ${b.name}`,
            body: 'Sell these first or return them to the supplier.', data: { link: '/inventory/batches?view=expiring30' }, dedupeKey: `exp-soon:${b.id}:${today}`,
          });
          if (expired) out.push({
            tenantId, branchId: b.id, type: 'EXPIRED', severity: 'CRITICAL',
            title: `${expired} expired batch${expired === 1 ? '' : 'es'} still in stock at ${b.name}`,
            body: 'They cannot be sold. Write them off or return them.', data: { link: '/inventory/batches?view=expired' }, dedupeKey: `expired:${b.id}:${today}`,
          });
        }
      }
      return this.notifications.create(tx, out);
    }, { timeout: 120_000 });
  }

  /** Reacts to domain events written in the same transaction as the business change (transactional outbox). */
  async processOutbox(tenantId: string, limit = 100): Promise<{ processed: number; failed: number }> {
    return this.db.run(tenantId, async (tx) => {
      const events = await tx.$queryRaw<{ id: string; topic: string; payload: Record<string, unknown>; attempts: number }[]>`
        SELECT id, topic, payload, attempts FROM outbox_events
        WHERE status = 'PENDING' AND available_at <= now() ORDER BY available_at, id LIMIT ${limit} FOR UPDATE SKIP LOCKED`;
      let processed = 0, failed = 0;
      const t = await this.tenantInfo.get(tx);
      for (const e of events) {
        try {
          await tx.$executeRaw`SAVEPOINT outbox_event`;
          if (e.topic === 'sale.completed' && t.settings.lowStockAlerts) await this.afterSale(tx, tenantId, t.timezone, e.payload);
          await tx.$executeRaw`RELEASE SAVEPOINT outbox_event`;
          await tx.outboxEvent.update({ where: { id: e.id }, data: { status: 'PROCESSED', processedAt: new Date(), attempts: e.attempts + 1 } });
          processed++;
        } catch (err) {
          await tx.$executeRaw`ROLLBACK TO SAVEPOINT outbox_event`;
          const attempts = e.attempts + 1;
          failed++;
          await tx.outboxEvent.update({
            where: { id: e.id },
            data: { attempts, lastError: (err as Error).message.slice(0, 1000), status: attempts >= 5 ? 'FAILED' : 'PENDING', availableAt: new Date(Date.now() + 2 ** attempts * 30_000) },
          });
          if (attempts >= 5) {
            await this.notifications.create(tx, [{
              tenantId, type: 'JOB_FAILED', severity: 'CRITICAL', title: `Background event "${e.topic}" failed`, body: (err as Error).message.slice(0, 300), dedupeKey: `outbox-failed:${e.id}`,
            }]);
          }
        }
      }
      return { processed, failed };
    });
  }

  /** Per-product low-stock alert right after a sale pushes a product to/below its reorder level. */
  private async afterSale(tx: Prisma.TransactionClient, tenantId: string, timezone: string, payload: Record<string, unknown>) {
    const branchId = String(payload.branchId);
    const productIds = (payload.productIds as string[] | undefined) ?? [];
    if (!productIds.length) return;
    const today = todayIn(timezone);
    const low = await this.lowStock(tx, branchId, today, productIds);
    await this.notifications.create(tx, low.map((l) => ({
      tenantId, branchId, type: 'LOW_STOCK' as const, severity: l.qty <= 0 ? ('CRITICAL' as const) : ('WARNING' as const),
      title: l.qty <= 0 ? `Out of stock: ${l.name}` : `Low stock: ${l.name} (${l.qty} left)`,
      body: `Reorder level is ${l.reorder}.`, data: { link: `/medicines/${l.productId}`, productId: l.productId },
      dedupeKey: `low:${branchId}:${l.productId}:${isoWeek(today)}`,
    })));
  }

  /** Housekeeping: expired idempotency keys, sessions, reset tokens and very old notifications. */
  async cleanupTenant(tenantId: string) {
    return this.db.run(tenantId, async (tx) => {
      const idem = await tx.idempotencyKey.deleteMany({ where: { expiresAt: { lt: new Date() } } });
      const sessions = await tx.session.deleteMany({ where: { OR: [{ expiresAt: { lt: new Date(Date.now() - 30 * 86_400_000) } }, { revokedAt: { lt: new Date(Date.now() - 30 * 86_400_000) } }] } });
      const tokens = await tx.passwordResetToken.deleteMany({ where: { expiresAt: { lt: new Date(Date.now() - 86_400_000) } } });
      const notes = await tx.notification.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 180 * 86_400_000) } } });
      const outbox = await tx.outboxEvent.deleteMany({ where: { status: 'PROCESSED', processedAt: { lt: new Date(Date.now() - 14 * 86_400_000) } } });
      const result = { idempotencyKeys: idem.count, sessions: sessions.count, resetTokens: tokens.count, notifications: notes.count, outboxEvents: outbox.count };
      this.logger.log(`cleanup ${tenantId}: ${JSON.stringify(result)}`);
      return result;
    }, { timeout: 120_000 });
  }

  /** Lets owners/managers know a background job keeps failing. */
  async notifyJobFailed(tenantId: string | undefined, jobName: string, message: string) {
    const tenants = tenantId ? [tenantId] : await this.activeTenants();
    for (const t of tenants) {
      await this.db.run(t, (tx) => this.notifications.create(tx, [{
        tenantId: t, type: 'JOB_FAILED', severity: 'CRITICAL', title: `Background job "${jobName}" failed`, body: message.slice(0, 300),
        dedupeKey: `job-failed:${jobName}:${new Date().toISOString().slice(0, 13)}`,
      }]));
    }
  }
}
