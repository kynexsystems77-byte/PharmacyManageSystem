import { INestApplication } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { addStock, bootApp, CSRF, createProduct, expectStatus, isoDay, login, uid, type Session } from './helpers';

const key = () => randomUUID().replace(/-/g, '');
const phone = () => `07${Math.floor(Math.random() * 1e8).toString().padStart(8, '0')}`;
// smallest valid PNG (1x1)
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');

describe('Customers and prescriptions (Phase 8)', () => {
  let app: INestApplication;
  let owner: Session;
  beforeAll(async () => {
    app = await bootApp();
    owner = await login(app, 'owner@demo.local');
  });
  afterAll(async () => {
    await app.close();
  });

  async function ensureShift(s: Session) {
    const mine = await s.get('/registers/my-shift');
    if (mine.body.current) return;
    const reg = await owner.post('/registers', { name: `Till ${uid()}` });
    expectStatus(await s.post(`/registers/${reg.body.id}/open`, { openingBalance: 0 }), 201);
  }

  it('creates customers with codes, refuses duplicate phones and guards the credit limit', async () => {
    const p = phone();
    const c = await owner.post('/customers', { fullName: 'Kamala Perera', phone: p });
    expectStatus(c, 201);
    expect(c.body.code).toMatch(/^C-\d{6}$/);
    expect((await owner.post('/customers', { fullName: 'Someone Else', phone: p })).status).toBe(409);

    const cashier = await login(app, 'cashier@demo.local');
    const withCredit = await cashier.post('/customers', { fullName: 'Credit Try', phone: phone(), creditLimit: 500 });
    expect(withCredit.status).toBe(403);
    const plain = await cashier.post('/customers', { fullName: 'Walk In Regular', phone: phone() });
    expectStatus(plain, 201);
    expect((await cashier.patch(`/customers/${plain.body.id}`, { creditLimit: 100 })).status).toBe(403);
    expectStatus(await owner.patch(`/customers/${plain.body.id}`, { creditLimit: 100 }), 200);

    const found = await cashier.get(`/customers?search=${p.slice(-6)}`);
    expect(found.body.data.map((x: { id: string }) => x.id)).toContain(c.body.id);
  });

  it('records a prescription, attaches a scan, and dispenses it through a sale', async () => {
    await ensureShift(owner);
    const cust = await owner.post('/customers', { fullName: `Rx Patient ${uid()}`, phone: phone() });
    const rxProduct = await createProduct(owner, { requiresPrescription: true, sellingPrice: 10 });
    await addStock(owner, rxProduct.id, { quantity: 100 });

    const rx = await owner.post('/prescriptions', {
      customerId: cust.body.id, doctorName: 'Dr. Silva', doctorRegistration: 'SLMC 12345', prescribedDate: isoDay(-1), validUntil: isoDay(30),
      items: [{ medicineName: rxProduct.brandName, productId: rxProduct.id, dosage: '500 mg', frequency: 'twice daily', durationDays: 5, quantityPrescribed: 10 }],
    });
    expectStatus(rx, 201);
    expect(rx.body.status).toBe('ACTIVE');

    const up = await owner.agent.post(`/v1/prescriptions/${rx.body.id}/attachments`).set(CSRF).set('X-Branch-Id', owner.branchId).attach('file', PNG, { filename: 'scan.png', contentType: 'image/png' });
    expectStatus(up, 201);
    expect(up.body.mimeType).toBe('image/png');
    const fake = await owner.agent.post(`/v1/prescriptions/${rx.body.id}/attachments`).set(CSRF).attach('file', Buffer.from('not really a pdf'), { filename: 'x.pdf', contentType: 'application/pdf' });
    expect(fake.status).toBe(400);
    const dl = await owner.agent.get(`/v1/attachments/${up.body.id}/download`);
    expect(dl.status).toBe(200);
    expect(dl.headers['content-type']).toBe('image/png');

    const itemId = rx.body.prescriptionItems[0].id;
    const sale1 = await owner.post('/sales', {
      idempotencyKey: key(), customerId: cust.body.id, prescriptionId: rx.body.id,
      items: [{ productId: rxProduct.id, quantity: 4, prescriptionItemId: itemId }], payments: [{ method: 'CARD', amount: 40 }],
    });
    expectStatus(sale1, 201);
    let detail = await owner.get(`/prescriptions/${rx.body.id}`);
    expect(detail.body.status).toBe('PARTIALLY_DISPENSED');
    expect(Number(detail.body.prescriptionItems[0].quantityDispensed)).toBe(4);
    expect(detail.body.sales).toHaveLength(1);
    expect(detail.body.attachments).toHaveLength(1);

    expectStatus(await owner.post('/sales', {
      idempotencyKey: key(), customerId: cust.body.id, prescriptionId: rx.body.id,
      items: [{ productId: rxProduct.id, quantity: 6, prescriptionItemId: itemId }], payments: [{ method: 'CARD', amount: 60 }],
    }), 201);
    detail = await owner.get(`/prescriptions/${rx.body.id}`);
    expect(detail.body.status).toBe('DISPENSED');

    // a dispensed prescription can no longer be used
    const again = await owner.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, prescriptionId: rx.body.id, items: [{ productId: rxProduct.id, quantity: 1 }], payments: [{ method: 'CARD', amount: 10 }] });
    expect(again.status).toBe(422);

    const history = await owner.get(`/customers/${cust.body.id}`);
    expect(history.body.stats.visits).toBe(2);
    expect(history.body.prescriptions[0].id).toBe(rx.body.id);
  });

  it('treats prescriptions past their validity as expired', async () => {
    const cust = await owner.post('/customers', { fullName: `Old Rx ${uid()}`, phone: phone() });
    const rx = await owner.post('/prescriptions', { customerId: cust.body.id, doctorName: 'Dr. Old', prescribedDate: isoDay(-60), validUntil: isoDay(-30), items: [{ medicineName: 'Anything' }] });
    expectStatus(rx, 201);
    const got = await owner.get(`/prescriptions/${rx.body.id}`);
    expect(got.body.status).toBe('EXPIRED');
    expect(got.body.dispensable).toBe(false);
    const list = await owner.get(`/prescriptions?customerId=${cust.body.id}&dispensable=true`);
    expect(list.body.data).toHaveLength(0);
  });

  it("lists receivables and keeps a customer's statement", async () => {
    await ensureShift(owner);
    const cust = await owner.post('/customers', { fullName: `Owing ${uid()}`, phone: phone(), creditLimit: 1000 });
    const p = await createProduct(owner, { sellingPrice: 10 });
    await addStock(owner, p.id, { quantity: 50 });
    expectStatus(await owner.post('/sales', { idempotencyKey: key(), customerId: cust.body.id, items: [{ productId: p.id, quantity: 20 }], payments: [{ method: 'CASH', amount: 50 }, { method: 'CUSTOMER_CREDIT', amount: 150 }] }), 201);
    expectStatus(await owner.post(`/customers/${cust.body.id}/payments`, { amount: 100, method: 'BANK_TRANSFER', reference: 'BT-9' }), 201);
    const rec = await owner.get('/customers/receivables');
    expect(rec.body.customers.find((c: { id: string }) => c.id === cust.body.id).balance).toBe('50.00');
    const ledger = await owner.get(`/customers/${cust.body.id}/ledger`);
    expect(ledger.body.data.map((e: { entryType: string; balance: string }) => [e.entryType, e.balance])).toEqual([['PAYMENT', '50.00'], ['SALE_ON_CREDIT', '150.00']]);
    expect((await owner.del(`/customers/${cust.body.id}`)).status).toBe(409);
  });
});
