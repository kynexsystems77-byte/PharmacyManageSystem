import { ForbiddenException, Injectable } from '@nestjs/common';
import { PERMISSION_KEYS } from '@kynex/contracts';
import type { Prisma } from '@kynex/database';
import type { AuthContext } from '../common/request-context';

export interface LoadedAccess {
  branchIds: Set<string>;
  permissionsByBranch: Map<string, Set<string>>;
  allPermissions: Set<string>;
}

@Injectable()
export class AccessService {
  /** Resolves what a user may do, per branch. Owners hold every permission in every active branch. */
  async load(tx: Prisma.TransactionClient, user: { id: string; isOwner: boolean }): Promise<LoadedAccess> {
    const permissionsByBranch = new Map<string, Set<string>>();

    if (user.isOwner) {
      const branches = await tx.branch.findMany({ where: { deletedAt: null, isActive: true }, select: { id: true } });
      for (const b of branches) permissionsByBranch.set(b.id, new Set<string>(PERMISSION_KEYS));
      return { branchIds: new Set(permissionsByBranch.keys()), permissionsByBranch, allPermissions: new Set<string>(PERMISSION_KEYS) };
    }

    const rows = await tx.userBranchRole.findMany({
      where: { userId: user.id, branch: { isActive: true, deletedAt: null } },
      select: { branchId: true, role: { select: { rolePermissions: { select: { permission: { select: { key: true } } } } } } },
    });
    const allPermissions = new Set<string>();
    for (const row of rows) {
      const set = permissionsByBranch.get(row.branchId) ?? new Set<string>();
      for (const rp of row.role.rolePermissions) {
        set.add(rp.permission.key);
        allPermissions.add(rp.permission.key);
      }
      permissionsByBranch.set(row.branchId, set);
    }
    return { branchIds: new Set(permissionsByBranch.keys()), permissionsByBranch, allPermissions };
  }

  /** Profile returned to the web app after login and on /auth/me. */
  async profile(tx: Prisma.TransactionClient, userId: string) {
    const user = await tx.user.findUniqueOrThrow({
      where: { id: userId },
      select: { id: true, email: true, fullName: true, isOwner: true, mfaEnabledAt: true },
    });
    const tenant = await tx.tenant.findFirstOrThrow({
      select: { id: true, name: true, slug: true, currencyCode: true, timezone: true },
    });
    const access = await this.load(tx, user);
    const branches = await tx.branch.findMany({
      where: { id: { in: [...access.branchIds] } },
      select: { id: true, name: true, code: true },
      orderBy: { name: 'asc' },
    });
    const { mfaEnabledAt, ...rest } = user;
    return {
      user: { ...rest, mfaEnabled: mfaEnabledAt !== null },
      tenant,
      branches: branches.map((b) => ({ ...b, permissions: [...(access.permissionsByBranch.get(b.id) ?? [])].sort() })),
    };
  }

  /** Nobody may hand out permissions they do not hold themselves (privilege-escalation guard). */
  assertCanGrant(auth: AuthContext, permissionKeys: Iterable<string>): void {
    if (auth.isOwner) return;
    const denied = [...new Set(permissionKeys)].filter((k) => !auth.allPermissions.has(k));
    if (denied.length > 0) {
      throw new ForbiddenException(`You cannot grant permissions you do not have: ${denied.slice(0, 5).join(', ')}`);
    }
  }
}
