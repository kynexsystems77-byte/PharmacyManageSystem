'use client';

import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { MOVEMENT_TYPES } from '@kynex/contracts';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { LocationSelect } from '@/components/pickers';
import { Card, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num, qty, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Movement } from '@/lib/types';

export default function LedgerPage() {
  const params = useSearchParams();
  const { can, profile } = useAuth();
  const productId = params.get('productId') ?? '';
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [locationId, setLocationId] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, type, locationId, from, to, productId]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Movement>>(
    `/inventory/movements${qs({
      page, pageSize: 50, search: s, type, locationId, productId,
      from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined,
      to: to ? new Date(`${to}T23:59:59.999`).toISOString() : undefined,
    })}`,
    { keepPrevious: true },
  );
  return (
    <div>
      <PageHeader title="Stock ledger" subtitle="Every stock change, append-only. Mistakes are fixed with a reversing entry, never by editing." />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-[1fr_200px_180px_150px_150px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Product or batch" />
          <Select value={type} onChange={(e) => setType(e.target.value)} aria-label="Movement type">
            <option value="">All movement types</option>
            {MOVEMENT_TYPES.map((t) => <option key={t} value={t}>{titleCase(t)}</option>)}
          </Select>
          <LocationSelect value={locationId} onChange={setLocationId} allowAll />
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(m) => m.id}
          columns={[
            { key: 'w', header: 'When', cell: (m) => <span className="whitespace-nowrap">{dateTime(m.occurredAt)}</span> },
            { key: 'p', header: 'Product', cell: (m) => <span className="font-medium">{m.product.brandName}</span> },
            { key: 'b', header: 'Batch', cell: (m) => <span className="font-mono text-xs">{m.batch.batchNumber}</span> },
            { key: 't', header: 'Type', cell: (m) => titleCase(m.movementType) },
            { key: 'l', header: 'Location', cell: (m) => m.location.name },
            { key: 'r', header: 'Reason', cell: (m) => <span className="text-fg-muted">{m.reason ?? '-'}</span> },
            { key: 'u', header: 'By', cell: (m) => m.createdBy?.fullName ?? 'System' },
            ...(can('report:financial:view') ? [{ key: 'c', header: 'Unit cost', align: 'right' as const, cell: (m: Movement) => money(num(m.unitCost), profile.tenant.currencyCode) }] : []),
            { key: 'q', header: 'Qty', align: 'right', cell: (m) => <span className={num(m.quantityDelta) < 0 ? 'text-danger' : 'text-success'}>{num(m.quantityDelta) > 0 ? '+' : ''}{qty(num(m.quantityDelta))}</span> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
