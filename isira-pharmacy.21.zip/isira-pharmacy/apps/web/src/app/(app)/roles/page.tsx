'use client';

import { Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, Forbidden, Modal, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, Field, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { num } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { RoleRow } from '@/lib/types';

export default function RolesPage() {
  const router = useRouter();
  const { can } = useAuth();
  const toast = useToast();
  const { data, isLoading } = useBranchQuery<RoleRow[]>(can('role:read') ? '/roles' : null);
  const [form, setForm] = useState<{ name: string; description: string; copyFrom: string } | null>(null);
  const create = useApiMutation<object, RoleRow>('POST', '/roles', { onSuccess: (r) => { toast.success('Role created'); setForm(null); router.push(`/roles/${r.id}`); } });
  if (!can('role:read')) return <Forbidden what="roles" />;
  return (
    <div>
      <PageHeader title="Roles & permissions" subtitle="System roles are fixed; copy one to make a custom role." actions={can('role:manage') && <Button onClick={() => setForm({ name: '', description: '', copyFrom: '' })}><Plus size={16} /> New role</Button>} />
      <Card>
        <DataTable
          rows={data}
          loading={isLoading}
          rowKey={(r) => r.id}
          onRowClick={(r) => router.push(`/roles/${r.id}`)}
          columns={[
            { key: 'n', header: 'Role', cell: (r) => <div><p className="font-medium">{r.name}</p><p className="text-xs text-fg-muted">{r.description ?? ''}</p></div> },
            { key: 't', header: 'Type', cell: (r) => (r.isSystem ? <Badge>System</Badge> : <Badge tone="success">Custom</Badge>) },
            { key: 'p', header: 'Permissions', align: 'right', cell: (r) => r.permissions.length },
            { key: 'd', header: 'Max discount', align: 'right', cell: (r) => `${num(r.maxDiscountPercent)}%` },
            { key: 'u', header: 'Assignments', align: 'right', cell: (r) => r.assignedUsers },
          ]}
        />
      </Card>
      <Modal open={Boolean(form)} onClose={() => setForm(null)} title="New role" size="sm"
        footer={<><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button loading={create.isPending} disabled={(form?.name.trim().length ?? 0) < 2} onClick={() => {
          if (!form) return;
          const src = data?.find((r) => r.id === form.copyFrom);
          create.mutate({ name: form.name.trim(), description: form.description.trim() || undefined, permissions: src?.permissions ?? [], maxDiscountPercent: src ? num(src.maxDiscountPercent) : 0 });
        }}>Create</Button></>}>
        {form && (
          <div className="space-y-3">
            {create.error && <Alert>{errorMessage(create.error)}</Alert>}
            <Field label="Name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus placeholder="Senior cashier" /></Field>
            <Field label="Description"><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
            <Field label="Start from">
              <select value={form.copyFrom} onChange={(e) => setForm({ ...form, copyFrom: e.target.value })} className="h-10 w-full rounded-lg border border-line bg-surface px-2.5 text-sm">
                <option value="">No permissions</option>
                {data?.map((r) => <option key={r.id} value={r.id}>Copy of {r.name}</option>)}
              </select>
            </Field>
          </div>
        )}
      </Modal>
    </div>
  );
}
