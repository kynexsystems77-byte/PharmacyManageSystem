import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center p-4 text-center">
      <div>
        <p className="text-5xl font-semibold text-brand">404</p>
        <p className="mt-2 text-sm text-fg-muted">This page does not exist.</p>
        <Link href="/" className="mt-4 inline-block text-sm text-brand hover:underline">Back to the dashboard</Link>
      </div>
    </main>
  );
}
