import { Injectable, Logger, Module } from '@nestjs/common';
import type { Job } from 'bullmq';
import { CoreModule } from '../common/core';
import { ConfigModule } from '../config/env';
import { Mailer, MailerModule, type MailMessage } from '../jobs/mailer';
import { JobsModule } from '../jobs/queue';
import { NotificationsCoreModule } from '../notifications/notifications.module';
import { PrismaModule } from '../prisma/prisma.service';
import { AlertsService } from './alerts.service';

/** Job names. Fan-out jobs (scan-alerts, process-outbox, cleanup) enqueue one job per tenant. */
export type JobName = 'scan-alerts' | 'scan-tenant' | 'process-outbox' | 'outbox-tenant' | 'cleanup' | 'cleanup-tenant' | 'mail';

@Injectable()
export class JobProcessor {
  private readonly logger = new Logger('Jobs');
  constructor(private readonly alerts: AlertsService, private readonly mailer: Mailer) {}

  /** Runs one job. `enqueue` is used for fan-out; without a queue the per-tenant work runs directly. */
  async handle(name: JobName, data: Record<string, unknown>, enqueue?: (name: JobName, data: Record<string, unknown>) => Promise<unknown>): Promise<unknown> {
    switch (name) {
      case 'scan-alerts':
      case 'process-outbox':
      case 'cleanup': {
        const tenants = name === 'process-outbox' ? await this.alerts.tenantsWithOutbox() : await this.alerts.activeTenants();
        const child: JobName = name === 'scan-alerts' ? 'scan-tenant' : name === 'process-outbox' ? 'outbox-tenant' : 'cleanup-tenant';
        for (const tenantId of tenants) {
          if (enqueue) await enqueue(child, { tenantId });
          else await this.handle(child, { tenantId });
        }
        return { tenants: tenants.length };
      }
      case 'scan-tenant':
        return { created: await this.alerts.scanTenant(String(data.tenantId)) };
      case 'outbox-tenant':
        return this.alerts.processOutbox(String(data.tenantId));
      case 'cleanup-tenant':
        return this.alerts.cleanupTenant(String(data.tenantId));
      case 'mail':
        await this.mailer.send(data as unknown as MailMessage);
        return { sent: true };
      default:
        throw new Error(`Unknown job ${String(name)}`);
    }
  }

  async failed(job: Pick<Job, 'name' | 'data' | 'attemptsMade' | 'opts'>, err: Error) {
    const final = job.attemptsMade >= (job.opts.attempts ?? 1);
    this.logger.error(`Job ${job.name} failed (attempt ${job.attemptsMade}): ${err.message}`);
    if (final && job.name !== 'mail') {
      await this.alerts.notifyJobFailed((job.data as { tenantId?: string }).tenantId, job.name, err.message).catch((e: Error) => this.logger.error(e.message));
    }
  }
}

/** Everything the worker needs, without HTTP controllers. Also used by the tests. */
@Module({
  imports: [ConfigModule, PrismaModule, CoreModule, JobsModule, MailerModule, NotificationsCoreModule],
  providers: [AlertsService, JobProcessor],
  exports: [AlertsService, JobProcessor],
})
export class WorkerModule {}
