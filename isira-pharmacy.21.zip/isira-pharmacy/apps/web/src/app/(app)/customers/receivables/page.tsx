'use client';

import { Wallet } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { DataTable, PageHeader } from '@/components/kit';
import { Card, StatTile } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, money, num } from '@/lib/format';
import { useBranchQuery } from '@/lib/hooks';
import type { Receivables } from '@/lib/types';

export default function ReceivablesPage() {
  const router = useRouter();
  const { profile } = useAuth();
  const fmt = (v: string | number) => money(num(v), profile.tenant.currencyCode);
  const { data, isLoading } = useBranchQuery<Receivables>('/customers/receivables');
  return (
    <div className="space-y-4">
      <PageHeader title="Customer receivables" subtitle="Credit sales not yet paid, across all branches." />
      <div className="max-w-sm"><StatTile label="Total owed to the pharmacy" value={fmt(data?.total ?? 0)} icon={<Wallet size={18} />} tone="warning" /></div>
      <Card>
        <DataTable
          rows={data?.customers}
          loading={isLoading}
          rowKey={(c) => c.id}
          onRowClick={(c) => router.push(`/customers/${c.id}`)}
          empty={<p className="px-4 py-10 text-center text-sm text-fg-muted">Nobody owes anything.</p>}
          columns={[
            { key: 'n', header: 'Customer', cell: (c) => <div><p className="font-medium">{c.fullName}</p><p className="text-xs text-fg-muted">{[c.code, c.phone].filter(Boolean).join(' · ')}</p></div> },
            { key: 'l', header: 'Limit', align: 'right', cell: (c) => fmt(c.creditLimit) },
            { key: 'a', header: 'Last activity', cell: (c) => dateOnly(c.lastActivity) },
            { key: 'b', header: 'Owes', align: 'right', cell: (c) => <span className={`font-semibold ${num(c.balance) > num(c.creditLimit) && num(c.creditLimit) > 0 ? 'text-danger' : ''}`}>{fmt(c.balance)}</span> },
          ]}
        />
      </Card>
    </div>
  );
}
