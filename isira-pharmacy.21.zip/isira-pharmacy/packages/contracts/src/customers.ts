import { z } from 'zod';
import { dateOnlySchema, moneySchema, nullableText, optionalText, quantitySchema } from './common';
import { paginationSchema, uuidSchema } from './schemas';

/** Phase 8: customers (credit accounts) and prescriptions. */

const email = z.string().trim().email().max(254);

export const createCustomerSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  code: z.string().trim().toUpperCase().regex(/^[A-Z0-9-]{1,30}$/).optional(),
  phone: optionalText(40),
  email: email.optional().or(z.literal('').transform(() => undefined)),
  address: optionalText(300),
  dateOfBirth: dateOnlySchema.optional(),
  /** 0 = no credit allowed. Setting a limit needs customer:credit:manage. */
  creditLimit: moneySchema.default(0),
  notes: optionalText(1000),
});

export const updateCustomerSchema = z
  .object({
    fullName: z.string().trim().min(2).max(120).optional(),
    phone: nullableText(40),
    email: email.nullable().optional().or(z.literal('').transform(() => null)),
    address: nullableText(300),
    dateOfBirth: dateOnlySchema.nullable().optional(),
    creditLimit: moneySchema.optional(),
    notes: nullableText(1000),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const listCustomersQuerySchema = paginationSchema.extend({
  status: z.enum(['active', 'inactive', 'all']).default('active'),
  withBalance: z.enum(['true', 'false']).optional(),
  /** Only customers who owe money. */
  owing: z.enum(['true', 'false']).optional(),
});

export const customerPaymentSchema = z.object({
  amount: moneySchema.refine((v) => v > 0, 'Amount must be positive'),
  method: z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'OTHER']),
  reference: optionalText(120),
  note: optionalText(500),
});

// ---- prescriptions ----
export const prescriptionItemSchema = z.object({
  medicineName: z.string().trim().min(1).max(160),
  productId: uuidSchema.nullable().optional(),
  dosage: optionalText(80),
  frequency: optionalText(80),
  durationDays: z.coerce.number().int().min(0).max(3650).optional(),
  quantityPrescribed: quantitySchema.optional(),
  instructions: optionalText(300),
});

export const createPrescriptionSchema = z.object({
  customerId: uuidSchema,
  prescriptionNumber: optionalText(60),
  doctorName: z.string().trim().min(2).max(120),
  doctorRegistration: optionalText(60),
  prescribedDate: dateOnlySchema,
  validUntil: dateOnlySchema.nullable().optional(),
  notes: optionalText(1000),
  items: z.array(prescriptionItemSchema).max(50).default([]),
});

export const updatePrescriptionSchema = z
  .object({
    prescriptionNumber: nullableText(60),
    doctorName: z.string().trim().min(2).max(120).optional(),
    doctorRegistration: nullableText(60),
    prescribedDate: dateOnlySchema.optional(),
    validUntil: dateOnlySchema.nullable().optional(),
    notes: nullableText(1000),
    /** Replaces the items; items already dispensed cannot be removed. */
    items: z.array(prescriptionItemSchema.extend({ id: uuidSchema.optional() })).max(50).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update');

export const listPrescriptionsQuerySchema = paginationSchema.extend({
  customerId: uuidSchema.optional(),
  status: z.enum(['ACTIVE', 'PARTIALLY_DISPENSED', 'DISPENSED', 'EXPIRED', 'CANCELLED']).optional(),
  /** Only prescriptions that can still be dispensed today. */
  dispensable: z.enum(['true', 'false']).optional(),
});

export const ATTACHMENT_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'] as const;
export const ATTACHMENT_MAX_BYTES = 10 * 1024 * 1024;
