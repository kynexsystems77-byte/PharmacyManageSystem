'use client';

import { useState } from 'react';
import { ConfirmDialog, DataTable, KeyValue, PageHeader, useToast } from '@/components/kit';
import { Alert, Badge, Button, Card, CardHeader, Input, Skeleton } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateOnly, dateTime, num, qty, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Transfer } from '@/lib/types';
import { TRANSFER_TONE } from '@/lib/status';

export default function TransferPage({ params }: { params: { id: string } }) {
  const { can, branchId } = useAuth();
  const toast = useToast();
  const { data: t, isLoading, error } = useBranchQuery<Transfer>(`/inventory/transfers/${params.id}`);
  const [received, setReceived] = useState<Record<string, string>>({});
  const [confirmCancel, setConfirmCancel] = useState(false);
  const receive = useApiMutation<object>('POST', `/inventory/transfers/${params.id}/receive`, { onSuccess: () => toast.success('Transfer received into stock') });
  const cancel = useApiMutation<object>('POST', `/inventory/transfers/${params.id}/cancel`, { onSuccess: () => { toast.success('Transfer cancelled; stock returned'); setConfirmCancel(false); } });

  if (isLoading) return <Skeleton className="h-64" />;
  if (error || !t) return <Alert>{errorMessage(error) || 'Transfer not found'}</Alert>;
  const canReceive = t.status === 'DISPATCHED' && t.toBranch.id === branchId && can('inventory:transfer');
  const canCancel = t.status === 'DISPATCHED' && t.fromBranch.id === branchId && can('inventory:transfer');

  return (
    <div className="space-y-4">
      <PageHeader
        back="/inventory/transfers"
        title={t.number}
        subtitle={<Badge tone={TRANSFER_TONE[t.status]}>{t.status === 'DISPATCHED' ? 'In transit' : titleCase(t.status)}</Badge>}
        actions={canCancel && <Button variant="outline" onClick={() => setConfirmCancel(true)}>Cancel transfer</Button>}
      />
      <Card className="p-4">
        <KeyValue items={[
          { label: 'From', value: `${t.fromBranch.name} · ${t.fromLocation.name}` },
          { label: 'To', value: `${t.toBranch.name} · ${t.toLocation.name}` },
          { label: 'Dispatched', value: `${dateTime(t.dispatchedAt)} by ${t.createdBy.fullName}` },
          { label: 'Received', value: t.receivedAt ? `${dateTime(t.receivedAt)} by ${t.receivedBy?.fullName ?? '-'}` : '-' },
          { label: 'Note', value: t.note },
        ]} />
      </Card>
      <Card>
        <CardHeader title="Items" action={canReceive && <span className="text-xs text-fg-muted">Enter what actually arrived; shortfalls are recorded.</span>} />
        <DataTable
          rows={t.stockTransferItems}
          rowKey={(i) => i.id}
          columns={[
            { key: 'p', header: 'Product', cell: (i) => i.product.brandName },
            { key: 'b', header: 'Batch', cell: (i) => <span className="font-mono text-xs">{i.batch.batchNumber}</span> },
            { key: 'e', header: 'Expiry', cell: (i) => dateOnly(i.batch.expiryDate) },
            { key: 's', header: 'Sent', align: 'right', cell: (i) => `${qty(num(i.quantity))} ${i.product.baseUnit}` },
            {
              key: 'r', header: 'Received', align: 'right',
              cell: (i) =>
                canReceive ? (
                  <Input type="number" min="0" max={num(i.quantity)} step="0.001" className="ml-auto w-28 text-right" value={received[i.id] ?? String(num(i.quantity))} onChange={(e) => setReceived({ ...received, [i.id]: e.target.value })} />
                ) : t.status === 'RECEIVED' ? (
                  <span className={num(i.receivedQuantity) < num(i.quantity) ? 'text-warning' : ''}>{qty(num(i.receivedQuantity))}</span>
                ) : '-',
            },
          ]}
        />
        {canReceive && (
          <div className="flex justify-end border-t border-line p-3">
            <Button
              loading={receive.isPending}
              onClick={() => receive.mutate({ items: t.stockTransferItems.map((i) => ({ itemId: i.id, receivedQuantity: Number(received[i.id] ?? num(i.quantity)) })) })}
            >
              Receive into {t.toLocation.name}
            </Button>
          </div>
        )}
      </Card>
      {receive.error && <Alert>{errorMessage(receive.error)}</Alert>}
      <ConfirmDialog
        open={confirmCancel}
        title="Cancel transfer?"
        danger
        confirmLabel="Cancel transfer"
        loading={cancel.isPending}
        onClose={() => setConfirmCancel(false)}
        onConfirm={() => cancel.mutate({}, { onError: (e) => toast.error(errorMessage(e)) })}
        body={<p>All items go back into {t.fromLocation.name}. This cannot be undone.</p>}
      />
    </div>
  );
}
