'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Badge, Card, Input } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num, titleCase, todayIso } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import { SALE_TONE } from '@/lib/status';
import type { SaleListRow } from '@/lib/types';

export default function SalesPage() {
  const router = useRouter();
  const { profile } = useAuth();
  const cur = profile.tenant.currencyCode;
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [from, setFrom] = useState(todayIso());
  const [to, setTo] = useState(todayIso());
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, status, from, to]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<SaleListRow> & { totalSales: string }>(
    `/sales${qs({ page, pageSize: 25, search: s, status, from, to })}`,
    { keepPrevious: true },
  );
  return (
    <div>
      <PageHeader title="Invoices" subtitle={data ? `${data.meta.total} invoices · ${money(num(data.totalSales), cur)} sold in this range` : undefined} />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-[1fr_180px_160px_160px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Invoice number, customer or phone" />
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">All (excluding held)</option>
            {['COMPLETED', 'PARTIALLY_RETURNED', 'RETURNED', 'VOIDED'].map((x) => <option key={x} value={x}>{titleCase(x)}</option>)}
          </Select>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From" />
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To" />
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(r) => r.id}
          onRowClick={(r) => router.push(`/sales/${r.id}`)}
          empty={<p className="px-4 py-10 text-center text-sm text-fg-muted">No invoices in this range.</p>}
          columns={[
            { key: 'n', header: 'Invoice', cell: (r) => <span className="font-mono text-xs">{r.invoiceNo}</span> },
            { key: 'd', header: 'Time', cell: (r) => dateTime(r.soldAt) },
            { key: 'c', header: 'Customer', cell: (r) => r.customer?.fullName ?? <span className="text-fg-muted">Walk-in</span> },
            { key: 'u', header: 'Cashier', cell: (r) => r.cashier.fullName },
            { key: 'm', header: 'Paid by', cell: (r) => r.methods.map((m) => titleCase(m)).join(', ') || '-' },
            { key: 's', header: 'Status', cell: (r) => <Badge tone={SALE_TONE[r.status]}>{titleCase(r.status)}</Badge> },
            { key: 'i', header: 'Items', align: 'right', cell: (r) => r.itemCount },
            { key: 't', header: 'Total', align: 'right', cell: (r) => <span className={r.status === 'VOIDED' ? 'text-fg-muted line-through' : 'font-medium'}>{money(num(r.grandTotal), cur)}</span> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
