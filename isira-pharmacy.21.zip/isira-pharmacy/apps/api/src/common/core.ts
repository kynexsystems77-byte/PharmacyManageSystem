import { randomBytes } from 'node:crypto';
import { BadRequestException, Global, Injectable, Module } from '@nestjs/common';
import { Prisma } from '@kynex/database';

// ---------------------------------------------------------------------------------------------
// Decimal helpers. Money and quantities are NEVER handled as floats in business logic.
// ---------------------------------------------------------------------------------------------
export const Decimal = Prisma.Decimal;
export type Dec = Prisma.Decimal;

export function dec(v: Prisma.Decimal.Value | null | undefined): Dec {
  return new Decimal(v ?? 0);
}

/** Rounds to currency precision (half-up, 2 dp). */
export function money2(v: Prisma.Decimal.Value): Dec {
  return new Decimal(v).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
}

export function qty3(v: Prisma.Decimal.Value): Dec {
  return new Decimal(v).toDecimalPlaces(3, Decimal.ROUND_HALF_UP);
}

export function price4(v: Prisma.Decimal.Value): Dec {
  return new Decimal(v).toDecimalPlaces(4, Decimal.ROUND_HALF_UP);
}

export function sumDec(values: Prisma.Decimal.Value[]): Dec {
  return values.reduce<Dec>((acc, v) => acc.plus(v), new Decimal(0));
}

// ---------------------------------------------------------------------------------------------
// UUIDv7 (time-ordered) for rows written with raw SQL (Prisma generates them for normal creates).
// ---------------------------------------------------------------------------------------------
export function uuidv7(): string {
  const bytes = randomBytes(16);
  const ts = BigInt(Date.now());
  for (let i = 0; i < 6; i++) bytes[i] = Number((ts >> BigInt(8 * (5 - i))) & 0xffn);
  bytes[6] = (bytes[6] & 0x0f) | 0x70;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const h = bytes.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

// ---------------------------------------------------------------------------------------------
// Dates
// ---------------------------------------------------------------------------------------------
export function safeTimezone(tz: string | null | undefined): string {
  try {
    new Intl.DateTimeFormat('en', { timeZone: tz ?? 'UTC' });
    return tz ?? 'UTC';
  } catch {
    return 'UTC';
  }
}

/** Today's calendar date (YYYY-MM-DD) in a time zone. */
export function todayIn(tz: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
}

/** 'YYYY-MM-DD' -> Date at UTC midnight (how Prisma represents @db.Date). */
export function parseDateOnly(v: string): Date {
  const d = new Date(`${v}T00:00:00.000Z`);
  if (Number.isNaN(d.getTime())) throw new BadRequestException(`Invalid date: ${v}`);
  return d;
}

export function optionalDate(v: string | null | undefined): Date | null | undefined {
  if (v === undefined) return undefined;
  if (v === null) return null;
  return parseDateOnly(v);
}

export function formatDateOnly(d: Date | null | undefined): string | null {
  return d ? d.toISOString().slice(0, 10) : null;
}

// ---------------------------------------------------------------------------------------------
// Tenant settings (stored in tenants.settings JSON, with safe defaults)
// ---------------------------------------------------------------------------------------------
export interface TenantSettings {
  /** Batches with fewer days left than this cannot be sold (0 = sell until the expiry date). */
  minDaysToExpiryForSale: number;
  /** Batches expiring within this many days are flagged as "expiring soon". */
  expiryWarningDays: number;
  /** Refunds at or above this amount need refund:approve. */
  refundApprovalThreshold: number;
  /** Round invoice totals to this step (0 = no rounding), e.g. 0.05 or 1. */
  cashRoundingStep: number;
  /** Require an open register shift to complete a sale. */
  requireOpenShiftForSale: boolean;
  /** Allow selling products that require a prescription without linking one (pharmacist override). */
  allowRxWithoutRecord: boolean;
  lowStockAlerts: boolean;
  expiryAlerts: boolean;
}

export const DEFAULT_TENANT_SETTINGS: TenantSettings = {
  minDaysToExpiryForSale: 0,
  expiryWarningDays: 30,
  refundApprovalThreshold: 5000,
  cashRoundingStep: 0,
  requireOpenShiftForSale: true,
  allowRxWithoutRecord: false,
  lowStockAlerts: true,
  expiryAlerts: true,
};

export function readTenantSettings(raw: unknown): TenantSettings {
  const s = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const num = (k: keyof TenantSettings, min: number, max: number) => {
    const v = Number(s[k]);
    return Number.isFinite(v) && v >= min && v <= max ? v : (DEFAULT_TENANT_SETTINGS[k] as number);
  };
  const bool = (k: keyof TenantSettings) => (typeof s[k] === 'boolean' ? (s[k] as boolean) : (DEFAULT_TENANT_SETTINGS[k] as boolean));
  return {
    minDaysToExpiryForSale: num('minDaysToExpiryForSale', 0, 3650),
    expiryWarningDays: num('expiryWarningDays', 1, 3650),
    refundApprovalThreshold: num('refundApprovalThreshold', 0, 1e12),
    cashRoundingStep: num('cashRoundingStep', 0, 1000),
    requireOpenShiftForSale: bool('requireOpenShiftForSale'),
    allowRxWithoutRecord: bool('allowRxWithoutRecord'),
    lowStockAlerts: bool('lowStockAlerts'),
    expiryAlerts: bool('expiryAlerts'),
  };
}

export interface TenantInfo {
  id: string;
  name: string;
  currencyCode: string;
  timezone: string;
  settings: TenantSettings;
}

@Injectable()
export class TenantInfoService {
  /** Reads the current tenant (RLS limits the query to it). */
  async get(tx: Prisma.TransactionClient): Promise<TenantInfo> {
    const t = await tx.tenant.findFirstOrThrow({ select: { id: true, name: true, currencyCode: true, timezone: true, settings: true } });
    return { id: t.id, name: t.name, currencyCode: t.currencyCode, timezone: safeTimezone(t.timezone), settings: readTenantSettings(t.settings) };
  }
}

// ---------------------------------------------------------------------------------------------
// Gapless document numbers (invoice, GRN, adjustment, ...). The sequence row stays locked until the
// surrounding transaction commits, so numbers are never skipped or reused.
// ---------------------------------------------------------------------------------------------
export type DocType =
  | 'SALE' | 'SALES_RETURN' | 'PURCHASE' | 'PURCHASE_ORDER' | 'PURCHASE_RETURN' | 'ADJUSTMENT' | 'TRANSFER' | 'CUSTOMER'
  | 'PAYMENT' | 'PRODUCT' | 'EXPENSE';

@Injectable()
export class SequenceService {
  /** Returns e.g. INV-2026-000123, or SKU-000123 when `yearless`. */
  async next(
    tx: Prisma.TransactionClient,
    opts: { tenantId: string; docType: DocType; scopeKey: string; prefix: string; year?: number; pad?: number; yearless?: boolean },
  ): Promise<string> {
    const year = opts.yearless ? 0 : (opts.year ?? new Date().getUTCFullYear());
    const rows = await tx.$queryRaw<{ value: number }[]>`
      INSERT INTO document_sequences (id, tenant_id, doc_type, scope_key, year, prefix, next_value, updated_at)
      VALUES (${uuidv7()}::uuid, ${opts.tenantId}::uuid, ${opts.docType}, ${opts.scopeKey}, ${year}, ${opts.prefix}, 2, now())
      ON CONFLICT (tenant_id, doc_type, scope_key, year)
      DO UPDATE SET next_value = document_sequences.next_value + 1, updated_at = now()
      RETURNING (next_value - 1)::int AS value`;
    const n = rows[0]?.value;
    if (!n) throw new Error('sequence: no value returned');
    const num = String(n).padStart(opts.pad ?? 6, '0');
    return opts.yearless ? `${opts.prefix}-${num}` : `${opts.prefix}-${year}-${num}`;
  }
}

@Global()
@Module({ providers: [SequenceService, TenantInfoService], exports: [SequenceService, TenantInfoService] })
export class CoreModule {}
