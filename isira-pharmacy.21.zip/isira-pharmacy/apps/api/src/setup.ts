import { INestApplication, VersioningType } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { patchNestJsSwagger } from 'nestjs-zod';
import type { Env } from './config/env';

/** Shared by main.ts and the e2e tests so both run the exact same configuration. */
export function configureApp(app: INestApplication, env: Env): void {
  app.use(helmet({ contentSecurityPolicy: false })); // JSON API; the web app sets its own CSP
  app.use(cookieParser());
  app.enableCors({
    origin: env.WEB_ORIGIN,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'X-Branch-Id', 'X-Kynex-Csrf', 'X-Request-Id'],
    exposedHeaders: ['X-Request-Id'],
  });
  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });
  app.enableShutdownHooks();

  if (env.SWAGGER_ENABLED) {
    patchNestJsSwagger();
    const config = new DocumentBuilder()
      .setTitle(`${env.APP_NAME} API`)
      .setDescription('Multi-tenant pharmacy management API. Authenticate with POST /v1/auth/login (session cookie). Send X-Kynex-Csrf: 1 on writes and X-Branch-Id on branch-scoped routes.')
      .setVersion('1.0')
      .addCookieAuth(env.COOKIE_NAME)
      .build();
    SwaggerModule.setup('docs', app, SwaggerModule.createDocument(app, config));
  }
}
