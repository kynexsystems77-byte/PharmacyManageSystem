// Load test: cashiers searching products and ringing up sales.
//   k6 run -e BASE_URL=http://localhost:3000 -e EMAIL=cashier@demo.local -e PASSWORD=ChangeMe123! tools/load/k6-pos.js
// Run against a staging copy, never production: it creates real sales and moves stock.
// The API rate-limits each client IP to 300 requests/minute; raise it or spread load across IPs for bigger runs.
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = __ENV.BASE_URL || 'http://localhost:3000';
const API = `${BASE}/api`;

export const options = {
  scenarios: {
    cashiers: { executor: 'ramping-vus', startVUs: 1, stages: [{ duration: '30s', target: 10 }, { duration: '2m', target: 10 }, { duration: '20s', target: 0 }] },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    'http_req_duration{kind:search}': ['p(95)<300'],
    'http_req_duration{kind:sale}': ['p(95)<800'],
  },
};

const json = { 'Content-Type': 'application/json', 'X-Kynex-Csrf': '1' };
const key = () => `${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`.padEnd(32, '0').slice(0, 32);

export function setup() {
  const res = http.post(`${API}/auth/login`, JSON.stringify({ email: __ENV.EMAIL || 'cashier@demo.local', password: __ENV.PASSWORD || 'ChangeMe123!' }), { headers: json });
  check(res, { 'logged in': (r) => r.status === 200 && !r.json('mfaRequired') });
  const branchId = res.json('branches.0.id');
  const cookie = res.cookies.kx_session[0].value;
  const h = { ...json, 'X-Branch-Id': branchId, Cookie: `kx_session=${cookie}` };
  const regs = http.get(`${API}/registers`, { headers: h }).json();
  const mine = http.get(`${API}/registers/my-shift`, { headers: h }).json('current');
  if (!mine && regs.length) http.post(`${API}/registers/${regs[0].id}/open`, JSON.stringify({ openingBalance: 0 }), { headers: h });
  return { h };
}

const TERMS = ['para', 'amox', 'vit', 'ome', 'cet', 'ibu'];

export default function ({ h }) {
  const term = TERMS[Math.floor(Math.random() * TERMS.length)];
  const found = http.get(`${API}/products?search=${term}&withStock=true&pageSize=10`, { headers: h, tags: { kind: 'search' } });
  check(found, { 'search ok': (r) => r.status === 200 });
  const items = (found.json('data') || []).filter((p) => Number(p.stock) > 0 && p.availableInBranch);
  if (items.length) {
    const p = items[0];
    const sale = http.post(`${API}/sales`, JSON.stringify({ idempotencyKey: key(), items: [{ productId: p.id, quantity: 1 }], payments: [{ method: 'CARD', amount: Number(p.branchSellingPrice ?? p.sellingPrice) }] }), { headers: h, tags: { kind: 'sale' } });
    check(sale, { 'sale created or rejected cleanly': (r) => r.status === 201 || r.status === 400 || r.status === 409 || r.status === 422 });
  }
  sleep(1 + Math.random() * 2);
}
