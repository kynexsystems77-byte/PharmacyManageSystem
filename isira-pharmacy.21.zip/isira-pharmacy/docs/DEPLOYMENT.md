# Deployment and operations

## Single server (Docker Compose)

A server with 2 vCPU and 4 GB RAM runs one pharmacy group with several branches comfortably.

1. Install Docker Engine and the compose plugin. Open ports 80 and 443 only.
2. Copy the project to the server, then run `cp .env.production.example .env.production` and fill in every `CHANGE` value.
3. Choose how HTTPS is handled:
   - **Caddy:** point the DNS `A` record at the server. Set `DOMAIN`, `WEB_ORIGIN=https://<domain>` and `TRUST_PROXY=2`. Then run:
     `docker compose -f docker-compose.prod.yml --env-file .env.production --profile tls up -d --build`
   - **Your own load balancer or proxy:** leave out the `tls` profile and send traffic to `WEB_PORT` (3000).
4. Create the first pharmacy with the `tenant:create` command in the README, then sign in as its owner.
5. Turn on two-factor authentication for the owner (top bar → your name → Account).

### Plain-HTTP LAN install (single shop, no internet exposure)

Set `WEB_ORIGIN=http://<server-ip>:3000` and leave out the `tls` profile. With `COOKIE_SECURE=auto`, cookies are not marked Secure, so login works over HTTP. Don't expose this setup to the internet.

## Upgrades

```bash
git pull                                   # or copy the new release
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
```

The `migrate` service applies new migrations and re-applies `security.sql` before `api` and `worker` start. If it fails, `docker compose logs migrate` explains why, and the old containers keep running.

## Backups

Database: run a nightly logical dump as the superuser and copy it off the server. Example cron entry:

```bash
0 2 * * * cd /opt/kynex && docker compose -f docker-compose.prod.yml exec -T postgres \
  pg_dump -U postgres -Fc kynex_pharmacy > /backups/kynex-$(date +\%F).dump && find /backups -mtime +30 -delete
```

To restore into an empty database:

```bash
docker compose -f docker-compose.prod.yml exec -T postgres pg_restore -U postgres -d kynex_pharmacy --clean --if-exists < kynex-2026-01-01.dump
docker compose -f docker-compose.prod.yml run --rm migrate      # re-applies grants/RLS
```

Uploaded files are in the `storage` volume, or in your S3 bucket if `S3_*` is set. Back them up with the database.

Redis holds only queues and rate-limit counters, so losing it does not lose business data. Events still in the outbox are retried from PostgreSQL.

## Monitoring

| Signal | How |
|---|---|
| API health | `GET /health`. Docker health checks restart unhealthy containers. |
| Logs | `docker compose logs -f api worker`. Every API error carries a `requestId`, which also appears in the error response shown to the user. |
| Worker | The notification bell gets low-stock and expiry alerts once per `ALERT_SCAN_MINUTES`. |
| Load | Run `tools/load/k6-pos.js` against a staging copy before large rollouts. |

## Scaling out

- **API:** stateless, so you can run several replicas behind the load balancer. Set `REDIS_URL` so rate limits are shared. Sessions live in PostgreSQL.
- **Worker:** run more than one if needed. BullMQ hands each job to only one worker, and the outbox claims events with row locks.
- **Database:** use a managed PostgreSQL 16 with point-in-time recovery for larger installs. Keep the two-role setup: `DIRECT_URL` as the owner and `DATABASE_URL` as the app role.
- **Uploads:** when you run more than one API host, point `S3_*` at S3, MinIO or R2 instead of the local volume.

## Building images without Compose

```bash
docker build --target api -t registry.example.com/kynex-api:1.0.0 .
docker build --target web -t registry.example.com/kynex-web:1.0.0 \
  --build-arg API_URL=http://kynex-api:4000 --build-arg WEB_ORIGIN=https://pharmacy.example.com .
```

The API image runs three things:

| Run | Command |
|---|---|
| API | Default command |
| Worker | `node dist/worker/main.js` |
| Migrations | `kynex-migrate` (one-shot, before each rollout) |
