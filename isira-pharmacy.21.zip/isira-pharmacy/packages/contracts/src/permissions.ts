/**
 * Permission catalogue: the single source of truth for authorization keys.
 * The API (guards, @RequirePermissions) and the web app (UI hiding only) both import from here.
 * Keys are `resource:action[:qualifier]`. The server always re-checks them; the UI never decides.
 */
export const PERMISSIONS = [
  // Administration
  { key: 'tenant:settings:manage', module: 'Administration', description: 'Change pharmacy-wide settings' },
  { key: 'branch:read', module: 'Administration', description: 'View branches' },
  { key: 'branch:manage', module: 'Administration', description: 'Create and edit branches, locations and registers' },
  { key: 'user:read', module: 'Administration', description: 'View users' },
  { key: 'user:manage', module: 'Administration', description: 'Create, edit and disable users' },
  { key: 'role:read', module: 'Administration', description: 'View roles and permissions' },
  { key: 'role:manage', module: 'Administration', description: 'Create and edit roles and permissions' },
  { key: 'audit:read', module: 'Administration', description: 'View the audit log' },
  // Catalogue
  { key: 'product:read', module: 'Catalogue', description: 'View medicines and products' },
  { key: 'product:create', module: 'Catalogue', description: 'Create medicines and products' },
  { key: 'product:update', module: 'Catalogue', description: 'Edit medicines and products' },
  { key: 'product:deactivate', module: 'Catalogue', description: 'Deactivate medicines and products' },
  { key: 'product:price:update', module: 'Catalogue', description: 'Change purchase and selling prices' },
  { key: 'category:manage', module: 'Catalogue', description: 'Manage categories and sub-categories' },
  { key: 'supplier:read', module: 'Catalogue', description: 'View suppliers' },
  { key: 'supplier:manage', module: 'Catalogue', description: 'Create and edit suppliers' },
  // Inventory
  { key: 'inventory:read', module: 'Inventory', description: 'View stock and the stock ledger' },
  { key: 'inventory:adjust', module: 'Inventory', description: 'Post stock adjustments' },
  { key: 'inventory:transfer', module: 'Inventory', description: 'Create and receive stock transfers' },
  { key: 'inventory:writeoff', module: 'Inventory', description: 'Write off damaged or expired stock' },
  { key: 'batch:read', module: 'Inventory', description: 'View batches and expiry dates' },
  // Purchasing
  { key: 'purchase:read', module: 'Purchasing', description: 'View purchases' },
  { key: 'purchase:create', module: 'Purchasing', description: 'Create purchase invoices' },
  { key: 'purchase:receive', module: 'Purchasing', description: 'Receive goods and create batches' },
  { key: 'purchase:return', module: 'Purchasing', description: 'Return goods to suppliers' },
  { key: 'purchase_order:manage', module: 'Purchasing', description: 'Create and manage purchase orders' },
  { key: 'supplier:payment', module: 'Purchasing', description: 'Record payments to suppliers' },
  // Sales
  { key: 'sale:read', module: 'Sales', description: 'View invoices' },
  { key: 'sale:create', module: 'Sales', description: 'Create sales at the POS' },
  { key: 'sale:discount', module: 'Sales', description: 'Give discounts up to the role limit' },
  { key: 'sale:discount:override', module: 'Sales', description: 'Give discounts above the role limit' },
  { key: 'sale:batch:override', module: 'Sales', description: 'Choose a batch other than the FEFO suggestion' },
  { key: 'sale:void', module: 'Sales', description: 'Void a bill' },
  { key: 'sale:return', module: 'Sales', description: 'Process customer returns' },
  { key: 'refund:approve', module: 'Sales', description: 'Approve refunds above the threshold' },
  // Customers
  { key: 'customer:read', module: 'Customers', description: 'View customers' },
  { key: 'customer:manage', module: 'Customers', description: 'Create and edit customers' },
  { key: 'customer:credit:manage', module: 'Customers', description: 'Manage customer credit and payments' },
  // Prescriptions
  { key: 'prescription:read', module: 'Prescriptions', description: 'View prescriptions' },
  { key: 'prescription:manage', module: 'Prescriptions', description: 'Create and edit prescriptions' },
  // Finance
  { key: 'register:open', module: 'Finance', description: 'Open a cash register shift' },
  { key: 'register:close', module: 'Finance', description: 'Close a cash register shift' },
  { key: 'register:read', module: 'Finance', description: 'View cash registers and shifts' },
  { key: 'cash:movement', module: 'Finance', description: 'Record cash withdrawals and deposits' },
  { key: 'expense:read', module: 'Finance', description: 'View expenses' },
  { key: 'expense:manage', module: 'Finance', description: 'Record and edit expenses' },
  { key: 'finance:read', module: 'Finance', description: 'View financial summaries' },
  { key: 'finance:reconcile', module: 'Finance', description: 'Reconcile payments and registers' },
  // Reports
  { key: 'report:sales:view', module: 'Reports', description: 'View sales reports' },
  { key: 'report:financial:view', module: 'Reports', description: 'View profit, tax and payable reports' },
  { key: 'report:inventory:view', module: 'Reports', description: 'View inventory and expiry reports' },
  { key: 'report:export', module: 'Reports', description: 'Export reports to CSV, Excel and PDF' },
  // Notifications
  { key: 'notification:manage', module: 'Notifications', description: 'Configure notification rules' },
] as const;

export type PermissionKey = (typeof PERMISSIONS)[number]['key'];
export const PERMISSION_KEYS: readonly PermissionKey[] = PERMISSIONS.map((p) => p.key);

export type SystemRoleKey = 'OWNER' | 'MANAGER' | 'PHARMACIST' | 'CASHIER' | 'INVENTORY_MANAGER' | 'ACCOUNTANT';

export interface SystemRoleDefinition {
  name: string;
  description: string;
  /** Highest discount (%) this role may give without `sale:discount:override`. */
  maxDiscountPercent: number;
  permissions: readonly PermissionKey[];
}

const without = (...excluded: PermissionKey[]): PermissionKey[] => PERMISSION_KEYS.filter((k) => !excluded.includes(k));

export const SYSTEM_ROLES: Record<SystemRoleKey, SystemRoleDefinition> = {
  OWNER: {
    name: 'Owner',
    description: 'Full access to the pharmacy company',
    maxDiscountPercent: 100,
    permissions: [...PERMISSION_KEYS],
  },
  MANAGER: {
    name: 'Manager',
    description: 'Runs a branch day to day',
    maxDiscountPercent: 25,
    permissions: without('tenant:settings:manage', 'role:manage'),
  },
  PHARMACIST: {
    name: 'Pharmacist',
    description: 'Dispenses medicines and manages stock and prescriptions',
    maxDiscountPercent: 10,
    permissions: [
      'product:read', 'product:create', 'product:update', 'supplier:read',
      'inventory:read', 'inventory:adjust', 'batch:read',
      'purchase:read', 'purchase:create', 'purchase:receive',
      'sale:read', 'sale:create', 'sale:discount', 'sale:batch:override', 'sale:return',
      'customer:read', 'customer:manage', 'prescription:read', 'prescription:manage',
      'register:open', 'register:close', 'register:read',
      'report:sales:view', 'report:inventory:view',
    ],
  },
  CASHIER: {
    name: 'Cashier',
    description: 'Operates the POS',
    maxDiscountPercent: 5,
    permissions: [
      'product:read', 'inventory:read', 'batch:read',
      'sale:read', 'sale:create', 'sale:discount',
      'customer:read', 'customer:manage', 'prescription:read',
      'register:open', 'register:close', 'register:read',
    ],
  },
  INVENTORY_MANAGER: {
    name: 'Inventory Manager',
    description: 'Owns stock, purchasing and suppliers',
    maxDiscountPercent: 0,
    permissions: [
      'product:read', 'product:create', 'product:update', 'category:manage', 'supplier:read', 'supplier:manage',
      'inventory:read', 'inventory:adjust', 'inventory:transfer', 'inventory:writeoff', 'batch:read',
      'purchase:read', 'purchase:create', 'purchase:receive', 'purchase:return', 'purchase_order:manage',
      'report:inventory:view', 'report:export',
    ],
  },
  ACCOUNTANT: {
    name: 'Accountant',
    description: 'Finance, payables and reporting (read-mostly)',
    maxDiscountPercent: 0,
    permissions: [
      'finance:read', 'finance:reconcile', 'expense:read', 'expense:manage', 'register:read',
      'purchase:read', 'supplier:payment', 'sale:read', 'customer:read', 'customer:credit:manage', 'supplier:read',
      'report:sales:view', 'report:financial:view', 'report:inventory:view', 'report:export', 'audit:read',
    ],
  },
};
