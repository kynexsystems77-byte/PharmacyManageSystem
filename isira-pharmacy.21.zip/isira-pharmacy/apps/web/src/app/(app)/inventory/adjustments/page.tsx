'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ADJUSTMENT_REASONS } from '@kynex/contracts';
import { DataTable, PageHeader, Pagination, SearchBox, Select } from '@/components/kit';
import { Button, Card } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { dateTime, titleCase } from '@/lib/format';
import { qs, useBranchQuery, useDebounced, usePaging, type Paged } from '@/lib/hooks';
import type { Adjustment } from '@/lib/types';

export default function AdjustmentsPage() {
  const router = useRouter();
  const { can } = useAuth();
  const [search, setSearch] = useState('');
  const [reason, setReason] = useState('');
  const s = useDebounced(search);
  const { page, setPage } = usePaging([s, reason]);
  const { data, isLoading, isFetching } = useBranchQuery<Paged<Adjustment>>(`/inventory/adjustments${qs({ page, pageSize: 25, search: s, reason })}`, { keepPrevious: true });
  return (
    <div>
      <PageHeader
        title="Adjustments & write-offs"
        actions={
          <>
            {can('inventory:writeoff') && <Link href="/inventory/adjustments/new?mode=writeoff"><Button variant="outline">Write off stock</Button></Link>}
            {can('inventory:adjust') && <Link href="/inventory/adjustments/new"><Button>New adjustment</Button></Link>}
          </>
        }
      />
      <Card>
        <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-[1fr_220px]">
          <SearchBox value={search} onChange={setSearch} placeholder="Document number" />
          <Select value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason">
            <option value="">All reasons</option>
            {ADJUSTMENT_REASONS.map((r) => <option key={r} value={r}>{titleCase(r)}</option>)}
          </Select>
        </div>
        <DataTable
          rows={data?.data}
          loading={isLoading || isFetching}
          rowKey={(a) => a.id}
          onRowClick={(a) => router.push(`/inventory/adjustments/${a.id}`)}
          columns={[
            { key: 'n', header: 'Number', cell: (a) => <span className="font-mono text-xs">{a.number}</span> },
            { key: 'd', header: 'Date', cell: (a) => dateTime(a.postedAt ?? a.createdAt) },
            { key: 'r', header: 'Reason', cell: (a) => titleCase(a.reason) },
            { key: 'l', header: 'Location', cell: (a) => a.location.name },
            { key: 'i', header: 'Lines', align: 'right', cell: (a) => a.stockAdjustmentItems.length },
            { key: 'u', header: 'By', cell: (a) => a.createdBy.fullName },
            { key: 'note', header: 'Note', cell: (a) => <span className="line-clamp-1 text-fg-muted">{a.note ?? '-'}</span> },
          ]}
        />
        {data && <Pagination page={data.meta.page} totalPages={data.meta.totalPages} total={data.meta.total} onPage={setPage} />}
      </Card>
    </div>
  );
}
