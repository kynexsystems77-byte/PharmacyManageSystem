import { Inject, Injectable } from '@nestjs/common';
import { ENV, type Env } from '../config/env';
import { Mailer, type MailMessage } from '../jobs/mailer';
import { QueueService } from '../jobs/queue';

/**
 * Account emails. Delivered by the worker through the queue (retries, never blocks the request);
 * sent inline when no queue is available. In development without SMTP the link is written to the log.
 */
@Injectable()
export class MailService {
  constructor(@Inject(ENV) private readonly env: Env, private readonly queue: QueueService, private readonly mailer: Mailer) {}

  async sendPasswordReset(to: string, token: string): Promise<void> {
    const link = `${this.env.WEB_ORIGIN}/reset-password?token=${token}`;
    const minutes = this.env.PASSWORD_RESET_MINUTES;
    const message: MailMessage = {
      to,
      subject: `Reset your ${this.env.APP_NAME} password`,
      text: `Someone asked to reset the password for this account.\n\nOpen this link within ${minutes} minutes to choose a new password:\n${link}\n\nIf it was not you, ignore this email; your password stays the same.`,
      html: `<p>Someone asked to reset the password for this account.</p><p><a href="${link}">Choose a new password</a> (the link works for ${minutes} minutes).</p><p>If it was not you, ignore this email; your password stays the same.</p>`,
    };
    if (await this.queue.add('mail', { ...message }, { attempts: 5 })) return;
    await this.mailer.send(message);
  }
}
