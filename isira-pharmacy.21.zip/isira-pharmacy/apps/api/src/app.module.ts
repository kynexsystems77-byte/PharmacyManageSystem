import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule, type ThrottlerStorage } from '@nestjs/throttler';
import { THROTTLER_STORE, ThrottlerStoreModule } from './common/throttler-storage';
import { ZodValidationPipe } from 'nestjs-zod';
import { AuditController } from './audit/audit.controller';
import { AuditModule } from './audit/audit.service';
import { AuthModule } from './auth/auth.module';
import { BranchesModule } from './branches/branches.module';
import { CatalogModule } from './catalog/catalog.module';
import { CoreModule } from './common/core';
import { StorageModule } from './common/storage';
import { CustomersModule } from './customers/customers.module';
import { AllExceptionsFilter } from './common/all-exceptions.filter';
import { AuthGuard, BranchGuard, CsrfGuard, PermissionsGuard } from './common/guards';
import { RequestContextMiddleware } from './common/request-context';
import { TenantTransactionInterceptor } from './common/tenant-transaction.interceptor';
import { ConfigModule } from './config/env';
import { DashboardModule } from './dashboard/dashboard.module';
import { FinanceModule } from './finance/finance.module';
import { HealthModule } from './health/health.module';
import { InventoryModule } from './inventory/inventory.module';
import { JobsModule } from './jobs/queue';
import { MailerModule } from './jobs/mailer';
import { NotificationsModule } from './notifications/notifications.module';
import { PrismaModule } from './prisma/prisma.service';
import { PrescriptionsModule } from './prescriptions/prescriptions.module';
import { PurchasingModule } from './purchasing/purchasing.module';
import { RegistersModule } from './registers/registers.module';
import { ReportsModule } from './reports/reports.module';
import { SalesModule } from './sales/sales.module';
import { RolesModule } from './roles/roles.module';
import { TenantsModule } from './tenants/tenants.module';
import { UsersModule } from './users/users.module';

@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    AuditModule,
    CoreModule,
    StorageModule,
    JobsModule,
    MailerModule,
    // Generous global limit; sensitive routes (login, password reset) set tighter limits. Redis-backed storage arrives in Phase 12.
    ThrottlerModule.forRootAsync({
      imports: [ThrottlerStoreModule],
      inject: [THROTTLER_STORE],
      useFactory: (storage: ThrottlerStorage) => ({
        throttlers: [{ ttl: 60_000, limit: 300 }],
        skipIf: () => process.env.NODE_ENV === 'test',
        storage,
      }),
    }),
    AuthModule,
    TenantsModule,
    BranchesModule,
    UsersModule,
    RolesModule,
    DashboardModule,
    CatalogModule,
    InventoryModule,
    PurchasingModule,
    RegistersModule,
    SalesModule,
    CustomersModule,
    PrescriptionsModule,
    FinanceModule,
    ReportsModule,
    NotificationsModule,
    HealthModule,
  ],
  controllers: [AuditController],
  providers: [
    { provide: APP_PIPE, useClass: ZodValidationPipe },
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    { provide: APP_INTERCEPTOR, useClass: TenantTransactionInterceptor },
    // guard order matters: throttle -> csrf -> authenticate -> branch -> permissions
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: CsrfGuard },
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_GUARD, useClass: BranchGuard },
    { provide: APP_GUARD, useClass: PermissionsGuard },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(RequestContextMiddleware).forRoutes('*');
  }
}
