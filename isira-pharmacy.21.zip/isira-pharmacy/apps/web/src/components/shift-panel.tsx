'use client';

import { Banknote, Lock, LogIn } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { dateTime, money, num, titleCase } from '@/lib/format';
import { errorMessage, useApiMutation, useBranchQuery } from '@/lib/hooks';
import type { Register, ShiftSummary } from '@/lib/types';
import { Modal, Select, useToast } from './kit';
import { Alert, Button, Card, Field, Input } from './ui';

export function useMyShift() {
  return useBranchQuery<{ current: ShiftSummary | null }>('/registers/my-shift', { refetchInterval: 60_000 });
}

/** Shown on the POS when the cashier has no open shift. */
export function OpenShiftCard() {
  const { can } = useAuth();
  const toast = useToast();
  const regs = useBranchQuery<Register[]>(can('register:read') ? '/registers' : null);
  const [registerId, setRegisterId] = useState('');
  const [opening, setOpening] = useState('');
  const free = (regs.data ?? []).filter((r) => r.isActive && r.registerSessions.length === 0);
  const chosen = registerId || free[0]?.id || '';
  const open = useApiMutation<object>('POST', () => `/registers/${chosen}/open`, { onSuccess: () => toast.success('Shift opened. Ready to sell.') });
  return (
    <Card className="mx-auto max-w-md p-6">
      <div className="mb-4 flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand"><LogIn size={20} /></span>
        <div><h2 className="font-semibold">Open your shift</h2><p className="text-sm text-fg-muted">Count the cash in the drawer to start selling.</p></div>
      </div>
      {!can('register:open') ? (
        <Alert>Your role cannot open a register shift in this branch.</Alert>
      ) : (
        <div className="space-y-3">
          {open.error && <Alert>{errorMessage(open.error)}</Alert>}
          <Field label="Register">
            <Select value={chosen} onChange={(e) => setRegisterId(e.target.value)}>
              {free.length === 0 && <option value="">No free register</option>}
              {free.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </Select>
          </Field>
          {(regs.data ?? []).filter((r) => r.registerSessions.length > 0).map((r) => (
            <p key={r.id} className="text-xs text-fg-muted">{r.name} is in use by {r.registerSessions[0].openedBy.fullName}</p>
          ))}
          <Field label="Opening cash (float)"><Input type="number" min="0" step="0.01" value={opening} onChange={(e) => setOpening(e.target.value)} placeholder="0.00" autoFocus /></Field>
          <Button className="w-full" disabled={!chosen} loading={open.isPending} onClick={() => open.mutate({ openingBalance: Number(opening || 0) })}>Open shift</Button>
        </div>
      )}
    </Card>
  );
}

/** X/Z report with cash movements and the close-out count. */
export function ShiftModal({ summary, onClose }: { summary: ShiftSummary; onClose: () => void }) {
  const { can, profile } = useAuth();
  const toast = useToast();
  const cur = profile.tenant.currencyCode;
  const fmt = (v: string | number) => money(num(v), cur);
  const [mode, setMode] = useState<'view' | 'cash' | 'close'>('view');
  const [cashType, setCashType] = useState('WITHDRAWAL');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [counted, setCounted] = useState('');
  const id = summary.shift.id;
  const cash = useApiMutation<object>('POST', `/shifts/${id}/cash`, { onSuccess: () => { toast.success('Cash movement recorded'); setMode('view'); setAmount(''); setNote(''); } });
  const close = useApiMutation<object, ShiftSummary>('POST', `/shifts/${id}/close`, {
    onSuccess: (s) => { toast.success(`Shift closed. Variance ${fmt(s.shift.variance ?? 0)}.`); onClose(); },
  });
  const variance = counted === '' ? null : num(counted) - num(summary.expectedCash);
  const open = summary.shift.status === 'OPEN';
  return (
    <Modal open onClose={onClose} size="lg" title={`${summary.shift.register.name} · ${open ? 'X-report (shift open)' : 'Z-report'}`}
      footer={
        mode === 'view' ? (
          <>
            <Button variant="outline" onClick={() => window.print()}>Print</Button>
            {open && can('cash:movement') && <Button variant="outline" onClick={() => setMode('cash')}><Banknote size={16} /> Cash in / out</Button>}
            {open && can('register:close') && <Button onClick={() => setMode('close')}><Lock size={16} /> Close shift</Button>}
          </>
        ) : mode === 'cash' ? (
          <><Button variant="outline" onClick={() => setMode('view')}>Back</Button><Button loading={cash.isPending} disabled={!(num(amount) > 0) || note.trim().length < 2} onClick={() => cash.mutate({ type: cashType, amount: num(amount), note: note.trim() })}>Record</Button></>
        ) : (
          <><Button variant="outline" onClick={() => setMode('view')}>Back</Button><Button loading={close.isPending} disabled={counted === ''} onClick={() => close.mutate({ countedClosingBalance: num(counted) })}>Close shift</Button></>
        )
      }>
      <div className="space-y-4 text-sm">
        <p className="text-fg-muted">Opened {dateTime(summary.shift.openedAt)} by {summary.shift.openedBy.fullName}{summary.shift.closedAt ? ` · closed ${dateTime(summary.shift.closedAt)}` : ''}</p>
        <div className="grid gap-3 sm:grid-cols-3">
          <Fig label="Sales" value={fmt(summary.sales.total)} hint={`${summary.sales.count} invoices${summary.sales.voided ? ` · ${summary.sales.voided} voided` : ''}`} />
          <Fig label="Returns" value={fmt(summary.returns.total)} hint={`${summary.returns.count} returns`} />
          <Fig label="Expected cash" value={fmt(summary.expectedCash)} hint={`Opening ${fmt(summary.shift.openingBalance)}`} strong />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <p className="mb-1 text-xs font-medium uppercase tracking-wide text-fg-muted">Payments</p>
            <ul className="divide-y divide-line rounded-lg border border-line">
              {summary.payments.length === 0 && <li className="px-3 py-2 text-fg-muted">None yet</li>}
              {summary.payments.map((p) => (
                <li key={`${p.kind}-${p.method}`} className="flex justify-between px-3 py-1.5"><span>{titleCase(p.kind === 'SALE_PAYMENT' ? p.method : `${p.kind} ${p.method}`)} <span className="text-fg-muted">×{p.count}</span></span><span className="tabular">{fmt(p.amount)}</span></li>
              ))}
            </ul>
          </div>
          <div>
            <p className="mb-1 text-xs font-medium uppercase tracking-wide text-fg-muted">Cash drawer</p>
            <ul className="divide-y divide-line rounded-lg border border-line">
              <li className="flex justify-between px-3 py-1.5"><span>Opening float</span><span className="tabular">{fmt(summary.shift.openingBalance)}</span></li>
              {summary.cash.map((c) => (
                <li key={c.type} className="flex justify-between px-3 py-1.5"><span>{titleCase(c.type)} <span className="text-fg-muted">×{c.count}</span></span><span className={`tabular ${num(c.amount) < 0 ? 'text-danger' : ''}`}>{fmt(c.amount)}</span></li>
              ))}
              <li className="flex justify-between px-3 py-1.5 font-semibold"><span>Expected in drawer</span><span className="tabular">{fmt(summary.expectedCash)}</span></li>
              {summary.shift.countedClosingBalance !== null && (
                <>
                  <li className="flex justify-between px-3 py-1.5"><span>Counted</span><span className="tabular">{fmt(summary.shift.countedClosingBalance)}</span></li>
                  <li className="flex justify-between px-3 py-1.5"><span>Variance</span><span className={`tabular ${num(summary.shift.variance) < 0 ? 'text-danger' : num(summary.shift.variance) > 0 ? 'text-warning' : 'text-success'}`}>{fmt(summary.shift.variance ?? 0)}</span></li>
                </>
              )}
            </ul>
          </div>
        </div>
        {mode === 'cash' && (
          <div className="grid gap-3 rounded-lg border border-line p-3 sm:grid-cols-3">
            {cash.error && <div className="sm:col-span-3"><Alert>{errorMessage(cash.error)}</Alert></div>}
            <Field label="Type"><Select value={cashType} onChange={(e) => setCashType(e.target.value)}><option value="WITHDRAWAL">Cash out (withdrawal)</option><option value="DEPOSIT">Cash in (deposit)</option></Select></Field>
            <Field label="Amount"><Input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus /></Field>
            <Field label="Reason"><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Bank deposit, change float…" /></Field>
          </div>
        )}
        {mode === 'close' && (
          <div className="space-y-2 rounded-lg border border-line p-3">
            {close.error && <Alert>{errorMessage(close.error)}</Alert>}
            <Field label="Cash counted in the drawer"><Input type="number" min="0" step="0.01" value={counted} onChange={(e) => setCounted(e.target.value)} autoFocus /></Field>
            {variance !== null && (
              <p className={variance === 0 ? 'text-success' : variance < 0 ? 'text-danger' : 'text-warning'}>
                {variance === 0 ? 'Drawer balances exactly.' : variance < 0 ? `Short by ${fmt(-variance)}` : `Over by ${fmt(variance)}`}
              </p>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}

function Fig({ label, value, hint, strong }: { label: string; value: string; hint?: string; strong?: boolean }) {
  return (
    <div className={`rounded-lg border p-3 ${strong ? 'border-brand/40 bg-brand/5' : 'border-line'}`}>
      <p className="text-xs font-medium uppercase tracking-wide text-fg-muted">{label}</p>
      <p className="tabular mt-0.5 text-lg font-semibold">{value}</p>
      {hint && <p className="text-xs text-fg-muted">{hint}</p>}
    </div>
  );
}
